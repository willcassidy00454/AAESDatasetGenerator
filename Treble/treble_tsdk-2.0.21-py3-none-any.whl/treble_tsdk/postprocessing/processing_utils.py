import numpy as np
from scipy import special as scipyspecial
from scipy.spatial.transform import Rotation


def compute_SH_indices(n_order: int) -> tuple[int, np.ndarray, np.ndarray, np.ndarray]:
    """
    Utility function to compute index arrays for spherical harmonics based on harmonics order

    :param int n_order: Spherical harmonics order
    :return tuple[int, np.ndarray, np.ndarray, np.ndarray]: Number of channels,
    utility vectors for order and degree per channel, reverse mask vector
    """
    n_channels = (n_order + 1) ** 2
    nvec = np.zeros(n_channels, dtype=int)
    mvec = np.zeros(n_channels, dtype=int)
    mask_reverse_m = np.zeros(n_channels, dtype=int)

    for nn in range(n_order + 1):
        mvec_tmp = np.arange(-nn, nn + 1, dtype=int)
        for jj, mm in enumerate(mvec_tmp):
            nchannel = nn**2 + jj
            nvec[nchannel] = nn
            mvec[nchannel] = mm
            mask_reverse_m[nchannel] = nn**2 + 2 * nn - jj

    return n_channels, nvec, mvec, mask_reverse_m


def sn3d_to_orthonormal(spatial_IR: np.ndarray, n_order: int) -> np.ndarray:
    """
    Change the normalization convention of the data from sn3d to orthonormal

    :param spatial_IR: Frequency domain IR
    :type spatial_IR: np.ndarray
    :param n_order: Ambisonics order
    :type n_order: int
    :return: SpatialIR with a different normalization convention
    :rtype: np.ndarray
    """
    n_channels, nvec, _, _ = compute_SH_indices(n_order=n_order)
    spatial_IR_scaled = np.zeros_like(spatial_IR)
    for i in range(n_channels):
        nn = nvec[i]
        spatial_IR_scaled[i, :] = spatial_IR[i, :] / (np.sqrt(4 * np.pi) / np.sqrt(2 * nn + 1))
    return spatial_IR_scaled


def convert_to_real(anm: np.ndarray, n_order: int) -> np.ndarray:
    """
    Converts a (complex) function encoded with the complex SH basis to the real basis

    :param anm: The complex spherical harmonics decomposition of the complex function
    :type anm: np.ndarray
    :param n_order: Highest spherical harmonics order
    :type n_order: int
    :return: The real spherical harmonics decomposition of the function
    :rtype: np.ndarray
    """
    _, _, mvec, _ = compute_SH_indices(n_order=n_order)
    (
        mask_negm,
        mask_posm,
        mask_negm_flip,
        mask_posm_flip,
    ) = compute_additional_SH_indices(n_order=n_order)
    anm_real = np.copy(anm).astype(complex)  # takes care of the m==0 cases

    anm_real[mask_negm, :] = (
        1j / np.sqrt(2) * ((anm[mask_posm_flip, :].T * (-1.0) ** mvec[mask_posm_flip]).T - anm[mask_negm, :])
    )

    anm_real[mask_posm, :] = (
        1 / np.sqrt(2) * ((anm[mask_posm, :].T * (-1.0) ** mvec[mask_posm]).T + anm[mask_negm_flip, :])
    )
    # transposes are used to allow for array broadcast

    return anm_real


def compute_additional_SH_indices(
    n_order: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Generates indices to allow change of Spherical Harmonics basis

    :param int n_order: Spherical harmonics order
    :return tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]: masking arrays for SH operations
    """

    mask_negm = np.array([], dtype=int)
    mask_posm = np.array([], dtype=int)
    mask_negm_flip = np.array([], dtype=int)
    mask_posm_flip = np.array([], dtype=int)

    for nn in range(1, n_order + 1):  # order 0 is not included
        # NOTE: ACN = nn.^2 + nn + (-nn:nn)
        base = nn**2 + nn
        mask_negm = np.append(mask_negm, base + np.arange(-nn, 0, dtype=int))
        mask_posm = np.append(mask_posm, base + np.arange(1, nn + 1, dtype=int))

        mask_negm_flip = np.append(mask_negm_flip, base + np.arange(-1, -(nn + 1), -1, dtype=int))
        mask_posm_flip = np.append(mask_posm_flip, base + np.arange(nn, 0, -1, dtype=int))

    return mask_negm, mask_posm, mask_negm_flip, mask_posm_flip


def _wigner_d(m, m_prime, n, beta):
    """Compute wigner d matrix used for rotation."""
    assert m.shape == m_prime.shape

    xi = np.ones(m.shape)
    idx = m < m_prime
    xi[idx] = float(-1) ** (m[idx] - m_prime[idx])

    mu = np.abs(m_prime - m)
    nu = np.abs(m_prime + m)
    s = n - (mu + nu) / 2

    coefficient = np.sqrt(
        scipyspecial.factorial(s)
        * scipyspecial.factorial(s + mu + nu)
        / (scipyspecial.factorial(s + mu) * scipyspecial.factorial(s + nu))
    )
    d = (
        xi
        * coefficient
        * np.sin(beta / 2) ** mu
        * np.cos(beta / 2) ** nu
        * scipyspecial.eval_jacobi(s, mu, nu, np.cos(beta))
    )

    return d


def rotate_matrix(fnm: np.ndarray, alpha: float, beta: float, gamma: float) -> np.ndarray:
    """
    Rotate matrix fnm (encoded with the COMPLEX spherical harmonics basis)
    based on the Euler angles rotation_angles = [alpha, beta, gamma].

    An initial counter-clockwise rotation of angle gamma is performed about the
    z-axis, followed by a counter-clockwise rotation by angle beta about the
    y-axis, and completed by a counter-clockwise rotation of angle alpha about
    the z-axis.

    :param np.ndarray fnm: Array to be rotated
    :param float alpha, beta, gamma: euler zyz rotation angles
    :return np.ndarray: Rotated input array
    """
    fnm = np.array(fnm)
    Nchannels = fnm.shape[0]
    Norder = int(np.sqrt(Nchannels)) - 1

    gnm = np.zeros(fnm.shape, dtype=complex)
    # D = np.zeros([Nchannels, Nchannels], dtype=complex)  # global block matrix

    for n in range(Norder + 1):
        mvec = np.arange(-n, n + 1, 1)
        m, m_prime = np.meshgrid(mvec, mvec)
        idx_start = np.sum(2 * np.arange(0, n, 1) + 1)
        idx_end = idx_start + 2 * n + 1
        idx = np.arange(idx_start, idx_end)

        # rotation matrix for order n
        Dn = np.exp(-1j * (m_prime * alpha + m * gamma)) * _wigner_d(m, m_prime, n, -beta)

        # apply rotation for given n
        gnm[idx, :] = np.matmul(Dn, fnm[idx, :])

        # store rotation matrix (this way no need to recompute it)
        # D[idx_start:idx_end, idx_start:idx_end] = Dn.copy()

    return gnm


def convert_rotation_angles(rotation_angles: np.ndarray) -> tuple[float, float, float]:
    """
    Convert azimuth, elevation and roll into zyz based rotation angles

    :param np.ndarray rotation_angles: azimuth, elevation, roll
    :return tuple[float, float, float]: zyz rotation angles
    """
    r = Rotation.from_euler("zyx", rotation_angles)
    alpha, beta, gamma = r.as_euler("zyz")
    return alpha, beta, gamma
