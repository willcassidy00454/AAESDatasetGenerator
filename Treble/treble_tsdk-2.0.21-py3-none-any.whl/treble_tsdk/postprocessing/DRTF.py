import importlib
from pathlib import Path
from typing import TYPE_CHECKING

import h5py
import matplotlib.pyplot as plt
import numpy as np
import sofar as sf
from scipy.interpolate import CubicSpline
from scipy.spatial import KDTree
import warnings


from ..core.device_obj import (
    DeviceDefinition,
    DeviceImpulseResponses,
    DeviceMicrophone,
    DeviceObj,
    DeviceSourceLocations,
)
from ..utility_classes import Rotation
from . import processing_utils

if TYPE_CHECKING:
    from ..results.device_ir import DeviceIR
    from ..results.spatial_ir import SpatialIR


def create_device_from_sofa_file(
    sofa_filepath: str | Path,
    device_name: str,
    max_ambisonics_order: int,
    device_description: str = None,
    reference_frequency: float | None = 100,
) -> DeviceDefinition:
    """
    Take a .sofa file and create a list of device microphones which can then
    be added to the project

    :param str | Path sofa_filepath: Path to sofa file
    :param str device_name: Name of the device
    :param int max_ambisonics_order: Highest ambisonics order to render devices for. Maximum allowed is 32
    :param Optional[str] device_description: Optional description of device, defaults to None
    :param Optional[float] reference_frequency: Reference frequency for the device.
    :return DeviceDefinition: A definition of the device contained in the sofa file
    """
    if not isinstance(sofa_filepath, Path):
        sofa_filepath = Path(sofa_filepath)

    sofa = sf.read_sofa(filename=sofa_filepath, verbose=False)

    n_mics = sofa.get_dimension("R")  # Number of microphones
    sampling_rate = sofa.Data_SamplingRate

    azimuth_degrees = sofa.SourcePosition[:, 0]
    elevation_degrees = sofa.SourcePosition[:, 1]

    source_locations = DeviceSourceLocations(azimuth_deg=azimuth_degrees, elevation_deg=elevation_degrees)
    device_microphones = []
    for mic in range(n_mics):
        impulse_responses = DeviceImpulseResponses(
            impulse_responses=np.squeeze(sofa.Data_IR[:, mic, :]),
            sampling_rate=sampling_rate,
        )
        device_microphones.append(
            DeviceMicrophone(
                source_locations=source_locations,
                recordings=impulse_responses,
                max_ambisonics_order=max_ambisonics_order,
                reference_frequency=reference_frequency,
            )
        )

    device_def = DeviceDefinition(
        device_microphones=device_microphones,
        name=device_name,
        description=device_description,
        reference_frequency=reference_frequency,
    )
    return device_def


def render_device(
    spatial_ir: "SpatialIR",
    device: DeviceObj | DeviceDefinition,
    orientation: Rotation = Rotation(0.0, 0.0, 0.0),
) -> "DeviceIR":
    """
    Using a spatial IR and a definition of a device, render a new device impulse response.

    :param SpatialIR spatial_ir: The spatial impulse response
    :param DeviceObj | DeviceDefinition device: The definition of the device
    :param Rotation: orientation rotation of the device in orientation, defaults to 0.0
    :return DeviceIR: Device rendered impulse response
    """
    from ..results.device_ir import DeviceIR

    if not isinstance(device, DeviceObj | DeviceDefinition):
        raise ValueError(
            """
            Device should be of type either `DeviceObj` or `DeviceDefinition`. 
            Use `tsdk.get_device()` to get the `DeviceObj`
            """
        )
    if isinstance(device, DeviceObj):
        device = device.device_definition_from_object()
    n_mics = len(device.device_microphones)
    max_order = min(device.max_ambisonics_order, spatial_ir.order)
    if max_order < spatial_ir.order:
        warning_message = "Warning: The device has a lower ambisonics order than the spatial IR. "
        warning_message += "The device will be rendered with the maximum order of the device: {max_order}"
        print(warning_message)
    n_channels = (max_order + 1) ** 2

    drtf_interpolated = np.zeros(shape=(n_mics, n_channels, len(spatial_ir.frequency)), dtype=complex)
    rotation_angles = orientation.to_array()
    rotation = False
    if np.any(rotation_angles % 360 != 0):
        rotation = True
        with warnings.catch_warnings():
            warn_message = "Gimbal lock detected. Setting third angle to zero since "
            warn_message += "it is not possible to uniquely determine all angles."
            warnings.filterwarnings(
                "ignore",
                message=warn_message,
            )
            alpha, beta, gamma = processing_utils.convert_rotation_angles(
                orientation.array_counterclockwise_rotation()
            )
    for i_mic in range(n_mics):
        # for interpolated_mic, device_mic in zip(drtf_interpolated, device.device_microphones):
        drtf_poly = CubicSpline(device.frequency, device.device_microphones[i_mic].hnm[:n_channels], axis=1)
        drtf_interpolated[i_mic] = drtf_poly(spatial_ir.frequency)

        if rotation:
            drtf_interpolated[i_mic] = processing_utils.rotate_matrix(
                fnm=drtf_interpolated[i_mic], alpha=alpha, beta=beta, gamma=gamma
            )

        drtf_interpolated[i_mic] = processing_utils.convert_to_real(
            anm=drtf_interpolated[i_mic], n_order=max_order
        )
    spatial_ir_fd_scaled = processing_utils.sn3d_to_orthonormal(
        spatial_IR=spatial_ir.frequency_response[:n_channels], n_order=max_order
    )

    data_rendered_td = np.zeros(shape=(n_mics, len(spatial_ir.time)))
    data_rendered_fd = np.zeros(shape=(n_mics, len(spatial_ir.frequency)), dtype=complex)

    # Loop through all mics and render the device response
    for i_mic in range(n_mics):
        rendering_freq = np.sum(spatial_ir_fd_scaled * drtf_interpolated[i_mic], axis=0)
        data_rendered_fd[i_mic] = rendering_freq
        data_rendered_td[i_mic] = (
            np.fft.irfft(rendering_freq, n=len(spatial_ir.time), axis=0) * spatial_ir.sampling_rate
        )

    return DeviceIR(
        data=data_rendered_td,
        sampling_rate=spatial_ir.sampling_rate,
        spatial_ir=spatial_ir,
        data_fd=(data_rendered_fd, spatial_ir.frequency),
        source=spatial_ir._source,
        receiver=spatial_ir._receiver,
        zero_pad_samples=spatial_ir.zero_pad_samples,
    )


def plot_transfer_function(
    device: DeviceObj | DeviceDefinition,
    angle: tuple[float, float],
    frequency_range: tuple[float, float] = None,
):
    """
    Plot the frequency domain transfer function for a specific angle

    :param DeviceObj device: The device object to plot transfer function for
    :param tuple[float, float] angle: Azimuth angle and elevation angle corresponding to the ones in
        input, if left empty, will plot all angles, defaults to None
    :param tuple[float, float] frequency_range: Frequency range to plot, defaults to None
    """
    if isinstance(device, DeviceObj):
        device_definition = device.device_definition_from_object()
    else:
        device_definition = device
    if device_definition.source_locations is None:
        raise ValueError("Transfer function plotting not available for this device")

    if frequency_range is None:
        frequency_range = (50.0, 12_000.0)
    condition1 = device_definition.device_microphones[0].frequency < frequency_range[1]
    condition2 = device_definition.device_microphones[0].frequency > frequency_range[0]
    condition = condition1 & condition2
    idx_freq = np.nonzero(condition)[0]
    try:
        importlib.import_module("treble_plotter")
        plt.style.use("treble_dark")
    except ImportError:
        pass

    for _i, device_microphone in enumerate(device_definition.device_microphones):
        if _i == 0:
            available_points = spherical_to_cartesian(
                azimuth=device_microphone.source_locations.azimuth_deg * np.pi / 180,
                elevation=device_microphone.source_locations.elevation_deg * np.pi / 180,
            ).T
            requested_point = spherical_to_cartesian(angle[0] * np.pi / 180, angle[1] * np.pi / 180)
            _, ii = KDTree(available_points).query(requested_point)
        plt.plot(
            device_definition.frequency[idx_freq],
            20 * np.log10(np.abs(device_microphone.transfer_function[ii, idx_freq]) + 1e-12),
            label=f"Microphone {_i}",
        )

    plt.title(f"DRTF for {device.name}")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("Gain [dB]")
    plt.legend()
    plt.grid()
    plt.show()


def plot_spherical_harmonics(device_microphone: DeviceMicrophone):
    """
    Plots an overview of the DRTF spherical harmonics energy per order

    :param DeviceMicrophone device_microphone: The device microphone to plot spherical harmonics for
    """
    if device_microphone.hnm is None:
        raise ValueError("The device microphone does not have spherical harmonics available")
    # Create the matrix to plot
    n_channels, nvec, mvec, _ = processing_utils.compute_SH_indices(device_microphone.max_ambisonics_order)

    drtf_sh_summary = np.zeros(
        shape=(
            device_microphone.max_ambisonics_order + 1,
            len(device_microphone.frequency),
        ),
        dtype=complex,
    )
    for i in range(device_microphone.max_ambisonics_order + 1):
        idx = np.nonzero(nvec == i)[0]
        drtf_sh_summary[i, :] = np.sum(np.abs(device_microphone.hnm[idx]) ** 2, axis=0)

    # Normalization
    drtf_sh_summary = drtf_sh_summary / np.max(drtf_sh_summary, axis=0)

    X, Y = np.meshgrid(
        device_microphone.frequency,
        np.arange(device_microphone.max_ambisonics_order + 1),
    )
    plt.pcolormesh(X, Y, 10 * np.log10(np.abs(drtf_sh_summary)), shading="nearest", cmap="viridis")
    plt.title("DRTF Spherical Harmonics Decomposition")
    plt.xlabel("Frequency")
    plt.ylabel("Harmonics Order")
    plt.xlim((0, 10_000))
    plt.clim(-40, 0)
    plt.show()


def plot_device_microphone_transfer_function(
    device_microphone: DeviceMicrophone,
    angle: tuple[float, float] = None,
    frequency_range: tuple[float, float] = None,
):
    """
    Plot the frequency domain transfer function, either for all angles or for a
    given azimuth and/or elevation

    :param DeviceMicrophone device_microphone: The device microphone to plot transfer function for
    :param tuple[float, float] angle: Azimuth angle and elevation angle corresponding to the ones in
        input, if left empty, will plot all angles, defaults to None
    :param tuple[float, float] frequency_range: Frequency range to plot, defaults to None
    """
    if device_microphone.transfer_function is None:
        raise ValueError("Transfer function plotting not available for this microphone")
    if frequency_range is None:
        frequency_range = (50.0, 12_000.0)
    condition1 = device_microphone.frequency < frequency_range[1]
    condition2 = device_microphone.frequency > frequency_range[0]
    condition = condition1 & condition2
    idx_freq = np.nonzero(condition)[0]
    try:
        importlib.import_module("treble_plotter")
        plt.style.use("treble_dark")
    except ImportError:
        pass
    # Only plot one specific angle
    if angle is not None:
        available_points = spherical_to_cartesian(
            azimuth=device_microphone.source_locations.azimuth_deg * np.pi / 180,
            elevation=device_microphone.source_locations.elevation_deg * np.pi / 180,
        ).T
        requested_point = spherical_to_cartesian(angle[0] * np.pi / 180, angle[1] * np.pi / 180)
        _, ii = KDTree(available_points).query(requested_point)

        plt.plot(
            device_microphone.frequency[idx_freq],
            device_microphone.impulse_response[ii, idx_freq],
        )
    else:
        for transfer in device_microphone.transfer_function:
            plt.plot(
                device_microphone.frequency[idx_freq],
                20 * np.log10(np.abs(transfer[idx_freq]) + 1e-12),
            )
    plt.title("Device Related Transfer Function")
    plt.xlabel("Frequency [Hz]")
    plt.ylabel("Gain [dB]")
    plt.grid()
    plt.show()


def plot_device_microphone_impulse_response(
    device_microphone: DeviceMicrophone,
    angle: tuple[float, float] = None,
    temporal_range_in_ms: tuple[float, float] = None,
):
    """
    Plot the impulse responses from sources to microphone. Either from a specific angle or all of them.

    :param DeviceMicrophone device_microphone: The device microphone to plot impulse response for
    :param tuple[float, float] angle: Azimuth, Elevation angle to the source, defaults to None
    :param tuple[float, float] temporal_range_in_ms: Temporal range in millisecons to plot, defaults to None
    """
    if device_microphone.impulse_response is None:
        raise ValueError("Impulse response plotting not available for this microphone")
    time = np.arange(device_microphone.impulse_response.shape[1]) / device_microphone.sampling_rate * 1000
    if temporal_range_in_ms is not None:
        condition1 = time < temporal_range_in_ms[1]
        condition2 = time > temporal_range_in_ms[0]
        condition = condition1 & condition2
        idx_time = np.nonzero(condition)[0]
    else:
        idx_time = np.arange(len(time))

    try:
        importlib.import_module("treble_plotter")
        plt.style.use("treble_dark")
    except ImportError:
        pass

    # Only plot one specific angle
    if angle is not None:
        available_points = spherical_to_cartesian(
            azimuth=device_microphone.source_locations.azimuth_deg * np.pi / 180,
            elevation=device_microphone.source_locations.elevation_deg * np.pi / 180,
        ).T
        requested_point = spherical_to_cartesian(angle[0] * np.pi / 180, angle[1] * np.pi / 180)
        _, ii = KDTree(available_points).query(requested_point)
        plt.plot(time[idx_time], device_microphone.impulse_response[ii, idx_time])

    else:
        for impulse in device_microphone.impulse_response:
            plt.plot(time[idx_time], impulse[idx_time])
    plt.title("Device Related Impulse Response")
    plt.xlabel("Time [ms]")
    plt.ylabel("Amplitude")
    plt.grid()
    plt.show()


def spherical_to_cartesian(azimuth, elevation, radius=1.0):
    """
    Convert spherical coordinates to Cartesian coordinates.

    :param float azimuth: Azimuth angle in radians
    :param float elevation: Elevation angle in radians
    :param float radius: Radius, defaults to 1.0
    :return: Cartesian coordinates (x, y, z)
    """
    x = radius * np.cos(elevation) * np.cos(azimuth)
    y = radius * np.cos(elevation) * np.sin(azimuth)
    z = radius * np.sin(elevation)
    return np.array([x, y, z])
