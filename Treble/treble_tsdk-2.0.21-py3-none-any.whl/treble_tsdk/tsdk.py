from __future__ import annotations

import base64
import json
import logging
import os
import sys
from importlib.metadata import version
import time
from functools import lru_cache
from pathlib import Path

import httpx

from . import utils
from .client.api_models import (
    CategoryInfoDto,
    DeviceDto,
    FittedMaterialDto,
    MaterialBuilderDto,
    MaterialCategory,
    MaterialDefinitionDto,
    MaterialDto,
    ObjectMetadataDto,
    OverviewDto,
    ProjectDto,
    SdkStatus,
    SdkStatusDto,
    SdkVersionDto,
    SourceDirectivityDto,
    TokenStatusDto,
)
from .client.auth import AuthenticationMiddleware, SSOAuthenticationMiddleware, UnauthorizedException
from .client.exceptions import BadRequestException, SSLErrorException
from .client.tsdk_client import TSDKClient
from .core.device_obj import DeviceDefinition, DeviceObj
from .core.geometry_component_library import GeometryComponent
from .core.geometry_library_obj import GeometryLibraryDataset, GeometryLibraryObj
from .core.material_obj import FittedMaterial, Material
from .core.object_metadata import ObjectMetadata
from .core.project import Project
from .core.simulation import Simulation
from .core.source_boundary_velocity import BoundaryVelocitySubmodel
from .core.source_directivity_obj import (
    SourceDirectivityAmplified,
    SourceDirectivityCategory,
    SourceDirectivityNatural,
    SourceDirectivityObj,
    SourceDirectivityOther,
    DirectivityPatternInputData,
)
from .treble_logging import logger


def _configure_httpx_log_level():
    """
    Set httpx log level to WARNING to reduce noise as it logs all http requests as INFO.
    """
    try:
        httpx_logger = logging.getLogger("httpx")
        httpx_logger.setLevel(logging.WARNING)
    except Exception as e:
        logger.error(f"Error configuring httpx log level: {e}")


class TSDKCredentials:
    """
    TSDK credentials container.
    Credentials can be stored
    """

    class CredentialsNotFoundException(Exception):
        pass

    class InvalidEnvironmentNameException(Exception):
        pass

    def __init__(
        self, client_id: str, client_secret: str = None, environment: str = None, is_sso: bool = False
    ):
        """
        Creates a TSDKCredentials container. This class can either be initialized by supplying a TSDK credentials string or
        client_id and client_secret variables.
        F.ex:
            cred = TSDKCredentials("bG9vayBhdCB5b3UsIGhhY2tlcg==")
            cred = TSDKCredentials("my client_id", "my client_secret")

        :param client_id: client_id or credentials string
        :param client_secret: if client_id is provided then client_secret is required.
        :param environment: Environment should be set if using client_id+client_secret and connecting to a specific environment.
        """
        _configure_httpx_log_level()
        self._is_sso = is_sso
        if is_sso:
            self._parse_sso_token(client_id)
            if self.environment in ("local", "test", "dev"):
                self._sso_token_endpoint = "https://treble-dev.eu.auth0.com/oauth/token"
            elif self.environment in ("stage" or "staging" or "eu2"):
                self._sso_token_endpoint = "https://treble-staging.jp.auth0.com/oauth/token"
            else:
                self._sso_token_endpoint = "https://treble-prod.eu.auth0.com/oauth/token"
        else:
            if client_secret is None:
                self._load_from_cred_string(client_id)
            else:
                self.client_id = client_id
                self.client_secret = client_secret
                self.environment = environment or "prod"

        if self.environment == "local":
            self.url = "https://localhost:7128"
        elif self.environment == "test" or self.environment == "dev":
            self.url = "https://stapi.dev.treble.tech"
        elif self.environment == "stage" or self.environment == "staging" or self.environment == "eu2":
            self.url = "https://stapi.eu2.treble.tech"
        elif self.environment == "prod":
            self.url = "https://stapi.treble.tech"
        else:
            raise TSDKCredentials.InvalidEnvironmentNameException(
                f"Unknown environment '{self.environment}'!"
            )

    def _load_from_cred_string(self, cred_string):
        parts = base64.decodebytes(cred_string.encode()).decode("utf-8").split(":")
        self.client_id = parts[0]
        self.client_secret = parts[1]
        self.environment = parts[2]

    def _parse_sso_token(self, sso_token):
        # access_token|refresh_token|environment
        parts = base64.b64decode(sso_token).decode("utf-8").split("|")
        self._sso_access_token = parts[0]
        self._sso_refresh_token = parts[1]
        self.environment = parts[2]

    @staticmethod
    def sso(token: str = None) -> "TSDKCredentials":
        if token is None:
            # Try and fetch token from environment variables.
            token = os.environ.get("TSDK_SSO_TOKEN")
            if not token:
                raise TSDKCredentials.CredentialsNotFoundException(
                    "No SSO token provided and TSDK_SSO_TOKEN environment variable not found."
                )
        return TSDKCredentials(token, is_sso=True)

    @staticmethod
    def from_file(cred_file_path: str) -> "TSDKCredentials":
        """
        Load TSDKCredentials container from a credentials file.
        :param cred_file_path: Path to TSDK .cred file.
        """
        return TSDKCredentials._from_cred_string(open(cred_file_path, "rb").read())

    @staticmethod
    def _from_cred_string(cred_string: str) -> "TSDKCredentials":
        if isinstance(cred_string, (bytes, bytearray)):
            credentials = cred_string
        else:
            credentials = cred_string.encode()
        return TSDKCredentials(*base64.decodebytes(credentials).decode("utf-8").strip().split(":"))

    @staticmethod
    def _from_environment() -> "TSDKCredentials":
        """
        Try to create TSDKCredentials container by searching for credentials on users system.
        Searches for credentials in the following places:
            Windows: %userprofile%/AppData/Local/treble/tsdk/tsdk.cred and %userprofile%/AppData/Roaming/treble/tsdk/tsdk.cred
            Linux: ~/.config/treble/tsdk.cred
            Macos: ~/.config/treble/tsdk.cred and ~/Library/Application Support/treble/tsdk.cred
            Credentials as environment variable: TSDK_CREDENTIALS
            Credential parts as environment variables: TSDK_CLIENT_ID, TSDK_CLIENT_SECRET, TSDK_ENVIRONMENT
        """
        if sys.platform == "win32":
            if (
                cred_path := Path(Path.home(), "AppData\\Local\\treble\\tsdk\\tsdk.cred")
            ) and cred_path.is_file():
                return TSDKCredentials.from_file(str(cred_path))
            if (
                cred_path := Path(Path.home(), "AppData\\Roaming\\treble\\tsdk\\tsdk.cred")
            ) and cred_path.is_file():
                return TSDKCredentials.from_file(str(cred_path))

        if (
            (sys.platform == "linux" or sys.platform == "darwin")
            and (cred_path := Path(Path.home(), ".config/treble/tsdk.cred"))
            and cred_path.is_file()
        ):
            # Try .config/treble for linux and macos.
            return TSDKCredentials.from_file(str(cred_path))

        if (
            sys.platform == "darwin"
            and (cred_path := Path(Path.home(), "Library/Application Support/treble/tsdk.cred"))
            and cred_path.is_file()
        ):
            # Try ~/Library/Application Support on macos.
            return TSDKCredentials.from_file(str(cred_path))

        if os.environ.get("TSDK_CREDENTIALS"):
            return TSDKCredentials._from_cred_string(os.environ.get("TSDK_CREDENTIALS"))

        if os.environ.get("TSDK_CLIENT_ID") and os.environ.get("TSDK_CLIENT_SECRET"):
            return TSDKCredentials(
                os.environ.get("TSDK_CLIENT_ID"),
                os.environ.get("TSDK_CLIENT_SECRET"),
                os.environ.get("TSDK_ENVIRONMENT", "prod"),
            )

        # Use SSO token if found.
        if os.environ.get("TSDK_SSO_TOKEN"):
            return TSDKCredentials.sso(os.environ.get("TSDK_SSO_TOKEN"))

        raise TSDKCredentials.CredentialsNotFoundException


class TSDK:
    class __MaterialLibrary:
        def __init__(self, client: TSDKClient):
            self._client = client

        def _sort_by_name_in_place(self, data: list[Material]) -> list[Material]:
            utils.natural_sort(data, "name")
            return data

        @lru_cache(20)
        def get_by_id(self, id: str) -> Material | None:
            """
            Get material by id.

            :param id: Id of material.
            :returns Material: Material object.
            """
            dto = self._client.material.get_material_by_id(id)
            if dto:
                return Material(dto)
            return None

        @lru_cache(20)
        def get_by_name(self, name: str) -> Material | None:
            """
            Get material by name.

            :param str name: Name of material to fetch.
            :returns Material: Material object.
            """
            if not name or len(name) == 0:
                return None
            dto = self._client.material.get_material_by_name(name)
            if dto:
                return Material(dto)
            return None

        @lru_cache(5)
        def get(self, category: MaterialCategory | str = None) -> list[Material]:
            """
            Get materials.

            :param MaterialCategory | str category: Optional, filter results by material category.
            :returns list[Material]: Returns a list of Materials.
            """
            if isinstance(category, MaterialCategory):
                category = category.value
            return self._sort_by_name_in_place(
                [Material(m) for m in self._client.material.get_materials(category=category)]
            )

        @lru_cache(1)
        def get_categories(self) -> list[str]:
            """
            Get available material categories.

            :returns list[str]: Returns a list of category names as strings.
            """
            return self._client.material.get_material_categories()

        def get_categories_with_count(self) -> list[CategoryInfoDto]:
            """
            Get all categories and the number of materials in that category.

            :returns dict[str, int]: dictionary where the category name is the key and number of materials in that category is the value.
            """
            return self._client.material.get_material_categories_with_count()

        def search(self, name: str) -> list[Material]:
            """
            Performs search on material name.
            :param str name: string to search for in name. Note: the value is not case sensitive.
            :returns: Returns a list of materials where their name contains 'name'.
            """
            mats = self.get()
            return [m for m in mats if name.lower() in m.name.lower()]

        def perform_material_fitting(
            self, material_definition: "MaterialDefinition" | "PorousMaterialBuilderDefinition"
        ) -> FittedMaterial:
            """
            Material definition goes through material fitting and outputs a FittedMaterial object usable by the Treble
            solvers. Nothing is saved in this step, to save the output of the material fitting and create the material
            please use material_client.create(material) with the output of this step.

            :param MaterialDefinitionDto | PorousMaterialBuilderDefinition material_definition: Definition of a material
                to be used for material fitting. Use PorousMaterialBuilderDefinition for input type material_builder, and use
                MaterialDefinitionDto for all other types.
            :returns: FittedMaterial material that can be used in material_client.create(material) to save the output of the fitting.
            """
            if material_definition.input_type == "MaterialBuilder":
                dto = self._client.material.perform_material_builder(
                    MaterialBuilderDto.for_request(
                        name=material_definition.name,
                        description=material_definition.description,
                        category=material_definition.category,
                        input_type=material_definition.input_type,
                        default_scattering=material_definition.default_scattering,
                        material_layers=material_definition.material_layers,
                    )
                )
            else:
                dto = self._client.material.perform_material_fitting(
                    MaterialDefinitionDto.for_request(
                        name=material_definition.name,
                        description=material_definition.description,
                        category=material_definition.category,
                        input_type=material_definition.input_type,
                        default_scattering=material_definition.default_scattering,
                        coefficients=material_definition.coefficients,
                        coefficients_imaginary=material_definition.coefficients_imaginary,
                    )
                )
            if dto is None:
                raise BadRequestException("Material fitting failed")
            return FittedMaterial(dto)

        def create(self, material: FittedMaterial) -> Material | None:
            """
            Create material using result from material fitting (material_client.perform_material_fitting)

            :param Material material: Material outputted from the material fitting process.
            """
            dto = self._client.material.create(MaterialDto(**material))
            if dto:
                return Material(dto)
            return None

        def delete(self, material: Material | str) -> bool:
            """
            Deletes material from library.

            :param Material|str material: Material object or material id to delete.
            """
            if isinstance(material, str):
                return self._client.material.delete(material)
            else:
                return self._client.material.delete(material.id)

        def rename(self, material: Material, new_name: str) -> Material | None:
            """
            Rename material.

            :param Material material: Material object to rename.
            :param str new_name: New name for material.
            """
            if not material:
                logger.error("No material object was provided!")
                return None
            if material.name == new_name:
                return material
            dto = self._client.material.rename(material.id, new_name)
            if dto:
                material._thaw()
                material._dto.name = new_name
                material["name"] = new_name
                material._freeze()
                return Material(dto)
            return None

    class __GeometryLibrary:
        def __init__(self, client: TSDKClient):
            self._client = client

        def get_dataset(
            self, dataset: GeometryLibraryDataset | str, name: str = None, tag: str = None
        ) -> list[GeometryLibraryObj]:
            """
            Get a geometry library dataset.
            :param dataset: Name of dataset to fetch.
            :param name: If provided the library will filter by geometry name.
            :param tag: If provided the library will filter by geometry tag.
            :returns list[GeometryObj]: Returns a list of GeometryObjects.
            """
            if dataset is not None:
                if isinstance(dataset, GeometryLibraryDataset):
                    dataset = dataset.value
            dtos = self._client.geometry_library.query(name, tag, dataset)
            data = [GeometryLibraryObj(dto, self._client) for dto in dtos]
            utils.natural_sort(data, "name")
            return data

        def get_single(self, id: str) -> GeometryLibraryObj:
            dto_res = self._client.geometry_library.get_single(id)
            return GeometryLibraryObj(dto_res, self._client)

        @lru_cache(1)
        def list_datasets(self) -> list[str]:
            """
            Get available geometry library datasets.

            :returns list[str]: Returns a list of category names.
            """
            return self._client.geometry_library.get_geometry_library_datasets()

        def list_datasets_with_count(self) -> list[CategoryInfoDto]:
            """
            Get all datasets and the number of geometries in each dataset.

            :returns: dictionary where the dataset name is the key and number of geometries in that dataset is the value.
            """
            return self._client.geometry_library.get_geometry_library_datasets_with_count()

    class __GeometryComponentLibrary:
        def __init__(self, client: TSDKClient):
            self._client = client

        def query(self, name: str = None, group: str = None) -> list[GeometryComponent] | None:
            """
            Query the geometry component library based on name and/or group.
            :param str name: Name of geometry component to fetch.
            :param str group: Group name of geometry component to fetch.
            :returns list[GeometryComponent]: Returns a list of GeometryComponent objects.
            """
            dtos = self._client.geometry_component_library.query(name=name, group=group)
            return [GeometryComponent(dto, self._client) for dto in dtos]

        def get_by_id(self, id: str) -> GeometryComponent | None:
            """
            Get geometry component by id.
            :param str id: Id of geometry component.
            :return GeometryComponent: Geometry component.
            """
            dto = self._client.geometry_component_library.get_by_id(id)
            if dto is None:
                return None
            return GeometryComponent(dto, self._client)

        def get_groups_with_count(self) -> list[CategoryInfoDto]:
            """
            Get available groups in geometry component library with component count for each one.
            """
            return self._client.geometry_component_library.get_groups_with_count()

        def get_group_names(self) -> list[str]:
            """
            Get available group names in geometry component library.
            """
            return [x.name for x in self._client.geometry_component_library.get_groups_with_count()]

    class __SourceDirectivityLibrary:
        def __init__(self, client: TSDKClient):
            self._client = client

        def query(
            self,
            category: SourceDirectivityCategory = None,
            sub_category: (
                SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther
            ) = None,
            manufacturer: str = None,
            name: str = None,
            filter_by_organization: bool = False,
            sort_by: str = "name",
        ) -> list[SourceDirectivityObj]:
            """
            Query the source directivity library based on various optional factors.
            Any of the source directivity objects can then be used to define a directive source using
            the SourceProperties class

            :param SourceDirectivityCategory type: Type of source directivity, defaults to None
            :param SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther category:
                Subcategory of the source directivity type, defaults to None
            :param str manufacturer: The source directivity manufacturer, defaults to None
            :param str name: Name of source directivity, defaults to None
            :param str sort_by: Parameter to sort the list with, defaults to name
            :return list[SourceDirectivityObj]: A list of source directivities which fit the description
            """
            dtos = self._client.source_directivity.query(
                name=name,
                category=category,
                sub_category=sub_category,
                manufacturer=manufacturer,
                filter_by_organization=filter_by_organization,
            )
            data = [SourceDirectivityObj(source_directivity_dto=dto, client=self._client) for dto in dtos]
            sort_bys = ["name", "manufacturer"]
            if sort_by.lower() not in sort_bys:
                print(f"Only possible to sort by {sort_bys}, defaulting to name")
                sort_by = "name"
            utils.natural_sort(data, sort_by.lower())
            return data

        def get_organization_directivities(self) -> list[SourceDirectivityObj]:
            return self.query(filter_by_organization=True)

        def get_by_name(self, name: str) -> SourceDirectivityObj | None:
            """
            Query the source directivity library based on the name.
            :param str name: Name of source directivity
            :return Source directivity object with the name or None
            :rtype: SourceDirectivityObj
            """
            res = self.query(name=name)
            if res:
                return res[0]
            return None

        def get_by_id(self, source_directivity_id: str) -> SourceDirectivityObj | None:
            """
            Get the source directivity with the associated id, the source directivity object
            can be used to define a directive source using the SourceProperties class.

            :param str source_directivity_id: The unique id of the requested source direcitvity
            :return: A class instance of SourceDirectivityObj, containing the requested source directivity
            :rtype: SourceDirectivityObj
            """
            dto = self._client.source_directivity.get_source_directivity(source_directivity_id)
            if dto is None:
                logger.error(f"Source directivity with id {source_directivity_id} not found")
                return None
            return SourceDirectivityObj(source_directivity_dto=dto, client=self._client)

        def create_source_directivity(
            self,
            name: str,
            source_directivity_file_path: str | DirectivityPatternInputData,
            category: SourceDirectivityCategory,
            sub_category: (
                SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther
            ) = None,
            description: str = None,
            manufacturer: str = None,
            correct_ir_by_on_axis_spl_default: bool = True,
        ) -> SourceDirectivityObj | None:
            """
            Create a source directivity object from file. The source directivity object
            can be used to define a directive source using the SourceProperties class.

            :param str name: Name of the source directivity
            :param str source_directivity_file_path: Path to the source directivity file
            :param SourceDirectivityCategory category: Category of the source directivity. Available values are amplified, natural and other
            :param SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther sub_category: Sub category of the source directivity.
                Optional, defaults to None. Please use SourceDirectivityAmplified if category is amplified, SourceDirectivityNatural if category is natural
                and SourceDirectivityOther if category is other.
            :param str description: A short description of the source directivity, defaults to None
            :param str manufacturer: Name of the manufacturer, defaults to None
            :param bool correct_ir_by_on_axis_spl_default: When enabled, the impulse response gets corrected with the on axis SPL levels.
                It is recommended to enable this for most amplified sources, but to disable it for sources where the response is embedded in the source signal.
                Note that the SPL parameter and frequency response plots in the results will always be corrected.
            :return: A source directivity object which can be used to define directive sources
            :rtype: SourceDirectivityObject
            """
            if isinstance(source_directivity_file_path, DirectivityPatternInputData):
                logger.warning(
                    "The import of source direcitivity from data does not currently support application of the on-axis response. The data will be normalized to on axis SPL@1m=94dB SPL"
                )
                if m := utils.try_load_treble_module("free_field.source_model_generation"):
                    return m.import_source_directivity_from_data(
                        self._client,
                        name,
                        source_directivity_file_path,
                        category,
                        sub_category,
                        description,
                        manufacturer,
                    )
                else:
                    return None
            else:
                source_directivity_dto = self._client.source_directivity.create_source_directivity(
                    filepath=source_directivity_file_path,
                    category=category,
                    sub_category=sub_category,
                    name=name,
                    description=description,
                    manufacturer=manufacturer,
                    correct_ir_by_on_axis_spl_default=correct_ir_by_on_axis_spl_default,
                )
                if source_directivity_dto is None:
                    return None
                retry_count = 0
                max_retries = 200
                # Wait until lambda has finished processing
                while source_directivity_dto.resultStatus.result_code == 101 and retry_count < max_retries:
                    time.sleep(1)
                    source_directivity_dto = self._client.source_directivity.get_source_directivity(
                        source_directivity_id=source_directivity_dto.id
                    )
                    retry_count += 1
                if source_directivity_dto.resultStatus.result_code == 500:
                    raise BadRequestException("Source directivity import failed")
                return SourceDirectivityObj(
                    source_directivity_dto=source_directivity_dto, client=self._client
                )

        def delete_source_directivity(
            self, source_directivity: str | SourceDirectivityDto | SourceDirectivityObj
        ) -> bool:
            """
            Delete source directivity

            :param str|SourceDirectivityDto|SourceDirectivityObj source_directivity: Can either be a source directivity id string, SourceDirectivityDto or a SourceDirectivityObj object.
            """
            if isinstance(source_directivity, SourceDirectivityDto) or isinstance(
                source_directivity, SourceDirectivityObj
            ):
                source_directivity = source_directivity.id
            return self._client.source_directivity.delete_source_directivity(source_directivity)

        def get_manufacturers(self) -> list[CategoryInfoDto]:
            """
            Get all manufecturers and the number of source directivities for each manufacturer.

            :returns dict[str, int]: dictionary where the manufacturer name is the key and number of source directivities for that manufacturer is the value.
            """
            return self._client.source_directivity.get_manufacturers()

        def rename_source_directivity(
            self, source_dir: SourceDirectivityObj, new_name: str
        ) -> SourceDirectivityObj | None:
            if source_dir.name == new_name:
                return source_dir
            dto = self._client.source_directivity.rename_source_directivity(source_dir.id, new_name)
            if dto:
                source_dir._dto.name = new_name
                return SourceDirectivityObj(dto, self._client)
            return None

    class __BoundaryVelocitySubmodelLibrary:
        def __init__(self, client: TSDKClient):
            self._client = client

        def get_by_id(self, id: str) -> BoundaryVelocitySubmodel | None:
            """
            Get source submodel by id.

            :param id: Id of source submodel.
            :returns SourceSubmodelDto: SourceSubmodelDto object.
            """
            res = self._client.boundary_velocity_submodel.get_by_id(id)
            if res:
                return BoundaryVelocitySubmodel(res, self._client)
            return None

        def get_by_name(self, name: str) -> BoundaryVelocitySubmodel | None:
            res = self.query(name=name)
            if res:
                return res[0]
            return None

        def query(self, name: str = None) -> list[BoundaryVelocitySubmodel]:
            return [
                BoundaryVelocitySubmodel(dto=item, client=self._client)
                for item in self._client.boundary_velocity_submodel.query(name=name)
            ]

        def delete(self, id: str | BoundaryVelocitySubmodel) -> bool:
            """
            Delete boundary velocity submodel from library.

            :param str|BoundaryVelocitySubmodel id: Source submodel object or source submodel id to delete.
            """
            if isinstance(id, BoundaryVelocitySubmodel):
                id = id.id
            return self._client.boundary_velocity_submodel.delete(id)

        def rename_submodel(
            self, submodel: BoundaryVelocitySubmodel, new_name: str
        ) -> BoundaryVelocitySubmodel | None:
            """
            Rename BoundaryVelocitySubmodel.

            :param BoundaryVelocitySubmode submodel: Object to rename.
            :param str new_name: New name for submodel.
            """
            dto = self._client.boundary_velocity_submodel.rename(submodel.id, new_name)
            if dto:
                submodel._dto.name = new_name
                return BoundaryVelocitySubmodel(dto, self._client)
            return None

    class __DeviceLibrary:
        def __init__(self, client: TSDKClient):
            self._client = client

        def add_device(self, device_definition: DeviceDefinition) -> DeviceObj | None:
            """
            Upload a device to project.

            :param DeviceDefinition device_definition: The DeviceDefinition object
            :returns DeviceObj: Returns the uploaded DeviceObj object.
            """
            device_dto = self._client.device.create_device(
                name=device_definition.name,
                filepath=str(device_definition.filename),
                description=device_definition.description,
            )
            # Clean temporary directory
            if device_definition._tmpdir is not None:
                device_definition._tmpdir.cleanup()
            if device_dto:
                return DeviceObj(device_dto, self._client)

            return None

        def get_device(self, device: str | DeviceObj | DeviceDto) -> DeviceObj | None:
            """
            Get device information as DeviceObj.

            :param str|DeviceDto|DeviceObj device: Can either be a device id string, DeviceObj or a DeviceDto object.
            :returns DeviceObj: Returns a DeviceObj object
            """
            if isinstance(device, DeviceDto) or isinstance(device, DeviceObj):
                device = device.id
            device_dto = self._client.device.get_device(device)
            if device_dto:
                return DeviceObj(device_dto, self._client)
            return None

        def get_device_by_name(self, name: str) -> DeviceObj | None:
            """
            Get device information as DeviceObj. If multiple devices have the same name it will return
            the device most recently created.

            :param str name: Name of device.
            :returns: Returns a DeviceObj if found, else None.
            """
            device_dto = self._client.device.get_device_by_name(name)
            if device_dto:
                return DeviceObj(device_dto, self._client)
            return None

        def get_by_name(self, name: str) -> DeviceObj | None:
            """
            Get device information as DeviceObj. If multiple devices have the same name it will return
            the device most recently created.

            :param str name: Name of device.
            :returns: Returns a DeviceObj if found, else None.
            """
            return self.get_device_by_name(name)

        def get_devices(self) -> list[DeviceObj]:
            """
            Get all devices associated with this project.

            :returns list[DeviceObj]: Returns a list of DeviceDto objects.
            """
            dtos = self._client.device.get_devices()
            if dtos:
                return [DeviceObj(dto, self._client) for dto in dtos]
            return []

        def delete_device(self, device: str | DeviceDto | DeviceObj) -> bool:
            """
            Delete device from project.

            :param str|DeviceDto|DeviceObj model: Can either be a device id string, DeviceDto or a DeviceObj object.
            """
            if isinstance(device, DeviceDto) or isinstance(device, DeviceObj):
                device = device.id
            return self._client.device.delete_device(device)

        def rename_device(self, device: DeviceObj, new_name: str) -> DeviceObj | None:
            if not device:
                logger.error("No device object provided!")
                return None
            if device.name == new_name:
                return device
            dto = self._client.device.rename_device(device.id, new_name)
            if dto:
                device._dto.name = new_name
                return DeviceObj(dto, self._client)
            return None

    def _credentials_to_auth_middleware(
        self,
        credentials: TSDKCredentials,
    ) -> AuthenticationMiddleware | SSOAuthenticationMiddleware:
        if credentials._is_sso:
            return SSOAuthenticationMiddleware(
                access_token=credentials._sso_access_token,
                refresh_token=credentials._sso_refresh_token,
                token_endpoint=credentials._sso_token_endpoint,
            )
        else:
            return AuthenticationMiddleware(
                f"{credentials.url}/login", credentials.client_id, credentials.client_secret
            )

    def __init__(self, credentials: TSDKCredentials = None):
        if credentials is None:
            # Search for credentials
            credentials = TSDKCredentials._from_environment()
        self.env = credentials.environment
        try:
            self.check_status()
            self._client = TSDKClient(
                base_url=credentials.url,
                credentials=self._credentials_to_auth_middleware(credentials),
            )
            self.check_rate_limit()
            self.check_for_updates()
        except SSLErrorException as e:
            logger.error(
                f"SSL connection issue detected. It is possible you are behind a proxy or a corporate firewall. Please see https://docs.treble.tech/treble-sdk/fixing_ssl_errors for more information."
            )
            logger.debug(str(e), exc_info=e)
        except Exception:
            raise
        self.material_library = TSDK.__MaterialLibrary(self._client)
        self.geometry_library = TSDK.__GeometryLibrary(self._client)
        self.source_directivity_library = TSDK.__SourceDirectivityLibrary(self._client)
        self.device_library = TSDK.__DeviceLibrary(self._client)
        self.boundary_velocity_submodel_library = TSDK.__BoundaryVelocitySubmodelLibrary(self._client)
        self.geometry_component_library = TSDK.__GeometryComponentLibrary(self._client)

    def check_rate_limit(self) -> int | None:
        return self._client.check_rate_limit()

    def check_for_updates(self) -> SdkVersionDto | None:
        res = self._client.check_for_updates()
        self.update_available = False
        if res:
            self.update_available = res.update_available
        return res

    def check_status(self):
        verify = True
        if utils.get_env_var_as_string("STAPI_DISABLE_SSL_VERIFY") == "1":
            verify = False
        res = httpx.get(utils.get_status_url(self.env), verify=verify)
        if res.status_code == 200:
            dto = SdkStatusDto(**res.json())
            if dto.status == SdkStatus.warning:
                print(f"Warning: {dto.message}")
            elif dto.status == SdkStatus.offline:
                print(f"Offline: {dto.message}")

    def download_update(self, download_dir: str) -> str | None:
        """
        Downloads update wheel to the specified directory. Returns the path to the wheel file.
        """
        return self._client.download_update(download_dir)

    def get_update_url(self) -> str:
        return self._client.get_update_url()

    def refresh_authentication(self, cred: TSDKCredentials = None):
        """
        Re-authenticate the SDK using updated credentials. This method is used with SSO users.

        :param TSDKCredentials cred: Updated credentials to use.
        """
        if cred is None:
            cred = TSDKCredentials._from_environment()
        # Make sure that current credentials are for the same user as the old one.
        old_client_id = self._client._session.auth.clientId
        self._client._build_auth(self._credentials_to_auth_middleware(cred))
        if old_client_id != self._client._session.auth.clientId:
            logger.error(
                "Error: original authentication token owner does not match new authentication token owner! This can cause unexpected behaviour, please restart your SDK/Python session!"
            )

    def get_overview(self, filter_user: str = False) -> OverviewDto:
        """
        Get a report of running/queued simulations.
        :param filter_user: If true then it will only show/report the simulations the logged in user has created.
        """
        return self._client.report.overview(filter_user)

    def create_project(
        self,
        name: str,
        description: str = None,
        metadata: dict[str, str] | ObjectMetadataDto | ObjectMetadata = None,
    ) -> Project | None:
        """
        Create a TSDK Project.
        Projects are used to organize simulation, each simulation belong to a project.
        The project, and its associated simulations, can later be accessed with the method `get_project()`

        :param str name: Name of the project
        :param str description: A short description of the project, defaults to None
        :return: A Project object which can be used to add simulations to
        :rtype: Project
        """
        if metadata is not None and isinstance(metadata, ObjectMetadataDto):
            # Get data as dict[str, str]
            metadata = metadata.keyValuePairs

        dto = self._client.project.create_project(
            ProjectDto.for_request(name, description, metadata=metadata)
        )
        if dto:
            return Project(dto, self._client)

    def get_project(self, project_id: ProjectDto | str) -> Project | None:
        """
        Get the project with the associated id, from the project object
        you can access the simulations which belong to that project.

        To find the project id, you can run `list_projects()` and for the relevant entry
        you can access the `id` instance attribute of the project

        :param str id: The unique id of the requested project.
        :return: A class instance of Project, containing the requested project
        :rtype: Project
        """
        if isinstance(project_id, ProjectDto):
            project_id = project_id.id
        dto = self._client.project.get_project(project_id)
        return Project(dto, self._client) if dto else None

    def get_project_by_name(self, name: str) -> Project | None:
        """
        Gets a project by name, if multiple projects match the name the one created the most
        recently is returned.

        :param str name: Name of project to get.
        :return: A Project object, containing the requested project or None if no project is found.
        """
        dto = self._client.project.get_project_by_name(name)
        return Project(dto, self._client) if dto else None

    def get_by_name(self, name: str) -> Project | None:
        """
        Gets a project by name, if multiple projects match the name the one created the most
        recently is returned.

        :param str name: Name of project to get.
        :return: A Project object, containing the requested project or None if no project is found.
        """
        return self.get_project_by_name(name)

    def list_projects(self) -> list[Project]:
        """
        Listing the projects with information useful to identify the project which
        is of interest. Each element of the list is an object containing information
        about the associated project. Elements of the list can be queried to access information
        such as the ids of the projects

        :returns list[Project]: Returns a list of Project objects.
        """
        return [Project(dto, self._client) for dto in self._client.project.get_projects()]

    def get_projects(self) -> list[Project]:
        """
        Listing the projects with information useful to identify the project which
        is of interest. Each element of the list is an object containing information
        about the associated project. Elements of the list can be queried to access information
        such as the ids of the projects

        :returns list[Project]: Returns a list of Project objects.
        """
        return self.list_projects()

    def list_my_projects(self) -> list[Project]:
        """
        list all projects created by the logged in user
        :returns list[Project]: Returns a list of Project objects.
        """
        return [Project(dto, self._client) for dto in self._client.project.get_my_projects()]

    def delete_project(self, project: Project | str, force: bool = False) -> bool:
        """
        Remove a project from the record. Be careful not to delete anything you are not
        sure you want to delete

        :param id: The id of the project you want to delete
        :type id: str
        :param force: If true, the project will be deleted even if it contains running simulations. The simulations will be cancelled.
        """
        if isinstance(project, Project):
            project = project.id
        return self._client.project.delete_project(project, force)

    def rename_project(self, project: Project, new_name: str) -> Project | None:
        """
        Rename a project.

        :param Project project: Project object to rename.
        :param str new_name: New name for project.
        """
        if project.name == new_name:
            return project
        dto = self._client.project.rename(project.id, new_name)
        if dto:
            project._dto.name = new_name
            return Project(dto, self._client)
        return None

    def get_or_create_project(self, name: str, description: str = None) -> Project:
        """
        Looks for a project with the given name, if it's not found it will create the project

        Args:
            name (str): project name
            description (str, optional): description of the project. Defaults to None.

        Returns:
            Project: loaded or new project
        """
        project_list = self.list_projects()
        if name in [p.name for p in project_list]:
            project = self.get_project([p.id for p in project_list if p.name == name][0])
        else:
            project = self.create_project(name, description)
        return project

    def _load_simulation_info(self, simulation_info_path: str | Path) -> dict | None:
        """
        Try and load simulation_info.json and verify that the 'id' and 'project_id' properties exist.
        """
        info_path = Path(simulation_info_path)
        if not info_path.exists():
            logger.error(f"File or directory not found: {info_path}!")
            return None
        if info_path.is_dir():
            info_path = Path(info_path, "simulation_info.json")
            if not info_path.is_file():
                logger.error(
                    f"Directory {simulation_info_path} does not contain a simulation_info.json file!"
                )
                return None
        try:
            with open(str(info_path), "r") as f:
                data = json.load(f)
            if "id" not in data.keys() or "project_id" not in data.keys():
                logger.error(f"Simulation or Project Id missing in simulation_info data from {info_path}!")
                return None
            return data
        except Exception as e:
            logger.error(f"Unable to load simulation_info data from {info_path}!", exc_info=e)
            return None

    def get_project_from_simulation_info_file(self, simulation_info_path: str | Path) -> Project | None:
        """
        Get Project object from a simulation_info json file.

        :param str|Path simulation_info_path: Path to either a simulation_info json file or a directory that contains
                                              previously downloaded simulation results.
        :returns: Project that the simulation belongs to.
        """
        data = self._load_simulation_info(simulation_info_path)
        if data is None:
            return None
        try:
            return self.get_project(data["project_id"])
        except Exception as e:
            logger.error(f"Unable to load project with id {data['project_id']}!", exc_info=e)
            return None

    def get_simulation_from_simulation_info_file(self, simulation_info_path: str | Path) -> Simulation | None:
        """
        Get Simulation object from a simulation_info json file.

        :param str|Path simulation_info_path: Path to either a simulation_info json file or a directory that contains
                                              previously downloaded simulation results.
        :returns: Simulation that the simulation_info belongs to.
        """
        data = self._load_simulation_info(simulation_info_path)
        if data is None:
            return None
        proj = self.get_project_from_simulation_info_file(simulation_info_path)
        if proj is None:
            return None
        return proj.get_simulation(data["id"])

    def get_token_status(self) -> TokenStatusDto:
        return self._client.admin.get_token_status()

    def __repr__(self):
        try:
            sdk_version = version("treble_tsdk")
        except:
            sdk_version = "unknown"

        return (
            f"TSDK(version='{sdk_version}', update_available={self.update_available}, environment={self.env})"
        )
