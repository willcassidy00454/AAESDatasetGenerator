import base64
import importlib
from pathlib import Path
from zipfile import ZipFile
import json
import numpy as np

from .. import utils
from ..treble_logging import logger
from ..core.temp_folder import TempFolder
from ..client.tsdk_client import TSDKClient
from ..client.api_models import BoundaryVelocitySubmodelDto
from ..geometry.mesh_collection import _load_layer_names_with_ids_from_3dm


class BoundaryVelocityLayer:
    def __init__(
        self,
        boundary_layer_name: str,
        mesh_local_sizing: float = None,
        mesh_keep_exterior_edges: bool = True,
    ):
        self.boundary_layer_name = boundary_layer_name
        self.mesh_local_sizing = mesh_local_sizing
        self.mesh_keep_exterior_edges = mesh_keep_exterior_edges

    def __repr__(self) -> str:
        base_str = f"BoundaryVelocityLayer(boundary_layer_name='{self.boundary_layer_name}', mesh_keep_exterior_edges={self.mesh_keep_exterior_edges}"
        if self.mesh_local_sizing is not None:
            base_str += f", mesh_local_sizing={self.mesh_local_sizing}"
        return base_str + ")"


class BoundaryVelocitySubmodel:
    def __init__(self, dto: BoundaryVelocitySubmodelDto, client: TSDKClient):
        self._dto = dto
        self._client = client
        self._temp_dir = None
        self._model_file_path = None
        self._original_file_hash = None
        self._ga_directivity_file_path = None
        self._original_file_hash_ga_directivity = None
        self._original_mesh_collection = None

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def description(self) -> str:
        return self._dto.description

    @property
    def max_crossover_frequency(self) -> int | None:
        return self._dto.maxCrossoverFrequency

    @property
    def simulation_type_filter(self) -> list[str] | None:
        return self._dto.simulationTypeFilter

    def _has_valid_local_file_ga_directivity(self, download_if_missing: bool = False) -> bool:
        if (
            self._ga_directivity_file_path
            and Path(self._ga_directivity_file_path).is_file()
            and self._original_file_hash_ga_directivity
        ):
            # Found file, verify the file is still valid
            new_hash = utils.calculate_file_hash(self._ga_directivity_file_path)
            if new_hash == self._original_file_hash_ga_directivity:
                return True
        if download_if_missing:
            if self._temp_dir is None:
                self._temp_dir = TempFolder()
            ga_directivity_file = self._download_local_ga_directivity_file()
            if ga_directivity_file and ga_directivity_file.endswith(".zip"):
                with ZipFile(str(ga_directivity_file), "r") as zip_obj:
                    data_member = [member for member in zip_obj.filelist if member.filename.endswith(".h5")][
                        0
                    ]
                    zip_obj.extract(data_member, self._temp_dir.temp_dir)
                    self._ga_directivity_file_path = f"{self._temp_dir.temp_dir}/{data_member.filename}"
                self._original_file_hash_ga_directivity = utils.calculate_file_hash(
                    self._ga_directivity_file_path
                )
            else:
                self._ga_directivity_file_path = ga_directivity_file
                self._original_file_hash_ga_directivity = utils.calculate_file_hash(
                    self._ga_directivity_file_path
                )
            if self._ga_directivity_file_path != None:
                return True
        return False

    def _has_valid_local_file(self, download_if_missing: bool = False) -> bool:
        # Check if the .3dm file representing the model is available locally.
        if self._model_file_path and Path(self._model_file_path).is_file() and self._original_file_hash:
            # Found model file, verify the file is still valid.
            new_hash = utils.calculate_file_hash(self._model_file_path)
            if new_hash == self._original_file_hash:
                return True
        if download_if_missing:
            if self._temp_dir is None:
                self._temp_dir = TempFolder()
            model_file = self._download_local_file()
            if model_file and model_file.endswith(".zip"):
                with ZipFile(str(model_file), "r") as zip_obj:
                    model_member = [
                        member for member in zip_obj.filelist if member.filename.endswith(".3dm")
                    ][0]
                    zip_obj.extract(model_member, self._temp_dir.temp_dir)
                    self._model_file_path = f"{self._temp_dir.temp_dir}/{model_member.filename}"
                self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
            else:
                # Model was not compressed
                self._model_file_path = model_file
                self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
            return True
        return False

    def _get_mesh_collection(self):
        if self._original_mesh_collection is None:
            self._has_valid_local_file(True)
            self._original_mesh_collection = importlib.import_module(
                "treble_tsdk.geometry.mesh_collection"
            ).MeshCollection.load_3dm(self._model_file_path)
        return self._original_mesh_collection

    def _download_local_file(self) -> str | None:
        download_info = self._client.boundary_velocity_submodel.get_model_url(self._dto.id)
        if download_info is None:
            logger.info("Unable to download source submodel {self.id}!")
            return None
        destination_file = f"{self._temp_dir.temp_dir}/{download_info.filename}"
        utils.download_file(download_info.downloadUrl, destination_file)
        return destination_file

    def _download_local_ga_directivity_file(self) -> str | None:
        download_info = self._client.boundary_velocity_submodel.get_ga_directivity_url(self._dto.id)
        if download_info is None:
            logger.info("Unable to download GA directivity data {self.id}!")
            return None
        destination_file = f"{self._temp_dir.temp_dir}/{download_info.filename}"
        utils.download_file(download_info.downloadUrl, destination_file)
        return destination_file

    def _get_material_assignments(self):
        return self._client.boundary_velocity_submodel.get_material_assignments(self._dto.id)

    def plot(self):
        self._plot_directivity()

    def plot_geometry(self):
        """
        Uses the plot module to plot the model.
        """
        if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
            self._get_mesh_collection().plot()
        else:
            try:
                importlib.import_module("treble_tsdk.geometry.plot").plot_submodel_dash(self)
            except ImportError:
                logger.warning(
                    "Unable to find required treble_tsdk.geometry.plot module, has it been installed?"
                )

    def get_directivity_data(self):
        if not self._has_valid_local_file_ga_directivity(True):
            logger.warning("Unable to plot boundary velocity submodel, no data file available")
            return

        with open(self._ga_directivity_file_path, "r") as f:
            ga_json = json.load(f)

        data_complex = np.array(ga_json["data_real"]) + 1j * np.array(ga_json["data_imag"])
        frequencies = np.array(ga_json["f"])
        azi = np.array(ga_json["phi"])
        colat = np.array(ga_json["theta"])
        ele = np.pi / 2 - colat
        # For the plot, we append the first element of the azimuth to complete the loop
        azi = np.append(azi, azi[0])

        AZI, ELE = np.meshgrid(azi, ele)

        x = np.cos(ELE) * np.cos(AZI)
        y = np.cos(ELE) * np.sin(AZI)
        z = np.sin(ELE)

        # Append first azimuth directivity to the end
        data_complex = np.concatenate((data_complex, data_complex[:, :1, :]), axis=1)

        directivity = np.swapaxes(data_complex, 1, 2)
        return frequencies, x, y, z, directivity

    def _plot_directivity(self):
        frequencies, x, y, z, directivity = self.get_directivity_data()

        try:
            importlib.import_module("treble_tsdk.results.plot").plot_directive_source(
                20 * np.log10(np.abs(directivity)) + 94,
                frequencies,
                x,
                y,
                z,
                name="Boundary Velocity",
            )
        except ImportError:
            logger.error("Results module could not be loaded, is it installed?")

    def __repr__(self) -> str:
        base_repr = f"BoundaryVelocitySubmodel(id='{self.id}', name='{self.name}'"
        if self.max_crossover_frequency:
            base_repr += f", max_crossover_frequency={self.max_crossover_frequency}"
        if self.simulation_type_filter:
            base_repr += f", simulation_type_filter={self.simulation_type_filter}"
        return base_repr + ")"
