import json

from ..client.api_models import FittedMaterialDto, MaterialDto
from ..utils import FreezableDict, try_load_treble_module


class Material(FreezableDict):
    def __init__(self, dto: MaterialDto):
        super().__init__()
        self._dto = dto
        super().__setitem__("id", self._dto.id)
        super().__setitem__("name", self._dto.name)
        super().__setitem__("description", self._dto.description)
        super().__setitem__("category", self._dto.category)
        super().__setitem__("materialJson", self._dto.materialJson)
        super().__setitem__("materialMetadataJson", self._dto.materialMetadataJson)
        super().__setitem__("defaultScattering", self._dto.defaultScattering)
        super().__setitem__("userId", self._dto.userId)
        super().__setitem__("organizationId", self._dto.organizationId)
        super().__setitem__("absorptionCoefficients", self._dto.absorptionCoefficients)
        self._freeze()

    @property
    def id(self) -> str:
        return self["id"]

    @property
    def name(self) -> str:
        return self["name"]

    @property
    def description(self) -> str:
        return self["description"]

    @property
    def category(self) -> str:
        return self["category"]

    @property
    def default_scattering(self) -> str:
        return self["defaultScattering"]

    @property
    def absorption_coefficients(self) -> list[float]:
        return self["absorptionCoefficients"]

    @property
    def material_json(self) -> str:
        return self["materialJson"]

    @property
    def material_metadata_json(self) -> str:
        return self["materialMetadataJson"]

    def __repr__(self):
        return f"Material(id='{self.id}', name='{self.name}', category='{self.category}', absorption_coefficients='{self.absorption_coefficients}')"

    def __str__(self):
        data = {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "category": self.category,
            "default_scattering": self.default_scattering,
        }
        if self.absorption_coefficients:
            data["absorption_coefficients"] = self.absorption_coefficients
        return json.dumps(
            data,
            indent=2,
        )

    def plot(self):
        if m := try_load_treble_module("geometry.plot"):
            m.plot_material_info(self)

    def as_tree(self):
        """
        Uses the display_data module to display material info as tree.
        """
        if m := try_load_treble_module("display_data"):
            m.as_tree(self)


class FittedMaterial(Material):
    def __init__(self, dto: MaterialDto | FittedMaterialDto):
        super().__init__(dto)
        # Make editable
        self._thaw()

    # Make it easy to change name.
    @property
    def name(self):
        return self["name"]

    @name.setter
    def name(self, value: str):
        self._freeze_check()
        self["name"] = value
