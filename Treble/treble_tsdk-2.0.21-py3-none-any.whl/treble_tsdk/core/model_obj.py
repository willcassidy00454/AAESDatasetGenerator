from __future__ import annotations

import math
import shutil
import time
from pathlib import Path
from zipfile import ZipFile
from .object_metadata import ObjectMetadata

from .. import utils
from ..core.material_obj import Material
from ..client.api_models import LocalMeshSizingDto, MaterialAssignmentDto, MaterialDto, ModelDto, ProjectDto
from ..client.tsdk_client import TSDKClient
from .temp_folder import TempFolder
from ..treble_logging import logger


class MaterialAssignment(utils.FreezableDict):
    def __init__(
        self,
        layer_name: str,
        material: Material,
        scattering_coefficient: list[float] | float = None,
    ):
        """
        Represents a layer material assignment.
        :param str layer_name: Name of layer to assign material to.
        :param Material material: Material to assign to layer.
        :param float|list[float] scattering_coefficient: If None then the default scattering coefficient defined in the
        selected material is used. If set it can either be a single value or a list of 8 values, one per octave band.
        If this is a single value then the value will be used to calculate scattering for all octave bands.
        """
        super().__init__()
        super().__setitem__("layerName", layer_name)
        super().__setitem__("materialId", material.id)
        super().__setitem__("materialName", material.name)
        if scattering_coefficient is not None:
            if isinstance(scattering_coefficient, list):
                super().__setitem__("scatteringCoefficient", list(map(float, scattering_coefficient)))
            else:
                super().__setitem__("scatteringCoefficient", float(scattering_coefficient))
        self._material = material or None

    @property
    def layer_name(self) -> str:
        return self["layerName"]

    @layer_name.setter
    def layer_name(self, value: str):
        self._freeze_check()
        self["layerName"] = value

    @property
    def material_id(self) -> str:
        return self["materialId"]

    @property
    def material_name(self) -> str:
        return self["materialName"]

    def set_material(self, value: Material):
        self._freeze_check()
        if value is None:
            raise ValueError("Material cannot be None.")
        self["materialId"] = value.id
        self["materialName"] = value.name
        self._material = value

    @property
    def scattering_coefficient(self) -> list[float] | float | None:
        return self.get("scatteringCoefficient", None)

    @scattering_coefficient.setter
    def scattering_coefficient(self, value: list[float] | float | None):
        self._freeze_check()
        if value is not None:
            if isinstance(value, list):
                self["scatteringCoefficient"] = list(map(float, value))
            else:
                self["scatteringCoefficient"] = float(value)

    @staticmethod
    def assign_multiple(layer_names: list[str], material: Material) -> list["MaterialAssignment"]:
        """
        Assigns the same material to multiple layers.
        :param list[str] layer_names: List of layer names to assign material to.
        :param Material material: Material to assign to layers.
        :returns list[MaterialAssignment]: List of material assignments.
        """
        return [MaterialAssignment(layer_name, material) for layer_name in layer_names]

    @classmethod
    def _from_dto(cls, dto: MaterialAssignmentDto, material: Material | None, freeze: bool):
        if material is None:
            o = cls(
                layer_name=dto.layerName,
                material=MaterialDto(
                    id=dto.materialId,
                    name=dto.materialName,
                    description="",
                    category=None,
                    materialJson="",
                    materialMetadataJson="",
                    defaultScattering=None,
                ),
                scattering_coefficient=dto.scatteringCoefficient,
            )
            # Cleanup material reference.
            o._material = None
        else:
            o = cls(
                dto.layerName,
                material,
                dto.scatteringCoefficient,
            )
        if freeze:
            o._deep_freeze()
        return o

    def __repr__(self):
        return f"MaterialAssignment(layer_name='{self.layer_name}', material='{self.material_name}')"


class LocalMeshSizing(utils.FreezableDict):
    def __init__(
        self,
        layer_name: str,
        mesh_sizing_m: float,
        keep_exterior_edges: bool = False,
    ):
        """
        Represents a custom local mesh sizing assignment. Makes it possible to control the mesh quality of individual elements in a simulation.
        :param str layer_name: Name of layer to assign custom mesh sizing to.
        :param float mesh_sizing_m: Mesh sizing in meters.
        :param bool keep_exterior_edges: If True, ensures that the outline of the object is never altered, regardless of the meshing settings (including mesh size). Defaults to false.
        """
        super().__init__()
        super().__setitem__("layerName", layer_name)
        super().__setitem__("meshSizingM", mesh_sizing_m)
        super().__setitem__("keepExteriorEdges", keep_exterior_edges)

    @property
    def layer_name(self) -> str:
        return self["layerName"]

    @layer_name.setter
    def layer_name(self, value: str):
        self._freeze_check()
        self["layerName"] = value

    @property
    def mesh_sizing_m(self) -> float:
        return self["meshSizingM"]

    @mesh_sizing_m.setter
    def mesh_sizing_m(self, value: float):
        self._freeze_check()
        self["meshSizingM"] = value

    @property
    def keep_exterior_edges(self) -> bool:
        return self["keepExteriorEdges"]

    @keep_exterior_edges.setter
    def keep_exterior_edges(self, value: bool):
        self._freeze_check()
        self["keepExteriorEdges"] = value

    @classmethod
    def _from_dto(cls, dto: LocalMeshSizingDto, freeze: bool):
        o = cls(
            dto.layerName,
            dto.meshSizingM,
            dto.keepExteriorEdges,
        )
        if freeze:
            o._deep_freeze()
        return o

    def __repr__(self):
        return f"LocalMeshSizing(layer_name='{self.layer_name}', mesh_sizing_m={self.mesh_sizing_m}, keep_exterior_edges={self.keep_exterior_edges})"


class ModelObj:
    def __init__(self, modelDto: ModelDto, model_file_path: str, client: TSDKClient):
        self._dto = modelDto
        self._model_file_path = model_file_path
        self._client = client
        self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
        self._temp_dir = None
        self.metadata = ObjectMetadata(
            self._client,
            {"model_id": self._dto.id, "project_id": self._dto.projectId},
            ObjectMetadata._MetadataOwnerType.model,
            self._dto.metadata,
        )

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def status(self) -> str:
        # If status is not final, try and perform update.
        if self._dto.status == "Processing":
            self._update_object()
        return self._dto.status

    @property
    def status_message(self) -> str:
        return self._dto.statusMessage

    @property
    def is_watertight(self) -> str:
        return self._dto.isWatertight

    @property
    def layer_names(self) -> list[str] | None:
        # If status is not final, try and perform update.
        if self._dto.status == "Processing" or not hasattr(self._dto, "layers"):
            self._update_object()
        if hasattr(self._dto, "layers"):
            return [l.name for l in self._dto.layers]
        else:
            return None

    def wait_for_model_processing(self, max_retries=1000) -> str | None:
        """
        Waits until model has been processed and then returns the model status.
        :param int max_retries: Maximum number of retries before stopping, each retry waits 3 seconds.
        :returns: Model status, "Valid", "NotValid", "Error" or "Processing" in case of timeout.
        """
        retry_count = 0
        while self.status in ("Created", "Processing") and retry_count < max_retries:
            time.sleep(3)
            retry_count += 1

        return self.status

    def wait_for_layer_names(self, max_retries=1000) -> list[str] | None:
        retry_count = 0
        while self.status == "Processing" and retry_count < max_retries:
            time.sleep(3)
            retry_count += 1

        if self.status == "Valid":
            return self.layer_names
        else:
            raise ValueError(f"Unable to get layer names for model in status {self.status}!")

    def _update_object(self):
        """
        Update object data from server.
        """
        self._dto = self._client.model.get_model(self._dto.projectId, self._dto.id)

    def _has_valid_local_file(self, download_if_missing: bool = False) -> bool:
        # Check if the .3dm file representing the model is available locally.
        if self._model_file_path and Path(self._model_file_path).is_file() and self._original_file_hash:
            # Found model file, verify the file is still valid.
            new_hash = utils.calculate_file_hash(self._model_file_path)
            if self._original_file_hash == new_hash:
                return True
        if download_if_missing:
            if self._temp_dir is None:
                self._temp_dir = TempFolder()
            model_file = self._download_local_file()
            if model_file and model_file.endswith(".zip"):
                # Extract 3dm file.
                with ZipFile(str(model_file), "r") as zip_obj:
                    # Find model.
                    model_member = [
                        member for member in zip_obj.filelist if member.filename.endswith(".3dm")
                    ][0]
                    zip_obj.extract(model_member, self._temp_dir.temp_dir)
                    self._model_file_path = f"{self._temp_dir.temp_dir}/{model_member.filename}"
                    # Find _feedback.png if it exists
                    feedback_members = [
                        member for member in zip_obj.filelist if member.filename.endswith("_feedback.png")
                    ]
                    if len(feedback_members) > 0:
                        zip_obj.extract(feedback_members[0], self._temp_dir.temp_dir)
                        self._feedback_png_path = f"{self._temp_dir.temp_dir}/{feedback_members[0].filename}"
                self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
            else:
                # Model was not compressed
                self._model_file_path = model_file
                self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
            return True
        return False

    def _download_local_file(self) -> str | None:
        """
        Download model to destination file.

        :param str destination_directory: Directory to download to.
        :returns str: Path to downloaded file or None if unable to download file.
        """
        download_info = self._client.model.get_model_url(self._dto.projectId, self._dto.id)
        if download_info is None:
            logger.info(
                f"Unable to download model {self.id}, make sure the model has been processed successfully and has status as 'Valid'"
            )
            return None
        destination_file = f"{self._temp_dir.temp_dir}/{download_info.filename}"
        utils.download_file(download_info.downloadUrl, destination_file)
        return destination_file

    def get_geometry_processing_feedback_png(self, destination_file: str) -> bool:
        """
        Get model feedback image from geometry processing.

        :param str destination_file: Path to download feedback image file to. F.ex. '/home/user/feedback.png'
        :returns bool: True if it was able to download the file.
        """
        if self.status != "Valid":
            print("Feedback only available for uploaded models that have status == 'Valid'")
            return False
        feedback_png = getattr(self, "_feedback_png_path", None)
        if not feedback_png or not Path(feedback_png).is_file():
            self._has_valid_local_file(True)
        feedback_png = getattr(self, "_feedback_png_path", None)
        if feedback_png:
            shutil.copy2(feedback_png, destination_file)
            return True
        else:
            print("Feedback png not available")
            return False

    def get_geometry_processing_feedback_json(self, destination_file: str) -> bool:
        """
        Download result json from Geometry Checking Service.

        :param str destination_file: Filepath to download to.
        :returns bool: True if it was able to download the file.
        """
        if self.status != "Valid":
            print("Feedback only available for uploaded models that have status == 'Valid'")
            return False
        res = self._client.model.get_gcs_results_json_url(self._dto.projectId, self._dto.id)
        if res and res.success and res.content and len(res.content) > 0:
            utils.download_file(res.content, destination_file)
            return True
        else:
            return False

    def clone_model(
        self, new_project: ProjectDto | "Project" | str, new_name: str = None
    ) -> "ModelObj" | None:
        """
        Create a clone of the model in a different project.

        :return ModelObj | None: New model object
        """
        if self.status != "Valid":
            logger.warning("Unable to clone model before model has been validated!")
            return None

        if hasattr(new_project, "id"):
            new_project_id = new_project.id
        else:
            new_project_id = new_project

        if not new_name:
            new_name = self.name

        return ModelObj(
            self._client.model.clone_model(self._dto.projectId, self.id, new_project_id, new_name),
            self._model_file_path,
            self._client,
        )

    def calculate_sabine_estimate(
        self,
        material_assignments: list[MaterialAssignment | MaterialAssignmentDto],
        model_volume: float = None,
    ) -> list[float]:
        """
        Calculates the sabine estimate of the reverberation time based on layer material assignment.

        :param list[MaterialAssignment|MaterialAssignmentDto] material_assignment: Layer material assignment for model to calculate the estimate on.
        :param float model_volume: Optional, If no model volume is input the model volume will be computed from the input objects. If a geometry without a closed shell is input the model_volume has to be specified.
        :returns list[float]: List of the sabine estimated RT for each frequency range valid for materials (63, 125, 250, 500, 1k, 2k, 4k, 8k).
        """
        if self.status != "Valid":
            raise ValueError(
                f"Unable to calculate sabine estimate before model has been validated! Current status: {self.status}"
            )

        if self._dto.geometryObjectInfo is None:
            raise ValueError("Unable to calculate sabine estimate on model, geometry object data is missing!")

        if model_volume is None:
            model_volume = self._compute_model_volume()

        if model_volume <= 0:
            raise ValueError("Calculated model volume is 0, unable to calculate sabine estimate!")

        def get_absorption_coefficients(mat) -> list[float]:
            if isinstance(mat, MaterialDto):
                return mat.absorptionCoefficients
            elif isinstance(mat, Material):
                return getattr(mat, "absorption_coefficients", None)
                return mat.absorption_coefficients
            elif isinstance(mat, str):
                get_mat = self._client.material.get_material_by_id(mat)
                if get_mat:
                    return get_mat.absorptionCoefficients
                else:
                    raise ValueError(f"Unable to find material with id {mat}")
            else:
                raise ValueError(f"Unknown material type {type(mat)}")

        # Get bands and absorption coefficients.
        if isinstance(material_assignments[0], MaterialAssignmentDto):
            # Assume MaterialAssignmentDto objects, need to populate material information.
            layer_to_absorption = {
                dto.layerName: get_absorption_coefficients(dto.materialId) for dto in material_assignments
            }
        else:
            # Assume MaterialAssignment objects.
            layer_to_absorption = {
                a.layer_name: get_absorption_coefficients(a._material or a.material_id)
                for a in material_assignments
            }
        n_bands = len(list(layer_to_absorption.values())[0])

        absorption_areas = [0] * n_bands
        for object_id in self._dto.geometryObjectInfo.keys():
            object_info = self._dto.geometryObjectInfo[object_id]
            surface_area = object_info.surfaceArea
            if object_info.groupType == 3:
                surface_area *= 2  # Multiplying by 2 here to add the back of the open surfaces
            for i_band in range(n_bands):
                absorption_areas[i_band] += surface_area * layer_to_absorption[object_info.layerName][i_band]

        sabine_rt = [0.161 * model_volume / abs_area for abs_area in absorption_areas]
        if max(sabine_rt) > 50:
            return [math.nan] * n_bands
        return sabine_rt

    def _compute_model_volume(self):
        model_volume = 0
        for group_id, group_volume in self._dto.geometryGroupTypeToVolume.items():
            if group_id in ["1", "2"]:
                model_volume += group_volume
        return model_volume

    def rename(self, model_name: str):
        if not model_name:
            logger.warning("Model name must have a value.")
            return False

        if self._client.model.update_model_name(self._dto.projectId, self.id, model_name):
            self._dto.name = model_name
            return True

    def _update_dto(self):
        """
        Update object data from server.
        """
        self._dto = self._client.model.get_model(self._dto.projectId, self._dto.id)

    #####
    # Stub functions
    def plot(self, view_2d: "View2d" = None):
        """
        Uses the plot module to plot the model.
        :param view_2d: Show a 2d view, choose between None, View2d.xy, View2d.xz, View2d.yz. Optional, defaults to false.
        """
        if self.status != "Valid":
            print(f"Unable to plot model in status {self.status}")
            return
        if m := utils.try_load_treble_module("geometry.plot"):
            if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
                m.plot_model_obj(self)
            else:
                m.plot_model_dash(self, view_2d)

    def plot_geometry_feedback(self):
        """
        Uses the plot module to plot the geometry feedback.
        """
        if m := utils.try_load_treble_module("geometry.plot"):
            if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
                m.plot_model_feedback(self)
            else:
                m.plot_model_feedback_dash(self)

    def as_tree(self):
        """
        Uses the display_data module to model object info as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)

    def as_live_model_status(self):
        """
        Uses the display_data module to show model status automatically updated until model has been processed
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_live_model_status(self)

    def __repr__(self) -> str:
        # Note: ModelObj should not be created directly by the user so the repr will only contain public properties.
        return f"ModelObj(id='{self.id}', name='{self.name}', status='{self.status}')"
