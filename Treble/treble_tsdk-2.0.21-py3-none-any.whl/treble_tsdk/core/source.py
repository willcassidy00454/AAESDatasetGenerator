from enum import Enum
import json
import reprlib
from typing import Optional

from treble_tsdk.client.tsdk_client import TSDKClient
from ..treble_logging import logger
from ..utility_classes import Point3d, Rotation
from ..utils import FreezableDict, is_valid_label
from ..client.api_models import (
    CancelSimulationDto,
    CancelTaskDto,
    LocalMeshSizingDto,
    MaterialAssignmentDto,
    ModelDto,
    ReceiverDto,
    SimulationDto,
    SimulationEstimateDto,
    SimulationMeshInfoDto,
    SimulationProgressDto,
    SourceDto,
    SourceEstimateDto,
    SourcePropertiesDto,
    SourceResultDto,
    ObjectMetadataDto,
    TaskInfoDto,
)
from .source_directivity_obj import SourceDirectivityObj
from .source_boundary_velocity import BoundaryVelocityLayer, BoundaryVelocitySubmodel


class TaskType(str, Enum):
    """
    Available task types
    """

    hybrid = "Hybrid"
    dg = "DG"
    ga = "GA"
    wave_based = "DG"
    geometrical = "GA"
    device_rendering = "DeviceRendering"
    join_directive_speech = "JoinDirectiveSpeech"
    join_directivity = "JoinDirectivity"
    geometry_checking = "GeometryChecking"
    mesher = "Mesher"


class SourceEstimate:
    def __init__(self, dto: SourceEstimateDto):
        self._dto = dto

    @property
    def source_id(self) -> str:
        return self._dto.sourceId

    @property
    def source_label(self) -> str:
        return self._dto.sourceLabel

    @property
    def estimated_runtime_hours(self) -> float:
        return self._dto.estimatedRuntimeHours

    @property
    def estimated_cost_in_tokens(self) -> float:
        return self._dto.estimatedCostInTokens

    @property
    def estimated_gpus_allocated(self) -> int | None:
        return self._dto.estimatedGpusAllocated

    def __repr__(self):
        return f"SourceEstimate(source_id={self.source_id}, source_label={self.source_label}, estimated_runtime_hours={self.estimated_runtime_hours}, estimated_cost_in_tokens={self.estimated_cost_in_tokens})"


class TaskInfo:
    def __init__(self, dto: TaskInfoDto):
        self._dto = dto

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def task_type(self) -> TaskType:
        return TaskType(self._dto.taskType)

    @property
    def status(self) -> str:
        return self._dto.status

    @property
    def created_at(self) -> str:
        return self._dto.createdAt

    @property
    def started_at(self) -> str:
        return self._dto.startedAt

    @property
    def completed_at(self) -> str:
        return self._dto.completedAt

    @property
    def progress_percentage(self) -> float:
        return self._dto.progressPercentage

    @property
    def status_message(self) -> str:
        return self._dto.statusMessage

    @property
    def task_sub_type(self) -> str | None:
        return self._dto.taskSubType

    @property
    def tokens_used(self) -> float:
        return self._dto.tokensUsed

    def __repr__(self):
        return f"TaskInfo(id='{self.id}', name='{self.name}', task_type={self.task_type}, status='{self.status}', created_at='{self.created_at}', started_at='{self.started_at}', completed_at='{self.completed_at}', progress_percentage={self.progress_percentage}, status_message='{self.status_message}')"


class SourceType(str, Enum):
    """
    Available source types.
    """

    omni = "Omni"
    directive = "Directive"
    cardioid = "Cardioid"
    dipole = "Dipole"
    boundary_velocity = "BoundaryVelocity"

    @classmethod
    def list(cls):
        return [c.value for c in cls]

    @classmethod
    def print(cls):
        print("Available source types")
        for c in cls:
            print(f" - {c.value}")


class SourceProperties(FreezableDict):
    def __init__(
        self,
        azimuth_angle: float = 0.0,
        elevation_angle: float = 0.0,
        source_directivity: str | SourceDirectivityObj = None,
        boundary_velocity_definition: BoundaryVelocitySubmodel | BoundaryVelocityLayer | str = None,
        source_boundary_layer_name: str = None,
        source_boundary_mesh_local_sizing: float = None,
        source_boundary_mesh_keep_exterior_edges: bool = False,
        disable_source_correction: bool = None,
        use_wave_based_pattern: bool = None,
    ):
        """
        Additional source properties.

        :param float azimuth_angle: Azimuth rotation angle for directional sources. From 0° to 360°.
        :param float elevation_angle: Elevation rotation angle for directional sources. From 0° to 90°.
        :param str|SourceDirectivityObj source_directivity: If the source type is Directive this parameter specifies the source directivity.
        :param BoundaryVelocitySubmodel|BoundaryVelocityLayer|str boundary_velocity_definition: If the source type is a boundary velocity source this parameter specified properties of that.
        :param source_boundary_layer_name: Deprecated. Use source_boundary_velocity instead.
        :param source_boundary_mesh_local_sizing: Deprecated. Use source_boundary_velocity instead.
        :param source_boundary_mesh_keep_exterior_edges: Deprecated. Use source_boundary_velocity instead.
        :param bool disable_source_correction: Optional: Disable source correction in solvers.
        :param bool use_wave_based_pattern: Optional: If flag is set and source is of type Directive. The GA solver will use an approximate directivity fitted to be used in the wave based solver.
        """
        super().__init__()
        super().__setitem__("azimuthAngle", self._check_azimuth_angle(azimuth_angle))
        super().__setitem__("elevationAngle", self._check_elevation_angle(elevation_angle))

        if isinstance(source_directivity, SourceDirectivityObj):
            super().__setitem__("sourceDirectivityId", source_directivity._dto.id)
        elif source_directivity:
            super().__setitem__("sourceDirectivityId", str(source_directivity))

        self._bv_def = boundary_velocity_definition
        if isinstance(boundary_velocity_definition, BoundaryVelocitySubmodel):
            # Boundary Velocity Submodel provided. Set sourceSubmodelId
            super().__setitem__("boundaryVelocitySubmodelId", boundary_velocity_definition._dto.id)
        elif isinstance(boundary_velocity_definition, BoundaryVelocityLayer):
            # Boundary Velocity Definition provided. Set properties.
            if boundary_velocity_definition.boundary_layer_name:
                super().__setitem__(
                    "sourceBoundaryLayerName", boundary_velocity_definition.boundary_layer_name
                )
            if boundary_velocity_definition.mesh_local_sizing:
                super().__setitem__(
                    "sourceBoundaryMeshLocalSizing", boundary_velocity_definition.mesh_local_sizing
                )
            if boundary_velocity_definition.mesh_keep_exterior_edges:
                super().__setitem__(
                    "sourceBoundaryMeshKeepExteriorEdges",
                    boundary_velocity_definition.mesh_keep_exterior_edges,
                )
        elif isinstance(boundary_velocity_definition, str):
            boundary_velocity_definition = BoundaryVelocityLayer(
                boundary_layer_name=boundary_velocity_definition
            )
        elif boundary_velocity_definition is not None:
            logger.error(
                "Boundary velocity definition must be of type BoundaryVelocitySubmodel or BoundaryVelocityLayer."
            )

        if disable_source_correction:
            super().__setitem__("disableSourceCorrection", disable_source_correction)

        if use_wave_based_pattern:
            super().__setitem__("useWaveBasedPattern", use_wave_based_pattern)

        # Deprecated, use source_boundary_velocity instead.
        if source_boundary_layer_name:
            super().__setitem__("sourceBoundaryLayerName", source_boundary_layer_name)
        if source_boundary_mesh_local_sizing:
            super().__setitem__("sourceBoundaryMeshLocalSizing", source_boundary_mesh_local_sizing)
        if source_boundary_mesh_keep_exterior_edges:
            super().__setitem__(
                "sourceBoundaryMeshKeepExteriorEdges", source_boundary_mesh_keep_exterior_edges
            )

    def _check_azimuth_angle(self, value: float) -> float:
        if value < -360 or value > 360:
            logger.error("Azimuth must be in the range [-360, 360].")
        return value

    def _check_elevation_angle(self, value: float) -> float:
        if value < -90 or value > 90:
            logger.error("Elevation must be in the range [-90, 90].")
        return value

    @property
    def azimuth_angle(self) -> float:
        return self["azimuthAngle"]

    @azimuth_angle.setter
    def azimuth_angle(self, value: float):
        self._freeze_check()
        self["azimuthAngle"] = self._check_azimuth_angle(value)

    @property
    def elevation_angle(self) -> float:
        return self["elevationAngle"]

    @elevation_angle.setter
    def elevation_angle(self, value: float):
        self._freeze_check()
        self["elevationAngle"] = self._check_elevation_angle(value)

    @property
    def source_directivity_id(self) -> str | None:
        return self.get("sourceDirectivityId", None)

    @source_directivity_id.setter
    def source_directivity_id(self, value: SourceDirectivityObj | str):
        self._freeze_check()
        if isinstance(value, SourceDirectivityObj):
            value = value.id
        self["sourceDirectivityId"] = value

    @property
    def boundary_velocity_submodel_id(self) -> str | None:
        return self.get("boundaryVelocitySubmodelId", None)

    @boundary_velocity_submodel_id.setter
    def boundary_velocity_submodel_id(self, value: str):
        self._freeze_check()
        self["boundaryVelocitySubmodelId"] = value

    @property
    def source_boundary_layer_name(self) -> str | None:
        return self.get("sourceBoundaryLayerName", None)

    @source_boundary_layer_name.setter
    def source_boundary_layer_name(self, value: str):
        self._freeze_check()
        self["sourceBoundaryLayerName"] = value

    @property
    def source_boundary_mesh_local_sizing(self) -> float | None:
        return self.get("sourceBoundaryMeshLocalSizing", None)

    @source_boundary_mesh_local_sizing.setter
    def source_boundary_mesh_local_sizing(self, value: float):
        self._freeze_check()
        self["sourceBoundaryMeshLocalSizing"] = value

    @property
    def source_boundary_mesh_keep_exterior_edges(self) -> bool | None:
        return self.get("sourceBoundaryMeshKeepExteriorEdges", None)

    @source_boundary_mesh_keep_exterior_edges.setter
    def source_boundary_mesh_keep_exterior_edges(self, value: bool):
        self._freeze_check()
        self["sourceBoundaryMeshKeepExteriorEdges"] = value

    @property
    def disable_source_correction(self) -> bool | None:
        return self.get("disableSourceCorrection", None)

    @disable_source_correction.setter
    def disable_source_correction(self, value: bool):
        self._freeze_check()
        self["disableSourceCorrection"] = value

    @property
    def use_wave_based_pattern(self) -> bool | None:
        return self.get("useWaveBasedPattern", None)

    @use_wave_based_pattern.setter
    def use_wave_based_pattern(self, value: bool):
        self._freeze_check()
        self["useWaveBasedPattern"] = value

    def __repr__(self):
        base_repr = (
            f"SourceProperties(azimuth_angle={self.azimuth_angle}, elevation_angle={self.elevation_angle}"
        )
        if self._bv_def:
            base_repr += f", boundary_velocity_definition={self._bv_def}"
        if self.disable_source_correction is not None:
            base_repr += f", disable_source_correction={self.disable_source_correction}"
        if self.use_wave_based_pattern is not None:
            base_repr += f", use_wave_based_pattern={self.use_wave_based_pattern}"
        return base_repr + ")"

    @classmethod
    def _from_dto(cls, dto: SourcePropertiesDto) -> "SourceProperties":
        o = cls(
            azimuth_angle=float(dto.azimuthAngle or 0.0),
            elevation_angle=float(dto.elevationAngle or 0.0),
            source_directivity=dto.sourceDirectivityId,
            boundary_velocity_definition=None,
            disable_source_correction=dto.disableSourceCorrection,
            use_wave_based_pattern=dto.useWaveBasedPattern,
        )
        # Add BoundaryVelocity information if needed.
        if dto.boundaryVelocitySubmodelId:
            o.boundary_velocity_submodel_id = dto.boundaryVelocitySubmodelId
        if dto.sourceBoundaryLayerName:
            o.source_boundary_layer_name = dto.sourceBoundaryLayerName
            o.source_boundary_mesh_keep_exterior_edges = dto.sourceBoundaryMeshKeepExteriorEdges
            o.source_boundary_mesh_local_sizing = dto.sourceBoundaryMeshLocalSizing
        return o


class Source(FreezableDict):
    def __init__(
        self,
        x: float,
        y: float,
        z: float,
        source_type: SourceType,
        label: str,
        source_properties: SourceProperties = None,
        id: str = None,
        tasks: list[TaskInfoDto] = None,
    ):
        """
        Represents a Simulation source.

        :param float x: X position of source in meters.
        :param float y: Y position of source in meters.
        :param float z: Z position of source in meters.
        :param SourceType source_type: Type of source.
        :param str label: Source label.
        :param SourceProperties source_properties: Optional, additional source properties.
        """
        super().__init__()
        super().__setitem__("id", id)
        super().__setitem__("x", x)
        super().__setitem__("y", y)
        super().__setitem__("z", z)
        super().__setitem__("sourceType", source_type.value)
        super().__setitem__("label", self._validate_label(label))
        if source_properties:
            super().__setitem__("sourceProperties", source_properties)
        self._tasks = None
        if tasks:
            self._tasks = [TaskInfo(task) for task in tasks]

    def _validate_label(self, value: str) -> str:
        if not is_valid_label(value):
            logger.error(
                f"invalid source label '{value}'. source labels must be alphanumeric and may contain underscores."
            )
        return value

    @property
    def id(self) -> str:
        return self["id"]

    @property
    def location(self) -> Point3d:
        return Point3d(self.x, self.y, self.z)

    @location.setter
    def location(self, value: Point3d):
        self._freeze_check()
        self.x = value.x
        self.y = value.y
        self.z = value.z

    @property
    def orientation(self) -> Rotation | None:
        """
        Returns the rotation of the source if it has been set..
        """
        if self.source_properties and self.source_properties.azimuth_angle is not None:
            return Rotation(
                azimuth=self.source_properties.azimuth_angle, elevation=self.source_properties.elevation_angle
            )
        return None

    @orientation.setter
    def orientation(self, value: Rotation):
        """
        Sets the rotation values of the source. (Azimuth and Elevation)
        """
        self._freeze_check()
        if not self.source_properties:
            self.source_properties = SourceProperties()
        self.source_properties.azimuth_angle = value.azimuth
        self.source_properties.elevation_angle = value.elevation

    @property
    def x(self) -> float:
        return self["x"]

    @x.setter
    def x(self, value: float):
        self._freeze_check()
        self["x"] = value

    @property
    def y(self) -> float:
        return self["y"]

    @y.setter
    def y(self, value: float):
        self._freeze_check()
        self["y"] = value

    @property
    def z(self) -> float:
        return self["z"]

    @z.setter
    def z(self, value: float):
        self._freeze_check()
        self["z"] = value

    @property
    def source_type(self) -> SourceType:
        return SourceType(self["sourceType"])

    @source_type.setter
    def source_type(self, value: SourceType):
        self._freeze_check()
        self["sourceType"] = value.value

    @property
    def label(self) -> str:
        return self["label"]

    @label.setter
    def label(self, value: str):
        self._freeze_check()
        self["label"] = self._validate_label(value)

    @property
    def source_properties(self) -> SourceProperties:
        return self.get("sourceProperties", None)

    @source_properties.setter
    def source_properties(self, value: SourceProperties):
        self._freeze_check()
        self["sourceProperties"] = value

    @property
    def tasks(self) -> list[TaskInfo] | None:
        """
        Read only property containing task list associated with this source.
        """
        return self._tasks

    def pos_as_point(self) -> Point3d:
        return Point3d(self.x, self.y, self.z)

    def __repr__(self):
        return f"Source(x={self.x}, y={self.y}, z={self.z}, source_type='{self.source_type}', label='{self.label}', source_properties={self.source_properties})"

    @classmethod
    def _from_dto(cls, dto: SourceDto, freeze: bool, ignore_id: bool = False) -> "Source":
        # Populate SourceProperties if required.
        source_properties = None
        if dto.sourceProperties:
            source_properties = SourceProperties._from_dto(dto.sourceProperties)
        source_type = (
            SourceType.boundary_velocity if dto.sourceType == "Boundary" else SourceType(dto.sourceType)
        )
        source = cls(
            id=getattr(dto, "id", None) if not ignore_id else None,
            x=float(dto.x),
            y=float(dto.y),
            z=float(dto.z),
            source_type=source_type,
            label=dto.label,
            source_properties=source_properties,
            tasks=dto.tasks,
        )
        if freeze:
            source._deep_freeze()
        return source

    @classmethod
    def make_omni(
        cls,
        position: Point3d | list[float],
        label: str,
    ) -> "Source":
        """
        Shortcut to create an omni Source object.
        :param Point3d|list[float] position: Position of the source.
        :param str label: Source label.
        :returns: Source object.
        """
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            source_type=SourceType.omni,
            label=label,
        )

    @classmethod
    def make_boundary_velocity_layer(
        cls,
        label: str,
        boundary_velocity_layer: BoundaryVelocityLayer | str,
        disable_source_correction: bool = False,
    ) -> "Source":
        """
        Shortcut to create a boundary velocity Source object with boundary layer specified.
        :param str label: Source label.
        :param BoundaryVelocityLayer boundary_velocity_definition: Boundary velocity definition.
        :returns: Source object.
        """
        if isinstance(boundary_velocity_layer, str):
            bv_layer = BoundaryVelocityLayer(boundary_layer_name=boundary_velocity_layer)
        else:
            bv_layer = boundary_velocity_layer

        return cls(
            x=0,
            y=0,
            z=0,
            source_type=SourceType.boundary_velocity,
            label=label,
            source_properties=SourceProperties(
                boundary_velocity_definition=bv_layer,
                disable_source_correction=disable_source_correction,
            ),
        )

    @classmethod
    def make_boundary_velocity_submodel(
        cls,
        position: Point3d | list[float],
        orientation: Rotation,
        label: str,
        boundary_velocity_submodel: BoundaryVelocitySubmodel,
        disable_source_correction: bool = False,
    ) -> "Source":
        """
        Shortcut to create a boundary velocity Source object with SourceSubmodel.
        :param Point3d|list[float] position: Position of the source.
        :param Rotation orientation: Orientation of the source.
        :param str label: Source label.
        :param BoundaryVelocitySubmodel boundary_velocity_definition: Boundary velocity submodel.
        :returns: Source object.
        """
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            source_type=SourceType.boundary_velocity,
            label=label,
            source_properties=SourceProperties(
                azimuth_angle=orientation.azimuth,
                elevation_angle=orientation.elevation,
                boundary_velocity_definition=boundary_velocity_submodel,
                disable_source_correction=disable_source_correction,
            ),
        )

    @classmethod
    def make_directive(
        cls,
        position: Point3d | list[float],
        orientation: Rotation,
        label: str,
        source_directivity: SourceDirectivityObj | str,
        disable_source_correction: bool = False,
    ) -> "Source":
        """
        Shortcut to create a directive Source object.
        :param Point3d|list[float] position: Position of the source.
        :param Rotation orientation: Orientation of the source.
        :param str label: Source label.
        :param SourceDirectivityObj|str source_directivity: Source directivity.
        """
        if isinstance(source_directivity, SourceDirectivityObj):
            source_directivity = source_directivity.id
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            source_type=SourceType.directive,
            label=label,
            source_properties=SourceProperties(
                azimuth_angle=orientation.azimuth,
                elevation_angle=orientation.elevation,
                source_directivity=source_directivity,
                disable_source_correction=disable_source_correction,
            ),
        )

    @classmethod
    def make_cardioid(
        cls,
        position: Point3d | list[float],
        orientation: Rotation,
        label: str,
    ) -> "Source":
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            source_type=SourceType.cardioid,
            label=label,
            source_properties=SourceProperties(
                azimuth_angle=orientation.azimuth, elevation_angle=orientation.elevation
            ),
        )

    @classmethod
    def make_dipole(
        cls,
        position: Point3d | list[float],
        orientation: Rotation,
        label: str,
    ) -> "Source":
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            source_type=SourceType.dipole,
            label=label,
            source_properties=SourceProperties(
                azimuth_angle=orientation.azimuth, elevation_angle=orientation.elevation
            ),
        )
