import shutil
import uuid
from pathlib import Path
from tempfile import TemporaryDirectory


class TempFolder:
    _custom_temp_dir = None

    def __init__(self, auto_cleanup: bool = True) -> None:
        """
        Create a temporary directory that is cleaned up automatically when this goes out of scope.
        :auto_cleanup: If true this class will try to remove the temporary directory when it goes out of scope.
        """
        self.auto_cleanup = auto_cleanup
        if TempFolder._custom_temp_dir is None:
            self._temp_dir_obj = TemporaryDirectory()
            self._temp_dir = self._temp_dir_obj.name
            Path(self._temp_dir_obj.name).mkdir(exist_ok=True)
        else:
            self._temp_dir = str(TempFolder._custom_temp_dir / str(uuid.uuid4()))
            Path(self._temp_dir).mkdir(parents=True, exist_ok=True)

    @classmethod
    def set_custom_temp_dir(cls, temp_dir_path: Path):
        """
        Can be used to set a global custom base temp directory.
        This function will attempt to create the directory if it does not exist.
        :param temp_dir_path: Path to custom temporary directory.
        """
        cls._custom_temp_dir = Path(temp_dir_path)
        cls._custom_temp_dir.mkdir(parents=True, exist_ok=True)

    @property
    def temp_dir(self):
        return self._temp_dir

    def get_available_path(self, filename: str) -> Path:
        """
        Tries to give you temp_dir/filename, if that path already exists it will append a number to the filename to make it unique.
        """
        path = Path(self._temp_dir) / filename
        if not path.exists():
            return path
        i = 1
        while i < 1000:
            new_path = Path(self._temp_dir) / f"{filename}_{i}"
            if not new_path.exists():
                return new_path
            i += 1

    def __del__(self) -> None:
        if self.auto_cleanup and Path(self._temp_dir).exists():
            shutil.rmtree(self._temp_dir)
