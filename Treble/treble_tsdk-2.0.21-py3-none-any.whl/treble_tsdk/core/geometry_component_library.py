from dataclasses import dataclass
from enum import Enum
from typing import Annotated
from ..utility_classes import BoundingBox
from .. import utils
from ..treble_logging import logger
from ..client.api_models import GeometryComponentDto
from ..client.tsdk_client import TSDKClient
from ..core.temp_folder import TempFolder


class GeometryComponent:
    def __init__(self, geometry_component_dto: GeometryComponentDto, client: TSDKClient):
        self.geometry_component_dto = geometry_component_dto
        self._client = client
        self._bounding_box = None
        self._file_path = None
        self._temp_folder = None

    @property
    def id(self) -> str:
        return self.geometry_component_dto.id

    @property
    def name(self) -> str:
        return self.geometry_component_dto.name

    @property
    def description(self) -> str:
        return self.geometry_component_dto.description

    @property
    def group_name(self) -> str:
        return self.geometry_component_dto.group_name

    @property
    def layer_names(self) -> list[str]:
        return self.geometry_component_dto.layer_names

    def _load_component_data(self):
        if self._temp_folder is None:
            self._temp_folder = TempFolder()

        if self._file_path is None:
            self._file_path = self._temp_folder.get_available_path(self.id)
            url = self._client.geometry_component_library._get_url(self.id)
            if url is None:
                return None
            utils.download_file(url, self._file_path)
        return self._file_path

    def get_bounding_box(self) -> BoundingBox:
        if self._bounding_box is None:
            self._bounding_box = BoundingBox.from_json_str(self.geometry_component_dto.bounding_box_json)
        return self._bounding_box

    def suggested_materials(self):
        return self.geometry_component_dto.suggested_materials_json

    def plot(self):
        self._load_component_data()
        if self._file_path:
            if m := utils.try_load_treble_module("geometry.plot"):
                m._plot_model_file(self._file_path)
        else:
            logger.error(f"Could not plot geometry component {self.id}, unable to load geometry data.")

    def __repr__(self):
        return f"GeometryComponent(id={self.id}, name={self.name}, group_name={self.group_name})"


class ComponentSelectionAlgorithm(str, Enum):
    """
    Algorithm for selecting components.
    """

    random: Annotated[str, "Select components at random from the list."] = "random"
    ordered_single: Annotated[
        str,
        "Try place components in order from their list, try add one element instance before moving on to the next.",
    ] = "ordered_single"
    ordered_all: Annotated[
        str,
        "Try place all components in order from their list, exhausting each element until moving on to the next.",
    ] = "ordered_all"


@dataclass
class ComponentAnglePool:
    allowed_angle_pool: list[int] = None

    def __post_init__(self):
        if not self.allowed_angle_pool:
            raise ValueError("Allowed angle pool cannot be empty.")
        if any([angle < 0.0 or angle > 360.0 for angle in self.allowed_angle_pool]):
            raise ValueError("All angles must be between 0 and 360 degrees.")

    @staticmethod
    def from_min_max(min_angle: int, max_angle: int):
        if min_angle >= max_angle:
            raise ValueError("Minimum angle must be less than maximum angle.")
        if min_angle < 0 or min_angle > 360:
            raise ValueError("Minimum angle must be between 0 and 360 degrees.")
        if max_angle <= 0 or max_angle >= 360:
            raise ValueError("Maximum angle must be between 0 and 360 degrees.")
        return ComponentAnglePool(allowed_angle_pool=list(range(int(min_angle), int(max_angle) + 1)))


@dataclass
class GeometryComponentPlacement:
    """
    Class to define a component placement
    :param component: Component to place, algorithm will select one component from the list at random each time it tries to place from this GeometryComponentPlacement.
    :param preferred_count: Preferred number of instances to place, note: this does not guarantee that this number of instances will be placed.
    :param min_dist_from_walls: Minimum distance from walls in meters
    :param min_dist_from_objects: Minimum distance from other objects in meters
    """

    components: list[GeometryComponent]
    preferred_count: int = 1
    min_dist_from_walls: float = 0.1
    min_dist_from_objects: float = 0.2
    rotation_settings: ComponentAnglePool = None

    def __post_init__(self):
        if not self.components:
            raise ValueError("Components list cannot be empty.")
        if self.preferred_count < 1:
            raise ValueError("Preferred count must be greater than 0.")
        if isinstance(self.components, GeometryComponent):
            self.components = [self.components]
