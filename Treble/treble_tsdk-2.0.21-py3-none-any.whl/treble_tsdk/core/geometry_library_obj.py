from enum import Enum
from zipfile import ZipFile

from treble_tsdk.core.material_obj import Material
from .. import utils
from ..core.model_obj import MaterialAssignment
from ..client.api_models import GeometryLibraryDto, MaterialAssignmentDto, MaterialDto, PositionSuggestionDto
from ..client.tsdk_client import TSDKClient
from pathlib import Path
import math
import json
from .temp_folder import TempFolder
from ..treble_logging import logger
from ..utility_classes import Point3d, Rotation, View2d


class GeometryLibraryDataset(str, Enum):
    """
    Available categories for geometry library.
    """

    meeting_room = "MeetingRoom"

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))

    @classmethod
    def print(cls):
        print("Available geometry datasets")
        for c in cls:
            print(f" - {c.value}")


class PositionSuggestion:
    def __init__(self, dto: PositionSuggestionDto):
        self._dto = dto
        self._position = Point3d(*dto.position)
        if dto.azimuth_angle is None:
            self._rotation = None
        else:
            self._rotation = Rotation(
                azimuth=dto.azimuth_angle or 0.0,
                elevation=dto.elevation_angle or 0.0,
                roll=dto.roll_angle or 0.0,
            )

    @property
    def position(self) -> Point3d:
        return self._position

    @property
    def orientation(self) -> Rotation | None:
        """
        Returns rotation if available, otherwise None.
        """
        return self._rotation

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def space(self) -> str:
        return self._dto.space

    def __repr__(self) -> str:
        rotation_str = ""
        if self._rotation:
            rotation_str = f", orientation={self.orientation}"
        return f"PositionSuggestion(name={self.name}, space={self.space}, position={self.position}{rotation_str})"

    def __str__(self) -> str:
        return self.__repr__()


class GeometryLibraryObj:
    """
    Object used for representing geometries from the geometry library.
    """

    def __init__(self, geometryDto: GeometryLibraryDto, client: TSDKClient, lazy: bool = True):
        self._dto = geometryDto
        self._client = client
        self._model_file_path = None
        self._temp_dir = None
        self._position_suggestions = (
            [PositionSuggestion(p) for p in geometryDto.positionSuggestions]
            if geometryDto.positionSuggestions != None
            else []
        )
        if geometryDto.metadata:
            self._metadata = json.loads(geometryDto.metadata)
        else:
            self._metadata = None
        self.lazy_loaded = lazy

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def description(self) -> str:
        return self._dto.description

    @property
    def dataset(self) -> str:
        return self._dto.dataset

    @property
    def metadata(self) -> dict:
        if self.lazy_loaded:
            self._load_full_instance()
        return self._metadata

    @property
    def volumeM3(self) -> float:
        return self._dto.volumeM3

    @property
    def layer_names(self) -> list[str] | None:
        if self.lazy_loaded:
            self._load_full_instance()
        return self._dto.layer_names

    @property
    def position_suggestions(self) -> list[PositionSuggestion]:
        if self.lazy_loaded:
            self._load_full_instance()
        return self._position_suggestions

    def _has_valid_local_file(self, download_if_missing: bool = False) -> bool:
        # Check if the .3dm file representing the geometry is available locally.
        if (
            self._model_file_path is not None
            and self._model_file_path
            and Path(self._model_file_path).is_file()
            and self._original_file_hash
        ):
            # Found geometry file, verify the file is still valid.
            new_hash = utils.calculate_file_hash(self._model_file_path)
            if self._original_file_hash == new_hash:
                return True
        if download_if_missing:
            if self._temp_dir is None:
                self._temp_dir = TempFolder()
            geometry_file = self._download_local_file()
            if geometry_file.endswith(".zip"):
                # Extract 3dm file.
                with ZipFile(str(geometry_file), "r") as zip_obj:
                    # Find geometry model
                    geometry_member = [
                        member for member in zip_obj.filelist if member.filename.endswith(".3dm")
                    ][0]
                    zip_obj.extract(geometry_member, self._temp_dir.temp_dir)
                    self._model_file_path = f"{self._temp_dir.temp_dir}/{geometry_member.filename}"
                self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
            else:
                # Geometry was not compressed
                self._model_file_path = geometry_file
                self._original_file_hash = utils.calculate_file_hash(self._model_file_path)
            return True
        return False

    def _download_local_file(self) -> str | None:
        """
        Download model to destination file.

        :param str destination_directory: Directory to download to.
        :returns str: Path to downloaded file or None if unable to download file.
        """
        download_info = self._client.geometry_library.get_download_url(self._dto.id)
        if download_info is None:
            logger.warning(f"Unable to download geometry {self.id}!")
            return None
        destination_file = f"{self._temp_dir.temp_dir}/{download_info.filename}"
        utils.download_file(download_info.downloadUrl, destination_file)
        return destination_file

    def plot(self, view_2d: View2d = None):
        """
        Uses the plot module to plot the geometry object.
        :param view_2d: Show a 2d view, choose between None, View2d.xy, View2d.xz, View2d.yz. Optional, defaults to false.
        """
        if m := utils.try_load_treble_module("geometry.plot"):
            if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
                m.plot_geometry(self)
            else:
                m.plot_geometry_dash(self, view_2d)

    def calculate_sabine_estimate(
        self,
        material_assignments: list[MaterialAssignment | MaterialAssignmentDto],
        model_volume: float = None,
    ) -> list[float]:
        """
        Calculates the sabine estimate of the reverberation time based on layer material assignment.

        :param list[MaterialAssignment|MaterialAssignmentDto] material_assignment: Layer material assignment for model to calculate the estimate on.
        :param float model_volume: Optional, If no model volume is input the model volume will be computed from the input objects. If a geometry without a closed shell is input the model_volume has to be specified.
        :returns list[float]: List of the sabine estimated RT for each frequency range valid for materials (63, 125, 250, 500, 1k, 2k, 4k, 8k).
        """
        if self.lazy_loaded:
            self._load_full_instance()

        if self._dto.geometryObjectInfo is None:
            raise ValueError("Unable to calculate sabine estimate on model, geometry object data is missing!")

        if model_volume is None:
            model_volume = self._compute_model_volume()

        if model_volume <= 0:
            raise ValueError("Calculated model volume is 0, unable to calculate sabine estimate!")

        def get_absorption_coefficients(mat) -> list[float]:
            if isinstance(mat, MaterialDto):
                return mat.absorptionCoefficients
            elif isinstance(mat, Material):
                return getattr(mat, "absorption_coefficients", None)
                return mat.absorption_coefficients
            elif isinstance(mat, str):
                get_mat = self._client.material.get_material_by_id(mat)
                if get_mat:
                    return get_mat.absorptionCoefficients
                else:
                    raise ValueError(f"Unable to find material with id {mat}")
            else:
                raise ValueError(f"Unknown material type {type(mat)}")

        # Get bands and absorption coefficients.
        if isinstance(material_assignments[0], MaterialAssignmentDto):
            # Assume MaterialAssignmentDto objects, need to populate material information.
            layer_to_absorption = {
                dto.layerName: get_absorption_coefficients(dto.materialId) for dto in material_assignments
            }
        else:
            # Assume MaterialAssignment objects.
            layer_to_absorption = {
                a.layer_name: get_absorption_coefficients(a._material or a.material_id)
                for a in material_assignments
            }
        n_bands = len(list(layer_to_absorption.values())[0])

        absorption_areas = [0] * n_bands
        for object_id in self._dto.geometryObjectInfo.keys():
            object_info = self._dto.geometryObjectInfo[object_id]
            surface_area = object_info.surfaceArea
            if object_info.groupType == 3:
                surface_area *= 2  # Multiplying by 2 here to add the back of the open surfaces
            for i_band in range(n_bands):
                absorption_areas[i_band] += surface_area * layer_to_absorption[object_info.layerName][i_band]

        sabine_rt = [0.161 * model_volume / abs_area for abs_area in absorption_areas]
        if max(sabine_rt) > 50:
            return [math.nan] * n_bands
        return sabine_rt

    def _compute_model_volume(self):
        if self.lazy_loaded:
            self._load_full_instance()

        model_volume = 0
        for group_id, group_volume in self._dto.geometryGroupTypeToVolume.items():
            if group_id in ["1", "2"]:
                model_volume += group_volume
        return model_volume

    def as_tree(self):
        """
        Uses the display_data module to display geometry library object as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)

    def _load_full_instance(self):
        tmp_dto = self._client.geometry_library.get_single(self.id)
        tmp_obj = GeometryLibraryObj(tmp_dto, self._client)
        self.__class__ = tmp_obj.__class__
        self.__dict__ = tmp_obj.__dict__
        self.lazy_loaded = False

    def __repr__(self):
        return f"GeometryLibraryObj(name='{self.name}', dataset='{self.dataset}', id='{self.id}')"
