from enum import Enum
from ..client.api_models import ObjectMetadataDto
from ..client.tsdk_client import TSDKClient
from ..treble_logging import logger


class ObjectMetadata(dict[str, str]):
    class _MetadataOwnerType(str, Enum):
        project = "Project"
        model = "Model"
        simulation = "Simulation"

    def __init__(
        self,
        client: TSDKClient,
        client_params: dict[str, str],
        owner_type: _MetadataOwnerType,
        metadata: ObjectMetadataDto,
    ):
        self._client = client
        self._client_params = client_params
        self._owner_type = owner_type
        self._owner_client = self._get_owner_client()
        self._has_changes = False  # Track if anything has changed.
        self._id = None
        self._updatedAt = None
        if metadata:
            self._id = metadata.id
            self._updatedAt = metadata.updatedAt
            super().__init__(metadata.keyValuePairs)

    def __setitem__(self, key: str, value: str) -> None:
        # Enforce that both key and value are strings
        if not isinstance(key, str):
            raise TypeError("Key must be a string")
        if not isinstance(value, str):
            raise TypeError("Value must be a string")
        if key.startswith("__treble"):
            raise KeyError("Keys starting with '__treble' are reserved for internal use.")
        if key in self and self[key] == value:
            # No need to update if we are setting the same value again.
            return
        self._has_changes = True
        super().__setitem__(key, value)

    def _key_count_ok(self):
        """Maximum allowed key count is 128."""
        keys_count = len(self.keys())
        if keys_count > 128:
            logger.error(f"Too many metadata keys. Max key count is 128. Current keycount is {keys_count}")
            return False
        return True

    def _payload_size_ok(self):
        """Check if the metadata size is within the limits."""
        metadata_length = len(str(self))
        if metadata_length > 16000:
            logger.error(
                f"Metadata size is too large. Max payload is 16000 characters. Current size is {metadata_length}"
            )
            return False
        return True

    def _get_owner_client(self):
        if self._owner_type == ObjectMetadata._MetadataOwnerType.project:
            return self._client.project
        elif self._owner_type == ObjectMetadata._MetadataOwnerType.model:
            return self._client.model
        elif self._owner_type == ObjectMetadata._MetadataOwnerType.simulation:
            return self._client.simulation
        else:
            raise ValueError(f"Invalid metadata owner type: {self._owner_type}")

    def _try_sync_metadata(self) -> bool:
        """
        Tries to sync metadata with the server. Only works if there are no conflicting changes
        between the local and remote metadata.

        :return bool: True if syncing was successful, False otherwise
        """
        remote = self._owner_client.get_metadata(**self._client_params)
        if remote and remote.updatedAt != self._updatedAt:
            logger.info("Metadata has been updated by another user. Attempting to sync metadata.")
            all_keys = set(self.keys()).union(remote.keyValuePairs.keys())
            merged_metadata = {}
            for key in all_keys:
                if key in self and key in remote.keyValuePairs:
                    if self[key] == remote.keyValuePairs[key]:
                        merged_metadata[key] = self[key]
                    else:
                        logger.warning(
                            f"Metadata key {key} has been updated by another user. Unable to save without syncing."
                        )
                        return False
                elif key in self:
                    merged_metadata[key] = self[key]
                elif key in remote.keyValuePairs:
                    merged_metadata[key] = remote.keyValuePairs[key]
            self.clear()
            self.update(merged_metadata)
            self._updatedAt = remote.updatedAt
        return True

    def sync(self, keep_local_values: bool = False):
        res = self._owner_client.get_metadata(**self._client_params)
        if res:
            remote_updated_at = res.updatedAt
            if remote_updated_at != self._updatedAt:
                logger.info("Metadata has been updated by another user. Syncing metadata.")
                self._updatedAt = remote_updated_at
                for key in res.keyValuePairs.keys():
                    if not keep_local_values or key not in self:
                        logger.info(f"New or updated metadata key {key}")
                        self[key] = res.keyValuePairs[key]
            else:
                logger.info("Metadata is up to date.")

    def save(self) -> bool:
        if not self._has_changes:
            return True

        if self._try_sync_metadata() == False:
            return False

        if not self._key_count_ok():
            return False

        if not self._payload_size_ok():
            return False

        self._updatedAt = self._owner_client.update_metadata(metadata=self, **self._client_params)
        self._has_changes = False
        return True
