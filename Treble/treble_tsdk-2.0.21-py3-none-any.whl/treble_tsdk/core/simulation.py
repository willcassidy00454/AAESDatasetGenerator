from __future__ import annotations

import glob
import json
import os
import shutil
import time
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING

import h5py

from ..treble_logging import logger

if TYPE_CHECKING:
    from ..results.simulation_result_obj import SimulationResultObject

from .. import utils
from ..client.api_models import (
    CancelSimulationDto,
    CancelTaskDto,
    GaSettingsDto,
    GpuCountRangeDto,
    MaterialDto,
    MesherSettingsDto,
    ModelDto,
    ObjectMetadataDto,
    ResultStatusDto,
    SimulationDto,
    SimulationEstimateDto,
    SimulationMeshInfoDto,
    SimulationProgressDto,
    SimulationSettingsDto,
    SourceDto,
    SourceResultDto,
)
from ..client.tsdk_client import TSDKClient
from ..utility_classes import View2d
from .geometry_library_obj import GeometryLibraryObj
from .mesh_obj import SimulationMeshInfoCollection
from .model_obj import LocalMeshSizing, MaterialAssignment, ModelObj
from .object_metadata import ObjectMetadata
from .receiver import Receiver, ReceiverType
from .source import Source, SourceEstimate

if TYPE_CHECKING:
    from ..results import Results


class SimulationProgressInfo:
    def __init__(self, dto: SimulationProgressDto, client: TSDKClient):
        self._dto = dto
        self._sources = []
        if hasattr(self._dto, "sources"):
            self._sources = [Source._from_dto(s, freeze=True) for s in self._dto.sources]

    @property
    def simulation_id(self) -> str:
        return self._dto.simulationId

    @property
    def simulation_name(self) -> str:
        return self._dto.simulationName

    @property
    def simulation_status(self) -> str:
        return self._dto.simulationStatus

    @property
    def simulation_progress_percentage(self) -> float:
        return self._dto.simulationProgressPercentage

    @property
    def project_id(self) -> str:
        return self._dto.projectId

    @property
    def project_name(self) -> str:
        return self._dto.projectName

    @property
    def sources(self) -> list[Source]:
        return self._sources

    def __repr__(self):
        # I'll put this in a try -> except as it would be annoying to have this fail
        try:
            n_sources = len(self.sources)
            sources_completed = 0
            return_string = f"Simulation status: {self.simulation_status}"
            if self.simulation_status != "InProgress":
                for source in self.sources:
                    tasks_done = True
                    for task in source.tasks:
                        return_string += f"\n{task.name}: {task.status}"
                        if task.status != "Completed":
                            tasks_done = False
                            if task.status in ["InProgress", "Running"]:
                                return_string += f" {task.progress_percentage}% done"
                    if tasks_done:
                        sources_completed += 1
                return_string += f"\n {(sources_completed / n_sources) * 100:.1f}% of sources completed"
        except Exception as e:
            # Fallback option is the __str__ method
            return_string = self.__str__()

        return return_string

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)

    def as_tree(self):
        """
        Uses the display_data module to display material info as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)


class CancelSimulationResult:
    def __init__(self, dto: CancelSimulationDto):
        self._dto = dto

    @property
    def result_status(self) -> ResultStatusDto:
        return self._dto.resultStatus

    @property
    def simulation_id(self) -> str:
        return self._dto.simulationId

    @property
    def simulation_name(self) -> str:
        return self._dto.simulationName

    @property
    def simulation_status(self) -> SimulationStatus:
        return SimulationStatus(self._dto.simulationStatus)

    @property
    def cancelled_tasks(self) -> list[CancelTaskDto]:
        return self._dto.cancelledTasks

    def __repr__(self):
        return (
            f"CancelSimulationResult(simulation_id='{self.simulation_id}', "
            f"simulation_name='{self.simulation_name}', "
            f"simulation_status='{self.simulation_status}', "
            f"result_status={self.result_status.__repr__()}, "
            f"cancelled_tasks_count={len(self.cancelled_tasks)})"
        )

    def as_tree(self):
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)


class SimulationBasicInfo:
    def __init__(self, dto: SimulationDto):
        self.id = dto.id
        self.name = dto.name
        self.description = dto.description
        self.simulation_type = dto.simulationType
        self.status = getattr(dto, "status", None)
        self.created_at = dto.createdAt

    def __repr__(self):
        return (
            f"SimulationBasicInfo(id='{self.id}', "
            f"name='{self.name}', "
            f"description='{self.description}', "
            f"simulation_type='{self.simulation_type}', "
            f"status='{self.status}', "
            f"created_at='{self.created_at}')"
        )


class SimulationEstimate:
    def __init__(self, dto: SimulationEstimateDto):
        self._dto = dto
        self._estimate_per_source = []
        if hasattr(self._dto, "estimatePerSource"):
            self._estimate_per_source = [SourceEstimate(s) for s in self._dto.estimatePerSource]

    @property
    def simulation_id(self) -> str:
        return self._dto.simulationId

    @property
    def simulation_name(self) -> str:
        return self._dto.simulationName

    @property
    def simulation_status(self) -> str:
        return self._dto.simulationStatus

    @property
    def total_estimated_runtime_hours(self) -> float:
        return self._dto.totalEstimatedRuntimeHours

    @property
    def total_estimated_cost_in_tokens(self) -> float:
        return self._dto.totalEstimatedCostInTokens

    @property
    def estimate_per_source(self) -> list[SourceEstimate]:
        return self._estimate_per_source

    @property
    def result_status(self) -> ResultStatusDto:
        return self._dto.resultStatus

    @property
    def supported_gpu_counts(self) -> GpuCountRangeDto | None:
        return self._dto.supportedGpuCounts

    def __repr__(self):
        return (
            f"SimulationEstimate(simulation_id='{self.simulation_id}', "
            f"simulation_name='{self.simulation_name}', "
            f"total_estimated_runtime_hours={self.total_estimated_runtime_hours}, "
            f"total_estimated_cost_in_tokens={self.total_estimated_cost_in_tokens}, "
            f"result_status={self.result_status.__repr__()}, "
            f"supported_gpu_counts={self.supported_gpu_counts.__repr__()})"
        )

    def as_tree(self):
        """
        Uses the display_data module to display estimate information as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)


class GaSolverType(str, Enum):
    """
    Available solver types.
    """

    ray_radiosity = "IsmPressureRayRadiosity"
    volumetric_raytracing = "IsmPressureVolumetricReceiver"

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))

    @classmethod
    def print(cls):
        print("Available solver types")
        for c in cls:
            print(f" - {c.value}")


class SimulationStatus(str, Enum):
    created = "Created"
    starting = "Starting"
    queued = "Queued"
    in_progress = "InProgress"
    processing_results = "ProcessingResults"
    completed = "Completed"
    completed_with_source_errors = "CompletedWithSourceErrors"
    cancelled = "Cancelled"
    error = "Error"
    material_assignment_error = "MaterialAssignmentError"
    mesher_error = "MesherError"
    not_enough_resources_error = "NotEnoughResourcesError"
    dispatch_error = "DispatchError"

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))

    @classmethod
    def print(cls):
        print("Available simulation statuses")
        for c in cls:
            print(f" - {c.value}")

    @staticmethod
    def is_final_status(status: "SimulationStatus" | str) -> bool:
        s = getattr(status, "value", status)
        return s in [
            "Completed",
            "CompletedWithSourceErrors",
            "Cancelled",
            "Error",
            "DispatchError",
            "MaterialAssignmentError",
            "MesherError",
            "NotEnoughResourcesError",
        ]


class SolveTaskStatus(str, Enum):
    unknown = "Unknown"
    created = "Created"
    queued = "Queued"
    provisioning = "Provisioning"
    running = "Running"
    completed = "Completed"
    error = "Error"
    cancelled = "Cancelled"
    dispatch_error = "DispatchError"

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))

    @classmethod
    def print(cls):
        print("Available task statuses")
        for c in cls:
            print(f" - {c.value}")

    @staticmethod
    def is_final_status(status: "SimulationStatus" | str) -> bool:
        s = getattr(status, "value", status)
        return s in [
            "Completed",
            "Cancelled",
            "Error",
            "DispatchError",
        ]

    @staticmethod
    def is_queued_status(status: "SimulationStatus" | str) -> bool:
        s = getattr(status, "value", status)
        return s == "Queued"

    @staticmethod
    def is_running_status(status: "SimulationStatus" | str) -> bool:
        s = getattr(status, "value", status)
        return s in [
            "Provisioning",
            "Running",
        ]


class ResultRenameRule(str, Enum):
    """
    Rename rules for results.
    """

    none = "none"
    by_label = "by_label"


class ResultDataFilter(str, Enum):
    """
    Available filters for results
    """

    none = "none"
    ir = "ir"


class GpuAllocationStrategy(str, Enum):
    # Use the default GPU allocation strategy. (Currently GPUCountOptimized)
    default = "default"

    # Use as much GPU memory as possible before allocating more GPUs.
    gpu_count_optimized = "gpuCountOptimized"

    # Add more GPUs when we know we can utilize 80-90%+ of allocated GPUs.
    utilization_optimized = "utilizationOptimized"


class SimulationType(str, Enum):
    """
    Available simulation types.
    """

    hybrid = "Hybrid"
    dg = "DG"
    ga = "GA"
    wave_based = "DG"
    geometrical = "GA"


class ResultType(str, Enum):
    """
    Available result types.
    """

    hybrid = "Hybrid"
    dg = "DG"
    ga = "GA"
    wave_based = "DG"
    geometrical = "GA"
    device_rendering = "DeviceRendering"


class SimulationOnTaskError(str, Enum):
    """
    Available Simulation "on task error" behaviours.
    """

    ignore = "Ignore"
    stop_simulation = "StopSimulation"
    stop_project = "StopProject"


class DgSolverSettings(utils.FreezableDict):
    def __init__(self):
        super().__init__()
        # No custom settings exposed here yet.
        pass

    @classmethod
    def _from_dto(cls, dto: "DgSettingsDto", freeze: bool):
        o = cls()
        if freeze:
            o._deep_freeze()
        return o


class GaSolverSettings(utils.FreezableDict):
    def __init__(
        self,
        number_of_rays: int = 50000,
        ism_order: int = 2,
        air_absorption: bool = True,
        ism_ray_count: int = 500_000,
        solver_type: GaSolverType = GaSolverType.ray_radiosity,
    ):
        """
        Custom settings for the geometrical acoustics (GA) solver.

        :param int number_of_rays: Number of rays to use in GA.
            defaults to 5000
        :param int ism_order: Image source method order to use in GA.
            defaults to 2
        :param bool air_absorption: Whether to include air absorption in GA simulation,
            defaults to True
        :param int ism_ray_count: How many rays are used in the image source pre-visibility check,
            accepted range is between 1000 and 5_000_000
        :param bool write_out_ism_raypaths: Save raypaths and pressure_per_reflection from ism
        :param GaSolverType solver_type: Type of GA solver
        """
        super().__init__()
        super().__setitem__("numberOfRays", int(number_of_rays))
        super().__setitem__("ismOrder", int(ism_order))
        super().__setitem__("isAirAbsorptionActive", bool(air_absorption))
        assert (
            1000 <= ism_ray_count <= 5_000_000
        ), f"ism_ray_count needs to be between 1000 and 5000000. Your input: {ism_ray_count}"
        super().__setitem__("ismRayCount", int(ism_ray_count))
        super().__setitem__("gaSolverType", solver_type.value)

    @property
    def number_of_rays(self) -> int:
        return self["numberOfRays"]

    @number_of_rays.setter
    def number_of_rays(self, value: int):
        self._freeze_check()
        self["numberOfRays"] = value

    @property
    def ism_order(self) -> int:
        return self["ismOrder"]

    @ism_order.setter
    def ism_order(self, value: int):
        self._freeze_check()
        self["ismOrder"] = value

    @property
    def air_absorption(self) -> bool:
        return self["isAirAbsorptionActive"]

    @air_absorption.setter
    def air_absorption(self, value: bool):
        self._freeze_check()
        self["isAirAbsorptionActive"] = value

    @property
    def ism_ray_count(self) -> int:
        return self["ismRayCount"]

    @ism_ray_count.setter
    def ism_ray_count(self, value: int):
        self._freeze_check()
        self["ismRayCount"] = value

    @classmethod
    def _from_dto(cls, dto: GaSettingsDto, freeze: bool):
        o = cls(
            number_of_rays=dto.numberOfRays,
            ism_order=dto.ISMOrder,
            air_absorption=dto.isAirAbsorptionActive,
            ism_ray_count=dto.ISMRayCount,
            solver_type=GaSolverType(dto.gaSolverType),
        )
        if freeze:
            o._deep_freeze()
        return o


class SimulationSettings(utils.FreezableDict):
    def __init__(
        self,
        speed_of_sound: float = 343.0,
        ga_settings: GaSolverSettings = None,
        dg_settings: DgSolverSettings = None,
        ambisonics_order: int = None,
        ir_shift_seconds: float = None,
        gpu_count: int = None,
        dev_blob: str = None,
        free_field_removal_max_distance: float = None,
    ):
        """
        Advanced simulation settings.

        :param float speed_of_sound: SpeedOfSound (m/s) in medium.
        :param GaSolverSettings ga_settings: Settings specific to the GA solver.
        :param DgSolverSettings dg_settings: Settings sepcific to the DG solver.
        :param ambisonics_order: Spatial receivers ambisonics order, allowed values: [1, 2, 4, 8, 16]
        :param float ir_shift_seconds: Shift the IRs and effectively pad the beginning of them to allow for the source correction and postprocessing create more accurate results.
        :param int gpu_count: Sets the number of GPUs to allocate for each wave-solver task in the simulation.
        :param float free_field_removal_max_distance: If a nonzero value is given, the free field response / direct sound is removed from the response within the given distance. In GA solver, the direct sound is simply skipped in the image source method response, but in the DG solver the analytical free field response of the source is subtracted from the signal in postprocessing. This distance should always be set lower than the minimum distance to any obstructing objects in the space. This is not validated in the simulation, so use with caution!
        """
        super().__init__()
        if speed_of_sound:
            super().__setitem__("speedOfSound", speed_of_sound)
        if ga_settings:
            super().__setitem__("gaSettings", ga_settings)
        if dg_settings:
            super().__setitem__("dgSettings", dg_settings)
        if ambisonics_order:
            super().__setitem__("ambisonicsOrder", ambisonics_order)
        if ir_shift_seconds:
            super().__setitem__("irShiftSeconds", ir_shift_seconds)
        if gpu_count:
            super().__setitem__("gpuCount", gpu_count)
        if dev_blob:
            super().__setitem__("devBlob", dev_blob)
        if free_field_removal_max_distance:
            super().__setitem__("freeFieldRemovalMaxDistance", free_field_removal_max_distance)

    @property
    def speed_of_sound(self) -> float:
        return self.get("speedOfSound", None)

    @speed_of_sound.setter
    def speed_of_sound(self, value: float):
        self._freeze_check()
        self["speedOfSound"] = value

    @property
    def ga_settings(self) -> GaSolverSettings:
        return self.get("gaSettings", None)

    @ga_settings.setter
    def ga_settings(self, value: GaSolverSettings):
        self._freeze_check()
        self["gaSettings"] = value

    @property
    def dg_settings(self) -> DgSolverSettings:
        return self.get("dgSettings", None)

    @dg_settings.setter
    def dg_settings(self, value: DgSolverSettings):
        self._freeze_check()
        self["dgSettings"] = value

    @property
    def ambisonics_order(self) -> int | None:
        """
        Gets the default ambisonics order for spatial receivers. If no ambisonics order is set for a spatial receiver it defaults to 2.
        """
        return self.get("ambisonicsOrder", None)

    @ambisonics_order.setter
    def ambisonics_order(self, value: int):
        self._freeze_check()
        self["ambisonicsOrder"] = value

    @property
    def ir_shift_seconds(self) -> float:
        return self.get("irShiftSeconds", None)

    @ir_shift_seconds.setter
    def ir_shift_seconds(self, value: float):
        self._freeze_check()
        self["irShiftSeconds"] = value

    @property
    def gpu_count(self) -> int:
        return self.get("gpuCount", None)

    @gpu_count.setter
    def gpu_count(self, value: int):
        self._freeze_check()
        self["gpuCount"] = value

    @property
    def freefield_removal_max_distance(self) -> float:
        return self.get("freeFieldRemovalMaxDistance", None)

    @freefield_removal_max_distance.setter
    def freefield_removal_max_distance(self, value: float):
        self._freeze_check()
        self["freeFieldRemovalMaxDistance"] = value

    @classmethod
    def _from_dto(cls, dto: SimulationSettingsDto, freeze: bool):
        o = cls(
            speed_of_sound=getattr(dto, "speedOfSound", None),
            ga_settings=(
                GaSolverSettings._from_dto(dto.gaSettings, freeze=freeze)
                if getattr(dto, "gaSettings", None)
                else None
            ),
            dg_settings=(
                DgSolverSettings._from_dto(dto.dgSettings, freeze=freeze)
                if getattr(dto, "dgSettings", None)
                else None
            ),
            ambisonics_order=getattr(dto, "ambisonicsOrder", None),
            ir_shift_seconds=getattr(dto, "irShiftSeconds", None),
            gpu_count=getattr(dto, "gpuCount", None),
            free_field_removal_max_distance=getattr(dto, "freeFieldRemovalMaxDistance", None),
            dev_blob=getattr(dto, "devBlob", None),
        )
        if freeze:
            o._deep_freeze()
        return o


class MesherSettings(utils.FreezableDict):
    def __init__(self, simplify_mesh: bool = True):
        """
        Advanced mesher settings.

        :param bool simplify_mesh: Can be used to stop mesher from performing simplification on the mesh structure.
        """
        super().__init__()
        if simplify_mesh is not None:
            super().__setitem__("simplifyMesh", simplify_mesh)

    @classmethod
    def _from_dto(cls, dto: MesherSettingsDto, freeze: bool):
        o = cls(simplify_mesh=dto.simplifyMesh)
        if freeze:
            o._deep_freeze()
        return o


class SimulationDefinition:
    def __init__(
        self,
        name: str,
        simulation_type: SimulationType,
        model: ModelDto | ModelObj | GeometryLibraryObj,
        receiver_list: list[Receiver],
        source_list: list[Source],
        material_assignment: list[MaterialAssignment],
        crossover_frequency: int = None,
        ir_length: float = None,
        energy_decay_threshold: float = None,
        simulation_settings: SimulationSettings = SimulationSettings(ambisonics_order=2),
        on_task_error: SimulationOnTaskError = "Ignore",
        description: str = None,
        local_mesh_sizing: list[LocalMeshSizing] = None,
        mesher_settings: MesherSettings = None,
        metadata: dict[str, str] | ObjectMetadataDto | ObjectMetadata = None,
    ):
        """
        Define simulation information that can be used to create a Simulation object later on.

        :param str name: Name of simulation
        :param SimulationType simulation_type: Type of simulation: dg, ga or hybrid.
        :param str|ModelDto|ModelObj|GeometryLibraryObj model: Model to be used by simulation. Can either be model id, ModelDto, ModelObj or GeometryLibraryObj.
        :param int crossover_frequency: Crossover frequency from DG to GA.
        :param float ir_length: Impulse response length in sec.
        :param list[Receiver|dict] receiver_list: List of Receiver objects.
        :param list[Source|dict] source_list: List of Source objects.
        :param list[MaterialAssignment|dict] material_assignment: List of material assignment objects.
        :param float energy_decay_threshold: Energy decay threshold in dB
        :param SimulationSettings simulation_settings: Optional custom simulation settings.
        :param SimulationOnTaskError on_task_error: Optional on task error behaviour. Defaults to "ignore".
        :param str description: Optional description of simulation.
        :param list[LocalMeshSizing] local_mesh_sizing: List of local mesh sizing object, used to control the mesh quality of individual elements in a simulation. Can be applied to any number of layers in a simulation.
        """
        if ir_length is None and energy_decay_threshold is None:
            raise ValueError("Either ir_length or energy_decay_threshold must have a value")

        if not isinstance(model, (ModelDto, ModelObj, GeometryLibraryObj, str)):
            raise TypeError(
                f"model must be one of (ModelDto, ModelObj, GeometryLibraryObj), got {type(model).__name__}."
            )

        if simulation_settings and not isinstance(
            simulation_settings, (SimulationSettings, SimulationSettingsDto)
        ):
            raise TypeError(
                f"simulation_settings must be an instance of SimulationSettings, got {type(simulation_settings).__name__}."
            )

        if not utils.is_valid_label(name):
            raise ValueError(
                f"Invalid simulation name '{name}'. Name must be alphanumeric and can contain underscores."
            )

        if simulation_type != SimulationType.ga and not crossover_frequency:
            raise ValueError("Crossover frequency is required for DG and Hybrid simulations")
        if not crossover_frequency:
            # In case of GA, set lowest possible crossover frequency.
            crossover_frequency = 25

        self._check_material_assignment(model, material_assignment)

        self.name = name
        self.simulation_type = simulation_type
        self.model = model
        self.crossover_frequency = crossover_frequency
        self.receiver_list = receiver_list
        self.source_list = source_list
        self.material_assignment = material_assignment
        self.ir_length = ir_length
        self.energy_decay_threshold = energy_decay_threshold
        self.simulation_settings = simulation_settings
        self.on_task_error = on_task_error
        self.description = description
        self.local_mesh_sizing = local_mesh_sizing
        self.mesher_settings = mesher_settings
        if metadata is None:
            metadata = {}
        elif isinstance(metadata, ObjectMetadataDto):
            # Get data as dict[str, str]
            metadata = metadata.keyValuePairs
        self.metadata = metadata

    def to_dto(self) -> SimulationDto:
        # Save original geometry library id if available (used for mesh caching)
        original_geometry_library_id = None
        if self.model and hasattr(self.model, "_dto"):
            if isinstance(self.model, ModelObj) and self.model._dto.geometryLibraryId:
                original_geometry_library_id = self.model._dto.geometryLibraryId
            elif isinstance(self.model, GeometryLibraryObj) and self.model._dto.id:
                original_geometry_library_id = self.model._dto.id
        return SimulationDto(
            name=self.name,
            simulationType=self.simulation_type,
            impulseLengthSec=self.ir_length,
            crossoverFrequency=self.crossover_frequency,
            modelDefinitionId=getattr(self.model, "id", self.model),
            onTaskError=self.on_task_error,
            receivers=self.receiver_list,
            sources=self.source_list,
            layerMaterialAssignments=self.material_assignment,
            description=self.description,
            energyDecayThreshold=self.energy_decay_threshold,
            simulationSettings=self.simulation_settings,
            mesherSettings=self.mesher_settings,
            localMeshSizing=self.local_mesh_sizing,
            originalGeometryLibraryId=original_geometry_library_id,
            metadata=self.metadata,
            category=getattr(self, "category", None),
        )

    def _check_material_assignment(self, model, mat_assignment: list[MaterialAssignment]):
        if mat_assignment is None:
            raise ValueError("Material assignment is missing")
        if isinstance(model, (ModelObj, GeometryLibraryObj)):
            # We have access to the layer names without any extra effort.
            if model_layer_names := getattr(model, "layer_names", None):
                check_mask = [m.layer_name in model_layer_names for m in mat_assignment]
                if not all(check_mask):
                    raise ValueError("Material assignment layer names do not match model layer names")

    def plot(
        self,
        with_validation=True,
        project=None,
        view_2d: View2d = None,
        disable_labels: bool = False,
    ):
        """
        Use the plot module to plot the simulation, plotting the model with sources and receivers.

        :param bool with_validation: Show validation results. Optional, defaults to true.
        :param Project project: Optional, only required if the "model" property of the simulation is a string containing the model id.
        :param view_2d: Show a 2d view, choose between None, View2d.xy, View2d.xz, View2d.yz. Optional, defaults to false.
        :param disable_labels: Disables source and receiver labels. Optional, defaults to false.
        """
        model = self.model
        if isinstance(self.model, str):
            if project is None:
                logger.warning(
                    "Unable to plot simulation, if model attribute is an Id then the project parameter must be specified."
                )
                return
            model = project.get_model(self.model)
        if m := utils.try_load_treble_module("geometry.plot"):
            if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
                m.plot_simulation(
                    Simulation(self.to_dto(), "", model._client, model),
                    with_validation,
                    view_2d,
                    disable_labels,
                )
            else:
                m.plot_simulation_dash(
                    Simulation(self.to_dto(), "", model._client, model), with_validation, view_2d
                )

    def validate(self, project=None):
        """
        Validate simulation.
        Validates source/receiver positions.
        Receivers should be inside model and be placed 0.15m from any surface.
        Sources should be inside model and placed 0.25m from any surface.
        All layers should have materials assigned to them.

        :param Project project: Optional, only required if the "model" property of the simulation is a string containing the model id.
        """
        model = self.model
        if isinstance(self.model, str):
            if project is None:
                logger.warning(
                    "Unable to validate simulation, if model attribute is an Id then the project parameter must be specified."
                )
                return
            model = project.get_model(self.model)

        if m := utils.try_load_treble_module("geometry.validation"):
            return m.validate_simulation(Simulation(self.to_dto(), "", model._client, model))

    def remove_invalid_receivers(self):
        """
        Performs validation and removes receivers that are invalid
        """
        validation_results = self.validate()

        self.receiver_list = [
            item
            for item in self.receiver_list
            if not any(
                item.label == invalid_item.receiver_label
                and item.x == invalid_item.receiver_position.x
                and item.y == invalid_item.receiver_position.y
                and item.z == invalid_item.receiver_position.z
                and item.receiver_type == invalid_item.receiver_type
                for invalid_item in validation_results.invalid_receivers
            )
        ]

    def remove_invalid_sources(self):
        """
        Performs validation and removes sources that are invalid
        """
        validation_results = self.validate()

        self.source_list = [
            item
            for item in self.source_list
            if not any(
                item.label == invalid_item.source_label
                and item.x == invalid_item.source_position.x
                and item.y == invalid_item.source_position.y
                and item.z == invalid_item.source_position.z
                and item.source_type == invalid_item.source_type
                for invalid_item in validation_results.invalid_sources
            )
        ]

    def __repr__(self) -> str:
        base_str = f"SimulationDefinition(name='{self.name}', simulation_type='{self.simulation_type}', model='{self.model}'"
        if self.crossover_frequency is not None:
            base_str += f", crossover_frequency='{self.crossover_frequency}'"
        base_str += f", receiver_list='{utils._repr_trim_lst(self.receiver_list)}', source_list={utils._repr_trim_lst(self.source_list)}, material_assignment={utils._repr_trim_lst(self.material_assignment)}"
        if self.ir_length is not None:
            base_str += f", ir_length='{self.ir_length}'"
        if self.energy_decay_threshold is not None:
            base_str += f", energy_decay_threshold='{self.energy_decay_threshold}'"
        base_str += (
            f", simulation_settings='{self.simulation_settings}', on_task_error='{self.on_task_error}'"
        )
        if self.description is not None:
            base_str += f", description={utils._repr_trim_str(self.description)}"
        if self.local_mesh_sizing is not None:
            base_str += f", local_mesh_sizing={utils._repr_trim_lst(self.local_mesh_sizing)}"
        if self.mesher_settings is not None:
            base_str += f", mesher_settings={self.mesher_settings}"
        if self.metadata is not None:
            base_str += f", metadata={self.metadata}"
        return base_str + ")"


class Simulation:
    """
    The Simulation class can be used to work with a single simulation. F.ex. start a simulation, estimate simulation runtime/cost, etc.
    """

    def __init__(
        self,
        dto: SimulationDto,
        project_id: str,
        client: TSDKClient,
        model_obj: ModelObj = None,
    ):
        self.project_id = project_id
        self._client = client
        self._dto = dto
        self._model_obj = model_obj
        self.metadata = ObjectMetadata(
            self._client,
            {"simulation_id": self._dto.id, "project_id": self.project_id},
            ObjectMetadata._MetadataOwnerType.simulation,
            self._dto.metadata,
        )
        self._receiver_list = self._get_receiver_list(freeze=True)
        self._source_list = self._get_source_list(freeze=True)
        self._material_assignments = self._get_material_assignments(freeze=True)
        self._local_mesh_sizing = self._get_local_mesh_sizing(freeze=True)

        # Cache for objects needed in validation/plotting/etc.
        self._boundary_velocity_submodel_cache = {}
        self._source_directivity_obj_cache = {}

    def _get_receiver_list(self, freeze: bool, ignore_id: bool = False) -> list[Receiver]:
        return [Receiver._from_dto(dto, freeze=freeze, ignore_id=ignore_id) for dto in self._dto.receivers]

    def _get_source_list(self, freeze: bool, ignore_id: bool = False) -> list[Source]:
        return [Source._from_dto(dto, freeze=freeze, ignore_id=ignore_id) for dto in self._dto.sources]

    def _get_local_mesh_sizing(self, freeze: bool) -> list[LocalMeshSizing]:
        return [LocalMeshSizing._from_dto(dto, freeze=freeze) for dto in self._dto.localMeshSizing]

    def _get_material_assignments(self, freeze: bool) -> list[MaterialAssignment]:
        return [
            MaterialAssignment._from_dto(
                dto=dto,
                material=None,
                freeze=freeze,
            )
            for dto in self._dto.layerMaterialAssignments
        ]

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def description(self) -> str:
        return self._dto.description

    @property
    def status(self) -> str:
        if not SimulationStatus.is_final_status(self._dto.status):
            # If status is not final, try and perform update.
            self._update_dto()
        return self._dto.status

    @property
    def created_at(self) -> str:
        return self._dto.createdAt

    @property
    def updated_at(self) -> str:
        return self._dto.updatedAt

    @property
    def receivers(self) -> list[Receiver]:
        return self._receiver_list

    @property
    def sources(self) -> list[Source]:
        return self._source_list

    @property
    def type(self) -> SimulationType:
        return SimulationType(self._dto.simulationType)

    @property
    def crossover_frequency(self) -> int:
        return self._dto.crossoverFrequency

    @property
    def layer_material_assignment(self) -> dict[str, MaterialAssignment]:
        """
        Returns a dictionary where layer name is the key and MaterialAssignmentDto is the value.
        """
        return {item.layer_name: item for item in self._material_assignments}

    @property
    def local_mesh_sizing(self) -> dict[str, LocalMeshSizing]:
        """
        Returns a dictionary where layer name is the key and LocalMeshSizingDto is the value.
        """
        return {item.layer_name: item for item in self._local_mesh_sizing}

    @property
    def mesher_settings(self) -> MesherSettings | None:
        if self._dto.mesherSettings:
            return MesherSettings._from_dto(self._dto.mesherSettings, freeze=True)
        return None

    @property
    def simulation_settings(self) -> SimulationSettings | None:
        if self._dto.simulationSettings:
            return SimulationSettings._from_dto(self._dto.simulationSettings, freeze=True)
        return None

    def _update_dto(self):
        """
        Update object data from server.
        """
        self._dto = self._client.simulation.get_simulation(self.project_id, self._dto.id)

    def __repr__(self):
        return f"Simulation(id='{self.id}', name='{self.name}', description='{self.description}', created_at='{self.created_at}', status='{self.status}')"

    def __str__(self):
        return json.dumps(
            {
                "id": self.id,
                "name": self.name,
                "description": self.description,
                "created_at": self.created_at,
                "updated_at": self.updated_at,
                "status": self.status,
            },
            indent=2,
        )

    def get_simulation_definition(self) -> SimulationDefinition:
        """
        Returns a SimulationDefinition object with the same specifications as this Simulation object.
        The simulation definition object can then be used to create/clone a simulation with identical settings.
        """
        mats = {
            x.materialId: self._client.material.get_material_by_id(x.materialId)
            for x in self._dto.layerMaterialAssignments
        }
        sim_name = self.name
        if not utils.is_valid_label(sim_name):
            # Clean name if it does not match allowed simulation names.
            # Makes this function backwards compatible with older simulations.
            sim_name = utils.clean_label_str(sim_name, default=self.id)
            logger.warning(
                f"Simulation name '{self.name}' does not match allowed simulation names. Name will be changed to '{sim_name}'"
            )
        sim_def = SimulationDefinition(
            name=sim_name,
            description=self._dto.description,
            simulation_type=self.type,
            model=self.get_model(),
            crossover_frequency=self.crossover_frequency,
            receiver_list=self._get_receiver_list(freeze=False, ignore_id=True),
            source_list=self._get_source_list(freeze=False, ignore_id=True),
            material_assignment=self._get_material_assignments(freeze=False),
            ir_length=self._dto.impulseLengthSec,
            energy_decay_threshold=self._dto.energyDecayThreshold,
            simulation_settings=(
                SimulationSettings._from_dto(self._dto.simulationSettings, freeze=False)
                if self._dto.simulationSettings
                else None
            ),
            on_task_error=self._dto.onTaskError,
            local_mesh_sizing=self._get_local_mesh_sizing(freeze=False),
            mesher_settings=(
                MesherSettings._from_dto(self._dto.mesherSettings, freeze=False)
                if self._dto.mesherSettings
                else None
            ),
            metadata=self._dto.metadata,
        )
        sim_def.category = self._dto.category
        return sim_def

    def get_model(self) -> ModelObj | GeometryLibraryObj:
        """
        Get the ModelObj associated to this simulation.

        :returns ModelObj: Returns ModelObj object.
        """
        if self._model_obj is None or isinstance(self._model_obj, str):
            self._model_obj = ModelObj(
                self._client.model.get_model(self.project_id, self._dto.modelDefinitionId),
                None,
                self._client,
            )
        if self._model_obj._dto.isDeleted:
            logger.warning(f"Model {self._model_obj.id} is deleted!")
        return self._model_obj

    def estimate(self) -> SimulationEstimate:
        """
        Get total estimated runtime and total estimated cost in tokens for this simulation, as well as estimations for each of the simulaiton's sources.

        :returns SimulationEstimate: Returns SimulationEstimate object
        """
        return SimulationEstimate(dto=self._client.simulation.estimate(self.project_id, self.id))

    def wait_for_estimate(self, max_retries=200) -> SimulationEstimate:
        """
        Wait for simulation estimate.

        :param int max_retries: Maximum retries for getting simulation estimate.
        :returns SimulationEstimate: Returns SimulationEstimate object either if estimate is ready or if max_retries seconds have elapsed.
        """
        retry_count = 0
        estimate = self.estimate()
        while estimate.result_status.result_code == 100 and retry_count < max_retries:
            time.sleep(3)
            estimate = self.estimate()
            retry_count += 1

        return estimate

    def start(self) -> bool:
        """
        Start the simulation.
        """
        res = self._client.simulation.start(self.project_id, self.id)
        if res.resultStatus.result_code == 0:
            self._dto = res

    def get_progress(self) -> SimulationProgressInfo:
        """
        Get progress of the simulation.

        :returns SimulationProgressInfo: Returns SimulationProgressInfo object containing progress percentage for the simulation as well as progress for each of the simulation's source.
        """
        progress = SimulationProgressInfo(
            self._client.simulation.get_progress(self.project_id, self.id), self._client
        )
        # Update self status in case it has changed.
        self._dto.status = progress._dto.simulationStatus
        return progress

    def cancel(self) -> CancelSimulationResult:
        """
        Cancel the simulation.

        :returns CancelSimulationDto: Returns CancelSimulationDto containing a list of all the simulation's cancelled tasks.
        """
        return CancelSimulationResult(self._client.simulation.cancel(self.project_id, self.id))

    def delete(self) -> bool:
        """
        Delete the simulation.
        """
        return self._client.simulation.delete_simulation(self.project_id, self.id)

    def get_tasks(self) -> list[Source]:
        """
        Get the simulation's tasks grouped by source.

        :returns list[Source]: Returns a list of Source objects containing task list for source.
        """
        res = self._client.simulation.get_simulation_tasks(self.project_id, self.id)
        if res:
            return [Source._from_dto(dto, freeze=True) for dto in res]
        return []

    def _get_results_json(
        self, result_type: ResultType = None, include_subtasks: bool = False
    ) -> list[SourceResultDto]:
        """
        Get results for the simulation.

        :param SimulationType result_type: Optional filter for type of results to fetch "wave_based"|"geometrical"|"hybrid" if None then all results will be fetched.
        :returns list[SourceResultDto]: List of SourceResultDto objects.
        """
        return self._client.simulation.get_results(self.project_id, self.id, [result_type], include_subtasks)

    def _get_mesh_info_internal(self) -> SimulationMeshInfoDto | None:
        return self._client.simulation.get_mesh_info(self.project_id, self.id)

    def get_mesh_info(self) -> SimulationMeshInfoCollection | None:
        """
        Gets information on the meshes generated for simulation.
        Returns the simulation mesh and additional source meshes, note: if a source does not
        require special meshing then it will use the simulation mesh.
        Will return None if the simulation type is GA since a mesh is not required.

        :returns SimulationMeshInfoCollection | None: None if simulation type is GA.
        """
        if self.type == SimulationType.ga or self.type == SimulationType.geometrical:
            logger.warning("Mesh info not available for GA only simulations")
            return None
        mesh_info_dto = self._get_mesh_info_internal()
        if mesh_info_dto is None:
            logger.warning("Mesh info not available")
        return SimulationMeshInfoCollection(mesh_info_dto, self)

    def get_tokens_used(self) -> float | None:
        """
        Gets the total amount of tokens used for the simulation.

        :returns float | None: Total amount of tokens used for the simulation. Returns None if simulation is not completed.
        """
        if self.status not in (SimulationStatus.completed, SimulationStatus.cancelled):
            return None
        tokens_used = sum(
            task.tokens_used
            for source in self.get_tasks()
            for task in source.tasks
            if task.tokens_used is not None
        )
        return round(tokens_used, 4)

    def set_gpu_count(self, gpu_count: int) -> bool:
        """
        Update the GPU count for the simulation. Note that this sets the gpu count for each wavb-based
        solve task in the simulation.
        :param int gpu_count: Number of GPUS to allocate for each wave-solver task in the simulation.
        """
        if self.type == SimulationType.ga or self.type == SimulationType.geometrical:
            logger.warning("GPU count not available for GA only simulations")
            return False
        status = self.status
        if status != SimulationStatus.created:
            logger.warning(f"Unable to update gpu count for simulation in status {status}")
            return False
        if gpu_count < 1 or (gpu_count > 1 and gpu_count % 2 != 0) or gpu_count > 100:
            logger.warning("GPU count must be 1 or an even number.")
            return False
        if self._client.simulation.update_gpu_count(self.project_id, self.id, gpu_count):
            self._update_dto()
            return True
        return False

    def rename(self, simulation_name: str) -> bool:
        """
        Update the simulation name.
        :param str simulation_name: Value of the updated name of the simulation.
        """
        if not simulation_name:
            logger.warning("Simulation name must have a value.")
            return False
        if simulation_name == self.name:
            logger.warning("Simulation name is already set to the provided value.")
            return False
        if not utils.is_valid_label(simulation_name):
            logger.warning("Simulation name must be alphanumeric and may contain underscores.")
            return False

        if self._client.simulation.update_simulation_name(self.project_id, self.id, simulation_name):
            self._dto.name = simulation_name
            return True

        return False

    def _download_source_results(
        self,
        source_results: list[SourceResultDto],
        destination_directory,
        rename_rule: ResultRenameRule = ResultRenameRule.none,
        task_type: SimulationType = None,
        output_mode: utils.ProgressOutputMode = utils.ProgressOutputMode.NO_OUTPUT,
        progress_leave: bool = True,  # If set to false then the tqdm progress bar will disappear upon completion.
    ):
        """
        Download result files from source result dto.
        """
        output_mode, tqdm = utils.try_load_tqdm(output_mode)

        # Create download list tuple.
        # List of (Url, destination_file) tuples to feed to utils.download_files.
        url_path_tuples = []
        # Map between url and source_result
        url_to_source_result = {}
        # Map between url to type_str.
        url_to_type_str = {}
        # Map between url to file type ('zip' or 'json')
        url_to_file_type = {}
        # Map between urls and the title to show in it's download progress bar.
        urls_to_titles = {}
        progress_bar = None

        def _process_downloaded_file(url: str, completed_count: int, total_count: int):
            # Handle progress output
            if total_count > 0:
                if output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
                    logger.info(f"Completed downloads: {completed_count}/{total_count}", end="")
                elif output_mode == utils.ProgressOutputMode.TQDM_OUTPUT and progress_bar:
                    progress_bar.update(1)
            sr = url_to_source_result[url]
            ts = url_to_type_str[url]
            source_identification = self._create_result_file_name(
                source_info=sr.sourceInfo, type_str=ts, rename_rule=rename_rule
            )
            if url_to_file_type[url] == "zip":
                # Assume result zip package.
                data_path = Path(destination_directory) / f"{source_identification}.zip"
                if not h5py.is_hdf5(data_path):
                    extract_dir = f"{destination_directory}/{source_identification}"
                    if Path(extract_dir).exists():
                        print(f"Directory: {extract_dir} already exists. Will not extract results")
                        return
                    utils.decompress_file(
                        filepath=data_path,
                        work_dir=extract_dir,
                        remove_original=True,
                    )
                    self._convert_old_results_to_new(
                        source_result=url_to_source_result[url],
                        type_str=type_str,
                        result_dir=destination_directory,
                        extracted_dir=extract_dir,
                        rename_rule=rename_rule,
                    )
                    shutil.rmtree(extract_dir)
                    # new_data_path = Path(destination_directory) / f"{source_identification}.h5"
                    # if data_path != new_data_path and data_path.exists():
                    #     os.rename(data_path, new_data_path)
                    #     data_path = new_data_path

                elif h5py.is_hdf5(data_path):
                    source_identification = self._create_result_file_name(
                        source_info=sr.sourceInfo, type_str=ts, rename_rule=rename_rule
                    )
                    new_data_path = Path(destination_directory) / f"{source_identification}.h5"
                    if data_path != new_data_path:
                        os.rename(data_path, new_data_path)
                        data_path = new_data_path
                else:
                    raise ValueError(f"Unknown file type for {data_path}")

        for source_result in source_results:
            for task_result in source_result.results:
                if task_type is not None and task_type.value != task_result.taskType:
                    continue
                type_str = str(task_result.taskType)
                if task_result.subType and task_result.subType != "None":
                    type_str += f"_{task_result.subType}"
                source_identifier = self._create_result_file_name(
                    source_info=source_result.sourceInfo,
                    type_str=type_str,
                    rename_rule=rename_rule,
                )
                result_zip_path = os.path.join(
                    destination_directory,
                    f"{source_identifier}.zip",
                )
                result_h5_path = os.path.join(
                    destination_directory,
                    f"{source_identifier}.h5",
                )

                result_json_path = os.path.join(
                    destination_directory,
                    f"{source_identifier}.json",
                )

                # Populate download lists and maps.
                if Path(result_zip_path).exists():
                    print(f"Results file {result_zip_path} already exists, will not download file.")
                elif Path(result_h5_path).exists():
                    print(f"Results file {result_h5_path} already exists, will not download file.")
                else:
                    url_path_tuples.append((task_result.dataFileUrl, result_zip_path))
                    url_to_source_result[task_result.dataFileUrl] = source_result
                    url_to_type_str[task_result.dataFileUrl] = type_str
                    url_to_file_type[task_result.dataFileUrl] = "zip"
                    urls_to_titles[task_result.dataFileUrl] = f"{type_str} (hdf5)".rjust(15)

                if Path(result_json_path).exists():
                    print(f"Results file {result_json_path} already exists, will not download file.")
                else:
                    url_path_tuples.append((task_result.jsonFileUrl, result_json_path))
                    url_to_source_result[task_result.jsonFileUrl] = source_result
                    url_to_type_str[task_result.jsonFileUrl] = type_str
                    url_to_file_type[task_result.jsonFileUrl] = "json"
                    urls_to_titles[task_result.jsonFileUrl] = f"{type_str} (json)".rjust(15)

        total_count = len(url_path_tuples)
        if total_count > 0:
            sub_output_mode = output_mode
            if total_count > 500:
                # If we are going to be downloading more than 500 files, disable per file progress output.
                sub_output_mode = utils.ProgressOutputMode.NO_OUTPUT
            else:
                sub_output_mode = output_mode
            if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
                progress_bar = tqdm.tqdm(
                    total=total_count,
                    desc=f"Download simulation {self.id}",
                    bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} tasks",
                    leave=progress_leave,
                )
            utils.download_files(
                urls_and_paths=url_path_tuples,
                progress_callback=_process_downloaded_file,
                progress_leave=False,
                urls_to_titles=urls_to_titles,
                output_mode=sub_output_mode,
            )

            if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
                progress_bar.close()
                # print("Download complete")
            elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
                print("Download completed")

    def _convert_old_results_to_new(
        self,
        source_result: SourceResultDto,
        type_str: str,
        result_dir: str | Path,
        extracted_dir: str | Path,
        rename_rule: ResultRenameRule = ResultRenameRule.none,
    ):
        """
        Take old extracted directory from zip file and convert to new result format.

        :param str | Path work_dir: Directory which results have been extracted to.
        """
        source_identifier = self._create_result_file_name(
            source_info=source_result.sourceInfo,
            type_str=type_str,
            rename_rule=rename_rule,
        )
        map_old_to_new = self._map_old_receiver_files_to_new_paths(
            type_str=type_str,
            result_dir=result_dir,
            source_result=source_result,
        )
        result_h5_path = os.path.join(
            result_dir,
            f"{source_identifier}.h5",
        )

        result_json_path = os.path.join(
            result_dir,
            f"{source_identifier}.json",
        )

        if m := utils.try_load_treble_module("treble_tsdk.results.results"):
            m._convert_old_results_to_new(
                old_files=map_old_to_new,
                new_file=result_h5_path,
                new_json=result_json_path,
                bv_source=source_result.sourceInfo.sourceType == "BoundaryVelocity",
            )
            s = source_result.sourceInfo.label
            print(f"Successfully ported old simulation result to new format for source {s}.")

    def _map_old_receiver_files_to_new_paths(
        self, type_str: str, result_dir: str | Path, source_result: SourceResultDto
    ) -> dict[str, str]:
        """
        Map old receiver files to new paths.

        :param str type_str: Type string for the result.
        :param str | Path: Path to extracted directory.
        :returns dict[str, str]: Dictionary mapping old receiver file paths to new hdf5 paths.
        """

        class _OldReceiverSuffixes(Enum):
            hybrid_spatial = "hybrid_Spatial_IR"
            hybrid_mono = "hybrid_IR"
            hybrid_device = "Hybrid_device"
            hybrid_json = "Hybrid"
            dg_spatial = "DG_IR_Spatial"
            dg_mono = "DG_IR_SC"
            dg_device = "DG_device"
            dg_json = "DG"
            ga_spatial = "GA_spatial_IR"
            ga_mono = "GA_IR"
            ga_device = "GA_device"
            ga_json = "GA"
            device_json = "DeviceRendering"

        # Write a little function that constructs the receiver wav path using the Enum above.
        def _get_wavname(receiver_id: str, type_str: str, receiver_type: str) -> str:
            receiver_filename = f"{receiver_id}_{_OldReceiverSuffixes[f'{type_str.lower()}_{receiver_type.lower()}'].value}.wav"
            return receiver_filename

        def _get_json(source_id: str, type_str: str) -> str:
            json_filename = f"{source_id}_{type_str}.json"
            return json_filename

        map_old_to_new = {}
        map_old_to_new["base_dir"] = result_dir
        map_old_to_new["sources"] = {}
        source = source_result.sourceInfo
        map_old_to_new["sources"][source.id] = {}
        map_old_to_new["sources"][source.id]["source_dir"] = f"{source.id}_{type_str}"
        map_old_to_new["sources"][source.id]["json"] = _get_json(source.id, type_str)
        map_old_to_new["sources"][source.id]["spatial"] = {}
        map_old_to_new["sources"][source.id]["mono"] = {}
        map_old_to_new["sources"][source.id]["device"] = {}
        for receiver in self.receivers:
            map_old_to_new["sources"][source.id]["mono"][receiver.id] = _get_wavname(
                receiver.id, type_str=type_str, receiver_type="Mono"
            )
            if receiver.receiver_type == ReceiverType.mono:
                continue
            map_old_to_new["sources"][source.id]["spatial"][receiver.id] = _get_wavname(
                receiver.id, type_str=type_str, receiver_type="Spatial"
            )
            if receiver.receiver_type == ReceiverType.spatial:
                continue
            map_old_to_new["sources"][source.id]["device"][receiver.id] = _get_wavname(
                receiver.id, type_str=type_str, receiver_type="Device"
            )
        return map_old_to_new

    def write_simulation_info_to_json(self, destination_file: str | Path):
        """
        Writes simulation info as a json string to a file.

        :param str destination_file: Path to file to write json data to f.ex. /my/path/simulation_info.json.
        """
        # Dump simulation info to a json file called simulation_info.json in the destination directory.
        sim_info = {k: v for k, v in vars(self._dto).items() if not k.startswith("_")}
        sim_info["project_id"] = self.project_id
        with open(str(destination_file), "w") as f:
            json.dump(sim_info, f, default=vars, indent=2)

    def download_results(
        self,
        destination_directory: str | Path,
        result_type: ResultType = None,
        rename_rule: ResultRenameRule = ResultRenameRule.none,
        output_mode: utils.ProgressOutputMode = utils.ProgressOutputMode.TQDM_OUTPUT,
        progress_leave: bool = True,
    ) -> "Results" | None:
        """
        Download results to a directory.

        :param str | Path destination_directory: Directory to download the results to.
        :param SimulationType result_type: Optional, if provide will only download results for the specific task type.
        :param ResultRenameRule rename_rule: Optional, If provided the result files will be renamed according to the rule given, f.ex.
        if rename_rule.by_label is provided the folder structure will be [source_label]/[receiver_label]_...wav and [source_label]_[task_type].json etc.
        Note when using this rule the labels must be guaranteed to be valid file/directory names, if not then the files will not be
        renamed.
        :param ResultDataFilter data_filter: Optional, if provided it can be used to remove result data files that the users is not interested in, f.ex. if
        user only wan't to see IRs.
        :param utils.ProgressOutputMode output_mode: Optional, can be used to set how download progress reporting is handled, defaults to TQDM progress bars.
        :param bool progress_leave: If set to False it will remove the TQDM progress bar upon completion.
        """
        result_type = self._determine_result_type(result_type)
        source_results = self._get_results_json(result_type=result_type.value, include_subtasks=False)
        if len(source_results) > 0:
            Path(destination_directory).mkdir(exist_ok=True, parents=True)
            # Check to see if there is a file in the directory that contains the source id or label.
            for source_result in source_results:
                for file in os.listdir(destination_directory):
                    if source_result.sourceInfo.id in file and result_type.value in file:
                        if ".h5" in file or ".json" in file:
                            message = f"File {file} in {destination_directory} contains the source id "
                            message += f"'{source_result.sourceInfo.id}', please remove this file or "
                            message += "choose a different destination directory."
                            raise ValueError(message)
                    if source_result.sourceInfo.label in file and result_type.value in file:
                        if ".h5" in file or ".json" in file:
                            message = f"File {file} in {destination_directory} contains the source label"
                            message += f"'{source_result.sourceInfo.label}', please remove this file "
                            message += "or choose a different destination directory."
                            raise ValueError(message)

            self._download_source_results(
                source_results=source_results,
                destination_directory=destination_directory,
                rename_rule=rename_rule,
                output_mode=output_mode,
                progress_leave=progress_leave,
            )
            try:
                # Try and dump simulation info to destination directory.
                self.write_simulation_info_to_json(f"{destination_directory}/simulation_info.json")
            except Exception as e:
                logger.warning("Unable to write simulation info to destination directory.", exc_info=e)
            if m := utils.try_load_treble_module("results.results"):
                return m.get_results_object(
                    simulation=self, results_directory=destination_directory, result_type=result_type
                )
        else:
            logger.info("No results available for simulation")

    def get_results_object(
        self,
        results_directory: str | Path,
        result_type: SimulationType | ResultType = None,
    ) -> "Results" | None:
        """
        Create a results object for simulation results which have been downloaded to a results_directory.
        If directory does not exist, results will be downloaded to that directory

        :param str | Path results_directory: Path to results directory. If results have already
            been downloaded to this directory a results object based on that directory will be created.
        :return Results | None Results: The respective results object
        """

        if self.status != "Completed":
            logger.warning("Simulation not completed")
            return
        result_type = self._determine_result_type(result_type)
        if (
            results_directory is not None
            and Path(results_directory).exists()
            and len(os.listdir(results_directory)) > 0
        ):
            # Directory contains files.
            if m := utils.try_load_treble_module("results"):
                return m.get_results_object(
                    simulation=self, results_directory=results_directory, result_type=result_type
                )
            return None
        else:
            # Non existent or empty directory provided.
            logger.info("Downloading results")
            return self.download_results(
                destination_directory=Path(results_directory),
                rename_rule=ResultRenameRule.none,
                result_type=result_type,
            )

    def _determine_result_type(self, result_type: ResultType = None) -> ResultType:
        if result_type is None:
            result_type = self.type
        return result_type

    def _apply_rename_rule_to_result_json_file(
        self,
        json_path: Path | str,
        source_info: SourceDto,
        rename_rule: ResultRenameRule,
    ):
        """
        When applying rename rules to the downloaded results, the json file does not make sense anymore.
        This applies changes to the json in order to align with the rename rule

        :param Path | str json_path: Path to the results json file
        :param SourceDto source_info: Information about the source
        :param ResultRenameRule rename_rule: Rule to rename files
        """
        if rename_rule is None or rename_rule == ResultRenameRule.none:
            return
        receiver_to_rename = {}
        if rename_rule == ResultRenameRule.by_label:
            source_to_rename = {source_info.id: source_info.label}
            for receiver in self.receivers:
                receiver_to_rename[receiver.id] = receiver.label

        with open(file=json_path, mode="r") as fh:
            json_dict = json.load(fh)
        jsonstring = json.dumps(json_dict)
        for key, val in source_to_rename.items():
            jsonstring = jsonstring.replace(key, val)
        for key, val in receiver_to_rename.items():
            jsonstring = jsonstring.replace(key, val)

        new_json_dict = json.loads(jsonstring)
        with open(file=json_path, mode="w") as fh:
            json.dump(new_json_dict, fh)

    def _apply_data_filter_to_result_json(self, json_path: Path | str, data_filter: ResultDataFilter):
        """
        If only IRs are downloaded there is no reason to point to all sorts of other files

        :param ResultDataFilter data_filter: How the downloaded data is filtered
        :param Path | str json_path: Path to the result json file
        """
        with open(json_path, "r") as fh:
            json_dict = json.load(fh)

        if data_filter == ResultDataFilter.ir:
            recs = json_dict["receivers"]
            for _i, receiver in enumerate(recs):
                filtered_list = []
                for file_pointer in receiver["result_files"]:
                    if file_pointer["type"].lower() in [
                        "ir",
                        "spatial-ir",
                        "device-ir",
                    ]:
                        del file_pointer["frequency"]
                        filtered_list.append(file_pointer)
                json_dict["receivers"][_i]["result_files"] = filtered_list

        with open(json_path, "w") as fh:
            json.dump(json_dict, fh)

    def _filter_result(
        self,
        source_info: SourceDto,
        type_str: str,
        download_directory: str,
        data_filter: ResultDataFilter,
    ):
        orig_result_data_directory = f"{download_directory}/{source_info.id}_{type_str}"

        cleanup = []
        for filepath in glob.glob(f"{orig_result_data_directory}/*"):
            if not os.path.isfile(filepath):
                # Skip directories.
                continue
            filename = os.path.basename(filepath)
            if data_filter == ResultDataFilter.ir and (not filename.endswith(".wav") or "_EDC" in filename):
                cleanup.append(filepath)

        for f in cleanup:
            os.unlink(f)

    def _rename_result_json(
        self,
        source_info: SourceDto,
        type_str: str,
        download_directory: str,
        rename_rule: ResultRenameRule,
    ):
        default_result_json_path = Path(download_directory) / f"{source_info.id}_{type_str}.json"
        source_identification = self._create_result_file_name(
            source_info=source_info, type_str=type_str, rename_rule=rename_rule
        )
        new_result_json_path = Path(download_directory) / f"{source_identification}.json"
        if default_result_json_path != new_result_json_path:
            os.rename(default_result_json_path, new_result_json_path)

    def _rename_result_data(
        self,
        source_info: SourceDto,
        type_str: str,
        download_directory: str,
        rename_rule: ResultRenameRule,
    ):
        orig_result_data_directory = Path(download_directory) / f"{source_info.id}_{type_str}"

        # data directory
        if rename_rule == ResultRenameRule.by_label:
            new_result_data_directory = Path(download_directory) / f"{source_info.label}_{type_str}"
            os.rename(orig_result_data_directory, new_result_data_directory)
        else:
            # Nothing to do (unknown rename_rule).
            return

        # Results data.
        for original_filepath in glob.glob(f"{new_result_data_directory}/*.wav") + glob.glob(
            f"{new_result_data_directory}/*.txt"
        ):
            # Harvest receiver id from filename and find receiver object.
            original_filename = os.path.basename(original_filepath)
            original_filename_split = original_filename.split("_")
            receiver = [r for r in self.receivers if r.id == original_filename_split[0]]
            if not receiver or len(receiver) == 0:
                # Receiver not found. Continue.
                continue
            receiver = receiver[0]
            if rename_rule == ResultRenameRule.by_label:
                new_filename = (
                    f"{new_result_data_directory}/{receiver.label}_{'_'.join(original_filename_split[1:])}"
                )
                os.rename(original_filepath, new_filename)

    def _create_result_file_name(
        self, source_info: SourceDto, type_str: str, rename_rule: ResultRenameRule
    ) -> str:
        if rename_rule == ResultRenameRule.by_label:
            return f"{source_info.label}_{type_str}"
        else:
            return f"{source_info.id}_{type_str}"

    def plot(
        self,
        with_validation: bool = True,
        view_2d: View2d = None,
        disable_labels: bool = False,
    ):
        """
        Use the plot module to plot the simulation, plotting the model with sources and receivers.

        :param with_validation: Show validation results. Optional, defaults to true.
        :param view_2d: Show a 2d view, choose between None, View2d.xy, View2d.xz, View2d.yz. Optional, defaults to false.
        :param disable_labels: Disables source and receiver labels. Optional, defaults to false.
        """
        if m := utils.try_load_treble_module("geometry.plot"):
            if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
                m.plot_simulation(self, with_validation, view_2d, disable_labels)
            else:
                m.plot_simulation_dash(self, with_validation, view_2d)

    def validate(self):
        """
        Validate simulation.
        Validates source/receiver positions.
        Receivers should be inside model and be placed 0.15m from any surface.
        Sources should be inside model and placed 0.25m from any surface.
        All layers should have materials assigned to them.
        """
        if m := utils.try_load_treble_module("geometry.validation"):
            return m.validate_simulation(self)

    def calculate_sabine_estimate(self) -> list[float]:
        """
        Calculate Sabine estimate for the simulation

        :returns list[float]: List of the sabine estimated RT for each frequency range valid for materials (63, 125, 250, 500, 1k, 2k, 4k, 8k).
        """
        return self.get_model().calculate_sabine_estimate(self._material_assignments)

    #####
    # Stubs
    def as_tree(self):
        """
        Uses the display_data module to display simulation information as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)

    def as_table(self):
        """
        Uses the display_data module to display simulation information as table.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_table(self)

    def as_live_progress(self):
        """
        Uses the display_data module to show simulation progress automatically updated until simulation finished.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_live_progress(self)
