from __future__ import annotations

import json
import time
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING

from treble_tsdk.core.temp_folder import TempFolder

from .. import utils
from ..client.api_models import (
    GeometryCheckerSettingsDto,
    GeometryObjectInfoDto,
    GeometryObjectLayerInfoDto,
    ModelDto,
    ObjectMetadataDto,
    ProjectDto,
    ProjectEstimateDto,
    ProjectProgressDto,
    ProjectUpdateDto,
    ResultStatusDto,
    SimulationDto,
    SimulationResultDto,
    StartProjectDto,
)
from ..client.tsdk_client import TSDKClient
from ..treble_logging import logger
from ..utility_classes import Point3d, Rotation, Transform3d
from .geometry_library_obj import GeometryLibraryObj
from .object_metadata import ObjectMetadata
from .simulation import (
    CancelSimulationResult,
    ModelObj,
    ResultRenameRule,
    ResultType,
    Simulation,
    SimulationBasicInfo,
    SimulationDefinition,
    SimulationProgressInfo,
    SimulationStatus,
    SimulationEstimate,
)
from .temp_folder import TempFolder

if TYPE_CHECKING:
    from ..geometry.geometry_definition import GeometryDefinition
    from ..geometry.mesh_collection import MeshCollection


class ProjectProgressInfo:
    def __init__(self, dto: ProjectProgressDto, client: TSDKClient = None):
        self._dto = dto
        self._simulations = []
        if self._dto.simulations:
            self._simulations = [
                SimulationProgressInfo(item, client=client) for item in self._dto.simulations
            ]

    @property
    def project_id(self) -> str:
        return self._dto.projectId

    @property
    def project_name(self) -> str:
        return self._dto.projectName

    @property
    def status(self) -> SimulationStatus:
        return SimulationStatus(self._dto.status)

    @property
    def project_progress_percentage(self) -> float:
        return self._dto.projectProgressPercentage

    @property
    def simulations(self) -> list[SimulationProgressInfo]:
        return self._simulations

    def as_table(self):
        """
        Uses the display_data module to display project progress as table.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_table(self)

    def __repr__(self):
        return (
            f"ProjectProgressInfo(project_id={self.project_id}, "
            f"project_name={self.project_name}, "
            f"status={self.status}, "
            f"project_progress_percentage={self.project_progress_percentage})"
        )


class ProjectEstimation:
    def __init__(self, dto: ProjectEstimateDto):
        self._dto = dto
        self._simulation_estimates = [SimulationEstimate(item) for item in self._dto.simulationEstimates]

    @property
    def result_status(self) -> ResultStatusDto:
        return self._dto.resultStatus

    @property
    def project_id(self) -> str:
        return self._dto.projectId

    @property
    def total_estimated_runtime_hours(self) -> int | None:
        return self._dto.totalEstimatedRuntimeHours

    @property
    def total_estimated_cost_tokens(self) -> int | None:
        return self._dto.totalEstimatedCostInTokens

    @property
    def simulation_estimates(self) -> list[SimulationEstimate]:
        return self._simulation_estimates

    def __repr__(self):
        return (
            f"ProjectEstimate(project_id={self.project_id}, "
            f"total_estimated_runtime_hours={self.total_estimated_runtime_hours}, "
            f"total_estimated_cost_tokens={self.total_estimated_cost_tokens}, "
            f"result_status={self.result_status})"
        )

    def as_tree(self):
        """
        Uses the display_data module to display project estimate as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)

    def as_table(self):
        """
        Uses the display_data module to display project estimate as table.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_table(self)


class StartProjectResult:
    def __init__(self, project_id: str, project_name: str, dto: StartProjectDto):
        self._dto = dto
        self.project_id = project_id
        self.project_name = project_name
        self._started = [SimulationBasicInfo(item) for item in self._dto.started]
        self._already_started = [SimulationBasicInfo(item) for item in self._dto.alreadyStarted]
        self._already_in_end_state = [SimulationBasicInfo(item) for item in self._dto.alreadyInEndState]

    @property
    def started(self) -> list[SimulationBasicInfo]:
        """
        List of simulations that were started by project.start_simulations.
        """
        return self._started

    @property
    def already_started(self) -> list[SimulationBasicInfo]:
        """
        List of simulations that were already started when project.start_simulations was called.
        """
        return self._already_started

    @property
    def already_in_end_state(self) -> list[SimulationBasicInfo]:
        """
        List of simulations that were already in an end state when project.start_simulations was called.
        """
        return self._already_in_end_state

    def __repr__(self):
        return (
            f"StartProjectResult(started_count={len(self.started)}, "
            f"already_started_count={len(self.already_started)}, "
            f"already_in_end_state_count={len(self.already_in_end_state)})"
        )

    def as_tree(self):
        """
        Uses the display_data module to display start project result as tree.
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)


class Project:
    def __init__(self, dto: ProjectDto, client: TSDKClient):
        self._client = client
        self._dto = dto
        self.metadata = ObjectMetadata(
            self._client,
            {"project_id": self._dto.id},
            ObjectMetadata._MetadataOwnerType.project,
            self._dto.metadata,
        )

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def description(self) -> str:
        return self._dto.description

    @property
    def created_at(self) -> str:
        return self._dto.createdAt

    @property
    def updated_at(self) -> str:
        return self._dto.updatedAt

    @property
    def created_by(self) -> str:
        return self._dto.createdBy

    def add_model(
        self,
        model_name: str,
        model_file_path: str | "GeometryDefinition",
        model_description: str = None,
        geometry_checker_settings: GeometryCheckerSettingsDto = None,
        metadata: dict[str, str] | ObjectMetadataDto | ObjectMetadata = None,
    ) -> ModelObj:
        """
        Upload a model to project.

        :param str model_name: Name of model
        :param str model_file_path: Path to model file to be uploaded.
        :param str model_description: Optional description of your model.
        :param GeometryCheckerSettingsDto geometry_checker_settings: Optional advanced settings for geometry checking service.
        :returns ModelObj: Returns the uploaded ModelObj object.
        """
        if type(model_file_path).__name__ == "GeometryDefinition":
            model_file_path._rebuild_joined_mesh_collection()
            model_file_path = model_file_path._joined_model_path
        if metadata is not None and isinstance(metadata, ObjectMetadataDto):
            # Get data as dict[str, str]
            metadata = metadata.keyValuePairs
        model_dto = self._client.model.create_model(
            self.id,
            model_name,
            model_file_path,
            model_description,
            compress=True,
            geometry_checking_settings=geometry_checker_settings,
            metadata=metadata,
        )
        return ModelObj(model_dto, None, self._client)

    def _add_model_from_meshcollection(
        self,
        model_name: str,
        meshcollection: "MeshCollection",
        model_description: str = None,
        geometry_checker_settings: GeometryCheckerSettingsDto = None,
        metadata: dict[str, str] = None,
        category: str = None,
        parent_id: str = None,
    ) -> ModelObj:
        """
        Upload a model to project.

        :param str model_name: Name of model
        :param MeshCollection meshcollection: Meshcollection object containing the model.
        :param str model_description: Optional description of your model.
        :param GeometryCheckerSettingsDto geometry_checker_settings: Optional advanced settings for geometry checking service.
        :returns ModelObj: Returns the uploaded ModelObj object.
        """
        tmp_folder = TempFolder()
        model_file_path = f"{tmp_folder._temp_dir}/model.3dm"
        meshcollection._save_simple_3dm(model_file_path)
        model_dto = self._client.model.create_model(
            self.id,
            model_name,
            model_file_path,
            model_description,
            compress=True,
            geometry_checking_settings=geometry_checker_settings,
            metadata=metadata,
            category=category,
            parent_id=parent_id,
        )
        if not model_dto:
            logger.error(f"Failed to add model from mesh collection. Name: {model_name}")
            return None
        return ModelObj(model_dto, None, self._client)

    def _add_model_skip_gcs(
        self,
        model_name: str,
        model_file_path: str,
        layer_info: list[GeometryObjectLayerInfoDto],
        object_info: dict[str, GeometryObjectInfoDto],
        groups_volume: dict[int, float],
        model_description: str = None,
        parent_id: str = None,
    ):
        """
        Upload a model to project without running geometry checking service.
        """
        model_dto = self._client.model.create_model_no_gcs(
            self.id,
            model_name,
            model_file_path,
            json.dumps(layer_info, default=vars),
            json.dumps(object_info, default=vars),
            json.dumps(groups_volume, default=vars),
            description=model_description,
            parent_id=parent_id,
        )
        return ModelObj(model_dto, model_file_path, self._client)

    @utils.beta_feature()
    def join_models(
        self,
        source_model: str | ModelObj | ModelDto,
        target_models: list[str | Path | "MeshCollection"],
        target_transforms: list[Transform3d],
        new_model_name: str,
        new_model_description: str = None,
        geometry_checker_settings: GeometryCheckerSettingsDto = None,
        merge_by_layer_name: bool = True,
    ) -> ModelObj:
        """
        joins a model (source_model) with a list of models (target_models). Each of the target models can be given a transform to locate it inside of the source model.

        This method can be used to for example insert sound sources in connection with the boundary velocity functionality or to modify existing spaces by inserting furniture and other objects into an existing space

        :param str source_model: Name of model to insert the target model into
        :param list[str | MeshCollection] target_models: Path to the target model file to be uploaded or MeshCollection containing the geometry.
        :param list[Transform3d] target_model_transform: Transform of the target model.
        :param str new_model_name: Optional description of your model.
        :param str new_model_description: Optional description of your model.
        :param GeometryCheckerSettingsDto geometry_checker_settings: Optional advanced settings for geometry checking service.
        :param bool merge_by_layer_name: If true, objects in layers that share the same name will be merged into one layer. If False the layers will be kept separate by appending a number to the layer name.
        :returns ModelObj: Returns the uploaded ModelObj object.
        """
        if isinstance(source_model, ModelDto) or isinstance(source_model, str):
            source_model = self.get_model(source_model)
        if source_model.status != "Valid":
            logger.error(
                f"Source model {source_model.name} is in status {source_model.status}, make sure the model has been processed successfully and has status as 'Valid'"
            )
            return None

        source_model._has_valid_local_file(True)
        if m := utils.try_load_treble_module("geometry._join_models"):
            joined_meshcollection = m.join_models(
                source_model._model_file_path,
                target_models,
                target_transforms,
                merge_by_layer_name,
            )
            return self._add_model_from_meshcollection(
                new_model_name,
                joined_meshcollection,
                new_model_description,
                geometry_checker_settings=geometry_checker_settings,
            )
        return None

    def get_model(self, model: str | ModelObj | ModelDto) -> ModelObj | None:
        """
        Get model information as ModelDto.

        :param str|ModelDto model: Can either be a model id string or a ModelDto object.
        :returns ModelObj: Returns the ModelObj object or None if model was not found.
        """
        if isinstance(model, ModelDto) or isinstance(model, ModelObj):
            model = model.id
        model_dto = self._client.model.get_model(self.id, model)
        if model_dto:
            return ModelObj(model_dto, None, self._client)
        return None

    def get_model_by_name(self, name: str) -> ModelObj | None:
        """
        Get Model information as ModelDto. If multiple models match name then the model most recently
        created is returned. Returns None if model is not found.

        :param str name: Name of model to find.
        :returns ModelObj: Returns the ModelObj object or None if model was not found.
        """
        model_dto = self._client.model.get_model_by_name(self.id, name)
        if model_dto:
            return ModelObj(model_dto, None, self._client)
        return None

    def get_models(self) -> list[ModelObj]:
        """
        Get all models associated with this project.

        :returns list[ModelDto]: Returns a list of ModelDto objects.
        """
        return [ModelObj(dto, None, self._client) for dto in self._client.model.get_models(self.id)]

    def delete_model(self, model: str | ModelDto | ModelObj, force: bool = False) -> bool:
        """
        Delete model from project.

        :param str|ModelDto|ModelObj model: Can either be a model id string, ModelDto or a ModelObj object.
        :param bool force: If True, the model will be deleted even if it is still being processed.
        """
        if isinstance(model, ModelDto) or isinstance(model, ModelObj):
            model = model.id
        return self._client.model.delete_model(self.id, model, force)

    def delete_simulation(self, simulation, force: bool = False) -> bool:
        """
        Delete simulation from project.

        :param simulation: Simulation object or id of the simulation to delete.
        :param bool force: If True, the simulation will be canceled and deleted if it is running.
        """
        sim_id = simulation
        if isinstance(sim_id, Simulation) or isinstance(sim_id, SimulationDto):
            sim_id = simulation.id
        return self._client.simulation.delete_simulation(self.id, sim_id, force)

    def get_simulations(
        self, simulation_status: SimulationStatus = None, name: str = None
    ) -> list[Simulation]:
        """
        Get all simulations in project.
        Optional filter on simulation status, available values: created, starting, queued, in_progress, processing_results, completed, completed_with_source_errors, cancelled, error

        :return list[Simulation]: Returns a list of Simulation objects
        """
        simulations = self._client.project.get_simulations(self.id, simulation_status, name)
        if simulations:
            return [Simulation(item, self.id, self._client) for item in simulations]
        return []

    def get_simulation(self, simulation_id: str) -> Simulation | None:
        """
        Get a project simulation by simulation id.

        :param str simulation_id: Id of the simulation to fetch
        :return Simulation: Returns a Simulation object.
        """
        if not simulation_id:
            return None
        res = self._client.simulation.get_simulation(self.id, simulation_id)
        if not res:
            return None
        return Simulation(res, self.id, self._client)

    def get_simulation_by_name(self, name: str) -> Simulation | None:
        """
        Get a project simulation by simulation name.

        :param str name: Name of the simulation to fetch
        :return Simulation: Returns a Simulation object.
        """
        if not name:
            return None
        simulations = self.get_simulations(name=name)
        return simulations[0] if simulations else None

    def add_simulation(self, definition: SimulationDefinition) -> Simulation | None:
        """
        Create a simulation and add it to project.
        :param SimulationDefinition definition: Simulation definition.
        :returns Simulation: Returns a Simulation object which can be used to start and monitor the simulation
        """
        if not isinstance(definition, SimulationDefinition):
            logger.error("add_simulation requires a SimulationDefinition.")
            return None
        sims_added = self.add_simulations([definition])
        if not sims_added or len(sims_added) == 0:
            return None
        else:
            return sims_added[0]

    def add_simulations(self, definitions: list[SimulationDefinition]) -> list[Simulation | None]:
        """
        Add multiple simulations from a list of SimulationDefinition objects

        :param list[SimulationDefinition] definitions: List of Simulations to create.
        :returns list[Simulation]: Returns a list of simulation objects.
        """
        if not isinstance(definitions, list) or not all(
            [isinstance(d, SimulationDefinition) for d in definitions]
        ):
            logger.error("add_simulations only access a list of SimulationDefinitions.")
            return None
        # Convert any geometry_library_objs to models.
        self._convert_geometry_library_objs_to_models(definitions)
        self._populate_ir_length_autostop(definitions)
        res = self._client.simulation.create(self.id, [definition.to_dto() for definition in definitions])
        if res is None:
            return None
        else:
            return [Simulation(item, self.id, self._client) for item in res]

    def _convert_geometry_library_objs_to_models(self, definitions: list[SimulationDefinition]):
        """
        Find any GeometryLibraryObjs in defintions.model and convert them to ModelObjs.
        """
        # Construct a map of GeometryLibraryObj ids as keys and a list of simulation definitions as values.
        geo_id_to_simulations = defaultdict(list)
        for definition in definitions:
            if isinstance(definition.model, GeometryLibraryObj):
                geo_id_to_simulations[definition.model.id].append(definition)

        if len(geo_id_to_simulations.keys()) > 0:
            # Convert all geometry library objs found to models.
            model_dtos = self._client.geometry_library.geometry_to_model_definition(
                list(geo_id_to_simulations.keys()), self.id
            )

            # Map model_dto to simulation_definition.model.
            for model_dto in model_dtos:
                for sim_def in geo_id_to_simulations[model_dto.geometryLibraryId]:
                    model_file_path = None
                    # Check if we can link local model to ModelObj
                    if sim_def.model._has_valid_local_file(download_if_missing=False):
                        model_file_path = sim_def.model._model_file_path
                    sim_def.model = ModelObj(model_dto, model_file_path, self._client)

    def _populate_ir_length_autostop(self, definitions: list[SimulationDefinition]):
        """
        Populate ir length for autostop simulations.
        """
        # Map between unique model_ids and a list of the Simulation Definitions they belong to.
        model_ids_to_simulations: dict[str, list[SimulationDefinition]] = defaultdict(list)
        # List of simulation definitions that need Sabine calculations.
        sabine_simulations: list[SimulationDefinition] = []
        # Find any model ids that need sabine calculations.
        for definition in definitions:
            if definition.energy_decay_threshold is not None:
                if isinstance(definition.model, str):
                    model_ids_to_simulations[definition.model].append(definition)
                sabine_simulations.append(definition)

        if len(model_ids_to_simulations.keys()) > 0:
            # Convert sabine model ids to ModelObjs.
            model_objs = [
                ModelObj(dto, None, self._client)
                for dto in self._client.model.get_models_by_id(self.id, list(model_ids_to_simulations.keys()))
            ]
            for model in model_objs:
                for sim_def in model_ids_to_simulations[model.id]:
                    sim_def.model = model

        for sabine_sim in sabine_simulations:
            max_sabine_ir = max(sabine_sim.model.calculate_sabine_estimate(sabine_sim.material_assignment))
            sabine_sim.ir_length = max_sabine_ir * (sabine_sim.energy_decay_threshold / 35)

    def estimate(self) -> ProjectEstimation:
        """
        Estimate simulation runtime and tokens for the project.

        :returns ProjectEstimate: Returns ProjectEstimate containing total estimated runtime and total estimated cost in tokens, as well as estimations for each simulation.
        """
        return ProjectEstimation(dto=self._client.project.estimate(self.id))

    def wait_for_estimate(self, max_retries: int = 200) -> ProjectEstimation:
        """
        Wait for project estimate. Returns estimate object either if estimate is ready or if operation timed out.

        :param int max_retries: Maximum number of retries for getting estimate, defaults to 200.
        """
        retry_count = 0
        estimate = self.estimate()
        while estimate.result_status.result_code == 100 and retry_count < max_retries:
            time.sleep(2)
            estimate = self.estimate()
            retry_count += 1

        return estimate

    def get_progress(self) -> ProjectProgressInfo:
        """
        Get progress of simulations in a project.

        :returns ProjectProgressInfo: Returns ProjectProgressInfo object with total project progress percentage as well as progress for each simulation.
        """
        return ProjectProgressInfo(self._client.project.progress(self.id), client=self._client)

    def start_simulations(self) -> StartProjectResult:
        """
        Start all the simulations added to this project.
        The simulations are run in the cloud and do thus not keep your computer busy.
        The simulations can be monitored, cancelled or the results can be downloaded
        once the simulations are completed.

        :returns StartProjectDto: Data container with information on the simulations which were started
        """
        return StartProjectResult(
            project_id=self.id, project_name=self.name, dto=self._client.project.start(self.id)
        )

    def cancel_simulations(self) -> list[CancelSimulationResult] | None:
        """
        Cancel all project simulations that have not reached an end state.

        :returns CancelSimulationDto: Data container with information about the cancelled simulation
        """
        res = self._client.project.cancel(self.id)
        if not res:
            return None
        return [CancelSimulationResult(dto) for dto in res]

    def update(self, name: str | None, description: str | None):
        """
        Update project.

        :param name: New name, if None the name will not be updated.
        :param description: New description, if None the description will not be updated.
        """
        self._dto = self._client.project.update(self.id, ProjectUpdateDto(name, description))

    def __str__(self):
        return json.dumps(
            {
                "id": self.id,
                "name": self.name,
                "description": self.description,
                "created_at": self.created_at,
                "updated_at": self.updated_at,
                "created_by": self.created_by,
            },
            indent=2,
        )

    def __repr__(self):
        return f"Project(id='{self.id}', name='{self.name}', description='{self.description}')"

    def download_results(
        self,
        destination_directory: str | Path,
        result_type: ResultType = None,
        rename_rule: ResultRenameRule = ResultRenameRule.none,
        output_mode: utils.ProgressOutputMode = utils.ProgressOutputMode.TQDM_OUTPUT,
    ):
        """
        Download results for all simulations in the project to the destination directory.

        :param str|Path destination_directory: Destination directory to download results to.
        :param SimulationType | None result_type: Optional filter for result type.
        :param output_mode: Optional, set how download progress is reported.
        """

        output_mode, tqdm = utils.try_load_tqdm(output_mode)
        simulation_level_output_mode = output_mode

        completed_simulations = self.get_simulations(simulation_status=SimulationStatus.completed.value)
        dest_path = Path(destination_directory)
        dest_path.mkdir(exist_ok=True)
        completed_count = 0
        progress_bar = None
        if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
            progress_bar = tqdm.tqdm(
                total=len(completed_simulations),
                desc=f"Project {self.id}",
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} simulations",
            )
        if len(completed_simulations) > 100:
            simulation_level_output_mode = utils.ProgressOutputMode.NO_OUTPUT
        for simulation in completed_simulations:
            if rename_rule == ResultRenameRule.none:
                simulation_dest_path = dest_path / simulation.id
            else:
                simulation_dest_path = dest_path / simulation.name
            simulation.download_results(
                destination_directory=simulation_dest_path,
                result_type=result_type,
                rename_rule=rename_rule,
                output_mode=simulation_level_output_mode,
                progress_leave=False,
            )
            completed_count += 1
            if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
                progress_bar.update(1)
            elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
                logger.info(
                    f"({completed_count}/{len(completed_simulations)}) Downloaded results for simulation {simulation.name} ({simulation.id})"
                )
        if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
            progress_bar.close()
            print("Download completed")
        elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
            print("Download completed")

    def validate(self) -> list["SimulationValidationResults"] | None:
        """
        Validate all simulations in the project.
        """
        if m := utils.try_load_treble_module("geometry.validation"):
            return m.validate_project(self)
        return None

    def as_live_progress(self):
        """
        Uses the display_data module to show simulation progress, automatically updated until all simulations are completed or interrupt signal is received (CTRL+C).
        """
        if m := utils.try_load_treble_module("display_data"):
            m.as_live_progress(self)
