import copy
import tempfile
import warnings
from pathlib import Path

import h5py
import numpy as np

from ..client.api_models import DeviceDto
from ..client.tsdk_client import TSDKClient
from ..core.temp_folder import TempFolder
from ..utils import ProgressOutputMode, download_file, try_load_treble_module


class DeviceImpulseResponses:
    def __init__(self, impulse_responses: np.ndarray, sampling_rate: int):
        """
        Class to define impulse responses at microphone location with respect to
        impulses from sources which are defined in `DeviceSourceLocations`

        :param np.ndarray impulse_responses: An array of impulse responses where
            source number is the first axis and time the second one.
        :param int sampling_rate: Temporal sampling rate (samples per second)
        """
        self.impulse_response = impulse_responses
        self.sampling_rate = sampling_rate
        self.transfer_function, self.freq = self._fourier_transform_impulse_response(df=10)

    def _fourier_transform_impulse_response(self, df: int = 1) -> tuple[np.ndarray, np.ndarray]:
        """
        Take sofa time domain response and convert to frequency domain

        :param sf.Sofa sofa: frequency interval
        :return tuple[np.ndarray, np.ndarray]: Frequency domain response and relevant frequencies
        """
        # NOTE: will break if the length of the input DRTF time data is very large -> implement negative times
        n_fft = int(np.ceil(self.sampling_rate / df))
        f_fft = np.arange(n_fft) * df
        idx_freq = np.where(f_fft < self.sampling_rate / 2)[0]
        freq = f_fft[idx_freq]

        TF = np.fft.rfft(self.impulse_response, n_fft, axis=1) / self.sampling_rate
        TF = TF[:, idx_freq]

        return TF, freq


class DeviceSourceLocations:
    def __init__(self, azimuth_deg: np.ndarray, elevation_deg: np.ndarray):
        """
        Define the source positions of the sources used to create the DRTF.
        They are defined in azimuthal degrees (rotation around z axis) and
        elevation/latitude degrees (rotation around y axis after applying the
        azimuthal rotation of the coordinate system).

        We expect the azimuth degrees and the elevation degrees to have the same length

        :param np.ndarray azimuth_deg: Azimuth degrees from center to sources
        :param np.ndarray elevation_deg: Elevation degrees from center to sources
        """
        self.azimuth_deg = azimuth_deg
        self.elevation_deg = elevation_deg

        if self.azimuth_deg.shape != self.elevation_deg.shape:
            raise ValueError(
                f"Azimuth and elevation do not have the same shape: {self.azimuth_deg.shape=}, {self.elevation_deg.shape=}"
            )

    def _deg_to_rad(self, deg: np.ndarray) -> np.ndarray:
        return deg * np.pi / 180

    def _rad_to_deg(self, rad: np.ndarray) -> np.ndarray:
        return rad / np.pi * 180

    @property
    def elevation_rad(self):
        return self._deg_to_rad(self.elevation_deg)

    @property
    def azimuth_rad(self):
        return self._deg_to_rad(self.azimuth_deg)

    @property
    def colatitude_deg(self):
        return 90 - self.elevation_deg

    @property
    def colatitude_rad(self):
        return np.pi / 2 - self.elevation_rad


class DeviceTransferFunctions:
    def __init__(
        self,
        transfer_functions: np.ndarray,
        frequency_array: np.ndarray,
        sampling_rate: int,
    ):
        """
        Class to define impulse responses at microphone location with respect to
        impulses from sources which are defined in `DeviceSourceLocations`

        :param np.ndarray transfer_functions: An array of transfer functions where source number
            is the first axis and frequency on the second. If computed via FFT of impulse responses we
            expect that the FFT is scaled by time step
        :param np.ndarray frequency_array: The frequencies associated with the second axis of the `transfer_functions`
        :param int sampling_rate: Temporal sampling rate (samples per second)
        """
        self.transfer_function = transfer_functions
        self.freq = frequency_array
        self.sampling_rate = sampling_rate
        self.impulse_response = None


class DeviceMicrophone:
    def __init__(
        self,
        source_locations: DeviceSourceLocations,
        recordings: DeviceImpulseResponses | DeviceTransferFunctions,
        max_ambisonics_order: int,
        **kwargs,
    ):
        """
        Class to define a microphone on a device for a device related transfer function
        It takes in the source locations and the respective impulse responses

        :param DeviceSourceLocations source_locations: Location coordinates of sources
        :param DeviceImpulseResponses | DeviceTransferFunctions recordings: Impulse responses
            (time domain) or the Transfer functions (frequency domain) og the sources
        :param int max_ambisonics_order: Maximum ambisonics order to use when rendering device
        """

        self.source_locations = copy.deepcopy(source_locations)
        self.transfer_function = recordings.transfer_function
        self.sampling_rate = recordings.sampling_rate
        self.frequency = recordings.freq
        self.impulse_response = recordings.impulse_response

        if "Hnm" in kwargs:
            self.hnm = kwargs["Hnm"]

        self.max_ambisonics_order = min(max_ambisonics_order, 32)

        # When creating a DeviceMicrophone from an old DeviceObj this information is unavailable
        if self.source_locations is None:
            return

        if self.source_locations.elevation_deg.shape[0] != self.transfer_function.shape[0]:
            raise ValueError(
                "Number of source locations need to correspond to the number of impulse responses"
            )
        self.n_sources = self.source_locations.elevation_deg.shape[0]

        min_elevation = np.min(self.source_locations.elevation_deg)
        if min_elevation > -84:
            self._add_low_elevation_data(min_elevation=min_elevation)

    def _add_low_elevation_data(self, min_elevation: float):
        """
        If low elevation data is missing from DRTF, we add the required elevation angles
        by repeating the data at the lowest values.
        """
        # we need to add low elevation data manually
        idx = np.where(self.source_locations.elevation_deg == min_elevation)[0]
        delev = max(
            1.0, np.floor(np.min(np.abs(np.diff(self.source_locations.elevation_deg))))
        )  # find smallest angle stride
        elev_indiv_new = np.arange(
            start=min_elevation - delev, stop=-90 - delev, step=-delev
        )  # Generate new elevation data
        elev_total_new = np.repeat(elev_indiv_new, len(idx))
        azim_total_new = np.tile(self.source_locations.azimuth_deg[idx], elev_indiv_new.shape)

        # Append to original vectors
        self.source_locations.elevation_deg = np.concatenate(
            (self.source_locations.elevation_deg, elev_total_new)
        )
        self.source_locations.azimuth_deg = np.concatenate(
            (self.source_locations.azimuth_deg, azim_total_new)
        )
        self.n_sources = self.n_sources + len(azim_total_new)
        tf_total_new = np.tile(
            self.transfer_function[idx],
            (len(elev_indiv_new), 1),
        )
        self.transfer_function = np.concatenate((self.transfer_function, tf_total_new))

    def plot_spherical_harmonics(self):
        """
        Plots an overview of the DRTF spherical harmonics energy per order
        """
        if m := try_load_treble_module("postprocessing.DRTF"):
            m.plot_spherical_harmonics(device_microphone=self)

    def plot_transfer_function(
        self,
        angle: tuple[float, float] = None,
        frequency_range: tuple[float, float] = None,
    ):
        """
        Plot the frequency domain transfer function, either for all angles or for a
        given azimuth and/or elevation

        :param Optional[tuple[float, float]] angle: Azimuth angle and elevation angle corresponding to the ones in
            input, if left empty, will plot all angles, defaults to None
        :param Optional[tuple[float, float]] frequency_range: Frequency range to plot, defaults to None
        """
        if m := try_load_treble_module("postprocessing.DRTF"):
            m.plot_transfer_function(device=self, angle=angle, frequency_range=frequency_range)


class DeviceDefinition:
    def __init__(
        self,
        device_microphones: list[DeviceMicrophone],
        name: str,
        reference_frequency: float = 100,
        description: str = None,
        directory: str | Path = None,
        **kwargs,
    ):
        """
        Define a device as a list of DeviceMicrophone objects along with a name

        :param list[DeviceMicrophone] device_microphones: An ordered list of the microphones on the device
        :param str name: The name of the device
        :param float | None reference_frequency: Reference frequency for the device.
            The median transfer function at the reference frequency is scaled to 0 dB, defaults to 100
        :param str | None description: An optional description of the device, defaults to None
        :param str | Path directory: Directory to store the device definition file, None creates a temporary directory
            which is deleted as soon as the device is added to the project, defaults to None
        """
        self.device_microphones = device_microphones
        self.reference_frequency = reference_frequency
        if self.reference_frequency is not None:
            self._normalize_transfer_functions()
        self.max_ambisonics_order = min([x.max_ambisonics_order for x in self.device_microphones])
        self.name = name
        self.description = description
        self.source_locations = self.device_microphones[0].source_locations
        self.frequency = self.device_microphones[0].frequency
        if "file_exists" in kwargs:
            return
        if directory is None:
            self._tmpdir = tempfile.TemporaryDirectory()
            self._directory = Path(self._tmpdir.name)
        else:
            self._directory = Path(directory)
            self._tmpdir = None
        self.filename = self._write_device_info_to_file()

    def _normalize_transfer_functions(self):
        """
        Normalize the transfer functions to 0 dB at the reference frequency
        """
        # Collect median level at reference frequency
        all_tfs = np.array([mic.transfer_function[:, 0] for mic in self.device_microphones])
        for _i, mic in enumerate(self.device_microphones):
            idx = np.argmin(np.abs(mic.frequency - self.reference_frequency))
            all_tfs[_i] = mic.transfer_function[:, idx]
        median_db = np.median(20 * np.log10(np.abs(all_tfs)))
        for _i, mic in enumerate(self.device_microphones):
            self.device_microphones[_i].transfer_function = mic.transfer_function / (10 ** (median_db / 20))

    def plot_transfer_function(self, angle: tuple[float, float], frequency_range: tuple[float, float] = None):
        """
        Plot the frequency domain transfer function for a specific angle

        :param tuple[float, float] angle: Azimuth angle and elevation angle corresponding to the ones in
            input, if left empty, will plot all angles
        :param Optional[tuple[float, float]] frequency_range: Frequency range to plot, defaults to None
        """
        if m := try_load_treble_module("postprocessing.DRTF"):
            m.plot_transfer_function(device=self, angle=angle, frequency_range=frequency_range)

    def _write_device_info_to_file(self):
        filename = self._directory / f"{self.name}.h5"
        with h5py.File(name=filename, mode="w") as fh:
            # We assume fixed source locations between microphones. Should be a fair assumption
            source_locations = fh.create_group("sources")
            # NOTE: Worth performance/storage check different compression levels
            source_locations.create_dataset(
                name="azimuth",
                data=self.device_microphones[0].source_locations.azimuth_rad,
                compression="gzip",
                compression_opts=6,
            )
            source_locations.create_dataset(
                name="colatitude",
                data=self.device_microphones[0].source_locations.colatitude_rad,
                compression="gzip",
                compression_opts=6,
            )
            # We assume fixed frequency for the microphones. Should be fair as well
            fh.create_dataset(
                name="freq",
                data=self.device_microphones[0].frequency,
                compression="gzip",
                compression_opts=4,
            )
            microphones = fh.create_group(name="Microphones")
            for _i, mic in enumerate(self.device_microphones):
                mic_group = microphones.create_group(name=f"mic_{_i:03}")
                mic_group.create_dataset(
                    name="transfer_function",
                    data=mic.transfer_function,
                    compression="gzip",
                    compression_opts=4,
                )
            fh.attrs.create(name="max_order", data=self.max_ambisonics_order)
            fh.attrs.create(name="num_mics", data=len(self.device_microphones))
        return filename

    def __repr__(self):
        return f"DeviceDefinition(name={self.name}, device_microphone_count={len(self.device_microphones or [])})"


class DeviceObj:
    """
    Object used to represent the device for the device related transfer function (DRTF)
    """

    def __init__(self, deviceDto: DeviceDto, client: TSDKClient):
        self._dto = deviceDto
        self._client = client
        self.created_device_file_path = None
        self._temp_folder = None
        self._device_microphones = None

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def device_microphones(self) -> list[DeviceMicrophone]:
        if self._device_microphones is None:
            self.download_created_device_file()
            self._device_microphones = self.device_definition_from_object().device_microphones
        return self._device_microphones

    def _get_download_url(self) -> str:
        return self._client.device.get_device_file_url(self._dto.id)

    def download_created_device_file(self):
        if self.created_device_file_path and Path(self.created_device_file_path).exists():
            return
        if self._temp_folder is None:
            self._temp_folder = TempFolder()
        file_destination = Path(self._temp_folder.temp_dir) / f"{self.name}.h5"

        download_file(
            url=self._get_download_url(),
            dest_path=file_destination,
            progress_title=f"Downloading device data for {self.name}",
            output_mode=ProgressOutputMode.TQDM_OUTPUT,
        )
        self.created_device_file_path = file_destination

    def plot_transfer_function(
        self,
        angle: tuple[float, float],
        frequency_range: tuple[float, float] = None,
    ):
        """
        Plot the frequency domain transfer function for a specific angle

        :param tuple[float, float] angle: Azimuth angle and elevation angle corresponding to the ones in
            input
        :param Optional[tuple[float, float]] frequency_range: Frequency range to plot, defaults to None
        """
        if not self.created_device_file_path:
            self.download_created_device_file()
        if not self.created_device_file_path:
            raise ValueError("No device file present")
        if m := try_load_treble_module("postprocessing.DRTF"):
            m.plot_transfer_function(device=self, angle=angle, frequency_range=frequency_range)

    def device_definition_from_object(self) -> DeviceDefinition:
        """
        Create a device definition from the device file which the device object points to

        :param DeviceObj device: The device object for that specific device
        :return DeviceDefinition: The definition and specifications of the device
        """
        if not self.created_device_file_path:
            self.download_created_device_file()
        if not self.created_device_file_path:
            raise ValueError("No device file present")

        with h5py.File(self.created_device_file_path, "r") as f:
            if "Hnm" in f:
                drtf_order = f["Hnm"].attrs.get("maxOrder")
                drtf_sh_basis = f["Hnm"][:, :, :]
            else:
                # If device has been created this should not happen
                warning_message = "This device does not seem to have been created properly. "
                warning_message += "Please contact support if that is unexpected."
                warnings.warn(warning_message)
                drtf_order = 1
                drtf_sh_basis = np.matrix([[], [], []])

            freq = f["freq"][:]

            # Backwards compatibility wrt older devices. They don't have this information available
            if "sources" in f:
                sources = f["sources"]
                source_locations = DeviceSourceLocations(
                    azimuth_deg=sources["azimuth"][:] * 180 / np.pi,
                    elevation_deg=(np.pi / 2 - sources["colatitude"][:]) * 180 / np.pi,
                )
            else:
                source_locations = None
            if "Microphones" in f:
                microphones = f["Microphones"]
            else:
                microphones = None

            device_microphones = []
            for _i in range(drtf_sh_basis.shape[0]):
                input_data = {"Hnm": drtf_sh_basis[_i], "freq": freq}
                if microphones:
                    mic = microphones[f"mic_{_i:03}"]
                    recordings = DeviceTransferFunctions(
                        transfer_functions=mic["transfer_function"][:],
                        frequency_array=freq,
                        sampling_rate=None,
                    )
                else:
                    recordings = DeviceTransferFunctions(
                        transfer_functions=None,
                        frequency_array=freq,
                        sampling_rate=None,
                    )
                device_microphones.append(
                    DeviceMicrophone(
                        source_locations=source_locations,
                        recordings=recordings,
                        max_ambisonics_order=drtf_order,
                        **input_data,
                    )
                )

        return DeviceDefinition(
            device_microphones=device_microphones,
            name=self.name,
            file_exists=True,
            reference_frequency=None,
        )

    def __repr__(self):
        return f"DeviceObj(id='{self.id}', name='{self.name}')"
