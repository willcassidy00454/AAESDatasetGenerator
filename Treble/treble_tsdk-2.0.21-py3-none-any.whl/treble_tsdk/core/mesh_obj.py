from zipfile import ZipFile
from pathlib import Path
import importlib

from .temp_folder import TempFolder
from enum import Enum
from .. import utils
from ..client.api_models import SimulationMeshInfoDto, MeshInfoDto
from ..core.source_boundary_velocity import BoundaryVelocitySubmodel
from ..core.source import SourceDto
from ..treble_logging import logger
from ..utility_classes import Point3d, Rotation, Transform3d


class MeshStatisticsParameter(str, Enum):
    char_length = "charlength"
    edge_length = "edgelength"


class MeshObject:
    def __init__(self, mesh_info: MeshInfoDto, simulation: "Simulation" = None):
        self._dto = mesh_info

        self.id = mesh_info.id
        self.task_success = mesh_info.taskSuccess
        self.task_status = mesh_info.taskStatus
        self.created_at = mesh_info.createdAt
        self.source_id = mesh_info.sourceId
        self.mesh_binding = "Source" if self.source_id else "Simulation"
        self.crossover_frequency = mesh_info.crossoverFrequency
        self.element_count = mesh_info.elementCount
        self.element_min_height_m = 3 * (
            mesh_info.elementMinLength or 0.0
        )  # multiply by 3 to get the tetrahedron height from the characteristic length
        self.mesh_efficiency_percentage = mesh_info.meshQualityPercentage

        self._temp_folder = TempFolder()
        self._mesh_file_path = None

        self._model = None
        self._simulation = None
        self._source = None
        self._source_submodel = None
        if simulation:
            self._simulation = simulation
            self._model = simulation.get_model()
            if self.source_id:
                self._source = next((s for s in simulation.sources if s.id == self.source_id), None)

        self._title = self._construct_title()

    def __repr__(self):
        repr_str = f"MeshObject(id={self.id}, mesh_binding='{self.mesh_binding}'"
        if self.mesh_binding == "Source":
            repr_str += f", source_id={self.source_id}"
        elif self.mesh_binding == "Simulation" and hasattr(self, "_simulation"):
            repr_str += f", simulation_id={self._simulation.id}"
        repr_str += f", task_status='{self.task_status}', task_success={self.task_success}, element_count={self.element_count})"
        return repr_str

    def _add_submodel_to_mesh_collection(self, mesh_collection):
        submodel_id = self._source.source_properties.boundary_velocity_submodel_id
        if submodel_id not in self._simulation._boundary_velocity_submodel_cache:
            self._simulation._boundary_velocity_submodel_cache[submodel_id] = BoundaryVelocitySubmodel(
                self._simulation._client.boundary_velocity_submodel.get_by_id(submodel_id),
                client=self._simulation._client,
            )
        source_submodel = self._simulation._boundary_velocity_submodel_cache[submodel_id]
        submodel_mesh_collection = source_submodel._get_mesh_collection()
        submodel_mesh_collection = submodel_mesh_collection.transform(
            Transform3d(
                Point3d(x=self._source.x, y=self._source.y, z=self._source.z),
                Rotation(
                    azimuth=self._source.source_properties.azimuth_angle,
                    elevation=self._source.source_properties.elevation_angle,
                    roll=0,
                ),
            ),
        )
        if m := utils.try_load_treble_module("geometry.mesh_collection"):
            return m.MeshCollection.join_mesh_collections([mesh_collection, submodel_mesh_collection])
        else:
            return None

    def _construct_title(self) -> str:
        """
        Construct a title for the mesh object based on the available information.
        """
        if self._simulation and self._source:
            return f"{self._simulation.name} - {self._source.label} mesh"
        elif self._simulation:
            return f"{self._simulation.name} mesh"
        elif self._source.label:
            return f"{self._source.label} mesh"
        elif self._model:
            return f"{self._model.name} mesh"
        else:
            return f"Mesh {self.id}"

    def _has_valid_local_file(self, download_if_missing: bool = False) -> bool:
        """
        Attempts to find an existing mesh file if mesh has already been downloaded.
        Other wise it downloads it and returns the path to the mesh file.
        """
        if self._mesh_file_path is None and download_if_missing:
            download_url = self._dto.fileDownloadInfo.downloadUrl
            mesh_zip_path = f"{self._temp_folder.temp_dir}/{self._dto.id}.zip"
            logger.info("Loading mesh file...")
            utils.download_file(
                download_url,
                mesh_zip_path,
                output_mode=utils.ProgressOutputMode.TQDM_OUTPUT,
                progress_title="Downloading mesh: ",
            )

            # Extract file
            with ZipFile(str(mesh_zip_path), "r") as zip_obj:
                mesh_member = [member for member in zip_obj.filelist if member.filename.endswith(".msh")]
                if not mesh_member:
                    logger.error("No mesh file available")
                    return None
                mesh_file = mesh_member[0]
                self._mesh_file_path = zip_obj.extract(mesh_file, self._temp_folder.temp_dir)
            # Cleanup zip file
            Path(mesh_zip_path).unlink()
        return self._mesh_file_path is not None

    def get_model_layer_names(self) -> list[str]:
        if self._model:
            return self._model.wait_for_layer_names()
        else:
            logger.warning("No model information available to get layer names")

    def plot(
        self,
        layer_names: list[str] = None,
        smallest_element_length_threshold: float = None,
        n_small_elements: int = 100,
    ):
        """
        Use the plot module to plot the simulation mesh, plotting the surface mesh of the model.

        :param layer_names: Optional parameter to plot only the surface mesh of selected layers.
        :param smallest_element_length_threshold: Optional parameter to plot volume elements smaller than the given characteristic length (see ).
        :param n_small_elements: Optional parameter for limiting the number of small elements plotted.
        """
        if self._model is None:
            logger.warning("No model information available to plot mesh")
            return
        if not self.is_meshing_completed():
            logger.warning("Unable to plot mesh, meshing in progress")
            return
        if not self.was_meshing_successful():
            logger.warning("Unable to plot mesh, meshing was not successful")
            return
        if not self._has_valid_local_file(True):
            logger.warning("Unable to plot mesh, no mesh file available")
            return
        if Path(self._mesh_file_path).exists():
            try:
                plot_module = importlib.import_module("treble_tsdk.geometry.plot")
                self._model._has_valid_local_file(True)
                model_mesh_collection = importlib.import_module(
                    "treble_tsdk.geometry.mesh_collection"
                ).MeshCollection.load_3dm(self._model._model_file_path)
                if (
                    self._source
                    and self._source.source_type.value == "BoundaryVelocity"
                    and self._source.source_properties
                    and self._source.source_properties.boundary_velocity_submodel_id
                ):
                    model_mesh_collection = self._add_submodel_to_mesh_collection(model_mesh_collection)
                if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING", None) == "1":
                    plot_module.plot_surface_mesh(
                        self._mesh_file_path,
                        model_mesh_collection,
                        layer_names,
                        smallest_element_length_threshold,
                        n_small_elements,
                    )
                else:
                    plot_module.plot_surface_mesh_dash(
                        self._mesh_file_path,
                        model_mesh_collection,
                        layer_names,
                        smallest_element_length_threshold,
                        n_small_elements,
                    )
            except ImportError as e:
                logger.warning(
                    "Unable to find required treble_tsdk.geometry.plot module, has it been installed?",
                    exc_info=e,
                )

    @utils.beta_feature()
    def plot_mesh_statistics(
        self, parameter_type: MeshStatisticsParameter = MeshStatisticsParameter.char_length
    ) -> None:
        """
        Use the plot module to plot the simulation mesh, plotting the surface mesh of the model.

        :param layer_names: Optional parameter to plot only the surface mesh of selected layers.
        :param MeshStatisticsParameter parameter_type: select which mesh parameter to plot
        """
        if not self.is_meshing_completed():
            logger.warning("Unable to plot mesh statistics, meshing in progress")
            return
        if not self.was_meshing_successful():
            logger.warning("Unable to plot mesh statistics, meshing was not successful")
            return
        if not self._has_valid_local_file(True):
            logger.warning("Unable to plot mesh statistics, no mesh file available")
            return
        if Path(self._mesh_file_path).exists():
            try:
                plot = importlib.import_module("treble_tsdk.geometry.plot")
                return plot.plot_mesh_statistics(
                    self._construct_title(), self._mesh_file_path, parameter_type
                )
            except ImportError as e:
                logger.warning(
                    "Unable to find required treble_tsdk.geometry.plot module, has it been installed?",
                    exc_info=e,
                )

    def is_meshing_completed(self) -> bool:
        """
        Returns True if meshing process is finished, regardless of success or failure.
        See was_meshing_successful().
        """
        # Task may be marked as completed before task_sucess flag is set.
        if self.task_status not in ("Error", "Completed") or (
            self.task_status == "Completed" and self.task_success is None
        ):
            return False
        return True

    def was_meshing_successful(self) -> bool | None:
        """
        Returns True if meshing process was successful, False if it failed, and None if it is still in progress.
        """
        if not self.is_meshing_completed():
            logger.warning("Meshing is not completed, unable to determine if it was successful.")
            return None
        return self.task_success == True

    def as_tree(self):
        if m := utils.try_load_treble_module("display_data"):
            m.as_tree(self)


class SimulationMeshInfoCollection:
    def __init__(self, simulationMeshInfos: SimulationMeshInfoDto, simulation: "Simulation" = None):
        self._dto = simulationMeshInfos
        self._simulation = simulation
        self._meshing_completed = None
        self.simulation_mesh_info: MeshObject = None
        if simulationMeshInfos.simulationMeshInfo:
            self.simulation_mesh_info = MeshObject(simulationMeshInfos.simulationMeshInfo, simulation)
        else:
            logger.info(
                "No simulation mesh info available, this can happen if a simulation contains only boundary sources, please look at .source_mesh_infos_by_* info instead."
            )
        self.source_mesh_infos_by_id: dict[str, MeshObject] = {}
        self.source_mesh_infos_by_label: dict[str, MeshObject] = {}
        if simulationMeshInfos.sourceMeshInfos:
            source_id_to_label = {s.id: s.label for s in simulation.sources}
            for source_id, mesh_info in simulationMeshInfos.sourceMeshInfos.items():
                mesh_object = MeshObject(mesh_info, simulation)
                self.source_mesh_infos_by_id[source_id] = mesh_object
                if source_id in source_id_to_label:
                    self.source_mesh_infos_by_label[source_id_to_label[source_id]] = mesh_object
        self._is_meshing_completed_internal()

    def __repr__(self):
        return f"SimulationMeshInfoCollection(has_simulation_mesh={self.simulation_mesh_info != None}, source_mesh_count={len(self.source_mesh_infos_by_id.values())})"

    def as_table(self):
        if m := utils.try_load_treble_module("display_data"):
            m.as_table(self)

    def _is_meshing_completed_internal(self) -> bool:
        all_meshes = list(self.source_mesh_infos_by_label.values())
        if self.simulation_mesh_info:
            all_meshes.insert(0, self.simulation_mesh_info)
        self._meshing_completed = True
        for mesh in all_meshes:
            if not mesh.is_meshing_completed():
                self._meshing_completed = False
                break

        return self._meshing_completed

    def is_meshing_completed(self) -> bool | None:
        if self._meshing_completed:
            return self._meshing_completed

        if self._simulation is None:
            logger.error("Unable to determine if meshing is completed without a connection to a simulation!")
            return None

        # Update the mesh info and check if meshing is completed
        mesh_info_dto = self._simulation._get_mesh_info_internal()
        self.__init__(mesh_info_dto, self._simulation)
        return self._meshing_completed

    def as_live_mesher_progress(self):
        if m := utils.try_load_treble_module("display_data"):
            m.as_live_mesher_progress(self)

    def plot(
        self,
        source: SourceDto = None,
        layer_names: list[str] = None,
        smallest_element_length_threshold: float = None,
        n_small_elements: int = 100,
    ):
        """Plots the surface mesh of the tetrahedral computational mesh

        :param str mesh_label: label of, defaults to None
        :param layer_names: Optional parameter to plot only the surface mesh of selected layers.
        :param smallest_element_length_threshold: Optional parameter to plot volume elements smaller than the given characteristic length (see ).
        :param n_small_elements: Optional parameter for limiting the number of small elements plotted.
        """

        def get_mesh_obj(source_label: str):
            if source_label is None:
                source_label = next(iter(self.source_mesh_infos_by_label.keys()), None)
                if source_label is None:
                    return self.simulation_mesh_info

                if len(self.source_mesh_infos_by_label) > 1:
                    logger.info(
                        f"Plotting mesh for source {source_label}, use input argument to specify source"
                    )

                return self.source_mesh_infos_by_label[source_label]
            else:
                if len(self.source_mesh_infos_by_label) > 1:
                    if source_label not in self.source_mesh_infos_by_label.keys():
                        logger.warning(f"No mesh information available for source {source_label}")
                        return None

                    return self.source_mesh_infos_by_label[source_label]
                if source_label != self._simulation.sources[0].label:
                    logger.warning(f"No mesh information available for source {source_label}")
                    return None
                return self.simulation_mesh_info

        mesh_obj = get_mesh_obj(source.label if source else None)
        if mesh_obj:
            mesh_obj.plot(
                layer_names=layer_names,
                smallest_element_length_threshold=smallest_element_length_threshold,
                n_small_elements=n_small_elements,
            )
        else:
            logger.warning("No mesh found")
