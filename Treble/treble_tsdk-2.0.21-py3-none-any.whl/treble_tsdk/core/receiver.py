from enum import Enum
from ..utils import FreezableDict, is_valid_label
from ..utility_classes import Point3d, Rotation
from ..client.api_models import (
    ReceiverDto,
    ReceiverPropertiesDto,
    TraceIgnoreDto,
)
from .device_obj import DeviceObj
from ..treble_logging import logger


class ReceiverType(str, Enum):
    """
    Available receiver types.
    """

    mono = "Mono"
    spatial = "Spatial"

    @classmethod
    def list(cls):
        return [c.value for c in cls]

    @classmethod
    def print(cls):
        print("Available receiver types")
        for c in cls:
            print(f" - {c.value}")


class TraceIgnore(FreezableDict):
    def __init__(self, ms_to_cut_from_beginning: float, taper_width_in_ms: float = None):
        """
        To ignore the first milliseconds of a simulation result.

        :param float ms_to_cut_from_beginning: Number of milliseconds to cut away
        :param float | None taper_width_in_ms: Width of taper when tapering to zero in milliseconds, defaults to None
        """
        super().__init__()
        super().__setitem__("timeToCut", ms_to_cut_from_beginning / 1000)
        super().__setitem__("taperWidth", taper_width_in_ms / 1000 if taper_width_in_ms is not None else None)

    @property
    def time_to_cut(self) -> float:
        """
        Time to cut in seconds.
        """
        return self["timeToCut"]

    @time_to_cut.setter
    def time_to_cut(self, value: float):
        self._freeze_check()
        self["timeToCut"] = value

    @property
    def taper_width(self) -> float:
        """
        Taper width in seconds
        """
        return self["taperWidth"]

    @taper_width.setter
    def taper_width(self, value: float):
        self._freeze_check()
        self["taperWidth"] = value

    def __repr__(self):
        return f"TraceIgnore(time_to_cut={self.time_to_cut}, taper_width={self.taper_width})"

    @classmethod
    def _from_dto(cls, dto: TraceIgnoreDto, freeze: bool):
        o = cls(
            ms_to_cut_from_beginning=dto.timeToCut * 1000,
            taper_width_in_ms=dto.taperWidth * 1000 if dto.taperWidth is not None else None,
        )
        if freeze:
            o._deep_freeze()
        return o


class ReceiverProperties(FreezableDict):
    def __init__(
        self,
        ambisonics_sphere_radius_in_m: float = 0.1,
        ambisonics_order: int = None,
        trace_ignore: TraceIgnore = None,
        **kwargs,
    ):
        """
        Additional receiver properties further defining spatial receivers.
        For spatial receivers the only used parameter is the `ambisonics_sphere_radius_in_m`

        :param float ambisonics_sphere_radius_in_m: The radius in m of the sphere where receiver array will
            be generated on. From 0.05 to 0.15, defaults to 0.1
        :param int ambisonics_order: Sets the ambisonics order of spatial receiver, allowed values are 1, 2, 4, 8, 16 and 32. If this is set it
            will override the value set in the simulation settings for this receiver. If this is not set the default value will be 2.
        :param TraceIgnore | None trace_ignore: Experimental. Ignore a part of the results and replace with zeros
        """
        super().__init__()
        super().__setitem__("spatialRadius", ambisonics_sphere_radius_in_m)
        if ambisonics_order is not None:
            super().__setitem__("ambisonicsOrder", self._check_ambisonics_order(ambisonics_order))
        if trace_ignore is not None:
            super().__setitem__("traceIgnore", trace_ignore)

    def _check_ambisonics_order(self, value: int) -> int:
        if value not in [1, 2, 4, 8, 16, 32]:
            logger.error("Ambisonics order must be 1, 2, 4, 8, 16 or 32")
        return value

    @property
    def spatial_radius(self) -> float:
        return self["spatialRadius"]

    @spatial_radius.setter
    def spatial_radius(self, value: float):
        self._freeze_check()
        self["spatialRadius"] = value

    @property
    def ambisonics_order(self) -> int | None:
        """
        Ambisonics order of receiver.
        If this value is not set the simulation level ambisonics order is used which defaults to 2.
        """
        return self.get("ambisonicsOrder", None)

    @ambisonics_order.setter
    def ambisonics_order(self, value: int):
        self._freeze_check()
        self["ambisonicsOrder"] = self._check_ambisonics_order(value)

    @property
    def trace_ignore(self) -> TraceIgnore | None:
        return self.get("traceIgnore", None)

    @trace_ignore.setter
    def trace_ignore(self, value: TraceIgnore):
        self._freeze_check()
        self["traceIgnore"] = value

    def __repr__(self):
        return f"ReceiverProperties(spatial_radius={self.spatial_radius}, ambisonics_order={self.ambisonics_order}, trace_ignore={self.trace_ignore})"

    @classmethod
    def _from_dto(cls, dto: ReceiverPropertiesDto, freeze: bool):
        o = cls(
            ambisonics_sphere_radius_in_m=dto.spatialRadius,
            ambisonics_order=dto.ambisonicsOrder,
            trace_ignore=(
                TraceIgnore._from_dto(dto.traceIgnore, freeze) if getattr(dto, "traceIgnore", None) else None
            ),
        )
        if freeze:
            o._deep_freeze()
        return o


class Receiver(FreezableDict):
    def __init__(
        self,
        x: float,
        y: float,
        z: float,
        receiver_type: ReceiverType,
        label: str,
        receiver_properties: ReceiverProperties = None,
        id: str = None,
    ):
        """
        Represents a simulation Receiver.

        :param float x: X position of receiver in meters.
        :param float y: Y position of receiver in meters.
        :param float z: Z position of receiver in meters.
        :param ReceiverType receiver_type: Type of receiver.
        :param str label: Receiver label.
        :param ReceiverProperties receiver_properties: Optional, additional receiver properties.
        """
        super().__init__()
        super().__setitem__("id", id)
        super().__setitem__("x", x)
        super().__setitem__("y", y)
        super().__setitem__("z", z)
        super().__setitem__("receiverType", receiver_type.value)
        super().__setitem__("label", self._validate_label(label))
        if receiver_properties:
            super().__setitem__("receiverProperties", receiver_properties)

    def _validate_label(self, value: str) -> str:
        if not is_valid_label(value):
            logger.error(
                f"invalid source label '{value}'. source labels must be alphanumeric and may contain underscores."
            )
        return value

    @property
    def id(self) -> str:
        return self["id"]

    @property
    def location(self) -> Point3d:
        return Point3d(self.x, self.y, self.z)

    @location.setter
    def location(self, value: Point3d):
        self._freeze_check()
        self.x = value.x
        self.y = value.y
        self.z = value.z

    @property
    def x(self) -> float:
        return self["x"]

    @x.setter
    def x(self, value: float):
        self._freeze_check()
        self["x"] = value

    @property
    def y(self) -> float:
        return self["y"]

    @y.setter
    def y(self, value: float):
        self._freeze_check()
        self["y"] = value

    @property
    def z(self) -> float:
        return self["z"]

    @z.setter
    def z(self, value: float):
        self._freeze_check()
        self["z"] = value

    @property
    def receiver_type(self) -> ReceiverType:
        return ReceiverType(self["receiverType"])

    @receiver_type.setter
    def receiver_type(self, value: ReceiverType):
        self._freeze_check()
        self["receiverType"] = value.value

    @property
    def label(self) -> str:
        return self["label"]

    @label.setter
    def label(self, value: str):
        self._freeze_check()
        self["label"] = self._validate_label(value)

    @property
    def receiver_properties(self) -> ReceiverProperties:
        return self.get("receiverProperties", None)

    @receiver_properties.setter
    def receiver_properties(self, value: ReceiverProperties):
        self._freeze_check()
        self["receiverProperties"] = value

    def pos_as_point(self) -> Point3d:
        return Point3d(self.x, self.y, self.z)

    def __repr__(self):
        rep = f"Receiver(x={self.x}, y={self.y}, z={self.z}, label={self.label}, receiver_type={self.receiver_type}"
        if self.receiver_properties:
            rep += f", receiver_properties={self.receiver_properties}"
        return rep + ")"

    @classmethod
    def _from_dto(cls, dto: ReceiverDto, freeze: bool, ignore_id: bool = False):
        if dto.receiverType == "Device":
            dto.receiverType = "Spatial"
        o = cls(
            id=None if ignore_id else getattr(dto, "id", None),
            label=dto.label,
            x=float(dto.x),
            y=float(dto.y),
            z=float(dto.z),
            receiver_type=ReceiverType(dto.receiverType),
            receiver_properties=(
                ReceiverProperties._from_dto(dto.receiverProperties, freeze)
                if dto.receiverProperties
                else None
            ),
        )
        if freeze:
            o._deep_freeze()
        return o

    @classmethod
    def make_mono(
        cls, position: Point3d | list[float], label: str, receiver_properties: ReceiverProperties = None
    ):
        """
        Shortcut for creating a mono receiver.
        :param Point3d|list[float] position: Position of the receiver in meters.
        :param str label: Label of the receiver.
        :param ReceiverProperties receiver_properties: Optional, additional receiver properties.
        """
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            receiver_type=ReceiverType.mono,
            label=label,
            receiver_properties=receiver_properties,
        )

    @classmethod
    def make_spatial(
        cls,
        position: Point3d | list[float],
        label: str,
        ambisonics_order: int = None,
        ambisonics_sphere_radius_in_m: float = 0.1,
        receiver_properties: ReceiverProperties = None,
    ):
        """
        Shortcut for creating a spatial receiver.
        :param Point3d|list[float] position: Position of the receiver in meters.
        :param str label: Label of the receiver.
        :param int ambisonics_order: Ambisonics order of the receiver, defaults to 2.
        :param float ambisonics_sphere_radius_in_m: The radius in m of the sphere of receivers generated.
        :param ReceiverProperties receiver_properties: Optional, additional receiver properties.
        """
        if receiver_properties:
            receiver_properties.ambisonics_order = ambisonics_order
            receiver_properties.spatial_radius = ambisonics_sphere_radius_in_m
        else:
            receiver_properties = ReceiverProperties(
                ambisonics_order=ambisonics_order, ambisonics_sphere_radius_in_m=ambisonics_sphere_radius_in_m
            )
        return cls(
            x=position[0],
            y=position[1],
            z=position[2],
            receiver_type=ReceiverType.spatial,
            label=label,
            receiver_properties=receiver_properties,
        )
