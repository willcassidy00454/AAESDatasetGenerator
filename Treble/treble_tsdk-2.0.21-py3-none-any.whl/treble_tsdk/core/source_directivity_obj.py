import importlib
import json
from enum import Enum
from pathlib import Path
from zipfile import ZipFile
from dataclasses import dataclass

import numpy as np

from ..treble_logging import logger
from .. import utils
from ..client.api_models import SourceDirectivityDto
from ..client.tsdk_client import TSDKClient
from .temp_folder import TempFolder


class SourceDirectivityAmplified(Enum):
    """
    Available categories for amplified source directivities
    """

    full_range = "FullRange"
    line_array = "LineArray"
    portable = "Portable"
    installation = "Installation"
    ceiling = "Ceiling"
    en_54 = "EN54"
    studio_and_broadcast_monitor = "StudioAndBroadCastMonitors"
    subwoofers = "Subwoofers"
    cinema_speakers = "CinemaSpeakers"

    @classmethod
    def _type(cls):
        return "Amplified"

    @classmethod
    def list(cls):
        return [c.name for c in cls]

    @classmethod
    def print(cls):
        print("Available amplified source directivity sub categories")
        for c in cls:
            print(f" - {c.name}")


class SourceDirectivityNatural(Enum):
    """
    Available categories for natural source directivities
    """

    speech = "Speech"
    instrument = "Instrument"
    other = "Other"

    @classmethod
    def _type(cls):
        return "Natural"

    @classmethod
    def list(cls):
        return [c.name for c in cls]

    @classmethod
    def print(cls):
        print("Available natural source directivity sub categories")
        for c in cls:
            print(f" - {c.name}")


class SourceDirectivityOther(Enum):
    """
    Available categories for the uncategorized source directivities
    """

    test_sources = "TestSources"
    noise_sources = "NoiseSources"
    other = "Other"

    @classmethod
    def _type(cls):
        return "Other"

    @classmethod
    def list(cls):
        return [c.name for c in cls]

    @classmethod
    def print(cls):
        print("Available other source directivity sub categories")
        for c in cls:
            print(f" - {c.name}")


class SourceDirectivityCategory(Enum):
    """
    Available source directivity categories
    """

    amplified = SourceDirectivityAmplified
    natural = SourceDirectivityNatural
    other = SourceDirectivityOther

    @classmethod
    def list(cls):
        return [c.name for c in cls]

    @classmethod
    def print(cls):
        print("Available source directivity categories")
        for c in cls:
            print(f" - {c.name}")


class SourceDirectivityObj:
    def __init__(
        self,
        source_directivity_dto: SourceDirectivityDto,
        client: TSDKClient,
    ):
        self._dto = source_directivity_dto
        self._client = client
        self._temp_dir = None
        self._dg_directivity_file_path = None
        self._original_dg_file_hash = None
        self._ga_directivity_file_path = None
        self._original_ga_file_hash = None

    @property
    def id(self) -> str:
        return self._dto.id

    @property
    def name(self) -> str:
        return self._dto.name

    @property
    def description(self) -> str:
        return self._dto.description

    @property
    def category(self) -> str:
        return self._dto.category

    @property
    def sub_category(self) -> str:
        return self._dto.subCategory

    @property
    def manufacturer(self) -> str:
        return self._dto.manufacturer

    @property
    def organization_id(self) -> str:
        return self._dto.organizationId

    @property
    def max_crossover_frequency(self) -> int | None:
        return self._dto.maxCrossoverFrequency

    @property
    def simulation_type_filter(self) -> list[str] | None:
        return self._dto.simulationTypeFilter

    def _has_valid_local_file(
        self, file_path, _original_file_hash, download_file, download_if_missing: bool = False
    ) -> bool:
        # Check if the source directivity file is available locally
        if file_path and Path(file_path).is_file() and _original_file_hash:
            # Found directivity file, verify the file is still valid
            new_hash = utils.calculate_file_hash(file_path)
            if _original_file_hash == new_hash:
                return file_path, _original_file_hash
        if download_if_missing:
            if self._temp_dir is None:
                self._temp_dir = TempFolder()
            file = download_file()
            if file.endswith(".zip"):
                # Extract file
                with ZipFile(str(file), "r") as zip_obj:
                    # Find directivity json file
                    directivity_member = [
                        member for member in zip_obj.filelist if member.filename.endswith(".json")
                    ][0]
                    zip_obj.extract(directivity_member, self._temp_dir.temp_dir)
                    file_path = f"{self._temp_dir.temp_dir}/{directivity_member.filename}"
                return file_path, utils.calculate_file_hash(file_path)
            else:
                # File was not compressed
                file_path = file
            return file_path, utils.calculate_file_hash(file_path)
        return None, None

    def _has_valid_local_file_dg_directivity(self, download_if_missing: bool = False) -> bool:
        file_path, hash = self._has_valid_local_file(
            self._dg_directivity_file_path,
            self._original_dg_file_hash,
            self._download_local_dg_directivity_file,
            download_if_missing,
        )
        if file_path != None and hash != None:
            self._dg_directivity_file_path = file_path
            self._original_dg_file_hash = hash
            return True
        return False

    def _has_valid_local_file_ga_directivity(self, download_if_missing: bool = False) -> bool:
        file_path, hash = self._has_valid_local_file(
            self._ga_directivity_file_path,
            self._original_ga_file_hash,
            self._download_local_ga_directivity_file,
            download_if_missing,
        )
        if file_path != None and hash != None:
            self._ga_directivity_file_path = file_path
            self._original_ga_file_hash = hash
            return True
        return False

    def _download_local_dg_directivity_file(self) -> str | None:
        """
        Download dg directivity file

        :returns str: Path to downloaded file, None if unable to download file
        """
        download_url = self._client.source_directivity.get_download_url(self._dto.id)
        if download_url is None:
            logger.warning(f"Unable to download source directivity {self._dto.id}")
            return None
        destination_file = f"{self._temp_dir.temp_dir}/{self._dto.dgDirectivityUploadId}.json"
        utils.download_file(download_url, destination_file)
        return destination_file

    def _download_local_ga_directivity_file(self) -> str | None:
        """
        Download ga directivity file

        :returns str: Path to downloaded file, None if unable to download file
        """
        download_url = self._client.source_directivity.get_download_ga_directivity_url(self._dto.id)
        if download_url is None:
            logger.warning(f"Unable to download ga source directivity {self._dto.id}")
            return None
        destination_file = f"{self._temp_dir.temp_dir}/{self._dto.gaDirectivityUploadId}.json"
        utils.download_file(download_url, destination_file)
        return destination_file

    def plot_directivity_pattern(self):
        if self._dto.dgDirectivityUploadId is None:
            logger.info("No SPL data available")
            return

        dg_file_valid = self._has_valid_local_file_dg_directivity(True)
        # ga_file_valid = self._has_valid_local_file_ga_directivity(True)

        if dg_file_valid == False:
            logger.info("No SPL data available!")
            return

        data = json.loads(open(self._dg_directivity_file_path, "r").read())

        mono = data["mono_coefficient"]
        dipole = data["dipole_coefficient"]
        frequency = data["frequency"]
        # Constructing arrays to compute directivity
        azimuth_rad = np.arange(0, 360 + 10, 10) * np.pi / 180
        elevation_rad = np.arange(-90 - 10, 90 + 10, 10) * np.pi / 180
        elevation_mesh, phi_mesh = np.meshgrid(elevation_rad, azimuth_rad)

        # Convert spherical coordinates to Cartesian
        x_coordinate = np.cos(elevation_mesh) * np.cos(phi_mesh)
        y_coordinate = np.cos(elevation_mesh) * np.sin(phi_mesh)
        z_coordinate = np.sin(elevation_mesh)

        coordinates = np.array([x_coordinate.ravel(), y_coordinate.ravel(), z_coordinate.ravel()])
        n_s = np.array(
            [
                np.ones_like(elevation_mesh).ravel(),
                np.zeros_like(elevation_mesh).ravel(),
                np.zeros_like(elevation_mesh).ravel(),
            ]
        )
        gamma = np.arccos(
            np.sum(n_s.conj() * coordinates, axis=0).reshape(elevation_mesh.shape[0], elevation_mesh.shape[1])
        )
        unity_array = np.ones_like(x_coordinate)
        dipole = np.cos(gamma)
        directive_source = np.zeros((len(frequency), unity_array.shape[0], unity_array.shape[1]))
        frequency = np.array(frequency)
        relevant_freqs = frequency[np.nonzero(frequency < 12_000)[0]]
        for _i, freq in enumerate(relevant_freqs):
            pattern = mono[_i] * unity_array + dipole[_i] * dipole
            # Normalization of pattern:
            directive_source[_i] = 20 * np.log10((np.abs(pattern)) / 20e-6)

        try:
            importlib.import_module("treble_tsdk.results.plot").plot_directive_source(
                directivity=directive_source,
                frequency=relevant_freqs,
                x_coordinates=x_coordinate,
                y_coordinates=y_coordinate,
                z_coordinates=z_coordinate,
                name=self.name,
            )
        except ImportError:
            logger.error("Results module could not be loaded, is it installed?")

    def plot_spl_on_axis(self):
        try:
            importlib.import_module("treble_tsdk.geometry.plot").plot_spl_on_axis(self)
        except ImportError:
            logger.error("geometry.plot module could not be loaded, is it installed?")

    def __repr__(self) -> str:
        return f"SourceDirectivityObj(id='{self.id}', name='{self.name}', category='{self.category}', sub_category='{self.sub_category}', manufacturer='{self.manufacturer}')"


@dataclass
class DirectivityPatternInputData:
    """
    Container for the directivity pattern input data, the direcitivity frequency responses should be structure as [n_points, n_frequencies].
    The points is require to lie on a sphere and be distributed somewhat evenly across the sphere.
    If measurement points are missing. e.g. below the source, please provide interpolated values in the input
    """

    frequencies: np.ndarray
    points: np.ndarray
    frequency_responses: np.ndarray

    def __post_init__(self):
        self.frequencies = np.array(self.frequencies)
        self.points = np.array(self.points)
        self.frequency_responses = np.array(self.frequency_responses)
