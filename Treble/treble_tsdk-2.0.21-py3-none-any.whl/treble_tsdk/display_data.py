from enum import Enum
from datetime import datetime
from .core.simulation import (
    CancelSimulationResult,
    Simulation,
    SimulationProgressInfo,
    SimulationStatus,
    MaterialAssignment,
    LocalMeshSizing,
    SimulationEstimate,
)
from .core.material_obj import Material
from .core.source import Source
from .core.mesh_obj import MeshObject, SimulationMeshInfoCollection
from .core.project import Project, ProjectEstimation, ProjectProgressInfo, StartProjectResult
from .core.model_obj import ModelObj
from .core.geometry_library_obj import GeometryLibraryObj
from .core.source_directivity_obj import SourceDirectivityObj
from .core.device_obj import DeviceObj
from .core.source_boundary_velocity import BoundaryVelocitySubmodel
from .client.api_models import (
    ProjectEstimateDto,
    SimulationEstimateDto,
    ProjectDto,
    SimulationProgressDto,
    OverviewDto,
    CategoryInfoDto,
    ModelDto,
    DeviceDto,
    SourceDto,
)
from .geometry.validation import SimulationValidationResults
from rich.tree import Tree
from rich.table import Table
from rich.console import Console

C_TOKENS = "green"
C_HOURS = "magenta"

ID_COL_LENGTH = 36


def _is_notebook() -> bool:
    try:
        shell = get_ipython().__class__.__name__
        if shell == "ZMQInteractiveShell":
            return True  # Jupyter notebook or qtconsole
        elif shell == "TerminalInteractiveShell":
            return False  # Terminal running IPython
        elif get_ipython().__class__.__module__ == "google.colab._shell":
            return True
        else:
            return False  # Other type (?)
    except NameError:
        return False  # Probably standard Python interpreter


def _get_colored_sim_status(status: str):
    if status in ["Starting", "InProgress", "ProcessingResults"]:
        return f"[cornflower_blue]{status}[/cornflower_blue]"
    elif status == "Completed":
        return f"[green]{status}[/green]"
    elif status in ["CompletedWithSourceErrors", "Error"]:
        return f"[red1]{status}[/red1]"
    else:
        return status


def _get_colored_model_status(status: str):
    if status == "Processing":
        return f"[cornflower_blue]{status}[/cornflower_blue]"
    elif status == "Valid":
        return f"[green]{status}[/green]"
    elif status == "NotValid":
        return f"[red1]{status}[/red1]"
    else:
        return status


def _parse_timestamp(timestamp: str, trim_seconds: bool = False):
    format = "%Y-%m-%dT%H:%M:%S.%fZ" if "." in timestamp else "%Y-%m-%dT%H:%M:%SZ"
    try:
        if trim_seconds:
            return datetime.strptime(timestamp, format).strftime("%Y-%m-%d %H:%M")
        else:
            return datetime.strptime(timestamp, format).strftime("%Y-%m-%d %H:%M:%S")
    except:
        return timestamp


def _cut_string(data: str, length: str = 50):
    if data and len(data) > length:
        return f"{data[:length]}..."
    else:
        return data or ""


def _join_list(data: list, delimiter: str = ", ") -> str:
    if data:
        if isinstance(data, list):
            return delimiter.join(map(str, data))
        else:
            return str(data)
    return ""


def _get_max_length(data: list[str], cut_off_at: int = None):
    max_length = 0
    for s in data:
        length = len(s)
        if cut_off_at and length > cut_off_at:
            return cut_off_at
        else:
            max_length = max(max_length, length)
    return max_length


def _visualize_start_project_result_tree(res: StartProjectResult):
    root = Tree(f"Project {res.project_name} started")
    started = root.add(f"Started simulations:")
    for sim in res.started_simulations:
        started.add(f"{sim.name} ({sim.id}) - {sim.status}")
    already_started = root.add(f"Already started simulations:")
    for sim in res.already_started_simulations:
        already_started.add(f"{sim.name} ({sim.id}) - {sim.status}")
    already_end_state = root.add(f"Simulations already in end state:")
    for sim in res.already_end_state_simulations:
        already_end_state.add(f"{sim.name} ({sim.id}) - {sim.status}")
    return root


def _visualize_validation_results_tree(res: SimulationValidationResults):
    root = Tree(f"Validation results for {res.simulation_name} ({res.simulation_id})")
    if res.is_valid:
        root.add("is_valid: [green]true[/green]")
    else:
        root.add("is_valid: [red1]false[/red1]")
        if res.invalid_receivers and len(res.invalid_receivers) > 0:
            receivers_branch = root.add("Invalid receivers")
            for check in res.invalid_receivers:
                r = receivers_branch.add(f"{check.receiver_label} ({check.receiver_id})")
                r.add(f"Position: {check.receiver_position}")
                r.add(f"Check: {check.check}")
        if res.invalid_sources and len(res.invalid_sources) > 0:
            sources_branch = root.add("Invalid sources")
            for check in res.invalid_sources:
                r = sources_branch.add(f"{check.source_label} ({check.source_id})")
                r.add(f"Position: {check.source_position}")
                r.add(f"Check: {check.check}")
        if res.layers_without_material_assignment and len(res.layers_without_material_assignment) > 0:
            layers_branch = root.add("Layers without material assignment")
            for layer_name in res.layers_without_material_assignment:
                layers_branch.add(layer_name)
        if res.invalid_settings:
            settings_branch = root.add("Invalid simulation settings")
            for message in res.invalid_settings:
                settings_branch.add(message)
        if res.error_message:
            root.add(f"Error message: {res.error_message}")
    return root


def _visualize_overview_dto_tree(res: OverviewDto):
    maxSimulations = 20
    root = Tree("Overview")
    root.add(f"User email: {res.email}")
    org = root.add(f"Organization: {res.organizationName}")
    sub = org.add(f"Subscriptions")
    res.products.sort(key=lambda x: x.productKey, reverse=True)
    for product in res.products:
        key = sub.add(f"{product.productKey}")
        key.add(f"Expires at: {_parse_timestamp(product.expiresAt, True)}")
        if product.productKey == "TASS":
            key.add(f"Maximum concurrency: {product.concurrency}")
        if product.productKey == "TSDK":
            key.add(f"Maximum CPU concurrency: {product.sdkMaxCpuConcurrency}")
            key.add(f"Maximum GPU concurrency: {product.sdkMaxGpuConcurrency}")
            key.add(f"Maximum task concurrency: {product.sdkMaxGpuCountPerTask}")
            if product.sdkTier:
                key.add(f"SDK Tier: {product.sdkTier}")
    org.add(f"Queued task count: {res.queuedCpuTasks + res.queuedGpuTasks}")

    rs = org.add(f"Running simulations ({res.runningSimulationsCount})")
    runningCount = (
        res.runningSimulationsCount if res.runningSimulationsCount < maxSimulations else maxSimulations
    )
    for sim in res.runningSimulations[:maxSimulations]:
        sub = rs.add(f"{sim.simulationName} ({sim.simulationId})")
        sub.add(f"Status: {sim.simulationStatus}")
        sub.add(f"ProgressPercentage: {sim.simulationProgressPercentage}%")
        sub.add(f"Project: {sim.projectName} ({sim.projectId})")
    if res.runningSimulationsCount > 0:
        rs.add(f"{runningCount} / {res.runningSimulationsCount}")

    qs = org.add(f"Queued simulations ({res.queuedSimulationsCount})")
    queuedCount = (
        res.queuedSimulationsCount if res.queuedSimulationsCount < maxSimulations else maxSimulations
    )
    for sim in res.queuedSimulations[:maxSimulations]:
        qs.add(f"{sim.simulationName} ({sim.simulationId})")
    if res.queuedSimulationsCount > 0:
        qs.add(f"{queuedCount} / {res.queuedSimulationsCount}")
    return root


def _visualize_geometry_library_dto_tree(res: GeometryLibraryObj):
    root = Tree(res.name)
    root.add(f"Id: {res.id}")
    root.add(f"Description: {res.description}")
    root.add(f"Layer: {_join_list(res.layer_names)}")
    sx = root.add("Position suggestions")
    for item in res.position_suggestions:
        ss = sx.add(item.name)
        ss.add(f"Position: {item.position}")
        if item.space:
            ss.add(f"Space: {item.space}")
    if res.metadata:
        root.add(f"Metadata: {res.metadata}")
    return root


def _visualize_mesh_object_tree(mesh: MeshObject):
    root = Tree(f"{mesh._title}")
    root.add(f"Id: {mesh.id}")
    root.add(f"Mesh binding: {mesh.mesh_binding}")
    if mesh._simulation and mesh._simulation.id and mesh._simulation.name:
        root.add(f"Simulation: {mesh._simulation.name} ({mesh._simulation.id})")
    if mesh.source_id:
        root.add(f"Source: {mesh.source_label} ({mesh.source_id})")
    root.add(f"CreatedAt: {_parse_timestamp(mesh.created_at)}")
    root.add(f"Crossover frequency: {mesh.crossover_frequency}")
    root.add(f"TaskSuccess: {mesh.task_success}")
    if mesh.task_success is None and mesh._dto.mesherTaskInfo:
        status = mesh._dto.mesherTaskInfo.status
    else:
        status = "Success" if mesh.task_success else "Error"
    root.add(f"TaskStatus: {status}")
    if mesh.task_status not in ("Completed", "Error") and mesh._dto.mesherTaskInfo:
        root.add(f"Progress Percentage: {mesh._dto.mesherTaskInfo.progress_percentage}%")
    if mesh.is_meshing_completed() and mesh.was_meshing_successful():
        root.add(f"Element count: {mesh.element_count}")
        element_min_length = round(mesh.element_min_height_m, 6) if mesh.element_min_height_m else ""
        root.add(f"Element min characteristic length: {element_min_length} meters")
        root.add(f"Mesh quality percentage: {mesh.mesh_efficiency_percentage}%")
    return root


def _visualize_simulation_mesh_collection_as_table(mesh_collection: SimulationMeshInfoCollection):
    table = Table(title="Mesh Info")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Status")
    table.add_column("Mesh binding")
    table.add_column("Source label")
    table.add_column("Crossover frequency")
    table.add_column("Element count")
    table.add_column("Element min height")
    table.add_column("Mesh efficiency percentage")
    mesh_list = list(mesh_collection.source_mesh_infos_by_id.values())
    if mesh_collection.simulation_mesh_info:
        mesh_list.insert(0, mesh_collection.simulation_mesh_info)
    for mesh in mesh_list:
        if mesh.task_success is None and mesh._dto.mesherTaskInfo:
            if mesh._dto.mesherTaskInfo.status == "InProgress":
                status = f"InProgress ({mesh._dto.mesherTaskInfo.progressPercentage}%)"
            else:
                status = mesh._dto.mesherTaskInfo.status
        else:
            status = "Success" if mesh.task_success else "Error"

        element_min_height = round(mesh.element_min_height_m, 6) if mesh.element_min_height_m else ""
        source_label = getattr(mesh._source, "label", None) or mesh.source_id
        table.add_row(
            mesh.id,
            str(status),
            mesh.mesh_binding,
            source_label,
            str(mesh.crossover_frequency),
            str(mesh.element_count),
            str(element_min_height),
            str(mesh.mesh_efficiency_percentage),
        )
    return table


def _visualize_simulation_tree(sim: Simulation):
    root = Tree(f"{sim.name} ({sim.id})")
    root.add(f"Status: {sim._dto.status}")
    source_branch = root.add("Sources")
    for source in sim.sources:
        s = source_branch.add(f"{source.label} ({source.id})")
        s.add(f"Type: {source.source_type}")
        s.add(f"Position: {source.x}, {source.y}, {source.z}")
        if hasattr(source, "sourceProperties") and source.source_properties:
            s.add(
                f"azimuth: {source.source_properties.azimuth_angle}°, elevation: {source.source_properties.elevation_angle}°"
            )
    receiver_branch = root.add("Receivers")
    for receiver in sim.receivers:
        r = receiver_branch.add(f"{receiver.label} ({receiver.id})")
        r.add(f"Type: {receiver.receiver_type}")
        r.add(f"Position: {receiver.x}, {receiver.y}, {receiver.z}")
    layer_branch = root.add("Layers")
    for layer, material_ass in sim.layer_material_assignment.items():
        layer_branch.add(f"{layer} - {material_ass.material_name} ({material_ass.material_id})")
    if sim.local_mesh_sizing and len(sim.local_mesh_sizing):
        local_sizing_branch = root.add("Local mesh sizing")
        for layer, local_sizing in sim.local_mesh_sizing.items():
            local_sizing_branch.add(
                f"{layer} - local size: {local_sizing.mesh_sizing_m}, keep exterior edges: {getattr(local_sizing, 'keep_exterior_edges', False)}"
            )
    return root


def _visualize_simulation_estimate_tree(res: SimulationEstimateDto, skip_sources: bool = False) -> Tree:
    root = Tree(f"{res.simulationName} ({res.simulationId})")
    root.add(f"Result status: {res.resultStatus.result_code_name}")
    root.add(f"Result message: {res.resultStatus.message}")
    root.add(f"Simulation status: {res.simulationStatus}")
    root.add(f"Total estimated Runtime [bold cyan]{res.totalEstimatedRuntimeHours}[/bold cyan] hours")
    root.add(f"Total estimated cost [bold cyan]{res.totalEstimatedCostInTokens}[/bold cyan] tokens")
    if res.supportedGpuCounts:
        gpu_node = root.add("Supported GPU counts")
        gpu_node.add(f"Minimum per task: {res.supportedGpuCounts.minimum_gpu_count}")
        gpu_node.add(f"Recommended per task: {res.supportedGpuCounts.recommended_gpu_count}")
        gpu_node.add(f"Maximum per task: {res.supportedGpuCounts.maximum_allowed_gpu_count}")
    if not skip_sources:
        s = root.add("Sources")
        for source in res.estimatePerSource:
            sx = s.add(f"{source.sourceLabel} ({source.sourceId})")
            sx.add(f"Estimated Runtime [bold {C_HOURS}]{source.estimatedRuntimeHours}[/bold {C_HOURS}] hours")
            sx.add(
                f"Total estimated cost [bold {C_TOKENS}]{source.estimatedCostInTokens}[/bold {C_TOKENS}] tokens"
            )
    return root


def _visualize_project_estimate_tree(res: ProjectEstimateDto) -> Tree:
    root = Tree(res.projectId)
    root.add(
        f"[bold]Total estimated Runtime [{C_HOURS}]{res.totalEstimatedRuntimeHours}[/{C_HOURS}] hours[/bold]"
    )
    root.add(
        f"[bold]Total estimated cost [{C_TOKENS}]{res.totalEstimatedCostInTokens}[/{C_TOKENS}] tokens[/bold]"
    )
    sim_branch = root.add("Simulations")
    for sim in res.simulationEstimates:
        sim_branch.add(_visualize_simulation_estimate_tree(sim, skip_sources=True))
    return root


def _visualize_simulation_progress_tree(res: SimulationProgressInfo) -> Tree:
    root = Tree(res.simulation_name)
    root.add(f"Id: {res.simulation_id}")
    root.add(f"Status: {_get_colored_sim_status(res.simulation_status)}")
    root.add(f"Percentage completed: {res.simulation_progress_percentage}%")
    s = root.add("Sources")
    for source in res.sources:
        sx = s.add(f"{source.label} ({source.id})")
        sx.add(f"Type: {source.source_type}")
        if source.tasks:
            for task in source.tasks:
                st = sx.add("Tasks")
                st.add(f"Id: {task.id}")
                if task.task_sub_type and task.task_sub_type != "None":
                    st.add(f"Type: {task.task_type} ({task.task_sub_type})")
                else:
                    st.add(f"Type: {task.task_type}")
                st.add(f"Status: {task.status}")
                st.add(f"Percentage completed: {task.progress_percentage}%")
    return root


def _visualize_material_tree(res: Material) -> Tree:
    root = Tree(res.name)
    root.add(f"Id: {res.id}")
    root.add(f"Description: {res.description}")
    root.add(f"Category: {res.category}")
    root.add(f"Default scattering coefficient: {res.default_scattering}")
    root.add(f"Absorption coefficients: {_join_list(res.absorption_coefficients)}")
    return root


def _visualize_model_tree(res: ModelObj) -> Tree:
    is_watertight = res.is_watertight if res.status in ("Valid", "NotValid") else "None"
    root = Tree(res.name)
    root.add(f"Id: {res.id}")
    root.add(f"Status: {_get_colored_model_status(res._dto.status)}")
    root.add(f"Status message: {res.status_message}")
    root.add(f"Is watertight: {is_watertight}")
    root.add(f"Filename: {res._dto.filename}")
    root.add(f"Filesize: {round(res._dto.filesize/1024, 2)}KB")
    root.add(f"Layers: {res.layer_names}")
    return root


def _visualize_project_estimate_table(res: ProjectEstimateDto) -> Table:
    table = Table(title=f"Project {res.projectId} estimate", show_footer=True)
    table.add_column("Simulation", justify="right", no_wrap=True, footer="[b]Total")
    table.add_column(
        "Simulation status",
        justify="right",
        footer="",
    )
    table.add_column(
        "Estimated runtime (hours)",
        justify="right",
        style=C_HOURS,
        footer=f"[{C_HOURS}]{res.totalEstimatedRuntimeHours}[/{C_HOURS}]",
    )
    table.add_column(
        "Estimated cost (tokens)",
        justify="right",
        style=C_TOKENS,
        footer=f"[{C_TOKENS}]{res.totalEstimatedCostInTokens}[/{C_TOKENS}]",
    )

    for sim in res.simulationEstimates:
        table.add_row(
            f"{sim.simulationName} ({sim.simulationId})",
            sim.simulationStatus,
            str(sim.totalEstimatedRuntimeHours),
            str(sim.totalEstimatedCostInTokens),
        )

    return table


def _visualize_task_table(res: list[Source]) -> Table:
    table = Table(title="Task list.")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Percentage completed")
    for source in res:
        for task in source.tasks:
            task_type = (
                f"{task.task_type} ({task.task_sub_type})"
                if task.task_sub_type and task.task_sub_type != "None"
                else f"{task.task_type}"
            )
            table.add_row(task.id, task_type, task.status, str(task.progress_percentage))
    return table


def _visualize_cancel_simulation_result_tree(res: CancelSimulationResult) -> Tree:
    root = Tree("Cancel simulation result:")
    root.add(f"Id: {res.simulation_id}")
    root.add(f"Name: {res.simulation_name}")
    root.add(f"Status: {res.simulation_status}")
    if res.result_status:
        root.add(f"ResultStatus: {res.result_status.result_code} ({res.result_status.result_code_name})")
    tasks = root.add(f"Cancelled tasks:")
    for t in res.cancelled_tasks:
        tasks.add(f"Source: {t.source_label} - Task: {t.task_type} - {t.task_status}")
    return root


def _visualize_cancel_simulation_table(res: list[CancelSimulationResult]) -> Table:
    table = Table(title="Cancelled simulation list.")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Name")
    table.add_column("Status")
    table.add_column("Cancelled task count")
    for c in res:
        table.add_row(
            c._dto.simulationId,
            c._dto.simulationName,
            c._dto.simulationStatus,
            str(len(c._dto.cancelledTasks)),
        )
    return table


def _visualize_device_table(res: list[DeviceDto | DeviceObj]) -> Table:
    table = Table(title="Project device list")
    table.add_column("Index")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Name")
    table.add_column("Created at")
    for i, device in enumerate(res):
        if isinstance(device, DeviceObj):
            device = device._dto
        table.add_row(str(i), device.id, device.name, _parse_timestamp(device.createdAt))
    return table


def _visualize_validation_results_table(res: list[SimulationValidationResults]) -> Table:
    display_valid = lambda is_valid: "[green]Yes[/green]" if is_valid else "[red1]No[/red1]"
    table = Table(title="Project validation results", show_footer=True)
    table.add_column("Simulation", footer="[b]Total[/b]")
    table.add_column(
        "Is valid",
        footer=f"[b][green]{len([x for x in res if x.is_valid])}[/green]/[red1]{len([x for x in res if not x.is_valid])}[/red1][/b]",
    )
    table.add_column("Invalid receivers")
    table.add_column("Invalid sources")
    table.add_column("Missing material assignments")
    for result in res:
        table.add_row(
            f"{result.simulation_name} ({result.simulation_id})",
            display_valid(result.is_valid),
            str(len(result.invalid_receivers)),
            str(len(result.invalid_sources)),
            str(len(result.layers_without_material_assignment)),
        )
    return table


def _visualize_material_assignment_table(res: list[MaterialAssignment]):
    table = Table(title="Material assignment")
    table.add_column("Layer name")
    table.add_column("Material name")

    for assignment in res:
        table.add_row(assignment.layer_name, assignment.material_name)
    return table


def _visualize_boundary_velocity_submodel_obj_table(res: list[BoundaryVelocitySubmodel]):
    table = Table(title="Source submodels")
    table.add_column("Index")
    table.add_column("Name")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Created at")
    table.add_column("Description")
    for i, source in enumerate(res):
        table.add_row(
            str(i),
            source.name,
            source.id,
            _parse_timestamp(source._dto.createdAt),
            _cut_string(source.description),
        )
    return table


def _visualize_local_mesh_sizing_table(res: list[LocalMeshSizing]):
    table = Table(title="Local mesh sizing")
    table.add_column("Layer name")
    table.add_column("Mesh sizing (m)")
    table.add_column("Keep exterior edges")

    for sizing in res:
        table.add_row(sizing.layer_name, str(sizing.mesh_sizing_m), str(sizing.keep_exterior_edges))
    return table


def _visualize_source_directivity_table(res: list[SourceDirectivityObj]):
    table = Table(title="Source directivity table")

    table.add_column("Index")
    table.add_column("Name", no_wrap=True)
    table.add_column("Description", no_wrap=True, max_width=20)
    table.add_column("Category", min_width=12)
    table.add_column("Sub category", no_wrap=True, max_width=16)
    table.add_column("Manufacturer", no_wrap=True, max_width=16)
    table.add_column("Private")
    for i, directivity in enumerate(res):
        table.add_row(
            str(i),
            directivity.name,
            _cut_string(directivity.description),
            directivity.category,
            directivity.sub_category,
            directivity.manufacturer,
            "True" if directivity.organization_id else None,
        )
    return table


def _visualize_geometry_library_dto_table(res: list[GeometryLibraryObj]):
    table = Table(title="Geometry table")
    table.add_column("Index")
    table.add_column("Name")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Description")
    table.add_column("Dataset")
    for i, geo in enumerate(res):
        table.add_row(str(i), geo.name, geo.id, _cut_string(geo.description), geo.dataset)
    return table


def _visualize_project_table(res: list[ProjectDto]) -> Table:
    table = Table(title="Projects")
    table.add_column("Index")
    table.add_column("Name", overflow="fold", min_width=_get_max_length([x.name for x in res], 80))
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Created at")
    table.add_column("Description")
    for i, o in enumerate(res):
        dto = getattr(o, "_dto", None) or o
        table.add_row(
            str(i),
            dto.name,
            dto.id,
            _parse_timestamp(getattr(dto, "createdAt"), True),
            _cut_string(dto.description),
        )
    return table


def _visualize_simulation_table(res: list[Simulation]) -> Table:
    table = Table(title="Simulations")
    table.add_column("Index")
    table.add_column("Name", overflow="fold", min_width=_get_max_length([x.name for x in res], 80))
    table.add_column("Created at")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Status")
    table.add_column("Freq. (Hz)")
    table.add_column("Rcv")
    table.add_column("Src")
    for i, sim in enumerate(res):
        table.add_row(
            str(i),
            sim.name,
            _parse_timestamp(sim.created_at, True),
            sim.id,
            _get_colored_sim_status(sim._dto.status),
            str(sim._dto.crossoverFrequency),
            str(len(sim.receivers)),
            str(len(sim.sources)),
        )
    return table


def _visualize_material_table(res: list[Material]) -> Table:
    table = Table(title="Materials")
    table.add_column("Name")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Description")
    table.add_column("Category")
    table.add_column("(Default) Scattering", max_width=10)
    table.add_column("Absorption coefficients")
    for mat in res:
        table.add_row(
            mat.name,
            mat.id,
            _cut_string(mat.description),
            mat.category,
            str(mat.default_scattering),
            _join_list(mat.absorption_coefficients),
        )
    return table


def _visualize_model_table(res: list[ModelDto | ModelObj]) -> Table:
    table = Table(title="Models")
    table.add_column("Index")
    table.add_column("Name", overflow="fold", min_width=_get_max_length([x.name for x in res], 80))
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Created At")
    table.add_column("Is Watertight")
    for i, o in enumerate(res):
        dto = getattr(o, "_dto", None) or o
        table.add_row(
            str(i),
            dto.name,
            dto.id,
            _parse_timestamp(dto.createdAt),
            str(dto.isWatertight),
        )
    return table


def _visualize_category_table(res: list[CategoryInfoDto]) -> Table:
    table = Table(title="Categories")
    table.add_column("Name")
    table.add_column("Count")
    for dto in res:
        table.add_row(
            dto.name,
            str(dto.count),
        )
    return table


def _visualize_project_progress_table(res: ProjectProgressInfo):
    table = Table(title=res.project_name, show_footer=True)
    table.add_column("Simulation Name")
    table.add_column("Id", min_width=ID_COL_LENGTH)
    table.add_column("Status", footer=_get_colored_sim_status(res._dto.status))
    table.add_column("Progress %", footer=f"{res.project_progress_percentage}%")

    for sim in res.simulations:
        table.add_row(
            sim.simulation_name,
            sim.simulation_id,
            _get_colored_sim_status(sim._dto.simulationStatus),
            f"{sim.simulation_progress_percentage}%",
        )

    return table


def _print(obj):
    Console(soft_wrap=True).print(obj)


def display(
    obj: (
        SimulationValidationResults
        | list[SimulationValidationResults]
        | Simulation
        | list[Simulation]
        | SimulationEstimate
        | ProjectEstimation
        | Material
        | GeometryLibraryObj
        | SimulationProgressDto
        | ModelObj
        | OverviewDto
        | MeshObject
        | SimulationMeshInfoCollection
        | list[SimulationValidationResults]
        | list[ProjectDto]
        | list[Project]
        | list[Simulation]
        | ProjectProgressInfo
        | list[GeometryLibraryObj]
        | list[Material]
        | list[CategoryInfoDto]
        | list[MaterialAssignment]
        | list[SourceDirectivityObj]
        | list[DeviceObj]
        | list[ModelDto]
        | list[ModelObj]
        | list[LocalMeshSizing]
        | list[BoundaryVelocitySubmodel]
        | list[Source]
    ),
):
    if (
        isinstance(obj, list)
        or isinstance(obj, ProjectEstimation)
        or isinstance(obj, SimulationMeshInfoCollection)
        or isinstance(obj, ProjectProgressInfo)
    ):
        as_table(obj)
    else:
        as_tree(obj)


def as_table(
    obj: (
        ProjectEstimation
        | SimulationMeshInfoCollection
        | list[SimulationValidationResults]
        | list[ProjectDto]
        | list[Project]
        | list[Simulation]
        | ProjectProgressInfo
        | list[GeometryLibraryObj]
        | list[Material]
        | list[CategoryInfoDto]
        | list[MaterialAssignment]
        | list[SourceDirectivityObj]
        | list[DeviceObj]
        | list[ModelDto]
        | list[ModelObj]
        | list[LocalMeshSizing]
        | list[BoundaryVelocitySubmodel]
        | list[Source]
    ),
):
    match obj:
        case ProjectEstimation():
            _print(_visualize_project_estimate_table(obj._dto))
        case ProjectProgressInfo():
            _print(_visualize_project_progress_table(obj))
        case SimulationMeshInfoCollection():
            _print(_visualize_simulation_mesh_collection_as_table(obj))
        case []:
            _print("No data")
        case [SimulationValidationResults(), *_]:
            _print(_visualize_validation_results_table(obj))
        case [ProjectDto(), *_] | [Project(), *_]:
            _print(_visualize_project_table(obj))
        case [Simulation(), *_]:
            _print(_visualize_simulation_table(obj))
        case [Material(), *_]:
            _print(_visualize_material_table(obj))
        case [GeometryLibraryObj(), *_]:
            _print(_visualize_geometry_library_dto_table(obj))
        case [CategoryInfoDto(), *_]:
            _print(_visualize_category_table(obj))
        case [ModelDto(), *_] | [ModelObj(), *_]:
            _print(_visualize_model_table(obj))
        case [MaterialAssignment(), *_]:
            _print(_visualize_material_assignment_table(obj))
        case [SourceDirectivityObj(), *_]:
            _print(_visualize_source_directivity_table(obj))
        case [DeviceDto(), *_] | [DeviceObj(), *_]:
            _print(_visualize_device_table(obj))
        case [CancelSimulationResult(), *_]:
            _print(_visualize_cancel_simulation_table(obj))
        case [LocalMeshSizing(), *_]:
            _print(_visualize_local_mesh_sizing_table(obj))
        case [BoundaryVelocitySubmodel(), *_]:
            _print(_visualize_boundary_velocity_submodel_obj_table(obj))
        case [Source(), *_]:
            _print(_visualize_task_table(obj))
        case _:
            _print("[red1]Unsupported object type![/red1]")


def as_tree(
    obj: (
        SimulationValidationResults
        | list[SimulationValidationResults]
        | Simulation
        | list[Simulation]
        | SimulationEstimate
        | ProjectEstimation
        | Material
        | GeometryLibraryObj
        | SimulationProgressInfo
        | ModelObj
        | OverviewDto
        | MeshObject
        | StartProjectResult
        | CancelSimulationResult
    ),
):
    match obj:
        case SimulationValidationResults():
            _print(_visualize_validation_results_tree(obj))
        case Simulation():
            _print(_visualize_simulation_tree(obj))
        case SimulationEstimate():
            _print(_visualize_simulation_estimate_tree(obj._dto))
        case ProjectEstimation():
            _print(_visualize_project_estimate_tree(obj._dto))
        case SimulationProgressInfo():
            _print(_visualize_simulation_progress_tree(obj))
        case Material():
            _print(_visualize_material_tree(obj))
        case GeometryLibraryObj():
            _print(_visualize_geometry_library_dto_tree(obj))
        case ModelObj():
            _print(_visualize_model_tree(obj))
        case OverviewDto():
            _print(_visualize_overview_dto_tree(obj))
        case MeshObject():
            _print(_visualize_mesh_object_tree(obj))
        case StartProjectResult():
            _print(_visualize_start_project_result_tree(obj))
        case CancelSimulationResult():
            _print(_visualize_cancel_simulation_result_tree(obj))
        case []:
            _print("No data")
        case [SimulationValidationResults(), *_]:
            t = Tree("Validation results")
            for o in obj:
                t.add(_visualize_validation_results_tree(o))
            _print(t)
        case [Simulation(), *_]:
            t = Tree("Simulations")
            for o in obj:
                t.add(_visualize_simulation_tree(o))
            _print(t)
        case _:
            _print("[red1]Unsupported object type![/red1]")


def as_live_progress(obj: Simulation | Project):
    if not (isinstance(obj, Simulation) or isinstance(obj, Project)):
        _print("[red1]Unsupported object type![/red1]")
        return

    def _as_tree_or_table(p):
        if isinstance(p, SimulationProgressInfo):
            return _visualize_simulation_progress_tree(p)
        else:
            return _visualize_project_progress_table(p)

    try:
        if _is_notebook():
            from IPython.display import clear_output
            import time

            while (progress := obj.get_progress()) and not SimulationStatus.is_final_status(
                getattr(progress, "status", getattr(progress, "simulation_status", "Error"))
            ):
                clear_output(wait=True)
                _print(_as_tree_or_table(progress))
                time.sleep(2)

            # Display final state.
            clear_output(wait=True)
            _print(_as_tree_or_table(progress))
        else:
            import time
            from rich.live import Live

            progress = obj.get_progress()
            with Live(_as_tree_or_table(progress), refresh_per_second=1) as live:
                time.sleep(1)
                while (progress := obj.get_progress()) and not SimulationStatus.is_final_status(
                    getattr(progress, "status", getattr(progress, "simulationStatus", "Error"))
                ):
                    live.update(_as_tree_or_table(progress))
                live.update(_as_tree_or_table(progress))
        _print("Done")
    except KeyboardInterrupt:
        _print("Interrupted")


def as_live_model_status(obj: ModelObj):
    if not isinstance(obj, ModelObj):
        _print("[red1]Unsupported object type![/red1]")
        return

    try:
        if _is_notebook():
            from IPython.display import clear_output
            import time

            while obj.status not in ("Valid", "NotValid"):
                clear_output(wait=True)
                _print(_visualize_model_tree(obj))
                time.sleep(3)

            # Display final state.
            clear_output(wait=True)
            _print(_visualize_model_tree(obj))
        else:
            import time
            from rich.live import Live

            with Live(_visualize_model_tree(obj), refresh_per_second=1) as live:
                while obj.status not in ("Valid", "NotValid"):
                    obj._update_object()
                    live.update(_visualize_model_tree(obj))
                    time.sleep(3)
                live.update(_visualize_model_tree(obj))
        _print("Done")
    except KeyboardInterrupt:
        _print("Interrupted")


def as_live_mesher_progress(obj: SimulationMeshInfoCollection):
    if not isinstance(obj, SimulationMeshInfoCollection):
        _print("[red1]Unsupported object type![/red1]")
        return

    try:
        if _is_notebook():
            from IPython.display import clear_output
            import time

            while not obj.is_meshing_completed():
                clear_output(wait=True)
                _print(_visualize_simulation_mesh_collection_as_table(obj))
                time.sleep(3)

            # Display final state.
            clear_output(wait=True)
            _print(_visualize_simulation_mesh_collection_as_table(obj))
        else:
            import time
            from rich.live import Live

            with Live(_visualize_simulation_mesh_collection_as_table(obj), refresh_per_second=1) as live:
                while not obj.is_meshing_completed():
                    obj._update_object()
                    live.update(_visualize_simulation_mesh_collection_as_table(obj))
                    time.sleep(3)
                live.update(_visualize_simulation_mesh_collection_as_table(obj))
        _print("Done")
    except KeyboardInterrupt:
        _print("Interrupted")
