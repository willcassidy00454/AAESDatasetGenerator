import time
import datetime
from threading import RLock
import asyncio

import jwt
import httpx

from .. import utils
from .exceptions import raise_on_ssl_issue


class APIAuthException(Exception):
    pass


class UnauthorizedException(Exception):
    pass


class AuthenticationMiddleware(httpx.Auth):
    """
    AuthBase middleware for requests.
    """

    def __init__(
        self,
        login_uri: str = None,
        clientId: str = None,
        clientSecret: str = None,
    ):
        """
        :param clientId:
        :param clientSecret:
        :param lazyAuth: Controls whether initial authentication happens
                         when instance is created or upon first request.
        """
        self.login_uri = login_uri
        self.clientId = clientId or utils.get_env_var_as_string("TSDK_CLIENT_ID")
        if self.clientId is None:
            raise NameError("Missing variable clientId|TSDK_CLIENT_ID")
        self.clientSecret = clientSecret or utils.get_env_var_as_string("TSDK_CLIENT_SECRET")
        if self.clientSecret is None:
            raise NameError("Missing variable clientSecret|TSDK_CLIENT_SECRET")
        self.tokenInfo = None
        self.expiryDate = None
        self.rateLimit = 1000  # Default (requests per second)
        # Lock for sync requests.
        self._sync_lock = RLock()
        # Lock for async requests
        self._async_lock = asyncio.Lock()

    def _authenticate_sync(self):
        """
        Perform authentication for syncronous connections.
        :raises APIAuthException: If authentication failed.
        """
        ssl_disable = utils.get_env_var_as_string(
            "STAPI_DISABLE_SSL_VERIFY"
        ) == "1" and self.login_uri.startswith("https://localhost")
        with self._sync_lock:
            if not self._is_auth_valid():
                try:
                    r = httpx.post(
                        self.login_uri,
                        data={"clientId": self.clientId, "clientSecret": self.clientSecret},
                        verify=ssl_disable == False,
                    )
                    self._process_authenticate_response(r)
                except (httpx.RequestError, httpx.ConnectError) as e:
                    raise_on_ssl_issue(e)
                    raise
                except Exception:
                    raise

    async def _authenticate_async(self):
        """
        Perform authentication for asyncronous connections.
        :raises APIAuthException: If authentication failed.
        """
        ssl_disable = utils.get_env_var_as_string(
            "STAPI_DISABLE_SSL_VERIFY"
        ) == "1" and self.login_uri.startswith("https://localhost")
        async with self._async_lock:
            # Check if we need to authenticate again
            if not self._is_auth_valid():
                try:
                    r = await httpx.AsyncClient(verify=not ssl_disable).post(
                        self.login_uri,
                        data={"clientId": self.clientId, "clientSecret": self.clientSecret},
                    )
                    self._process_authenticate_response(r)
                except (httpx.RequestError, httpx.ConnectError) as e:
                    raise_on_ssl_issue(e)
                    raise
                except Exception:
                    raise

    def _process_authenticate_response(self, r: httpx.Response):
        if r.status_code == 200:
            self.tokenInfo = r.json()
            if self.tokenInfo is None or "accessToken" not in self.tokenInfo:
                raise APIAuthException("No token received from API!")
            else:
                self.expiryDate = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(
                    seconds=self.tokenInfo["expiresIn"]
                )
        else:
            if r.text and not r.text.startswith('{"type"'):
                raise UnauthorizedException(
                    f"Unable to authenticate against SDK: {r.text} Unable to authenticate against the SDK! Please contact Treble if problem persists."
                )
            else:
                raise UnauthorizedException(
                    "Unable to authenticate against SDK, please contact Treble if problem persists."
                )

    def _getSecToExpiry(self) -> int:
        """
        Get number of seconds until token expires.
        """
        return (self.expiryDate - datetime.datetime.now(datetime.timezone.utc)).total_seconds()

    def _is_auth_valid(self) -> bool:
        """
        Is the current authentication is still valid.
        Checks if token is available and is not expired, not if token has been invalidated.
        """
        return self.tokenInfo is not None and self._getSecToExpiry() > 60

    def sync_auth_flow(self, request):
        """
        Auth flow for syncronous connections
        """
        if not self._is_auth_valid():
            self._authenticate_sync()
        request.headers["authorization"] = f'{self.tokenInfo["tokenType"]} {self.tokenInfo["accessToken"]}'
        yield request

    async def async_auth_flow(self, request):
        """
        Auth flow for asyncronous connections.
        """
        if not self._is_auth_valid():
            await self._authenticate_async()
        request.headers["authorization"] = f'{self.tokenInfo["tokenType"]} {self.tokenInfo["accessToken"]}'
        yield request


class SSOAuthenticationMiddleware(httpx.Auth):
    """
    Authentication middleware for SSO user requests.
    """

    def __init__(
        self,
        access_token: str,
        refresh_token: str,
        token_endpoint: str,
    ):
        """
        :param access_token: SSO user access/bearer token
        :param refresh_token: SSO user refresh token.
        :param token_endpoint: Endpoint to call when using refresh token.
        """
        # Lock for syncronous requests.
        self._sync_lock = RLock()
        # Lock for asyncronous requests.
        self._async_lock = asyncio.Lock()
        self._token_endpoint = token_endpoint
        self.clientId = None
        self.rateLimit = 1000  # Default (100 requests per seconds)
        self._load_credentials(access_token=access_token, refresh_token=refresh_token)

    def _load_credentials(self, access_token: str, refresh_token: str):
        # Set credentials data.
        self._access_token = access_token
        self._access_token_exp = 0
        self._refresh_token = refresh_token
        self._refresh_token_retry = False  # Disable refresh token request flooding.
        try:
            # Try and fetch access_token expiration date from JWT.
            jwt_data = jwt.decode(access_token, options={"verify_signature": False})
            self.clientId = jwt_data["sub"]  # Set unique client id.
            self._access_token_exp = jwt_data["exp"]
            self._access_token_azp = jwt_data["azp"]
        except:
            raise UnauthorizedException(
                "Your access credentials are invalid or expired, please log in again to get a new access token. If problem persists contact Treble for support."
            )

    def _process_refresh_auth_response(self, res: httpx.Response):
        if res.status_code == 200:
            # Success
            data = res.json()
            self._load_credentials(
                data.get("access_token", None), data.get("refresh_token", self._refresh_token)
            )
        else:
            raise UnauthorizedException(
                "Your access credentials are invalid or expired, please log in again to get a new access token. If problem persists contact Treble for support."
            )

    def _refresh_auth_sync(self, force: bool = False):
        with self._sync_lock:
            if not self._is_auth_valid() or force:
                self._refresh_token_retry = True
                # Use refresh token to get a new authentication token.
                try:
                    res = httpx.post(
                        self._token_endpoint,
                        headers={"content-type": "application/x-www-form-urlencoded"},
                        data={
                            "grant_type": "refresh_token",
                            "client_id": self._access_token_azp,
                            "refresh_token": self._refresh_token,
                        },
                    )
                    self._process_refresh_auth_response(res)
                except (httpx.RequestError, httpx.ConnectError) as e:
                    raise_on_ssl_issue(e)
                    raise
                except Exception:
                    raise

    async def _refresh_auth_async(self, force: bool = False):
        async with self._async_lock:
            if not self._is_auth_valid() or force:
                self._refresh_token_retry = True
                # Use refresh token to get a new authentication token.
                try:
                    res = await httpx.AsyncClient().post(
                        self._token_endpoint,
                        headers={"content-type": "application/x-www-form-urlencoded"},
                        data={
                            "grant_type": "refresh_token",
                            "client_id": self._access_token_azp,
                            "refresh_token": self._refresh_token,
                        },
                    )
                    self._process_refresh_auth_response(res)
                except (httpx.RequestError, httpx.ConnectError) as e:
                    raise_on_ssl_issue(e)
                    raise
                except Exception:
                    raise

    def _is_auth_valid(self) -> bool:
        # Check if access token expires within 60 sec.
        return self._access_token_exp > time.time() + 60

    def _set_request_auth_header(self, req: httpx.Request):
        req.headers["authorization"] = f"bearer {self._access_token}"
        return req

    def sync_auth_flow(self, r):
        # Use refresh token to get a new authentication token.
        if not self._is_auth_valid():
            self._refresh_auth_sync()

        r.headers["authorization"] = f"bearer {self._access_token}"
        yield r

    async def async_auth_flow(self, r):
        if not self._is_auth_valid():
            await self._refresh_auth_async()
        r.headers["authorization"] = f"bearer {self._access_token}"
        yield r
