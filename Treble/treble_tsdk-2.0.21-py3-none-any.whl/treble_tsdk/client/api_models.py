import json
import importlib
from enum import Enum
from numbers import Number
from pydantic import BaseModel, ConfigDict, BeforeValidator, Field
from pydantic.alias_generators import to_camel
from ..utility_classes import Point3d
from ..treble_logging import logger

DISPLAY_DATA_MODULE_NAME = "treble_tsdk.display_data"

# Base Pydantic configuration for DTOs.
_BASE_CONFIG = ConfigDict(
    alias_generator=to_camel, extra="ignore", frozen=True, populate_by_name=True, use_enum_values=True
)


class ResultStatusDto:
    def __init__(self, resultCode: int, resultCodeName: str, message: str, **kwargs):
        self.result_code = resultCode
        self.result_code_name = resultCodeName
        self.message = message

    def __repr__(self):
        return f"ResultStatusDto(result_code={self.result_code}, result_code_name={self.result_code_name}, message={self.message})"


class ObjectMetadataDto:
    def __init__(self, keyValuePairs: dict[str, str], id: str = None, updatedAt: str = None, **kwargs):
        self.id = id
        self.updatedAt = updatedAt
        self.keyValuePairs = keyValuePairs


class ProjectDto:
    def __init__(self):
        self.name = None
        self.description = None
        self.metadata = None

    @staticmethod
    def for_request(name: str, description: str, metadata: dict[str, str] = None) -> "ProjectDto":
        """
        Create a new ProjectDto for requests.

        :param name: Name given to project.
        :param description: Optional description of project.
        """
        dto = ProjectDto()
        dto.name = name
        dto.description = description
        if metadata:
            dto.metadata = ObjectMetadataDto(keyValuePairs=metadata)
        return dto

    @staticmethod
    def from_response(
        id: str,
        name: str,
        description: str,
        createdAt: str,
        updatedAt: str,
        createdBy: str,
        objectMetadataId: str,
        metadata: dict[str, str] = None,
        **kwargs,
    ) -> "ProjectDto":
        """
        Create a new ProjectDto for responses.

        :param id: Id of project in Guid format.
        :param name: Name given to project.
        :param description: Optional description of project.
        """
        dto = ProjectDto()
        dto.id = id
        dto.name = name
        dto.description = description
        dto.createdAt = createdAt
        dto.updatedAt = updatedAt
        dto.createdBy = createdBy
        dto.objectMetadataId = objectMetadataId
        dto.metadata = None
        if metadata:
            dto.metadata = ObjectMetadataDto(**metadata)
        return dto

    def __repr__(self) -> str:
        return f"'name='{self.name}', description='{self.description}'"

    def __str__(self):
        return json.dumps(
            {
                "id": self.id,
                "name": self.name,
                "description": self.description,
                "created_at": self.createdAt,
                "updated_at": self.updatedAt,
                "created_by": self.createdBy,
            },
            indent=2,
        )


class ProjectUpdateDto:
    def __init__(self, name: str | None, description: str | None, **kwargs):
        self.name = name
        self.description = description


class MaterialCategory(str, Enum):
    """
    Contains the material categories available in the database
    """

    carpets = "Carpets"
    curtains = "Curtains"
    furnishing = "Furnishing"
    gypsum = "Gypsum"
    natural_materials = "Natural materials"
    perforated_panels = "Perforated panels"
    porous = "Porous"
    rigid = "Rigid"
    windows = "Windows"
    wood = "Wood"
    other = "Other"


class RigidBackingLayer:
    """
    Rigid backing layer for material builder
    """

    def __init__(self, layerType: str, density: float = None, bulkModulus: float = None):
        self.layerType = layerType
        self.density = density
        self.bulkModulus = bulkModulus


class AirCavityLayer:
    """
    Air cavity layer for material builder
    """

    def __init__(self, layerType: str, thicknessInMm: float):
        self.layerType = layerType
        self.thicknessInMm = thicknessInMm


class PorousAbsorberLayer:
    """
    Porous absorber layer for material builder
    """

    def __init__(
        self,
        layerType: str,
        thicknessInMm: float,
        flowResistivity: float | None,
        density: float | None,
        woolType: str | None,
    ):
        self.layerType = layerType
        self.thicknessInMm = thicknessInMm
        self.flowResistivity = flowResistivity
        self.density = density
        self.woolType = woolType


class MaterialDefinitionDto:
    def __init__(
        self,
        name: str,
        description: str,
        category: str,
        inputType: str,
        defaultScattering: float,
        coefficientsReal: list,
        coefficientsImaginary: list | None,
        **kwargs,
    ):
        self.name = name
        self.description = description
        self.category = category
        self.inputType = inputType
        self.defaultScattering = defaultScattering
        self.coefficientsReal = coefficientsReal
        self.coefficientsImaginary = coefficientsImaginary

    @staticmethod
    def for_request(
        name: str,
        description: str,
        category: str,
        default_scattering: float,
        input_type: str,
        coefficients: list,
        coefficients_imaginary: list | None,
    ) -> "MaterialDefinitionDto":
        return MaterialDefinitionDto(
            name=name,
            description=description,
            category=category,
            inputType=input_type,
            defaultScattering=default_scattering,
            coefficientsReal=coefficients,
            coefficientsImaginary=coefficients_imaginary,
        )


class MaterialBuilderDto:
    """
    Dto for material builder, material_layers will always contain at least rigid backing layer, will also contain
    air cavity layer and porous absorber layer if appended by the user.
    """

    def __init__(
        self,
        name: str,
        description: str,
        category: str,
        defaultScattering: float,
        inputType: str,
        rigidBackingLayer: RigidBackingLayer = None,
        airCavityLayer: AirCavityLayer = None,
        porousAbsorberLayer: PorousAbsorberLayer = None,
        **kwargs,
    ):
        self.name = name
        self.description = description
        self.category = category
        self.inputType = inputType
        self.defaultScattering = defaultScattering
        self.rigidBackingLayer = rigidBackingLayer
        self.airCavityLayer = airCavityLayer
        self.porousAbsorberLayer = porousAbsorberLayer

    @staticmethod
    def for_request(
        name: str,
        description: str,
        category: str,
        default_scattering: float,
        input_type: str,
        material_layers: list,
    ) -> "MaterialBuilderDto":
        rigidBackingLayer = next(
            (layer for layer in material_layers if layer["layer_type"] == "rigid backing"), None
        )
        airCavityLayer = next(
            (layer for layer in material_layers if layer["layer_type"] == "air cavity"), None
        )
        porousAbsorberLayer = next(
            (layer for layer in material_layers if layer["layer_type"] == "porous absorber"), None
        )
        dto = MaterialBuilderDto(
            name=name,
            description=description,
            category=category,
            inputType=input_type,
            defaultScattering=default_scattering,
            rigidBackingLayer=RigidBackingLayer(
                layerType=rigidBackingLayer["layer_type"],
                density=rigidBackingLayer["density"],
                bulkModulus=rigidBackingLayer["bulk_modulus"],
            ),
        )

        if airCavityLayer:
            dto.airCavityLayer = AirCavityLayer(
                layerType=airCavityLayer["layer_type"],
                thicknessInMm=airCavityLayer["thickness_in_mm"],
            )
        if porousAbsorberLayer:
            dto.porousAbsorberLayer = PorousAbsorberLayer(
                layerType=porousAbsorberLayer["layer_type"],
                thicknessInMm=porousAbsorberLayer["thickness_in_mm"],
                flowResistivity=porousAbsorberLayer["flow_resistivity"],
                density=porousAbsorberLayer["density"],
                woolType=porousAbsorberLayer["wool_type"],
            )

        return dto


class MaterialDto:
    def __init__(
        self,
        name: str,
        description: str,
        category: str,
        materialJson: str,
        materialMetadataJson: str,
        defaultScattering: float,
        userId: str = None,
        organizationId: str = None,
        id: str = None,
        isDeleted: bool = None,
        **kwargs,
    ):
        self.id = id
        self.name = name
        self.description = description
        self.category = category
        self.materialJson = materialJson
        self.materialMetadataJson = materialMetadataJson
        self.defaultScattering = defaultScattering
        self.userId = userId
        self.organizationId = organizationId
        self.absorptionCoefficients = None
        self.isDeleted = isDeleted
        if self.materialJson:
            mat_json = json.loads(self.materialJson)
            self.absorptionCoefficients = mat_json["FittedAbsorptionCoefficients"]

    @staticmethod
    def from_response(
        name: str,
        description: str,
        category: str,
        materialJson: str,
        materialMetadataJson: str,
        defaultScattering: float,
        id: str = None,
        isDeleted: str = None,
        **kwargs,
    ) -> "MaterialDto":
        dto = MaterialDto(
            name=name,
            description=description,
            category=category,
            materialJson=materialJson,
            materialMetadataJson=materialMetadataJson,
            defaultScattering=defaultScattering,
            id=id,
            isDeleted=isDeleted,
        )
        return dto


class FittedMaterialDto(MaterialDto):
    pass


class ModelLayerDto:
    def __init__(self, id: str, name: str, modelDefinitionId: str, objectIds: list, **kwargs):
        self.id = id
        self.name = name
        self.model_definition_id = modelDefinitionId


class GeometryObjectInfoDto:
    def __init__(
        self,
        id: str = None,
        Id: str = None,
        groupType: int = None,
        GroupType: int = None,
        surfaceArea: float = None,
        SurfaceArea: float = None,
        layerName: str = None,
        LayerName: str = None,
        **kwargs,
    ):
        self.id = id or Id
        self.groupType = groupType or GroupType
        self.surfaceArea = surfaceArea or SurfaceArea
        self.layerName = layerName or LayerName


class ModelDto:
    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        createdAt: str,
        status: str,
        statusMessage: str,
        projectId: str,
        uploadedBy: str,
        filename: str,
        filesize: int,
        geometryLibraryId: str,
        taskInfoId: str,
        layers: list[dict | ModelLayerDto],
        geometryObjectInfo: dict[str, GeometryObjectInfoDto],
        geometryGroupTypeToVolume: dict[int, float],
        isWatertight: bool = None,
        metadata: dict[str, str] = None,
        category: str = None,
        isDeleted: bool = None,
        **kwargs,
    ):
        self.id = id
        self.name = name
        self.description = description
        self.status = status
        self.statusMessage = statusMessage
        self.createdAt = createdAt
        self.projectId = projectId
        self.uploadedBy = uploadedBy
        self.filename = filename
        self.filesize = filesize
        self.taskInfoId = taskInfoId
        self.geometryLibraryId = geometryLibraryId
        self.geometryObjectInfo = None
        self.category = category
        self.isDeleted = isDeleted
        self.isWatertight = isWatertight
        if geometryObjectInfo:
            self.geometryObjectInfo = {k: GeometryObjectInfoDto(**v) for (k, v) in geometryObjectInfo.items()}
        self.geometryGroupTypeToVolume = geometryGroupTypeToVolume
        if layers:
            self.layers = [
                layer if isinstance(layer, ModelLayerDto) else ModelLayerDto(**layer) for layer in layers
            ]
        self.metadata = None
        if metadata:
            self.metadata = ObjectMetadataDto(**metadata)

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class StringResponse:
    def __init__(self, content: str, success: bool, **kwargs):
        self.content = content
        self.success = success

    def __str__(self):
        return json.dumps({"content": self.content, "success": self.success}, indent=2)


class TraceIgnoreDto:
    def __init__(self, timeToCut: float, taperWidth: float = None):
        self.timeToCut = timeToCut
        self.taperWidth = taperWidth


class ReceiverPropertiesDto:
    def __init__(
        self,
        deviceId: str = None,
        azimuthAngle: float = 0.0,
        elevationAngle: float = 0.0,
        rollAngle: float = 0.0,
        spatialRadius: float = 0.1,
        ambisonicsOrder: int = None,
        traceIgnore: dict | TraceIgnoreDto = None,
        **kwargs,
    ):
        if deviceId is not None:
            self.deviceId = deviceId
        self.azimuthAngle = azimuthAngle
        self.elevationAngle = elevationAngle
        self.rollAngle = rollAngle
        self.spatialRadius = spatialRadius
        self.ambisonicsOrder = ambisonicsOrder
        if traceIgnore is not None:
            self.traceIgnore = (
                traceIgnore if isinstance(traceIgnore, TraceIgnoreDto) else TraceIgnoreDto(**traceIgnore)
            )

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class ReceiverDto:
    def __init__(
        self,
        receiverType: str,
        label: str,
        x: float,
        y: float,
        z: float,
        id: str = None,
        receiverProperties: dict | ReceiverPropertiesDto = None,
        orderNumber: int = None,
        **kwargs,
    ):
        self.id = None
        if id is not None:
            self.id = id
        self.receiverType = receiverType
        self.label = label
        self.x = x
        self.y = y
        self.z = z
        self.orderNumber = orderNumber
        self.receiverProperties = None
        if receiverProperties:
            self.receiverProperties = (
                receiverProperties
                if isinstance(receiverProperties, ReceiverPropertiesDto)
                else ReceiverPropertiesDto(**receiverProperties)
            )

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)

    def pos_as_point(self) -> Point3d:
        return Point3d(self.x, self.y, self.z)


class TaskInfoDto:
    def __init__(
        self,
        id: str,
        name: str,
        taskType: str,
        status: str,
        createdAt: str,
        startedAt: str,
        completedAt: str,
        progressPercentage: float,
        statusMessage: str,
        taskSubType: str = None,
        tokensUsed: float = None,
        **kwargs,
    ):
        self.id = id
        self.name = name
        self.taskType = taskType
        self.status = status
        self.createdAt = createdAt
        self.startedAt = startedAt
        self.completedAt = completedAt
        self.progressPercentage = progressPercentage
        self.statusMessage = statusMessage
        self.taskSubType = taskSubType
        self.tokensUsed = tokensUsed


class SourcePropertiesDto:
    def __init__(
        self,
        azimuthAngle: float = 0,
        elevationAngle: float = 0,
        sourceDirectivityId: str = None,
        boundaryVelocitySubmodelId: str = None,
        sourceBoundaryLayerName: str = None,
        sourceBoundaryMeshLocalSizing: float = None,
        sourceBoundaryMeshKeepExteriorEdges: bool = None,
        disableSourceCorrection: bool = None,
        useWaveBasedPattern: bool = None,
        **kwargs,
    ):
        self.azimuthAngle = azimuthAngle
        self.elevationAngle = elevationAngle
        self.sourceDirectivityId = sourceDirectivityId
        self.boundaryVelocitySubmodelId = boundaryVelocitySubmodelId
        self.sourceBoundaryLayerName = sourceBoundaryLayerName
        self.sourceBoundaryMeshLocalSizing = sourceBoundaryMeshLocalSizing
        self.sourceBoundaryMeshKeepExteriorEdges = sourceBoundaryMeshKeepExteriorEdges
        self.disableSourceCorrection = disableSourceCorrection
        self.useWaveBasedPattern = useWaveBasedPattern

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class SourceDto:
    def __init__(
        self,
        sourceType: str,
        label: str,
        x: float,
        y: float,
        z: float,
        id: str = None,
        sourceProperties: dict | SourcePropertiesDto = None,
        tasks: list[TaskInfoDto] = None,
        orderNumber: int = None,
        **kwargs,
    ):
        if id:
            self.id = id
        if tasks:
            self.tasks = tasks
        self.sourceType = sourceType
        self.label = label
        self.x = x
        self.y = y
        self.z = z
        self.orderNumber = orderNumber
        self.tasks = []
        if tasks:
            self.tasks = [task if isinstance(task, TaskInfoDto) else TaskInfoDto(**task) for task in tasks]
        if sourceProperties:
            self.sourceProperties = (
                sourceProperties
                if isinstance(sourceProperties, SourcePropertiesDto)
                else SourcePropertiesDto(**sourceProperties)
            )
        else:
            self.sourceProperties = None

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)

    def pos_as_point(self) -> Point3d:
        return Point3d(self.x, self.y, self.z)


class MaterialAssignmentDto:
    def __init__(
        self,
        materialId: str = None,
        materialName: str = None,
        layerId: str = None,
        layerName: str = None,
        scatteringCoefficient: list[float] = None,
        **kwargs,
    ):
        self.materialId = materialId if materialId else None
        self.materialName = None
        if materialName:
            self.materialName = materialName
        self.layerId = layerId if layerId else None
        if layerName:
            self.layerName = layerName

        self.scatteringCoefficient = None
        if scatteringCoefficient is not None:
            if isinstance(scatteringCoefficient, Number):
                self.scatteringCoefficient = [scatteringCoefficient]
            else:
                self.scatteringCoefficient = scatteringCoefficient

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class LocalMeshSizingDto:
    def __init__(
        self,
        meshSizingM: float,
        keepExteriorEdges: bool = False,
        layerName: str = None,
        **kwargs,
    ):
        self.meshSizingM = meshSizingM
        self.keepExteriorEdges = keepExteriorEdges
        self.layerName = None
        if layerName:
            self.layerName = layerName

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class GaSettingsDto:
    def __init__(
        self,
        numberOfRays: int,
        ismOrder: int,
        isAirAbsorptionActive: bool,
        ismRayCount: int,
        gaSolverType: str = "IsmPressureRayRadiosity",
        **kwargs,
    ):
        self.numberOfRays = numberOfRays
        self.ISMOrder = ismOrder
        self.isAirAbsorptionActive = isAirAbsorptionActive
        self.ISMRayCount = ismRayCount
        self.gaSolverType = gaSolverType


class DgSettingsDto:
    def __init__(
        self,
        polynomialOrder: int,
        disableBcOptimizations: bool = None,
        dumpRawIrs: bool = None,
        skipPostprocessing: bool = None,
        **kwargs,
    ):
        self.polynomialOrder = polynomialOrder
        self.disableBcOptimizations = disableBcOptimizations
        self.dumpRawIrs = dumpRawIrs
        self.skipPostprocessing = skipPostprocessing


class WorkerVersionSettingsDto:
    def __init__(self, dgSolver: str, gaSolver: str):
        self.dgSolver = dgSolver
        self.gaSolver = gaSolver


class SimulationSettingsDto:
    def __init__(
        self,
        speedOfSound: float = 343.0,
        gaSettings: GaSettingsDto | dict = None,
        dgSettings: DgSettingsDto | dict = None,
        ambisonicsOrder: int = None,
        advancedSettings: dict[str, str] = None,
        irShiftSeconds: float = None,
        gpuCount: int = None,
        devBlob: str = None,
        workerVersions: WorkerVersionSettingsDto | dict = None,
        freeFieldRemovalMaxDistance: float = None,
        **kwargs,
    ):
        """
        Container for simulation settings.
        :param gaSettings: GaSettingsDto in either object respresentation or as dict.
        :param dgSettings: DgSettingsDto in either object respresentation or as dict.
        :param ambisonicsOrder: Spatial receivers ambisonics order, allowed values: [0, 1, 2, 4, 6, 8, 16]
        """
        if speedOfSound:
            self.speedOfSound = speedOfSound
        if gaSettings:
            self.gaSettings = (
                gaSettings if isinstance(gaSettings, GaSettingsDto) else GaSettingsDto(**gaSettings)
            )
        if dgSettings:
            self.dgSettings = (
                dgSettings if isinstance(dgSettings, DgSettingsDto) else DgSettingsDto(**dgSettings)
            )
        if ambisonicsOrder is not None:
            self.ambisonicsOrder = ambisonicsOrder
        if advancedSettings is not None:
            self.advancedSettings = advancedSettings
        if irShiftSeconds is not None:
            self.irShiftSeconds = irShiftSeconds
        if gpuCount is not None:
            self.gpuCount = gpuCount
        if devBlob:
            self.devBlob = devBlob
        if workerVersions:
            self.workerVersions = workerVersions
        if freeFieldRemovalMaxDistance:
            self.freeFieldRemovalMaxDistance = freeFieldRemovalMaxDistance


class MesherSettingsDto:
    def __init__(
        self,
        meshSize: float = None,
        maxEdgeLength: float = None,
        elementsPerWavelength: float = None,
        forensicMode: bool = None,
        simplifyMesh: bool = None,
    ):
        self.meshSize = meshSize
        self.maxEdgeLength = maxEdgeLength
        self.elementsPerWavelength = elementsPerWavelength
        self.forensicMode = forensicMode
        self.simplifyMesh = simplifyMesh


class SimulationDto:
    def __init__(
        self,
        name: str,
        simulationType: str,
        impulseLengthSec: float,
        crossoverFrequency: int,
        modelDefinitionId: str,
        onTaskError: str,
        receivers: list[dict | ReceiverDto],
        sources: list[dict | SourceDto],
        layerMaterialAssignments: list[dict | MaterialAssignmentDto],
        description: str = None,
        energyDecayThreshold: float = None,
        simulationSettings: dict | SimulationSettingsDto = None,
        resultStatus: ResultStatusDto = None,
        mesherSettings: MesherSettingsDto = None,
        localMeshSizing: list[dict | LocalMeshSizingDto] = None,
        originalGeometryLibraryId: str = None,
        metadata: dict[str, str] = None,
        category: str = None,
    ):
        """
        :param name: Name of simulation
        :param description: optional description
        :param simulationType: Simulation type: "dg", "ga" or "hybrid"
        :param impulseLengthSec: Impulse length in seconds.
        :param crossoverFrequency: DG/GA crossover frequency.
        :param modelDefinitionId": Id of model to use in simulation.
        :param onTaskError: What to do in case of task error: "ignore", "stopSimulation", "stopProject".
        :param list[dict] receivers: List of receivers to use in simulation. Receiver object or ReceiverDto dictionary representation.
        :param list[dict] sources: List of sources to use in simulation. Source object or SourceDto dictionary representation.
        :param list[MaterialAssignmentDto] layerMaterialAssignments: List of layerMaterialAssignment objects. MaterialAssignment object or MaterialAssignmentDto dict representation.
        :param simulationSettings: Advanced simulation settings to use.
        :param energyDecayThreshold: Energy decay threshold in dB
        :param irShiftSeconds: Shift the IRs and effectively pad the beginning of them to allow for the source correction and postprocessing create more accurate results.
        """
        self.id = None
        self.projectId = None
        self.name = name
        self.description = description
        self.simulationType = simulationType
        self.impulseLengthSec = impulseLengthSec
        self.crossoverFrequency = crossoverFrequency
        self.modelDefinitionId = modelDefinitionId
        self.originalGeometryLibraryId = originalGeometryLibraryId
        self.onTaskError = onTaskError
        self.category = category
        if receivers:
            self.receivers = [
                receiver if isinstance(receiver, ReceiverDto) else ReceiverDto(**receiver)
                for receiver in receivers
            ]
        else:
            self.receivers = []
        if sources:
            self.sources = [
                source if isinstance(source, SourceDto) else SourceDto(**source) for source in sources
            ]
        else:
            self.sources = []
        # Material layer assignment
        self._originalLayerMaterialAssignments = layerMaterialAssignments
        if layerMaterialAssignments:
            self.layerMaterialAssignments = [
                (
                    assignment
                    if isinstance(assignment, MaterialAssignmentDto)
                    else MaterialAssignmentDto(**assignment)
                )
                for assignment in layerMaterialAssignments
            ]
        else:
            self.layerMaterialAssignments = []
        # Local mesh sizing
        if localMeshSizing:
            self.localMeshSizing = [
                (
                    layerSizing
                    if isinstance(layerSizing, LocalMeshSizingDto)
                    else LocalMeshSizingDto(**layerSizing)
                )
                for layerSizing in localMeshSizing
            ]
        else:
            self.localMeshSizing = []
        # Simulation settings
        self.simulationSettings = None
        if simulationSettings:
            self.simulationSettings = (
                simulationSettings
                if isinstance(simulationSettings, SimulationSettingsDto)
                else SimulationSettingsDto(**simulationSettings)
            )
        self.energyDecayThreshold = None
        if energyDecayThreshold:
            self.energyDecayThreshold = energyDecayThreshold
        self.resultStatus = None
        if resultStatus:
            self.resultStatus = (
                resultStatus if isinstance(resultStatus, ResultStatusDto) else ResultStatusDto(**resultStatus)
            )
        self.mesherSettings = None
        if mesherSettings:
            self.mesherSettings = (
                mesherSettings
                if isinstance(mesherSettings, MesherSettingsDto)
                else MesherSettingsDto(**mesherSettings)
            )

        self.metadata = None
        if metadata:
            self.metadata = ObjectMetadataDto(keyValuePairs=metadata)

    def from_response(
        id: str,
        createdAt: str,
        updatedAt: str,
        name: str,
        description: str,
        simulationType: str,
        status: str,
        impulseLengthSec: float,
        crossoverFrequency: int,
        modelDefinitionId: str,
        onTaskError: str,
        receivers: list[dict | ReceiverDto],
        sources: list[dict | SourceDto],
        layerMaterialAssignments: list[dict | MaterialAssignmentDto],
        simulationSettings: dict | SimulationSettingsDto,
        resultStatus: dict | ResultStatusDto,
        tasks: dict | TaskInfoDto = None,
        energyDecayThreshold: float = None,
        mesherSettings: MesherSettingsDto = None,
        localMeshSizing: list[dict | LocalMeshSizingDto] = None,
        metadata: dict[str, str] = None,
        category: str = None,
        projectId: str = None,
        **kwargs,
    ):
        dto = SimulationDto(
            name=name,
            description=description,
            simulationType=simulationType,
            impulseLengthSec=impulseLengthSec,
            crossoverFrequency=crossoverFrequency,
            modelDefinitionId=modelDefinitionId,
            onTaskError=onTaskError,
            receivers=receivers,
            sources=sources,
            layerMaterialAssignments=layerMaterialAssignments,
            energyDecayThreshold=energyDecayThreshold,
            simulationSettings=simulationSettings,
            mesherSettings=mesherSettings,
            localMeshSizing=localMeshSizing,
            category=category,
        )

        dto.id = id
        dto.projectId = projectId
        dto.createdAt = createdAt
        dto.updatedAt = updatedAt
        dto.status = status
        if tasks:
            dto.tasks = [TaskInfoDto(**task) for task in tasks]
        if resultStatus:
            dto.resultStatus = (
                resultStatus if isinstance(resultStatus, ResultStatusDto) else ResultStatusDto(**resultStatus)
            )
        dto.metadata = None
        if metadata:
            dto.metadata = ObjectMetadataDto(**metadata)
        return dto

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class SimulationUpdateDto:
    def __init__(
        self,
        name: str = None,
        description: str = None,
        impulse_length_sec: float = None,
        crossover_frequency: int = None,
        energy_decay_threshold: float = None,
        simulationSettings: SimulationSettingsDto = None,
        **kwargs,
    ):
        if name:
            self.name = name
        if description:
            self.description = description
        if impulse_length_sec:
            self.impulseLengthSec = impulse_length_sec
        if crossover_frequency:
            self.crossoverFrequency = crossover_frequency
        if energy_decay_threshold:
            self.energyDecayThreshold = energy_decay_threshold
        if simulationSettings:
            self.simulationSettings = SimulationSettingsDto(**simulationSettings)


class GpuCountRangeDto:
    def __init__(
        self,
        minimumGpuCount: int = None,
        recommendedGpuCount: int = None,
        maximumAllowedGpuCount: int = None,
        **kwargs,
    ):
        """
        Gives information on the minimum, recommended and maximum gpu count per task for a job.

        Args:
            minimumGpuCount (int, optional): The minimum required GPU count. Defaults to None.
            recommendedGpuCount (int, optional): The recommended GPU count. Defaults to None.
            maximumAllowedGpuCount (int, optional): The maximum allowed GPU count. Defaults to None.
        """
        self.minimum_gpu_count = minimumGpuCount
        self.recommended_gpu_count = recommendedGpuCount
        self.maximum_allowed_gpu_count = maximumAllowedGpuCount

    def __repr__(self):
        return f"GpuCountRangeDto(minimum_gpu_count={self.minimum_gpu_count}, recommended_gpu_count={self.recommended_gpu_count}, maximum_allowed_gpu_count={self.maximum_allowed_gpu_count})"


class SourceEstimateDto:
    def __init__(
        self,
        sourceId,
        sourceLabel,
        estimatedRuntimeHours,
        estimatedCostInTokens,
        estimatedGpusAllocated,
        **kwargs,
    ):
        self.sourceId = sourceId
        self.sourceLabel = sourceLabel
        self.estimatedRuntimeHours = estimatedRuntimeHours
        self.estimatedCostInTokens = estimatedCostInTokens
        self.estimatedGpusAllocated = estimatedGpusAllocated


class SimulationEstimateDto:
    def __init__(
        self,
        simulationId: str,
        simulationName: str,
        totalEstimatedRuntimeHours: float,
        totalEstimatedCostInTokens: float,
        estimatePerSource: list[dict | SourceEstimateDto],
        resultStatus: dict | ResultStatusDto,
        meshQualityPercentage: float,
        simulationStatus: str,
        supportedGpuCounts: GpuCountRangeDto = None,
        **kwargs,
    ):
        """
        :param list[dict] estimatePerSource: List of SourceEstimateDto in dict representation.
        """
        self.simulationId = simulationId
        self.simulationName = simulationName
        self.simulationStatus = simulationStatus
        self.totalEstimatedRuntimeHours = totalEstimatedRuntimeHours
        self.totalEstimatedCostInTokens = totalEstimatedCostInTokens
        self.meshQualityPercentage = meshQualityPercentage
        if estimatePerSource:
            self.estimatePerSource = [
                source if isinstance(source, SourceEstimateDto) else SourceEstimateDto(**source)
                for source in estimatePerSource
            ]
        else:
            self.estimatePerSource = []

        self.supportedGpuCounts = None
        if supportedGpuCounts:
            self.supportedGpuCounts = GpuCountRangeDto(**supportedGpuCounts)

        if resultStatus:
            self.resultStatus = (
                resultStatus if isinstance(resultStatus, ResultStatusDto) else ResultStatusDto(**resultStatus)
            )


class ProjectEstimateDto:
    def __init__(
        self,
        projectId: str,
        totalEstimatedRuntimeHours: float,
        totalEstimatedCostInTokens: float,
        simulationEstimates: list[dict | SimulationEstimateDto],
        resultStatus: dict,
        **kwargs,
    ):
        """
        :param list[dict] simulationEstimates: List of SimulationEstimateDto in dict representation.
        """
        self.projectId = projectId
        self.totalEstimatedRuntimeHours = totalEstimatedRuntimeHours
        self.totalEstimatedCostInTokens = totalEstimatedCostInTokens
        if simulationEstimates:
            self.simulationEstimates = [
                (
                    simulation
                    if isinstance(simulation, SimulationEstimateDto)
                    else SimulationEstimateDto(**simulation)
                )
                for simulation in simulationEstimates
            ]
        else:
            self.simulationEstimates = []
        if resultStatus:
            self.resultStatus = ResultStatusDto(**resultStatus)


class SimulationProgressDto:
    def __init__(
        self,
        simulationId: str,
        simulationName: str,
        simulationStatus: str,
        simulationProgressPercentage: float,
        sources: list[dict | SourceDto],
        projectId: str,
        projectName: str,
        **kwargs,
    ):
        self.simulationId = simulationId
        self.simulationName = simulationName
        self.simulationStatus = simulationStatus
        self.simulationProgressPercentage = simulationProgressPercentage
        if sources:
            self.sources = [
                source if isinstance(source, SourceDto) else SourceDto(**source) for source in sources
            ]
        self.projectId = projectId
        self.projectName = projectName


class ProjectProgressDto:
    def __init__(
        self,
        projectId: str,
        projectName: str,
        status: str,
        projectProgressPercentage: float,
        simulations: list[dict | SimulationProgressDto],
        **kwargs,
    ):
        self.projectId = projectId
        self.projectName = projectName
        self.status = status
        self.projectProgressPercentage = projectProgressPercentage
        self.simulations = []
        if simulations:
            self.simulations = [
                (
                    simulation
                    if isinstance(simulation, SimulationProgressDto)
                    else SimulationProgressDto(**simulation)
                )
                for simulation in simulations
            ]

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class CancelTaskDto:
    def __init__(
        self,
        taskId: str,
        sourceId: str,
        sourceLabel: str,
        taskType: str,
        taskStatus: str,
        simulationId: str,
        **kwargs,
    ):
        self.task_id = taskId
        self.source_id = sourceId
        self.source_label = sourceLabel
        self.task_type = taskType
        self.task_status = taskStatus
        self.simulation_id = simulationId

        def __repr__(self):
            return f"CancelTaskDto(task_id={self.task_id}, source_id={self.source_id}, source_label={self.source_label}, task_type={self.task_type}, task_status={self.task_status}, simulation_id={self.simulation_id})"


class CancelSimulationDto:
    def __init__(
        self,
        resultStatus: ResultStatusDto,
        simulationId: str,
        simulationName: str,
        simulationStatus: str,
        cancelledTasks: list[dict | CancelTaskDto],
        **kwargs,
    ):
        self.resultStatus = None
        if resultStatus:
            self.resultStatus = ResultStatusDto(**resultStatus)
        self.simulationId = simulationId
        self.simulationName = simulationName
        self.simulationStatus = simulationStatus
        self.cancelledTasks = []
        if cancelledTasks:
            self.cancelledTasks = [
                t if isinstance(t, CancelTaskDto) else CancelTaskDto(**t) for t in cancelledTasks
            ]


class SolveTaskResultDto:
    def __init__(
        self,
        id: str,
        createdAt: str,
        taskType: str,
        subType: str,
        sourceId: str,
        dataFileUrl: str,
        jsonFileUrl: str,
        resultJson: str,
        **kwargs,
    ):
        self.id = id
        self.createdAt = createdAt
        self.taskType = taskType
        self.subType = subType
        self.sourceId = sourceId
        self.dataFileUrl = dataFileUrl
        self.jsonFileUrl = jsonFileUrl
        self.resultJson = resultJson


class SourceResultDto:
    def __init__(self, sourceInfo: SourceDto, results: list[dict | SolveTaskResultDto], **kwargs):
        """
        :param SourceDto sourceInfo: SourceDto
        :param list[SolveTaskResultDto] results: List of SolveTaskResultDtos.
        """
        self.sourceInfo = SourceDto(**sourceInfo)
        self.results = None
        if results:
            self.results = [
                result if isinstance(result, SolveTaskResultDto) else SolveTaskResultDto(**result)
                for result in results
            ]

    def __repr__(self):
        return f"{type(self).__qualname__}(source: {str(self.sourceInfo)}, results: {self.results})"


class SimulationResultDto:
    def __init__(
        self,
        simulationId: str,
        name: str,
        description: str,
        sourceResults: list[SourceResultDto],
        createdAt: str,
        updatedAt: str,
        simulationType: str,
        **kwargs,
    ):
        self.simulationId = simulationId
        self.name = name
        self.description = description
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.simulationType = simulationType
        self.sourceResults = None
        if sourceResults:
            self.sourceResults = [SourceResultDto(**sourceResult) for sourceResult in sourceResults]


class StartProjectDto:
    def __init__(
        self,
        started: list[dict | SimulationDto],
        alreadyStarted: list[dict | SimulationDto],
        alreadyInEndState: list[dict | SimulationDto],
        **kwargs,
    ):
        """
        :param list[SimulationDto] started: List of SimulationDtos which were started.
        :param list[SimulationDto] alreadyStarted: List of SimulationDtos which were already started before this request.
        :param list[SimulationDto] alreadyInEndState: List of SimulationDtos which were already in end state before this request.
        """
        self.started = []
        self.alreadyStarted = []
        self.alreadyInEndState = []
        if started:
            self.started = [
                (
                    simulation
                    if isinstance(simulation, SimulationDto)
                    else SimulationDto.from_response(**simulation)
                )
                for simulation in started
            ]
        if alreadyStarted:
            self.alreadyStarted = [
                (
                    simulation
                    if isinstance(simulation, SimulationDto)
                    else SimulationDto.from_response(**simulation)
                )
                for simulation in alreadyStarted
            ]
        if alreadyInEndState:
            self.alreadyInEndState = [
                (
                    simulation
                    if isinstance(simulation, SimulationDto)
                    else SimulationDto.from_response(**simulation)
                )
                for simulation in alreadyInEndState
            ]


class PositionSuggestionDto:
    def __init__(
        self,
        name: str,
        position: list[float],
        space: str | None,
        azimuthAngle: float | None,
        elevationAngle: float | None,
        rollAngle: float | None,
    ):
        self.name = name
        self.position = position
        self.space = space
        self.azimuth_angle = azimuthAngle
        self.elevation_angle = elevationAngle
        self.roll_angle = rollAngle


class GeometryLibraryDto:
    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        dataset: str,
        tags: list[str],
        layers: list[str],
        positionSuggestions: list[PositionSuggestionDto],
        volumeM3: float,
        geometryObjectInfoJson: dict[str, GeometryObjectInfoDto],
        geometryGroupVolumesJson: dict[int, float],
        metadata: str,
        isDeleted: bool = None,
        **kwargs,
    ):
        """
        :param str id: Id of Geometry in GeometryLibrary
        :param str name: Name of Geometry.
        :param str description: Description of geometry.
        :param list[str] tags: List of tags for geometry.
        :param list[str] layers: List of layer names in geometry (For material assignment).
        :param dict[str, list[float]] positionSuggestions: A dictionary with position name as key and positions in format [x,y,z] as values.
        :param float volumeM3: Volume of surface in m^3.
        """
        self.id = id
        self.name = name
        self.description = description
        self.dataset = dataset
        self.tags = tags
        self.layer_names = layers
        self.layers = layers  # Only here for legacy support.
        if positionSuggestions:
            self.positionSuggestions = [PositionSuggestionDto(**x) for x in positionSuggestions]
        else:
            self.positionSuggestions = None
        self.volumeM3 = volumeM3
        self.metadata = metadata
        self.geometryObjectInfo = None
        self.geometryGroupTypeToVolume = None
        if geometryObjectInfoJson:
            parsed_geo_info = json.loads(geometryObjectInfoJson)
            self.geometryObjectInfo = {k: GeometryObjectInfoDto(**v) for (k, v) in parsed_geo_info.items()}
        if geometryGroupVolumesJson:
            self.geometryGroupTypeToVolume = json.loads(geometryGroupVolumesJson)
        self.isDeleted = isDeleted

    def __str__(self):
        return json.dumps(
            {
                "id": self.id,
                "name": self.name,
                "description": self.description,
                "category": self.dataset,
                "tags": self.tags,
                "layer_names": self.layer_names,
                "positionSuggestions": self.positionSuggestions,
                "volumeM3": self.volumeM3,
            },
            indent=2,
        )


class SourceDirectivityDto:
    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        category: str,
        subCategory: str,
        manufacturer: str,
        directivity2dJsonUploadId: str,
        gaDirectivityUploadId: str,
        dgDirectivityUploadId: str,
        splOnAxis1mByFrequencyJson: str,
        organizationId: str,
        maxCrossoverFrequency: int = None,
        simulationTypeFilter: list[str] = None,
        resultStatus: dict | ResultStatusDto = None,
        isDeleted: bool = None,
        **kwargs,
    ):
        """
        The definition of a directivity which can be used as a source
        in a simulation

        :param str id: Id of directivity
        :param str name: Name of directivity
        :param str description: Description of directivity, can be an empty string
        :param str category: Directivity category
        :param str subCategory: The sub category of the category of the directivity
        :param str manufacturer: Directivity manufacturer
        :param str dgDirectivityUploadId: Upload id of approximated dg directivity json file
        :param str gaDirectivityUploadId: Upload id of approximated ga directivity json file
        :param str directivity2dJsonUploadId: Upload id of directivity file
        :param str splOnAxis1mByFrequencyJson: SPL on axis by frequency
        :param str organizationId: Id of the organization this source directivity belongs to. Only has value if directivity is user created
        """
        self.id = id
        self.name = name
        self.description = description
        self.category = category
        self.subCategory = subCategory
        self.directivity2dJsonUploadId = directivity2dJsonUploadId
        self.gaDirectivityUploadId = gaDirectivityUploadId
        self.dgDirectivityUploadId = dgDirectivityUploadId
        self.splOnAxis1mByFrequencyJson = splOnAxis1mByFrequencyJson
        self.manufacturer = manufacturer
        self.organizationId = organizationId
        self.maxCrossoverFrequency = maxCrossoverFrequency
        self.simulationTypeFilter = simulationTypeFilter
        self.isDeleted = isDeleted
        if resultStatus:
            self.resultStatus = (
                resultStatus if isinstance(resultStatus, ResultStatusDto) else ResultStatusDto(**resultStatus)
            )

    def __str__(self):
        return json.dumps(
            {
                "name": self.name,
                "description": self.description,
                "type": self.category,
                "category": self.sub_category,
                "manufacturer": self.manufacturer,
            },
            indent=2,
        )


class DeviceDto:
    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        createdAt: str,
        updatedAt: str,
        uploadedBy: str,
        filename: str,
        filesize: int,
        **kwargs,
    ):
        self.id = id
        self.name = name
        self.description = description
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.uploadedBy = uploadedBy
        self.filename = filename
        self.filesize = filesize

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class SdkVersionDto:
    def __init__(
        self,
        updateAvailable: bool,
        majorVersion: int,
        minorVersion: int,
        patchLevel: int,
        changelog: str,
        **kwargs,
    ):
        self.update_available = updateAvailable
        self.major_version = majorVersion
        self.minor_version = minorVersion
        self.patch_level = patchLevel
        self.changelog = changelog

    def to_update_announcement(self) -> str:
        if self.update_available is False:
            return "== SDK package is up to date =="
        anno = f"SDK Update available {self.major_version}.{self.minor_version}.{self.patch_level}\n\nChangelog:\n{self.changelog}"
        anno += "To download the update package do sdk.download_update('/download/to/this/directory') or sdk.get_update_url() to get URL to update package."
        return anno


class SdkStatus(str, Enum):
    """
    Contains the possible values for SDK operational status
    """

    operational = "operational"
    warning = "warning"
    offline = "offline"


class SdkStatusDto:
    def __init__(self, id: int, status: SdkStatus, message: int, **kwargs):
        self.id = id
        self.status = status
        self.message = message


class GeometryObjectLayerInfoDto:
    def __init__(self, objectId: str, layerName: str, **kwargs):
        self.objectId = objectId
        self.layerName = layerName


class TokenStatusDto:
    def __init__(
        self, reservableTokens: float = None, reservedTokens: float = None, tokensLeftInPackages: float = None
    ):
        self.reservableTokens = reservableTokens
        self.reservedTokens = reservedTokens
        self.tokensLeftInPackages = tokensLeftInPackages

    @property
    def reservable_tokens(self) -> float | None:
        return self.reservableTokens

    @property
    def reserved_tokens(self) -> float | None:
        return self.reservedTokens

    @property
    def tokens_left_in_packages(self) -> float | None:
        return self.tokensLeftInPackages

    def __str__(self):
        return json.dumps(
            {
                "reservable_tokens": round(self.reservableTokens, 2),
                "reserved_tokens": round(self.reservedTokens, 2),
                "tokens_left_in_packages": round(self.tokensLeftInPackages, 2),
            },
            default=vars,
            indent=2,
        )

    def __repr__(self):
        return f"TokenStatusDto(reservableTokens={self.reservableTokens}, reservedTokens={self.reservedTokens}, tokensLeftInPackages={self.tokensLeftInPackages})"


class ProductDto:
    def __init__(
        self,
        productKey: str,
        billingType: str,
        concurrency: int,
        maxSeats: int,
        expiresAt: str = None,
        sdkMaxCpuConcurrency: Number = None,
        sdkMaxGpuConcurrency: Number = None,
        sdkMaxGpuCountPerTask: Number = None,
        sdkTier: str = None,
        **kwargs,
    ):
        self.productKey = productKey
        self.billingType = billingType
        self.concurrency = concurrency
        self.maxSeats = maxSeats
        self.expiresAt = expiresAt
        self.sdkMaxCpuConcurrency = sdkMaxCpuConcurrency
        self.sdkMaxGpuConcurrency = sdkMaxGpuConcurrency
        self.sdkMaxGpuCountPerTask = sdkMaxGpuCountPerTask
        self.sdkTier = sdkTier

    def __str__(self):
        return json.dumps(
            {
                "productKey": self.productKey,
                "expiresAt": self.expiresAt,
                "sdkMaxCpuConcurrency": round(self.sdkMaxCpuConcurrency, 2),
                "sdkMaxGpuConcurrency": round(self.sdkMaxGpuConcurrency, 2),
                "sdkMaxGpuCountPerTask": round(self.sdkMaxGpuCountPerTask, 2),
                "sdkTier": self.sdkTier,
            },
            default=vars,
            indent=2,
        )

    def __repr__(self):
        return self.__str__()


class OverviewDto:
    def __init__(
        self,
        userId: str,
        email: str,
        organizationId: str,
        organizationName: str,
        queuedCpuTasks: int,
        queuedGpuTasks: int,
        runningSimulationsCount: int,
        runningSimulations: list[dict],
        queuedSimulationsCount: int,
        queuedSimulations: list[dict],
        tokenStatus: TokenStatusDto,
        products: list[ProductDto],
        **kwargs,
    ):
        self.userId = userId
        self.email = email
        self.organizationId = organizationId
        self.organizationName = organizationName
        self.queuedCpuTasks = queuedCpuTasks
        self.queuedGpuTasks = queuedGpuTasks
        self.runningSimulationsCount = runningSimulationsCount
        self.runningSimulations = [SimulationProgressDto(**simulation) for simulation in runningSimulations]
        self.queuedSimulationsCount = queuedSimulationsCount
        self.queuedSimulations = [SimulationProgressDto(**simulation) for simulation in queuedSimulations]
        self.tokenStatus = TokenStatusDto(**tokenStatus)
        self.products = [ProductDto(**product) for product in products]

    def __repr__(self):
        return f"OverviewDto(organizationName={self.organizationName}, runningSimulationsCount={self.runningSimulationsCount}, queuedSimulationsCount={self.queuedSimulationsCount}, reservableTokens={self.tokenStatus.reservableTokens}, reservedTokens={self.tokenStatus.reservedTokens}, tokensLeftInPackages={self.tokenStatus.tokensLeftInPackages})"

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)

    def as_tree(self):
        """
        Uses the display_data module to display overview as tree.
        """
        try:
            importlib.import_module(DISPLAY_DATA_MODULE_NAME).as_tree(self)
        except ImportError:
            logger.warning(
                f"Unable to find required {DISPLAY_DATA_MODULE_NAME} module, has it been installed?"
            )


class FileDownloadInfoDto:
    def __init__(self, filename: str, filesize: int, downloadUrl: str, **kwargs):
        self.filename = filename
        self.filesize = filesize
        self.downloadUrl = downloadUrl


class ModelToGeometryLibraryDto:
    def __init__(
        self, modelDefinitionId: str, category: str, tags: list[str], positionSuggestionsJson: str, **kwargs
    ):
        self.modelDefinitionId = modelDefinitionId
        self.category = category
        self.tags = tags
        self.positionSuggestionsJson = positionSuggestionsJson


class CategoryInfoDto:
    def __init__(self, name: str, count: int, **kwargs):
        self.name = name
        self.count = count

    def as_table(self):
        try:
            importlib.import_module(DISPLAY_DATA_MODULE_NAME).as_table(self)
        except ImportError:
            logger.warning(
                f"Unable to find required {DISPLAY_DATA_MODULE_NAME} module, has it been installed?"
            )

    def __repr__(self):
        return f"CategoryInfoDto(name={self.name}, count={self.count})"


class MeshInfoDto:
    def __init__(
        self,
        id: str,
        taskInfoId: str,
        modelDefinitionId: str,
        createdAt: str,
        sourceId: str = None,
        taskSuccess: bool = None,
        crossoverFrequency: int = None,
        elementCount: int = None,
        elementsPerWavelength: float = None,
        basisOrder: int = None,
        faceCount: int = None,
        nodeCount: int = None,
        elementMinLength: float = None,
        elementMaxLength: float = None,
        elementMeanLength: float = None,
        elementStdLength: float = None,
        volume: float = None,
        smallestElements: str = None,
        meshQualityPercentage: float = None,
        meshQualityIndicator: int = None,
        fileDownloadInfo: dict = None,
        mesherTaskInfo: dict = None,
        **kwargs,
    ):
        self.id = id
        self.sourceId = sourceId
        self.taskInfoId = taskInfoId
        self.modelDefinitionId = modelDefinitionId
        self.createdAt = createdAt
        self.taskSuccess = taskSuccess
        self.crossoverFrequency = crossoverFrequency
        self.elementsPerWavelength = elementsPerWavelength
        self.basisOrder = basisOrder
        self.faceCount = faceCount
        self.nodeCount = nodeCount
        self.elementCount = elementCount
        self.elementMinLength = elementMinLength
        self.elementMaxLength = elementMaxLength
        self.elementMeanLength = elementMeanLength
        self.elementStdLength = elementStdLength
        self.volume = volume
        self.smallestElements = smallestElements
        self.meshQualityPercentage = meshQualityPercentage
        self.meshQualityIndicator = meshQualityIndicator
        self.fileDownloadInfo = None
        if fileDownloadInfo:
            self.fileDownloadInfo = FileDownloadInfoDto(**fileDownloadInfo)
        self.mesherTaskInfo = None
        self.taskStatus = None
        if mesherTaskInfo:
            self.mesherTaskInfo = TaskInfoDto(**mesherTaskInfo)
            self.taskStatus = self.mesherTaskInfo.status

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)


class SimulationMeshInfoDto:
    def __init__(self, simulationMeshInfo: MeshInfoDto, sourceMeshInfos: list[MeshInfoDto]):
        self.simulationMeshInfo = None
        if simulationMeshInfo:
            self.simulationMeshInfo = MeshInfoDto(**simulationMeshInfo)
        self.sourceMeshInfos = {}
        if sourceMeshInfos:
            self.sourceMeshInfos = {k: MeshInfoDto(**v) for k, v in sourceMeshInfos.items()}


class LayerExtractionMode(str, Enum):
    """
    Contains the possible values for layer extraction mode
    """

    nested = "nested_hierarchy"
    flat = "flat_hierarchy"
    material = "material_attribute"


class GeometryCheckerSettingsDto:
    def __init__(
        self,
        transitionFrequency: int = None,
        forensicMode: bool = None,
        simplificationThreshold: float = None,
        layerExtractionMode: LayerExtractionMode = LayerExtractionMode.nested,
        materialByAttribute: str = None,
        animationTimecode: float = None,
        **kwargs,
    ):
        """
        :param int transitionFrequency: Set this for the volumetric mesh to be generated with a size tailored for a specific transition frequency - and thus have the most relevant quality assessment.
        :param float simplificationThreshold: Resolution length in meters. Set this parameter to ensure that small elements (with edge length less than the given value for simplificationThreshold) would not be simplified. Defaults to 0.005 (5mm).
        """
        if simplificationThreshold < 0.001:
            raise ValueError("Simplification threshold must be 0.001 or greater")
        self.transitionFrequency = transitionFrequency
        self.forensicMode = forensicMode
        self.simplificationThreshold = simplificationThreshold
        self.layerExtractionMode = layerExtractionMode
        self.materialByAttribute = materialByAttribute
        self.animationTimecode = animationTimecode


class CreateBoundaryVelocitySubmodelDto:
    def __init__(self, name: str, description: str, parentSimulationId: str):
        self.name = name
        self.description = description
        self.parentSimulationId = parentSimulationId


class BoundaryVelocitySubmodelDto:
    def __init__(
        self,
        id: str,
        name: str,
        description: str,
        createdAt: str,
        createdBy: str | None,
        modelUploadId: str,
        boundingBoxJson: str,
        boundaryLayerName: str,
        organizationId: str | None,
        parentSimulationId: str | None,
        maxCrossoverFrequency: int = None,
        simulationTypeFilter: list[str] = None,
        isDeleted: bool = None,
        **kwargs,
    ):
        self.id = id
        self.name = name
        self.description = description
        self.createdAt = createdAt
        self.createdBy = createdBy
        self.modelUploadId = modelUploadId
        self.boundingBoxJson = boundingBoxJson
        self.boundaryLayerName = boundaryLayerName
        self.organizationId = organizationId
        self.parentSimulationId = parentSimulationId
        self.maxCrossoverFrequency = maxCrossoverFrequency
        self.simulationTypeFilter = simulationTypeFilter
        self.isDeleted = isDeleted


class GeometryComponentDto(BaseModel):
    model_config = _BASE_CONFIG
    id: str | None
    name: str
    description: str
    group_name: str
    bounding_box_json: str
    layer_names: list[str]
    suggested_materials_json: str
    model_file_upload_id: str | None
