# Custom STAPI exceptions.


class BadRequestException(Exception):
    pass


class InternalServerErrorException(Exception):
    pass


class MethodNotAllowedException(Exception):
    pass


class ConnectionErrorException(Exception):
    pass


class SSLErrorException(Exception):
    pass


class ForbiddenException(Exception):
    pass


class RateLimitException(Exception):
    pass


def raise_on_ssl_issue(e: Exception):
    """
    Detect if the error is related to SSL issues.
    raises SSLErrorException if SSL error is detected.
    :param error: The exception to check.
    """
    e_str = str(e)
    if "[SSL:" in e_str or "_ssl.c" in e_str:
        raise SSLErrorException(
            "SSL error detected. Please check your SSL configuration. If problem persists contact Treble support."
        ) from e
