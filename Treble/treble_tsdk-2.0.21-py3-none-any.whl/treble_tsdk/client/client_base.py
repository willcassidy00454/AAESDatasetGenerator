from functools import wraps

from ..treble_logging import logger
from .exceptions import ConnectionErrorException, raise_on_ssl_issue

import httpx

import time
from collections import deque


class ClientBase:
    def __init__(self, baseUrl: str, session: httpx.Client):
        self._client_base_url = baseUrl
        if session:
            self._session = session

    def sleep_and_log(max_retries: int = 5, period: int = 10):
        def decorator(func):
            call_times = deque()

            @wraps(func)
            def wrapper(self, *args, **kwargs):
                retries = 0

                while retries < max_retries:
                    rate_limit = self._session.auth.rateLimit
                    if rate_limit == 0:
                        raise Exception("Rate limit exceeded. Request failed.")
                    current_time = time.time()

                    # Remove timestamps outside the time window
                    while call_times and current_time - call_times[0] >= period:
                        call_times.popleft()

                    # Check if rate limit is exceeded
                    if len(call_times) >= rate_limit:
                        period_remaining = period - (current_time - call_times[0])
                        backoff = 5 * (2**retries)
                        sleep_time = max(period_remaining, backoff)
                        retries += 1
                        logger.warning(
                            f"Rate limit exceeded. Sleeping for {sleep_time:.2f} seconds... (Attempt {retries}/{max_retries})"
                        )
                        time.sleep(sleep_time)
                        continue

                    call_times.append(current_time)

                    return func(self, *args, **kwargs)

                raise Exception(f"Max retries reached ({max_retries}). Request failed.")

            return wrapper

        return decorator

    @sleep_and_log(max_retries=5, period=10)
    def _preflight_check(self):
        """
        Performs a preflight check by sending a HEAD request to the API. If it's unable to connect it will retry one time before returning False.
        :returns: True if connection to API is OK, False if unable to connect to API
        """
        try:
            self._session.head(self._client_base_url)
        except (httpx.RequestError, httpx.ConnectError) as e:
            try:
                self._session.head(self._client_base_url)
            except (httpx.RequestError, httpx.ConnectError) as e:
                raise_on_ssl_issue(e)
                logger.error(
                    f"Preflight connection check failed. Connection is not valid. Aborting the request. {e}"
                )
                raise ConnectionErrorException(
                    "Unable to connect to SDK API! If problem persists contact Treble support."
                ) from e

    def _session_post_json(self, url: str, data: str) -> httpx.Response:
        self._preflight_check()
        return self._session.post(url, content=data, headers={"Content-type": "application/json"})

    def _session_post(self, url: str, data=None, json=None) -> httpx.Response:
        self._preflight_check()
        return self._session.post(url, content=data, json=json)

    def _session_post_form_data(self, url: str, data: dict) -> httpx.Response:
        self._preflight_check()
        return self._session.post(url, data=data)

    def _session_post_files(self, url: str, data: dict, files: dict) -> httpx.Response:
        self._preflight_check()
        return self._session.post(url, data=data, files=files)

    def _session_get(self, url: str, params=None) -> httpx.Response:
        self._preflight_check()
        return self._session.get(url, params=params)

    def _session_delete(self, url: str) -> httpx.Response:
        self._preflight_check()
        return self._session.delete(url)

    def _session_delete_json(self, url: str, data: str) -> httpx.Response:
        self._preflight_check()
        return self._session.delete(url, data=data, headers={"Content-type": "application/json"})

    def _session_put(self, url: str, params=None) -> httpx.Response:
        self._preflight_check()
        return self._session.put(url, params=params)

    def _session_put_json(self, url: str, data=str) -> httpx.Response:
        self._preflight_check()
        return self._session.put(url, content=data, headers={"Content-type": "application/json"})
