import json
import sys
import tempfile
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from urllib.parse import quote_plus
from uuid import UUID
from zipfile import ZipFile

import logging
import httpx

from .. import __version__ as stapi_version
from ..treble_logging import logger
from .. import utils
from .transports import SSOTokenRefreshTransport
from .api_models import (
    CancelSimulationDto,
    CategoryInfoDto,
    DeviceDto,
    FileDownloadInfoDto,
    GeometryLibraryDto,
    SourceDirectivityDto,
    MaterialAssignmentDto,
    MaterialDto,
    FittedMaterialDto,
    MaterialDefinitionDto,
    MaterialBuilderDto,
    ModelDto,
    ModelToGeometryLibraryDto,
    OverviewDto,
    ProjectDto,
    ProjectEstimateDto,
    ProjectProgressDto,
    ProjectUpdateDto,
    ReceiverDto,
    ResultStatusDto,
    SdkVersionDto,
    SimulationDto,
    SimulationEstimateDto,
    SimulationProgressDto,
    SimulationResultDto,
    SimulationUpdateDto,
    SourceDto,
    SourceResultDto,
    StartProjectDto,
    StringResponse,
    SimulationMeshInfoDto,
    GeometryCheckerSettingsDto,
    TokenStatusDto,
    ObjectMetadataDto,
    BoundaryVelocitySubmodelDto,
    CreateBoundaryVelocitySubmodelDto,
    GeometryComponentDto,
)
from .auth import AuthenticationMiddleware, SSOAuthenticationMiddleware, UnauthorizedException
from .exceptions import (
    BadRequestException,
    InternalServerErrorException,
    MethodNotAllowedException,
    ForbiddenException,
    RateLimitException,
)
from .client_base import ClientBase
from .http_log_formatter import HttpFormatter


class TSDKClient(ClientBase):
    # Maps to ProjectController in API
    class __ProjectClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/Project"

        def create_project(self, req: ProjectDto) -> ProjectDto | None:
            """
            Creates a new project.
            :raises UnauthorizedException: If server returned status code 401
            :raises BadRequestException: If server returned status code 400
            :raises InternalServerErrorException: If server returned status code 500
            """
            res = self._session_post_json(self._base_url, json.dumps(req, default=vars))
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectDto.from_response(**res.json())
            return None

        def get_project(self, project_id: UUID) -> ProjectDto | None:
            """
            Get information on a single project.
            """
            res = self._session_get(f"{self._base_url}/{project_id}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectDto.from_response(**res.json())
            return None

        def get_project_by_name(self, name: str) -> ProjectDto | None:
            res = self._session_get(f"{self._base_url}/by-name?name={quote_plus(name)}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectDto.from_response(**res.json())
            if res.status_code == 404:
                logger.warning(f"Project '{name}' not found.")
            return None

        def get_by_name(self, name: str) -> ProjectDto | None:
            return self.get_project_by_name(name)

        def get_last_updated_project(self) -> ProjectDto | None:
            """
            Get last updated project along with simulations
            """
            res = self._session_get(f"{self._base_url}/last-updated")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectDto.from_response(**res.json())
            return None

        def get_projects(self, client_id: str = None) -> list[ProjectDto] | None:
            """
            Get all projects
            :param client_id: optional filter for clientId returning only that user's projects
            :returns list[ProjectDto]: Returns a list of ProjectDtos.
            """
            uri = f"{self._base_url}"
            if client_id:
                uri += f"?clientId={client_id}"
            res = self._session_get(uri)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ProjectDto.from_response(**item) for item in res.json()]
            return []

        def get_my_projects(self) -> list[ProjectDto] | None:
            """
            Get all projects created by the logged in user
            :returns list[ProjectDto]: Returns a list of ProjectsDtos
            """
            res = self._session_get(f"{self._base_url}/mine")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ProjectDto.from_response(**item) for item in res.json()]
            return []

        def delete_project(self, project_id: UUID, force: bool = False) -> None:
            res = self._session_delete(f"{self._base_url}/{project_id}?force={str(force).lower()}")
            if not TSDKClient._report_or_raise_on_status_code(res):
                if res.status_code:
                    logger.warning("Project not found!")
                else:
                    logger.warning("Unable to delete project")
                return False
            return True

        def rename(self, project_id: str, new_name: str) -> ProjectDto | None:
            res = self._session_put(
                f"{self._base_url}/{project_id}/rename",
                params={"newName": new_name},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectDto.from_response(**res.json())
            return None

        def get_simulations(
            self, project_id: str, simulation_status: "SimulationStatus" = None, name: str = None
        ) -> list[SimulationDto] | None:
            """
            Get all simulations in project.
            :param project_id: id of project.
            :param simulation_status: optional filter for simulation status
            :returns: List of SimulationDto objects.
            """
            uri = f"{self._base_url}/{project_id}/simulations"
            params = {}
            if simulation_status:
                params["status"] = simulation_status
            if name:
                params["name"] = name
            res = self._session_get(uri, params=params)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SimulationDto.from_response(**item) for item in res.json()]
            return None

        # @utils.ttl_cache(ttl=3)
        def estimate(self, project_id: UUID) -> ProjectEstimateDto | None:
            res = self._session_get(f"{self._base_url}/{project_id}/estimate")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectEstimateDto(**res.json())
            return None

        @utils.ttl_cache(ttl=10)
        def progress(self, project_id: UUID) -> ProjectProgressDto | None:
            res = self._session_get(f"{self._base_url}/{project_id}/progress")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectProgressDto(**res.json())
            return None

        def start(self, project_id: UUID) -> StartProjectDto | None:
            res = self._session_post(f"{self._base_url}/{project_id}/start")
            if TSDKClient._report_or_raise_on_status_code(res):
                return StartProjectDto(**res.json())
            return None

        def cancel(self, project_id: UUID) -> list[CancelSimulationDto] | None:
            """
            Cancel all simulation in project.
            :param project_id: id of project.
            :returns: List of CancelSimulationDto objects.
            """
            res = self._session_put(f"{self._base_url}/{project_id}/cancel")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [CancelSimulationDto(**item) for item in res.json()]
            return None

        def get_results(self, project_id: str, result_type: str = None) -> list[SimulationResultDto] | None:
            uri = f"{self._base_url}/{project_id}/results"
            if result_type:
                uri += f"?resultType={result_type}"
            res = self._session_get(uri)
            if res.status_code == 404:
                return []
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SimulationResultDto(**item) for item in res.json()]
            return None

        def update(self, project_id: str, req: ProjectUpdateDto) -> ProjectDto | None:
            res = self._session_put_json(f"{self._base_url}/{project_id}", data=json.dumps(req, default=vars))
            if TSDKClient._report_or_raise_on_status_code(res):
                return ProjectDto.from_response(**res.json())
            return None

        def get_metadata(self, project_id: str, **kwargs) -> ObjectMetadataDto:
            res = self._session_get(f"{self._base_url}/{project_id}/metadata")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ObjectMetadataDto(**res.json())
            return None

        def update_metadata(self, project_id: str, metadata: dict[str, str], **kwargs) -> str:
            res = self._session_put_json(f"{self._base_url}/{project_id}/metadata", data=json.dumps(metadata))
            TSDKClient._report_or_raise_on_status_code(res)
            return res.text.strip('"')

    # Maps to ModelController in API
    class __ModelClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/project"

        def create_model(
            self,
            project_id: str,
            name: str,
            filepath: str,
            description: str = None,
            compress: bool = False,
            geometry_checking_settings: GeometryCheckerSettingsDto = None,
            metadata: dict[str, str] = None,
            category: str = None,
            parent_id: str = None,
        ) -> ModelDto | None:
            res = None
            post_url = f"{self._base_url}/{project_id}/models"
            post_data = {
                "name": name,
                "description": description,
                "geometryCheckerSettings": json.dumps(geometry_checking_settings, default=vars),
                "category": category,
            }
            if metadata is not None:
                post_data["metadata"] = json.dumps(ObjectMetadataDto(keyValuePairs=metadata), default=vars)
            if parent_id:
                post_data["parentId"] = parent_id
            if compress and Path(filepath).suffix != ".zip":
                with tempfile.TemporaryDirectory() as tmpDir:
                    tmp_file = str(Path(tmpDir, Path(filepath).stem + ".zip"))
                    with ZipFile(tmp_file, "w") as zipObj:
                        zipObj.write(filepath, Path(filepath).name)
                    with open(tmp_file, "rb") as f:
                        res = self._session_post_files(
                            post_url,
                            data=post_data,
                            files={"formFile": f},
                        )
            else:
                with open(filepath, "rb") as f:
                    res = self._session_post_files(
                        post_url,
                        data=post_data,
                        files={"formFile": f},
                    )

            if TSDKClient._report_or_raise_on_status_code(res):
                return ModelDto(**res.json())
            return None

        def create_model_no_gcs(
            self,
            project_id: str,
            name: str,
            filepath: str,
            layer_data: str,
            object_info: str,
            groups_volume: str,
            description: str = None,
            parent_id: str = None,
        ) -> ModelDto | None:
            post_url = f"{self._base_url}/{project_id}/models/skipGCS"
            post_data = {
                "name": name,
                "description": description,
                "layerInfoJson": layer_data,
                "geometryObjectInfoJson": object_info,
                "geometryGroupVolumesJson": groups_volume,
            }
            if parent_id:
                post_data["parentId"] = parent_id
            with open(filepath, "rb") as f:
                res = self._session_post_files(
                    post_url,
                    data=post_data,
                    files={"formFile": f},
                )
            if TSDKClient._report_or_raise_on_status_code(res):
                return ModelDto(**res.json())
            return None

        # @utils.ttl_cache(ttl=3)
        def get_model(self, project_id: str, model_id: str) -> ModelDto | None:
            res = self._session_get(f"{self._base_url}/{project_id}/models/{model_id}")
            if res.status_code != 404 and TSDKClient._report_or_raise_on_status_code(res):
                return ModelDto(**res.json())
            return None

        def get_model_by_name(self, project_id: str, name: str) -> ModelDto | None:
            res = self._session_get(f"{self._base_url}/{project_id}/models/by-name?name={quote_plus(name)}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ModelDto(**res.json())
            return None

        def get_by_name(self, project_id: str, name: str) -> ModelDto | None:
            return self.get_model_by_name(project_id, name)

        # @utils.ttl_cache(ttl=3)
        def get_models(self, project_id: str) -> list[ModelDto] | None:
            """
            Get all models in project
            :param project_id: Id of project
            :returns: List of ModelDto objects.
            """
            res = self._session_get(f"{self._base_url}/{project_id}/models")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ModelDto(**item) for item in res.json()]
            return None

        # @utils.ttl_cache(ttl=3)
        def get_models_by_id(self, project_id: str, model_ids: list[str]) -> list[ModelDto] | None:
            """
            Get models by id in project
            :param project_id: Id of project
            :param model_ids: List of model ids to fetch.
            :returns: List of ModelDto objects.
            """
            res = self._session_post_json(
                f"{self._base_url}/{project_id}/models/from-ids",
                data=json.dumps(model_ids, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ModelDto(**item) for item in res.json()]
            return None

        def get_model_url(self, project_id: str, model_id: str) -> FileDownloadInfoDto | None:
            res = self._session_get(f"{self._base_url}/{project_id}/models/{model_id}/url")
            if res.status_code == 404:
                return None
            if TSDKClient._report_or_raise_on_status_code(res):
                return FileDownloadInfoDto(**res.json())
            return None

        def get_gcs_results_json_url(self, project_id: str, model_id: str) -> StringResponse | None:
            res = self._session_get(f"{self._base_url}/{project_id}/models/{model_id}/gcs_results_url")
            if res.status_code == 400:
                print("Geometry Checking Service results file not found!")
            elif TSDKClient._report_or_raise_on_status_code(res):
                return StringResponse(res.text, res.status_code == 200 and len(res.text) > 0)
            return None

        def delete_model(self, project_id: str, model_id: str, force: bool = False) -> bool:
            res = self._session_delete(
                f"{self._base_url}/{project_id}/models/{model_id}?force={str(force).lower()}"
            )
            return TSDKClient._report_or_raise_on_status_code(res)

        def clone_model(
            self, project_id: str, model_id: str, new_project_id: str, new_name: str = None
        ) -> ModelDto | None:
            res = self._session_post_json(
                f"{self._base_url}/{project_id}/models/{model_id}/clone",
                data=json.dumps(
                    {
                        "newProjectId": new_project_id,
                        "newName": new_name,
                    }
                ),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return ModelDto(**res.json())
            return None

        def get_metadata(self, project_id: str, model_id: str, **kwargs) -> ObjectMetadataDto:
            res = self._session_get(f"{self._base_url}/{project_id}/models/{model_id}/metadata")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ObjectMetadataDto(**res.json())
            return None

        def update_metadata(self, project_id: str, model_id: str, metadata: dict[str, str], **kwargs) -> str:
            res = self._session_put_json(
                f"{self._base_url}/{project_id}/models/{model_id}/metadata", data=json.dumps(metadata)
            )
            TSDKClient._report_or_raise_on_status_code(res)
            return res.text.strip('"')

        def update_model_name(self, project_id: str, model_id: str, model_name: str) -> bool:
            res = self._session_put(f"{self._base_url}/{project_id}/models/{model_id}/name/{model_name}")
            return TSDKClient._report_or_raise_on_status_code(res)

    # Maps to MaterialController in API
    class __MaterialClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/material"

        @utils.ttl_cache(ttl=120)
        def get_material_by_id(self, id: str) -> MaterialDto | None:
            res = self._session_get(f"{self._base_url}/{id}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return MaterialDto(**res.json())
            return None

        @utils.ttl_cache(ttl=10)
        def get_material_by_name(self, name: str) -> MaterialDto | None:
            res = self._session_get(f"{self._base_url}/?name={quote_plus(name)}")
            if TSDKClient._report_or_raise_on_status_code(res):
                res_json = res.json()
                if len(res_json) > 0:
                    return MaterialDto(**res_json[0])
            return None

        def get_by_name(self, name: str) -> MaterialDto | None:
            return self.get_material_by_name(name)

        @utils.ttl_cache(maxsize=1, ttl=60)
        def get_materials(self, category: str = None) -> list[MaterialDto] | None:
            """
            Get materials. Get all materials by default.
            :param category: Optional category to filter by.
            :returns: List of MaterialDto objects.
            """
            url = self._base_url
            if category:
                url = f"{self._base_url}/?category={quote_plus(category)}"
            res = self._session_get(url)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [MaterialDto(**item) for item in res.json()]
            return None

        @utils.ttl_cache(maxsize=1, ttl=60)
        def get_material_categories(self) -> list[dict] | None:
            """
            Get a list of available material categories.
            :returns: List of material category names as strings.
            """
            res = self._session_get(f"{self._base_url}/categories")
            if TSDKClient._report_or_raise_on_status_code(res):
                return res.json()
            return None

        def get_material_categories_with_count(self) -> list[CategoryInfoDto] | None:
            """
            Get all categories and the number of materials in that category.
            :returns: dictionary where the category name is the key and number of materials in that category is the value.
            """
            res = self._session_get(f"{self._base_url}/categories-with-count")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [CategoryInfoDto(category, count) for category, count in res.json().items()]
            return None

        def perform_material_fitting(
            self, material_definition: MaterialDefinitionDto
        ) -> FittedMaterialDto | None:
            """
            Material definition goes through material fitting and outputs a MaterialDto usable by the Treble
            solvers. Nothing is saved in this step, to save the output of the material fitting and create the material
            please use material_client.create(material) with the output of this step.

            :param MaterialDefinitionDto material_definition: Definition of a material to be used for material fitting.
            :returns: FittedMaterialDto material that can be used in material_client.create(material) to save the output of the fitting.
            """
            res = self._session.post(
                f"{self._base_url}/perform-material-fitting",
                data=json.dumps(material_definition, default=vars),
                headers={"Content-type": "application/json"},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return MaterialDto.from_response(**res.json())
            return None

        def perform_material_builder(
            self, material_definition: MaterialBuilderDto
        ) -> FittedMaterialDto | None:
            """
            Material definition goes through material fitting and outputs a MaterialDto usable by the Treble
            solvers. Nothing is saved in this step, to save the output of the material fitting and create the material
            please use material_client.create(material) with the output of this step.

            :param MaterialBuilderDefinitionDto material_definition: Definition of a material to be used for material builder.
            :returns: FittedMaterialDto material that can be used in material_client.create(material) to save the output of the fitting.
            """
            res = self._session.post(
                f"{self._base_url}/perform-material-builder",
                data=json.dumps(material_definition, default=vars),
                headers={"Content-type": "application/json"},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return MaterialDto.from_response(**res.json())
            return None

        def create(self, material: FittedMaterialDto) -> MaterialDto | None:
            """
            Create material using result from material fitting (material_client.perform_material_fitting)

            :param FittedMaterialDto material: Material outputted from the material fitting process.
            """
            res = self._session.post(
                self._base_url,
                data=json.dumps(material, default=vars),
                headers={"Content-type": "application/json"},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return MaterialDto.from_response(**res.json())
            return None

        def delete(self, material: str) -> bool:
            res = self._session.delete(f"{self._base_url}/{material}")
            return TSDKClient._report_or_raise_on_status_code(res)

        def rename(self, material_id: str, new_name: str) -> MaterialDto | None:
            res = self._session_put(
                f"{self._base_url}/{material_id}/rename",
                params={"newName": new_name},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return MaterialDto.from_response(**res.json())
            return None

    class __SourceDirectivityClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/source-directivity"

        # @utils.ttl_cache(maxsize=1, ttl=60)
        def query(
            self,
            name: str = None,
            category: str = None,
            sub_category: str = None,
            manufacturer: str = None,
            filter_by_organization: bool = False,
        ) -> list[SourceDirectivityDto] | None:
            """
            Query source directivity database by various factors

            :param str name: Name of directivity, defaults to None
            :param str category: Type of directivity (Amplified, Natural, Other), defaults to None
            :param str sub_category: Sub category of the directivity, defaults to None
            :param str manufacturer: Speaker manufacturer, defaults to None
            :return list[SourceDirectivityDto] | None: A list of source directivities which
            """
            params = {"filterByOrganization": filter_by_organization}
            if category:
                params["category"] = category.name
            if sub_category:
                params["subCategory"] = sub_category.value
            if manufacturer:
                params["manufacturer"] = manufacturer
            if name:
                params["name"] = name
            res = self._session_get(f"{self._base_url}", params=params)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SourceDirectivityDto(**item) for item in res.json()]
            return None

        @utils.ttl_cache(ttl=60)
        def get_download_url(self, id: str) -> str | None:
            res = self._session_get(f"{self._base_url}/{id}/download-dg-directivity")
            if TSDKClient._report_or_raise_on_status_code(res):
                return res.text
            return None

        @utils.ttl_cache(ttl=60)
        def get_download_ga_directivity_url(self, id: str) -> str | None:
            res = self._session_get(f"{self._base_url}/{id}/download-ga-directivity")
            if TSDKClient._report_or_raise_on_status_code(res):
                return res.text
            return None

        def get_source_directivity(self, source_directivity_id: str) -> SourceDirectivityDto | None:
            """
            Get source directivity by id

            :param str source_directivity_id: Id of the source direcitvity
            :return SourceDirectivityDto | None: The source directivity with the given id
            """
            res = self._session_get(f"{self._base_url}/{source_directivity_id}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return SourceDirectivityDto(**res.json())
            return None

        def create_source_directivity(
            self,
            filepath: str,
            category: str,
            sub_category: str,
            name: str,
            manufacturer: str = None,
            description: str = None,
            correct_ir_by_on_axis_spl_default: bool = True,
            use_spl_for_sti_default: bool = False,
            compress: bool = False,
        ) -> SourceDirectivityDto | None:
            res = None
            post_url = self._base_url
            post_data = {
                "name": name,
                "category": category.name,
                "subCategory": sub_category.value,
                "useSplForStiDefault": use_spl_for_sti_default,
                "correctIrByOnAxisSplDefault": correct_ir_by_on_axis_spl_default,
            }
            if description:
                post_data["description"] = description
            if manufacturer:
                post_data["manufacturer"] = manufacturer
            if compress and Path(filepath).suffix != ".zip":
                with tempfile.TemporaryDirectory() as tmpDir:
                    tmp_file = str(Path(tmpDir, Path(filepath).stem + ".zip"))
                    with ZipFile(tmp_file, "w") as zipObj:
                        zipObj.write(filepath, Path(filepath).name)
                    with open(tmp_file, "rb") as f:
                        res = self._session_post_files(
                            post_url,
                            data=post_data,
                            files={"formFile": f},
                        )
            else:
                with open(filepath, "rb") as f:
                    res = self._session_post_files(
                        post_url,
                        data=post_data,
                        files={"formFile": f},
                    )

            if TSDKClient._report_or_raise_on_status_code(res):
                return SourceDirectivityDto(**res.json())
            return None

        def delete_source_directivity(self, source_directivity_id: str) -> bool:
            res = self._session_delete(f"{self._base_url}/{source_directivity_id}")
            if res.status_code == 400:
                TSDKClient._handle_bad_request(res)
                return False
            return TSDKClient._report_or_raise_on_status_code(res)

        def get_manufacturers(self) -> list[CategoryInfoDto] | None:
            res = self._session_get(f"{self._base_url}/manufacturers")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [CategoryInfoDto(name, count) for name, count in res.json().items()]
            return None

        def create_source_directivity_from_models(
            self,
            ga_directivity_path: str,
            ga_fitted_mono_dipole_path: str,
            dg_mono_dipole_path: str,
            category: str,
            sub_category: str,
            name: str,
            manufacturer: str = None,
            description: str = None,
            correct_ir_by_on_axis_spl_default: bool = True,
            use_spl_for_sti_default: bool = False,
            parent_simulation_id: str = None,
            # compress: bool = False,
        ) -> SourceDirectivityDto | None:
            res = None
            post_url = self._base_url + "/from-models"
            post_data = {
                "name": name,
                "category": category.name,
                "subCategory": sub_category.value,
                "useSplForStiDefault": use_spl_for_sti_default,
                "correctIrByOnAxisSplDefault": correct_ir_by_on_axis_spl_default,
            }
            if description:
                post_data["description"] = description
            if manufacturer:
                post_data["manufacturer"] = manufacturer
            if parent_simulation_id:
                post_data["parentSimulationId"] = parent_simulation_id

            try:
                files = {
                    "gaDirectivityFile": (
                        "ga_directivity.json",
                        open(ga_directivity_path, "rb"),
                        "application/json",
                    ),
                    "gaFittedMonoDipoleFile": (
                        "ga_fitted_mono_dipole.json",
                        open(ga_fitted_mono_dipole_path, "rb"),
                        "application/json",
                    ),
                    "dgMonoDipoleFile": (
                        "dg_mono_dipole.json",
                        open(dg_mono_dipole_path, "rb"),
                        "application/json",
                    ),
                }
                res = self._session_post_files(post_url, data=post_data, files=files)
            finally:
                for file in files.values():
                    if not file[1].closed:
                        file[1].close()

            if TSDKClient._report_or_raise_on_status_code(res):
                return SourceDirectivityDto(**res.json())
            return None

        def rename_source_directivity(
            self, source_directivity_id: str, name: str
        ) -> SourceDirectivityDto | None:
            res = self._session_put(
                f"{self._base_url}/{source_directivity_id}/rename",
                params={"newName": name},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return SourceDirectivityDto(**res.json())
            return None

    # Maps to SimulationController in API
    class __SimulationClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/project"

        def _get_base_url(self, project_id: str, simulation_id: str) -> str:
            return f"{self._base_url}/{quote_plus(project_id)}/simulation/{quote_plus(simulation_id)}"

        def create(self, project_id: str, req: list[SimulationDto]) -> list[SimulationDto] | None:
            """
            Create simulations from dtos.
            :param req: A list of SimulationDto objects to create in SDK.
            :returns: List of SimulationDtos that were created.
            """
            res = self._session_post_json(
                f"{self._base_url}/{quote_plus(project_id)}/simulation",
                data=json.dumps(req, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SimulationDto.from_response(**item) for item in res.json()]
            return None

        def get_simulation(self, project_id: str, simulation_id: str) -> SimulationDto | None:
            res = self._session_get(self._get_base_url(project_id, simulation_id))
            if TSDKClient._report_or_raise_on_status_code(res):
                return SimulationDto.from_response(**res.json())
            return None

        def estimate(self, project_id: str, simulation_id: str) -> SimulationEstimateDto | None:
            res = self._session_get(f"{self._get_base_url(project_id, simulation_id)}/estimate")
            if TSDKClient._report_or_raise_on_status_code(res):
                return SimulationEstimateDto(**res.json())
            return None

        def start(self, project_id: str, simulation_id: str) -> SimulationDto | None:
            res = self._session_post(f"{self._get_base_url(project_id, simulation_id)}/start")
            if TSDKClient._report_or_raise_on_status_code(res):
                return SimulationDto.from_response(**res.json())
            return None

        @utils.ttl_cache(ttl=3)
        def get_progress(self, project_id: str, simulation_id: str) -> SimulationProgressDto | None:
            res = self._session_get(f"{self._get_base_url(project_id, simulation_id)}/progress")
            if TSDKClient._report_or_raise_on_status_code(res):
                return SimulationProgressDto(**res.json())
            return None

        def cancel(self, project_id: str, simulation_id: str) -> CancelSimulationDto | None:
            res = self._session_put(f"{self._get_base_url(project_id, simulation_id)}/cancel")
            if TSDKClient._report_or_raise_on_status_code(res):
                return CancelSimulationDto(**res.json())
            return None

        def add_receivers(
            self, project_id: str, simulation_id: str, req: list[ReceiverDto]
        ) -> list[ReceiverDto] | None:
            res = self._session_put_json(
                f"{self._get_base_url(project_id, simulation_id)}/receivers",
                data=json.dumps(req, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ReceiverDto(**item) for item in res.json()]
            return None

        def delete_receivers(
            self, project_id: str, simulation_id: str, req: list[str]
        ) -> list[ReceiverDto] | None:
            res = self._session_delete_json(
                f"{self._get_base_url(project_id, simulation_id)}/receivers",
                data=json.dumps(req, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ReceiverDto(**item) for item in res.json()]
            return None

        def add_sources(
            self, project_id: str, simulation_id: str, req: list[SourceDto]
        ) -> list[SourceDto] | None:
            res = self._session_put_json(
                f"{self._get_base_url(project_id, simulation_id)}/sources",
                data=json.dumps(req, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SourceDto(**item) for item in res.json()]
            return None

        def delete_sources(
            self, project_id: str, simulation_id: str, req: list[str]
        ) -> list[SourceDto] | None:
            res = self._session_delete_json(
                f"{self._get_base_url(project_id, simulation_id)}/sources",
                data=json.dumps(req, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SourceDto(**item) for item in res.json()]
            return None

        def get_material_assignment(
            self, project_id: str, simulation_id: str
        ) -> list[MaterialAssignmentDto] | None:
            res = self._session_get(f"{self._get_base_url(project_id, simulation_id)}/materials-assignment")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [MaterialAssignmentDto(**item) for item in res.json()]
            return None

        def update_material_assignment(
            self, project_id: str, simulation_id: str, req: list[MaterialAssignmentDto]
        ) -> ResultStatusDto | None:
            res = self._session_put_json(
                f"{self._get_base_url(project_id, simulation_id)}/materials-assignment",
                data=json.dumps(req, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return ResultStatusDto(**res.json())
            return None

        def get_results(
            self,
            project_id: str,
            simulation_id: str,
            result_types: list[str] = None,
            include_subtasks: bool = False,
        ) -> list[SourceResultDto] | None:
            """
            Get results for simulations
            :param project_id: Project id to use.
            :param simulation_id: Id of simulation to get results for.
            :param result_type: Type of results to fetch "dg"|"ga"|"hybrid" if None then all results will be fetched.
            :returns: List of SourceResultDtos
            """
            uri = f"{self._get_base_url(project_id, simulation_id)}/results"
            add_uri = ""
            if result_types:
                add_uri = "?resultTypes=" + "&resultTypes=".join(result_types)
            if include_subtasks is not None:
                if len(add_uri) > 0:
                    add_uri += f"&includeSubtasks={include_subtasks}"
                else:
                    add_uri += f"?includeSubtasks={include_subtasks}"
            uri += add_uri
            res = self._session_get(uri)
            if res.status_code == 404:
                return []
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SourceResultDto(**item) for item in res.json()]
            return None

        def get_source_results(
            self, project_id: str, simulation_id: str, source_id: str, result_type: str = None
        ) -> SourceResultDto | None:
            uri = f"{self._get_base_url(project_id, simulation_id)}/source/{source_id}/results"
            if result_type:
                uri += f"?resultType={result_type}"
            res = self._session_get(uri)
            if TSDKClient._report_or_raise_on_status_code(res):
                return SourceResultDto(**res.json())
            return None

        def get_simulation_tasks(self, project_id: str, simulation_id: str) -> list[SourceDto] | None:
            """
            :returns list[SourceDto]: Returns a list of SourceDto objects containing task list for source.
            """
            res = self._session_get(f"{self._get_base_url(project_id, simulation_id)}/tasks")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [SourceDto(**item) for item in res.json()]
            return None

        def delete_simulation(self, project_id: str, simulation_id: str, force: bool = False) -> bool:
            res = self._session_delete(
                f"{self._get_base_url(project_id, simulation_id)}?force={str(force).lower()}"
            )
            if not TSDKClient._report_or_raise_on_status_code(res):
                if res.status_code:
                    logger.warning("Simulation not found!")
                else:
                    logger.warning("Unable to delete simulation")
                return False
            return True

        def get_mesh_info(self, project_id: str, simulation_id: str) -> SimulationMeshInfoDto | None:
            res = self._session_get(f"{self._get_base_url(project_id, simulation_id)}/mesh-info")
            if res.status_code != 404 and TSDKClient._report_or_raise_on_status_code(res):
                data = res.json()
                if data:
                    return SimulationMeshInfoDto(**data)
            return None

        def update_gpu_count(self, project_id: str, simulation_id: str, gpu_count: int) -> bool:
            res = self._session_put(f"{self._get_base_url(project_id, simulation_id)}/gpuCount/{gpu_count}")
            return TSDKClient._report_or_raise_on_status_code(res)

        def update_simulation_name(self, project_id: str, simulation_id: str, simulation_name: str) -> bool:
            res = self._session_put(f"{self._get_base_url(project_id, simulation_id)}/name/{simulation_name}")
            return TSDKClient._report_or_raise_on_status_code(res)

        def get_metadata(self, project_id: str, simulation_id: str, **kwargs) -> ObjectMetadataDto:
            res = self._session_get(f"{self._get_base_url(project_id, simulation_id)}/metadata")
            if TSDKClient._report_or_raise_on_status_code(res):
                return ObjectMetadataDto(**res.json())
            return None

        def update_metadata(
            self, project_id: str, simulation_id: str, metadata: dict[str, str], **kwargs
        ) -> str:
            res = self._session_put_json(
                f"{self._get_base_url(project_id, simulation_id)}/metadata", data=json.dumps(metadata)
            )
            TSDKClient._report_or_raise_on_status_code(res)
            return res.text.strip('"')

    # Maps to GeometryLibraryController in API
    class __GeometryLibraryClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._admin_base_url = f"{baseUrl}/admin"
            self._base_url = f"{baseUrl}/geometrylibrary"

        @utils.ttl_cache(ttl=60)
        def query(
            self, name: str = None, tag: str = None, dataset: str = None, light: bool = True
        ) -> list[GeometryLibraryDto] | None:
            """
            Query the Geometry library by name, tag or fetch all available geometries.
            :param name: If provided the library will filter by geometry name.
            :param tag: If provided the library will filter by geometry tag.
            :param dataset: If provided the library will filter by geometry dataset.
            :param light: If set to False, will load all metadata for every object
            :returns: List of GeometryLibraryDtos.
            """
            params = {}
            if name:
                params["name"] = name
            if tag:
                params["tag"] = tag
            if dataset:
                params["dataset"] = dataset
            url = self._base_url
            if light:
                url += "/light"
            res = self._session_get(f"{url}", params=params)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [GeometryLibraryDto(**item) for item in res.json()]
            return None

        @utils.ttl_cache(maxsize=1, ttl=60)
        def get_geometry_library_datasets(self) -> list:
            """
            Get a list of available datasets in the geometry library.
            :returns: List of geometry library dataset names.
            """
            res = self._session_get(f"{self._base_url}/datasets")
            TSDKClient._report_or_raise_on_status_code(res)
            return res.json()

        def get_geometry_library_datasets_with_count(self) -> list[CategoryInfoDto] | None:
            """
            Get all datasets and the number of geometries in that category.
            :returns: dictionary where the dataset name is the key and number of geometries in that category is the value.
            """
            res = self._session_get(f"{self._base_url}/datasets-with-count")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [CategoryInfoDto(name, count) for name, count in res.json().items()]
            return None

        def get_single(self, id: str) -> GeometryLibraryDto:
            res = self._session_get(f"{self._base_url}/single/?id={id}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return GeometryLibraryDto(**res.json())
            return None

        @utils.ttl_cache(ttl=60)
        def get_download_url(self, id: str) -> FileDownloadInfoDto | None:
            res = self._session_get(f"{self._base_url}/{id}/download")
            if TSDKClient._report_or_raise_on_status_code(res):
                return FileDownloadInfoDto(**res.json())
            return None

        def geometry_to_model_definition(self, ids: list[str], project_id: str) -> list[ModelDto] | None:
            res = self._session_post_json(
                f"{self._base_url}/to-model?projectId={project_id}",
                data=json.dumps(ids),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return [ModelDto(**item) for item in res.json()]
            return None

        def model_definition_to_geometry(
            self, model_to_geo_dto: ModelToGeometryLibraryDto
        ) -> GeometryLibraryDto | None:
            res = self._session_post_json(
                f"{self._admin_base_url}/model-to-geometry-library",
                data=json.dumps(model_to_geo_dto, default=vars),
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return GeometryLibraryDto(**res.json())
            return None

        def delete_geometry(self, geometry_id):
            res = self._session_delete(
                f"{self._admin_base_url}/delete-from-geometry-library?geometryId={geometry_id}"
            )
            TSDKClient._report_or_raise_on_status_code(res)

    class __GeometryComponentLibraryClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/geometrycomponentlibrary"
            self._admin_base_url = f"{baseUrl}/admin"

        def _delete_geometry(self, id):
            res = self._session_delete(f"{self._admin_base_url}/delete-geometry-object?id={id}")
            TSDKClient._report_or_raise_on_status_code(res)

        def _create_geometry(self, dto: GeometryComponentDto, file_path: str) -> GeometryComponentDto:
            post_data = {
                "name": dto.name,
                "description": dto.description,
                "groupName": dto.group_name,
                "boundingBoxJson": dto.bounding_box_json,
                "suggestedMaterialsJson": dto.suggested_materials_json,
            }
            for i, layer in enumerate(dto.layer_names):
                post_data[f"layerNames[{i}]"] = layer

            with open(file_path, "rb") as f:
                res = self._session_post_files(
                    f"{self._admin_base_url}/new-geometry-object", data=post_data, files={"formFile": f}
                )

            if TSDKClient._report_or_raise_on_status_code(res):
                return GeometryComponentDto.model_validate_json(res.text)
            return None

        # @utils.ttl_cache(ttl=60)
        def query(self, name: str = None, group: str = None) -> list[GeometryComponentDto] | None:
            """
            Query the Geometry object library by name and/or group.
            :param name: If provided the library will filter by geometry object name.
            :param group: If provided the library will filter by geometry object group.
            :returns: List of GeometryObjectDtos.
            """
            if not name and not group:
                logger.warning("Name or group must be provided to query geometry object library.")
                return None
            params = {}
            if name:
                params["name"] = name
            if group:
                params["group"] = group
            res = self._session_get(f"{self._base_url}/query", params=params)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [GeometryComponentDto(**item) for item in res.json()]
            return None

        def get_groups_with_count(self) -> list[CategoryInfoDto]:
            res = self._session_get(f"{self._base_url}/groups")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [CategoryInfoDto(name, count) for name, count in res.json().items()]
            return []

        def _get_url(self, id: str) -> str | None:
            res = self._session_get(f"{self._base_url}/object/{id}/url")
            if TSDKClient._report_or_raise_on_status_code(res):
                return res.text
            return None

        def get_by_id(self, id: str) -> GeometryComponentDto | None:
            res = self._session_get(f"{self._base_url}/object/{id}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return GeometryComponentDto(**res.json())
            return None

    class __ReportClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/report"

        @utils.ttl_cache(ttl=10)
        def overview(self, filterUser: bool) -> OverviewDto:
            res = self._session_get(f"{self._base_url}/overview?filterUser={filterUser}")
            TSDKClient._report_or_raise_on_status_code(res)
            res_json = res.json()
            return OverviewDto(**res_json)

    # Maps to DeviceController in API
    class __DeviceClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/device"

        def create_device(
            self,
            name: str,
            filepath: str,
            description: str = None,
        ) -> DeviceDto | None:
            res = None
            post_url = self._base_url
            with open(filepath, "rb") as f:
                res = self._session_post_files(
                    post_url, data={"name": name, "description": description}, files={"formFile": f}
                )

            if TSDKClient._report_or_raise_on_status_code(res):
                return DeviceDto(**res.json())
            return None

        def get_device(self, device_id: str) -> DeviceDto | None:
            res = self._session_get(f"{self._base_url}/{device_id}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return DeviceDto(**res.json())
            return None

        def get_device_by_name(self, name: str) -> DeviceDto | None:
            res = self._session_get(f"{self._base_url}/by-name?name={quote_plus(name)}")
            if TSDKClient._report_or_raise_on_status_code(res):
                return DeviceDto(**res.json())
            return None

        def get_by_name(self, name: str) -> DeviceDto | None:
            return self.get_device_by_name(name)

        def get_devices(self) -> list[DeviceDto] | None:
            """
            Get all devices in organization

            :returns: List of DeviceDto objects.
            """
            res = self._session_get(self._base_url)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [DeviceDto(**item) for item in res.json()]
            return None

        def get_device_file_url(self, device_id: str) -> str:
            res = self._session_get(f"{self._base_url}/{device_id}/get-url")
            return res.text

        def delete_device(self, device_id: str):
            res = self._session_delete(f"{self._base_url}/{device_id}")
            if res.status_code == 400:
                TSDKClient._handle_bad_request(res)
                return False
            return TSDKClient._report_or_raise_on_status_code(res)

        def rename_device(self, device_id: str, name: str) -> DeviceDto | None:
            res = self._session_put(
                f"{self._base_url}/{device_id}/rename",
                params={"newName": name},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return DeviceDto(**res.json())
            return None

    class __AdminClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/admin"

        def get_token_status(self) -> TokenStatusDto:
            res = self._session.get(f"{self._base_url}/GetTokenStatus")
            if res.status_code == 400:
                TSDKClient._handle_bad_request(res)
                return False
            if TSDKClient._report_or_raise_on_status_code(res):
                return TokenStatusDto(**res.json())
            return None

        def get_metadata_updated_at(self, metadata_id: str) -> str:
            res = self._session_get(f"{self._base_url}/MetadataUpdatedAt?metadataId={metadata_id}")
            TSDKClient._report_or_raise_on_status_code(res)
            return res.text.strip('"')

    class __BoundaryVelocitySubmodelClient(ClientBase):
        def __init__(self, baseUrl: str, session: httpx.Client):
            super().__init__(baseUrl, session)
            self._base_url = f"{baseUrl}/boundary-velocity-submodel"

        def create(
            self,
            source_filter_path: str,
            ga_directivity_json_path: str,
            req: CreateBoundaryVelocitySubmodelDto,
        ) -> BoundaryVelocitySubmodelDto | None:
            res = None
            post_data = {
                "name": req.name,
                "description": req.description,
                "parentSimulationId": req.parentSimulationId,
            }
            try:
                files = {
                    "sourceCorrectionFilterFile": (
                        "source_correction_filter.h5",
                        open(source_filter_path, "rb"),
                        "application/octet-stream",
                    ),
                    "gaDirectivityFile": (
                        "ga_directivity.json",
                        open(ga_directivity_json_path, "rb"),
                        "application/json",
                    ),
                }

                res = self._session_post_files(
                    self._base_url,
                    data=post_data,
                    files=files,
                )

            except Exception as e:
                logger.error(f"Error creating boundary velocity submodel: {e}")
                return None
            finally:
                for file in files.values():
                    if not file[1].closed:
                        file[1].close()

            if res and TSDKClient._report_or_raise_on_status_code(res):
                data = res.json()
                return BoundaryVelocitySubmodelDto(**data)
            return None

        def get_by_id(self, id: str) -> BoundaryVelocitySubmodelDto | None:
            res = self._session_get(f"{self._base_url}/{id}")
            if res.status_code == 404:
                logger.error("Boundary velocity submodel not found.")
                return None
            if TSDKClient._report_or_raise_on_status_code(res):
                data = res.json()
                return BoundaryVelocitySubmodelDto(**data)
            return None

        def query(self, name: str = None) -> list[BoundaryVelocitySubmodelDto]:
            params = {}
            if name:
                params["name"] = name
            res = self._session_get(f"{self._base_url}/query", params=params)
            if TSDKClient._report_or_raise_on_status_code(res):
                return [BoundaryVelocitySubmodelDto(**item) for item in res.json()]
            return []

        def get_model_url(self, id: str) -> FileDownloadInfoDto | None:
            res = self._session_get(f"{self._base_url}/{id}/model-url")
            if TSDKClient._report_or_raise_on_status_code(res):
                return FileDownloadInfoDto(**res.json())
            return None

        def get_material_assignments(self, id: str) -> list[MaterialAssignmentDto] | None:
            res = self._session_get(f"{self._base_url}/{id}/material-assignments")
            if TSDKClient._report_or_raise_on_status_code(res):
                return [MaterialAssignmentDto(**item) for item in res.json()]
            return None

        def get_ga_directivity_url(self, id: str) -> FileDownloadInfoDto | None:
            res = self._session_get(f"{self._base_url}/{id}/ga-directivity-url")
            if TSDKClient._report_or_raise_on_status_code(res):
                return FileDownloadInfoDto(**res.json())
            return None

        def delete(self, id: str) -> bool:
            res = self._session_delete(f"{self._base_url}/{id}")
            if res.status_code == 400:
                TSDKClient._handle_bad_request(res)
                return False
            return TSDKClient._report_or_raise_on_status_code(res)

        def rename(self, id: str, new_name: str) -> BoundaryVelocitySubmodelDto | None:
            res = self._session.put(
                f"{self._base_url}/{id}/rename",
                params={"newName": new_name},
            )
            if TSDKClient._report_or_raise_on_status_code(res):
                return BoundaryVelocitySubmodelDto(**res.json())
            return None

    ######
    # TSDKClient
    ######
    def check_for_updates(self, silent: bool = False) -> SdkVersionDto | None:
        try:
            version_str = version("treble_tsdk")
            version_split = version_str.split(".")
            major = version_split[0]
            minor = version_split[1]
            patch = version_split[2]
            res = self._session_get(
                f"{self._base_url}/login/CheckForUpdates?majorVersion={major}&minorVersion={minor}&patchLevel={patch}"
            )
            if res.status_code == 200:
                res_json = res.json()
                dto = SdkVersionDto(**res_json)
                if not silent:
                    print(dto.to_update_announcement())
                return dto
            else:
                TSDKClient._report_or_raise_on_status_code(res)
                print("Unable to get SDK update information, please contact Treble if problem persists.")
        except PackageNotFoundError:
            print("Unable to detect SDK version, please contact Treble for support!")
        return None

    def check_rate_limit(self):
        try:
            res = self._session_get(f"{self._base_url}/login/CheckRateLimit")
            if res.status_code == 200:
                rate_limit_data = res.json()
                if isinstance(rate_limit_data, int) and rate_limit_data >= 0:
                    self._session.auth.rateLimit = rate_limit_data

        except Exception:
            pass

        return self._session.auth.rateLimit

    def download_update(self, download_directory: str):
        dto = self.check_for_updates(True)
        if dto.update_available:
            out_path = f"{download_directory}/treble_tsdk-{dto.major_version}.{dto.minor_version}.{dto.patch_level}-py3-none-any.whl"
            utils.download_file(
                self.get_update_url(),
                out_path,
            )
            return out_path
        else:
            logger.info("No update available")
            return None

    def get_update_url(self) -> str:
        res = self._session_get(f"{self._base_url}/login/GetLatestWheelUrl")
        if res.status_code == 200:
            return res.text

    def _build_auth(self, credentials: AuthenticationMiddleware | SSOAuthenticationMiddleware):
        self._session.auth = credentials
        if isinstance(credentials, SSOAuthenticationMiddleware):
            self._is_sso = True
        else:
            self._is_sso = False

    def _build_session(self, base_url: str, auth: AuthenticationMiddleware | SSOAuthenticationMiddleware):
        """
        Prepares a httpx.Client session object.
        """
        session_verify = True
        if utils.get_env_var_as_string("STAPI_DISABLE_SSL_VERIFY") == "1":
            print("WARNING: SSL VERIFICATION DISABLED!")
            session_verify = False
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

        self._is_sso = isinstance(auth, SSOAuthenticationMiddleware)
        timeouts = httpx.Timeout(connect=300, read=600, write=600, pool=600)

        if self._is_sso:
            transport = SSOTokenRefreshTransport(auth)
            return httpx.Client(
                base_url=base_url,
                transport=transport,
                verify=session_verify,
                timeout=timeouts,
                auth=auth,
                headers={"X-STAPIClient-version": stapi_version},
            )
        else:
            return httpx.Client(
                base_url=base_url,
                verify=session_verify,
                timeout=timeouts,
                auth=auth,
                headers={"X-STAPIClient-version": stapi_version},
            )

    def __init__(self, base_url: str, credentials: AuthenticationMiddleware | SSOAuthenticationMiddleware):
        # Prepare session object.
        self._base_url = base_url
        self._session = self._build_session(base_url, credentials)

        super().__init__(base_url, None)
        self.project = TSDKClient.__ProjectClient(base_url, self._session)
        self.model = TSDKClient.__ModelClient(base_url, self._session)
        self.material = TSDKClient.__MaterialClient(base_url, self._session)
        self.source_directivity = TSDKClient.__SourceDirectivityClient(base_url, self._session)
        self.simulation = TSDKClient.__SimulationClient(base_url, self._session)
        self.device = TSDKClient.__DeviceClient(base_url, self._session)
        self.geometry_library = TSDKClient.__GeometryLibraryClient(base_url, self._session)
        self.report = TSDKClient.__ReportClient(base_url, self._session)
        self.admin = TSDKClient.__AdminClient(base_url, self._session)
        self.boundary_velocity_submodel = TSDKClient.__BoundaryVelocitySubmodelClient(base_url, self._session)
        self.geometry_component_library = TSDKClient.__GeometryComponentLibraryClient(base_url, self._session)

    def enable_request_logging(self, to_stdout: bool = True, to_file: str = None):
        def logRoundtrip(response, *args, **kwargs):
            extra = {"req": response.request, "res": response}
            http_logger.debug("HTTP roundtrip", extra=extra)

        formatter = HttpFormatter("{asctime} {levelname} {name} {message}", style="{")
        http_logger = logging.getLogger("treble_http_debug_logger")
        if to_stdout:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(formatter)
            http_logger.addHandler(handler)
        if to_file:
            file_handler = logging.FileHandler(to_file)
            file_handler.setFormatter(formatter)
            http_logger.addHandler(file_handler)
        http_logger.setLevel(logging.DEBUG)
        http_logger.propagate = False
        if logRoundtrip not in self._session.event_hooks["response"]:
            self._session.event_hooks["response"].append(logRoundtrip)

    @staticmethod
    def _report_or_raise_on_status_code(res: httpx.Response) -> bool:
        """
        If request was successful it returns True, if request had error http status code (401,400,500)
        it will try to handle it gracefully and return False. If it's unable to handle and error gracefully
        it will raise an exception based on the http status code with more info.


        Args:
            res (_type_): httpx.Response

        Raises:
            UnauthorizedException: Failed to authenticate against API
            BadRequestException: Invalid request / BadRequest
            InternalServerErrorException: API returned internal server error.

        Returns:
            bool: Returns True if status code was OK (200) or Created (201),
            Returns False if it was able to handle an error http status code (400, 401, 500) gracefully.
            Otherwise it will raise an exception based on the http status code with more info.
        """
        if res.status_code == 401:
            raise UnauthorizedException(
                f"You do not have access to this resource or your access credentials are invalid or expired. If using access tokens please log in again to get a new access token, if using a credentials file please refer to the credentials guide. If problem persists contact Treble for support. Reason give: {res.text}"
            )
        elif res.status_code == 404:
            return False
        elif res.status_code == 400:
            if TSDKClient._handle_bad_request(res):
                return False
            # Failed to gracefully report bad request.
            raise BadRequestException(res.text)
        elif res.status_code == 500:
            raise InternalServerErrorException(res.text)
        elif res.status_code == 405:
            raise MethodNotAllowedException(res.text)
        elif res.status_code == 403:
            raise ForbiddenException(res.text)
        elif res.status_code == 429:
            raise RateLimitException(res.text)
        return True

    @staticmethod
    def _handle_bad_request(res: httpx.Response) -> bool:
        try:
            data = res.json()
            if "title" in data.keys() and "errors" in data.keys():
                logger.error(data["title"])
                for field, errors in data["errors"].items():
                    logger.error(f'Field: "{field}" - {errors}')
                return True
        except Exception as _:
            return False
        return False
