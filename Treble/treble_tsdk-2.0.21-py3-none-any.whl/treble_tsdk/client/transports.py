import httpx
from .auth import SSOAuthenticationMiddleware


class SSOTokenRefreshTransport(httpx.BaseTransport):
    # Hook for requests made by SSO user that is called for each http response received.
    # Will try and use refresh token to reauthenticate if status code is unauthorized.
    def __init__(self, auth_middleware: SSOAuthenticationMiddleware, **kwargs):
        self._wrapper = httpx.HTTPTransport(**kwargs)
        self._auth = auth_middleware

    def handle_request(self, request: httpx.Request) -> httpx.Response:
        response = self._wrapper.handle_request(request)
        if response.status_code == 401 and self._auth._refresh_token and not self._auth._refresh_token_retry:
            # Unauthorized
            if request.headers.get("TSDK_REATTEMPT"):
                # We already tried using the refresh token, just return the response.
                return response
            # Use refresh token and send the request again with REATTEMPT header to prevent infinite refresh token attempts.
            self._auth._refresh_auth_sync(force=True)
            request.headers["TSDK_REATTEMPT"] = "1"
            self._auth._set_request_auth_header(request)
            res = self._session.send(request)
            return res
        return response

    def close(self):
        self._wrapper.close()
