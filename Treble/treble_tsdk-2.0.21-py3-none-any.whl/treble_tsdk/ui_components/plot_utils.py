import os
import socket
import random

from dash import dash, Dash, html
from ..treble_logging import logger
import logging

BackgroundColor = "#1f1f1f"
assigned_dash_port = None


def _is_notebook() -> bool:
    try:
        shell = get_ipython().__class__.__name__
        if shell == "ZMQInteractiveShell":
            return True  # Jupyter notebook or qtconsole
        elif shell == "TerminalInteractiveShell":
            return False  # Terminal running IPython
        elif get_ipython().__class__.__module__ == "google.colab._shell":
            return True
        else:
            return False  # Other type (?)
    except NameError:
        return False  # Probably standard Python interpreter


def _is_local_port_available(port):
    """
    Check port availability on localhost for Dash plot server.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            # Check ports that are only accessible from the local machine.
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def try_run_app(app: Dash, height: int = 650):
    """
    Parameters:
        app (Dash): Dash app
        height (int): Define the height of the app when displayed using jupyter_mode="inline"
    """
    global assigned_dash_port
    allowed_dash_port = list(range(55660, 55760))
    if "TSDK_DASH_PORT" in os.environ and os.environ["TSDK_DASH_PORT"].isnumeric():
        assigned_dash_port = int(os.environ["TSDK_DASH_PORT"])

    if _is_notebook():
        jupyter_mode = "inline"
    else:
        # If notebook is not detected, run app as external (which print out the address of the Dash app to console.)
        jupyter_mode = "external"

    if assigned_dash_port is None:
        # We have not assigned a port to Dash in this session.
        for port in allowed_dash_port:
            if _is_local_port_available(port):
                assigned_dash_port = port
                break

    if assigned_dash_port is None:
        assigned_dash_port = random.choice(allowed_dash_port)
        logger.error(
            f"Unable to find a free port for results plotting backend. Choosing a port at random ({assigned_dash_port}). You can choose what port is used by settings the TSDK_DASH_PORT environment variable."
        )

    logging.getLogger("werkzeug").setLevel(logging.CRITICAL)
    # Use port number in AssignedDashPort.
    app.run(jupyter_mode=jupyter_mode, port=assigned_dash_port, debug=False, jupyter_height=height)


def initialize_widget(children: list, assets_path: str):
    app = Dash(__name__, assets_folder=assets_path)
    dash._dash_renderer._set_react_version("18.2.0")
    app.layout = html.Div(style={"backgroundColor": BackgroundColor}, children=children)
    return app
