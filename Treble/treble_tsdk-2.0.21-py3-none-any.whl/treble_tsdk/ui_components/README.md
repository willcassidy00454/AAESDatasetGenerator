# README

## Overview

The `plot` files located in the `ui_components` directory are responsible for rendering React-based UI components using the `tsdk_ui_components` package and the `assets` folder.

Use environment variable `%env TSDK_PYVISTA_PLOTTING=1` to enable pyvista plotting instead.

## About

1. **React Component Integration**
   - The `tsdk_ui_components` package is a Python wrapper for React components.
   - The React components reside in the `tsdk_ui_components` folder at the root level. These components are converted from React to Python to enable them to be displayed in the SDK.
   - Seee `tsdk_ui_components/README.md` for more info.

2. **Assets Folder**
   - The `assets` folder allows Dash to automatically serve all included files.
   - This functionality enables rendering of the React components.
   - This folder needs to either be located at the same level as the function that initializes the Dash app or the path of it needs to be passed to the `assets_folder` property when initializing Dash.

3. **Reference Documentation**
   - For additional details on using external resources in Dash/Plotly, consult the official documentation:  
     [Dash/Plotly Documentation on External Resources](https://dash.plotly.com/external-resources)
