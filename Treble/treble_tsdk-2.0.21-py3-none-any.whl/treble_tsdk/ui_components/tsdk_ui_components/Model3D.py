# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class Model3D(Component):
    """A Model3D component.
3D Model

Keyword arguments:

- id (string; optional):
    Unique ID to identify this component in Dash callbacks.

- height (number; default 650):
    Height of viewport.

- layerNames (list of dicts with strings as keys and values of type string; required):
    list of each layers id and full name.

- modelData (string; required):
    base64 encoded file data.

- suggestedSources (list of dicts; optional):
    a list of suggested source placements.

    `suggestedSources` is a list of dicts with keys:

    - x (number; required)

    - y (number; required)

    - z (number; required)

    - label (string; required)

- viewDirection (a value equal to: 'xz', 'yz', 'xy'; optional)

- volume (number; required):
    volume of the model."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'tsdk_ui_components'
    _type = 'Model3D'
    @_explicitize_args
    def __init__(self, modelData=Component.REQUIRED, layerNames=Component.REQUIRED, volume=Component.REQUIRED, suggestedSources=Component.UNDEFINED, id=Component.UNDEFINED, height=Component.UNDEFINED, viewDirection=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'height', 'layerNames', 'modelData', 'suggestedSources', 'viewDirection', 'volume']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'height', 'layerNames', 'modelData', 'suggestedSources', 'viewDirection', 'volume']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['layerNames', 'modelData', 'volume']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(Model3D, self).__init__(**args)
