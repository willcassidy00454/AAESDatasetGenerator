# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class GeometryFeedback3D(Component):
    """A GeometryFeedback3D component.
3D Geometry feedback

Keyword arguments:

- id (string; optional):
    Unique ID to identify this component in Dash callbacks.

- geometryInfo (dict; required):
    geometry feedback data.

    `geometryInfo` is a dict with keys:

    - objectCount (number; required)

    - layerCount (number; required)

    - watertight (boolean; required)

    - errors (list of strings; required)

    - warnings (list of strings; required)

    - isolated_edges (list of list of list of numbersss; required)

    - naked_edges (list of list of list of numbersss; required)

    - invalid_faces (list of list of list of numbersss; required)

    - small_edges (list of list of list of numbersss; required)

    - excluded_faces (list of list of list of numbersss; required)

    - problem_areas (list of dicts; required)

        `problem_areas` is a list of dicts with keys:

        - center (list of numbers; required)

        - radius (number; required)

    - boundaryMismatch (boolean; required)

    - modelVolume (number; required)

    - cappedElementLists (dict; required)

        `cappedElementLists` is a dict with keys:

        - small_edges (number; optional)

        - problem_areas (number; optional)

        - isolated_edges (number; optional)

        - naked_edges (number; optional)

        - excluded_faces (number; optional)

        - invalid_faces (number; optional)

- height (number; default 650):
    Height of viewport.

- layerNames (list of dicts with strings as keys and values of type string; required):
    list of each layers id and full name.

- modelData (string; required):
    base64 encoded file data.

- viewDirection (a value equal to: 'xz', 'yz', 'xy'; optional)

- volume (number; required):
    volume of the model."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'tsdk_ui_components'
    _type = 'GeometryFeedback3D'
    @_explicitize_args
    def __init__(self, modelData=Component.REQUIRED, layerNames=Component.REQUIRED, volume=Component.REQUIRED, geometryInfo=Component.REQUIRED, id=Component.UNDEFINED, height=Component.UNDEFINED, viewDirection=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'geometryInfo', 'height', 'layerNames', 'modelData', 'viewDirection', 'volume']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'geometryInfo', 'height', 'layerNames', 'modelData', 'viewDirection', 'volume']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['geometryInfo', 'layerNames', 'modelData', 'volume']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(GeometryFeedback3D, self).__init__(**args)
