from dataclasses import dataclass, asdict
import os

from treble_tsdk.core.receiver import Receiver, ReceiverProperties, ReceiverType
from treble_tsdk.core.source import Source, SourceProperties, SourceType
from treble_tsdk.geometry._geometry_feedback import GeometryFeedback

from ..treble_logging import logger
from .plot_utils import try_run_app, initialize_widget
from .tsdk_ui_components import Model3D, Simulation3D, GeometryFeedback3D, Mesh3D
from ..core.model_obj import MaterialAssignment
from ..client.api_models import SourceDto, ReceiverDto, ReceiverPropertiesDto, SourcePropertiesDto

from typing import Any, Literal

DEFAULT_VIEW_HEIGHT = 700


@dataclass
class Directivity:
    azimuth: float = 0
    elevation: float = 0
    rotation: float = 0


@dataclass
class SuggestedPoint:
    label: str
    x: float
    y: float
    z: float
    id: str = None
    directivity: Directivity = None


@dataclass
class SuggestedPoint:
    label: str
    x: float
    y: float
    z: float
    id: str = None
    directivity: Directivity = None


class Validation:
    type: str = "error"
    message: str = None
    diameter: float = 0.15

    def __init__(self, message, radius=None):
        self.message = message
        self.diameter = 0.15 if radius is None else radius

    def to_dict(self):
        return {
            "type": self.type,
            "message": self.message.capitalize(),
            "diameter": self.diameter,
        }


class PlotSource:
    label: str
    x: float
    y: float
    z: float
    sourceType: str
    id: str = None
    directivity: Directivity = None
    validation: Validation = None

    def __init__(self, source: Source, errorMessage: str = ""):
        self.id = getattr(source, "id", None) or source.label
        self.label = source.label
        self.x = source.x
        self.y = source.y
        self.z = source.z
        self.sourceType = source.source_type.value
        self.validation = Validation(errorMessage) if errorMessage != "" else None
        properties: SourceProperties = source.source_properties

        if (
            self.sourceType in [SourceType.directive, SourceType.boundary_velocity]
            and properties != None
            and (hasattr(properties, "azimuth_angle") or hasattr(properties, "elevation_angle"))
            and not getattr(properties, "source_boundary_layer_name")
        ):
            self.directivity = Directivity(properties.azimuth_angle or 0, properties.elevation_angle or 0)

    def to_dict(self):
        result = {
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "label": self.label,
            "sourceType": self.sourceType,
        }
        if self.directivity != None:
            result["directivity"] = asdict(self.directivity)
        if self.validation != None:
            result["validation"] = self.validation.to_dict()
        return result


class PlotReceiver:
    label: str
    x: float
    y: float
    z: float
    id: str = None
    receiverType: str
    directivity: Directivity = None
    validation: Validation = None
    spatialReceiverRadius: float = None

    def __init__(self, receiver: Receiver, errorMessage: str = ""):
        self.id = getattr(receiver, "id", None) or receiver.label
        self.label = receiver.label
        self.x = receiver.x
        self.y = receiver.y
        self.z = receiver.z
        self.receiverType = receiver.receiver_type.value

        properties: ReceiverProperties = getattr(receiver, "receiverProperties", None)
        self.spatialReceiverRadius = getattr(properties, "spatial_radius", 0)
        if receiver.receiver_type.value == "Spatial" and self.spatialReceiverRadius == 0:
            self.spatialReceiverRadius = 0.1
        radius = self.spatialReceiverRadius if self.spatialReceiverRadius > 0 else None
        self.validation = Validation(errorMessage, radius) if errorMessage != "" else None

    def to_dict(self):
        result = {
            "id": self.id,
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "label": self.label,
            "receiverType": self.receiverType,
            "spatialReceiverRadius": self.spatialReceiverRadius,
        }
        if self.directivity != None:
            result["directivity"] = asdict(self.directivity)
        if self.validation != None:
            result["validation"] = self.validation.to_dict()
        return result


@dataclass
class PlotMaterialAssignment:
    layerName: str
    materialName: str
    materialId: str
    materialCategory: str


def _get_assets_path():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "assets"))


# These plot functions use UI components from tsdk_ui_components, see tsdk_ui_components/READNE.md for more info


def plot_mesh(vertices, faces, model_data, layer_names):
    """
    Displays a 3D visualization of the mesh using Dash and Three.js
    """
    height = DEFAULT_VIEW_HEIGHT
    try:
        app_content = Mesh3D(
            id="mesh-viewer",
            height=height,
            layerNames=layer_names,
            vertices=vertices,
            faces=faces,
            modelData=model_data,
            volume=0,
        )
        app = initialize_widget(children=app_content, assets_path=_get_assets_path())
        try_run_app(app, height)
    except ImportError:
        logger.warning("Unable to find required ui_components module, has it been installed?")


def plot_model(
    model_data: str,
    layers: list[dict[str, str]],
    model_volume: float | Literal[0],
    view2d: str = None,
):
    """
    Displays a 3D visualization of the geometry using Dash and Three.js
    """
    height = DEFAULT_VIEW_HEIGHT
    try:
        app_content = Model3D(
            id="model-viewer",
            height=height,
            layerNames=layers,
            modelData=model_data,
            volume=model_volume,
            viewDirection=view2d,
        )
        app = initialize_widget(children=app_content, assets_path=_get_assets_path())
        try_run_app(app, height)
    except ImportError:
        logger.warning("Unable to find required ui_components module, has it been installed?")


def model_component(
    model_data: str,
    layers: list[dict[str, str]],
    model_volume: float | Literal[0],
    height: int = None,
    view2d: str = None,
):
    """
    Return a model component
    """
    height = height or DEFAULT_VIEW_HEIGHT
    try:
        return Model3D(
            id="model-viewer",
            height=height,
            layerNames=layers,
            modelData=model_data,
            volume=model_volume,
            viewDirection=view2d,
        )
    except ImportError:
        logger.warning("Unable to find required ui_components module, has it been installed?")


def plot_geometry(
    model_data: str,
    layers: list[dict[str, str]],
    suggested_points: list[ReceiverDto],
    model_volume: float,
    view2d: str = None,
):
    """
    Displays a 3D visualization of the geometry using Dash and Three.js
    """
    height = DEFAULT_VIEW_HEIGHT
    try:
        points = []
        for pos in suggested_points:
            directivity = None
            properties = getattr(pos, "receiverProperties", None)
            if properties != None:
                azimuth = getattr(properties, "azimuthAngle", None)
                elevation = getattr(properties, "elevationAngle", None)
                if azimuth != None or elevation != None:
                    directivity = Directivity(azimuth=azimuth or 0, elevation=elevation or 0)
            points.append(
                asdict(
                    SuggestedPoint(
                        x=pos.x,
                        y=pos.y,
                        z=pos.z,
                        label=pos.label,
                        directivity=directivity,
                    )
                )
            )

        app_content = Model3D(
            id="geometry-viewer",
            height=height,
            modelData=model_data,
            layerNames=layers,
            volume=model_volume,
            suggestedSources=points,
            viewDirection=view2d,
        )
        app = initialize_widget(children=app_content, assets_path=_get_assets_path())
        try_run_app(app, height)
    except ImportError:
        logger.warning("Unable to find required ui_components module, has it been installed?")


def plot_geometry_feedback(
    model_data: str,
    layers: list[dict[str, str]],
    geometry_feedback: GeometryFeedback,
    model_volume: float | Literal[0],
):
    """
    Displays a 3D visualization of the geometry feedback using Dash and Three.js
    """
    height = DEFAULT_VIEW_HEIGHT
    try:
        app_content = GeometryFeedback3D(
            id="geometry-feedback-viewer",
            height=height,
            modelData=model_data,
            layerNames=layers,
            volume=model_volume,
            geometryInfo=asdict(geometry_feedback),
        )
        app = initialize_widget(children=app_content, assets_path=_get_assets_path())
        try_run_app(app, height)
    except ImportError:
        logger.warning("Unable to find required ui_components module, has it been installed?")


def plot_simulation(
    model_data: str,
    layers: list[dict[str, str]],
    model_volume: float | Literal[0],
    material_assignments: list[MaterialAssignment],
    valid_sources: list[Source],
    valid_receivers: list[Receiver],
    invalid_sources: list[dict[str, Any]],
    invalid_receivers: list[dict[str, Any]],
    view2d: str = None,
):
    """
    Displays a 3D visualization of the simulation using Dash and Three.js
    """
    height = DEFAULT_VIEW_HEIGHT
    try:
        sources = [PlotSource(source).to_dict() for source in valid_sources]
        invalidSources = [
            PlotSource(Source._from_dto(invalid_source._dto, freeze=False), invalid_source.check).to_dict()
            for invalid_source in invalid_sources
        ]

        receivers = [PlotReceiver(receiver).to_dict() for receiver in valid_receivers]
        invalidReceivers = [
            PlotReceiver(
                Receiver._from_dto(invalid_receiver._dto, freeze=False), invalid_receiver.check
            ).to_dict()
            for invalid_receiver in invalid_receivers
        ]

        plot_material_assignments = [
            asdict(
                PlotMaterialAssignment(
                    m["layerName"], m["materialName"], m["materialId"], m.get("materialCategory", None)
                )
            )
            for m in material_assignments
        ]

        app_content = Simulation3D(
            id="simulation-viewer",
            height=height,
            modelData=model_data,
            layerNames=layers,
            volume=model_volume,
            materialAssignments=plot_material_assignments,
            sources=sources + invalidSources,
            receivers=receivers + invalidReceivers,
            viewDirection=view2d,
        )
        app = initialize_widget(children=app_content, assets_path=_get_assets_path())
        try_run_app(app, height)

    except ImportError:
        logger.warning("Unable to find required ui_components module, has it been installed?")
