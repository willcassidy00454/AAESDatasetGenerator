class AdminDgSettings(dict):
    def __init__(
        self,
        polynomial_order: int = 4,
        disable_bc_optimizations: bool = None,
        dump_raw_irs: bool = None,
        skip_postprocessing: bool = None,
        **kwargs,
    ):
        super().__setitem__("polynomialOrder", polynomial_order)
        if disable_bc_optimizations:
            super().__setitem__("disableBcOptimizations", disable_bc_optimizations)
        if dump_raw_irs:
            super().__setitem__("dumpRawIrs", dump_raw_irs)
        if skip_postprocessing:
            super().__setitem__("skipPostprocessing", skip_postprocessing)
