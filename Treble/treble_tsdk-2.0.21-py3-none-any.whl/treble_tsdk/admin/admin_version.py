from ..client.tsdk_client import TSDKClient
from ..client.api_models import SdkVersionDto


def list_sdk_versions(client: TSDKClient):
    res = client._session.get(f"{client._base_url}/admin/ListPySdkVersions")
    return [SdkVersionDto(**x) for x in res.json()]


def publish_sdk_version(
    major: int, minor: int, patch: int, whl_path: str, release_notes: str, client: TSDKClient
):
    post_url = f"{client._base_url}/admin/UploadPySdkVersion"
    post_data = {
        "majorVersion": str(major),
        "minorVersion": str(minor),
        "patchLevel": str(patch),
        "changeLog": release_notes,
    }
    with open(whl_path, "rb") as f:
        res = client._session.post(
            post_url,
            data=post_data,
            files={"formFile": f},
        )

        client._report_or_raise_on_status_code(res)


def remove_sdk_version(major: int, minor: int, patch: int, client: TSDKClient):
    res = client._session.delete(
        f"{client._base_url}/admin/RemovePySdkVersion?majorVersion={major}&minorVersion={minor}&patchLevel={patch}"
    )

    client._report_or_raise_on_status_code(res)
