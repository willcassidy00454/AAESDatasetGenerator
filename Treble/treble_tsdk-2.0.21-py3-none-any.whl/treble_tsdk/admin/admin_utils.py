import json
import httpx
from ..client.tsdk_client import TSDKClient
from ..core.simulation import Simulation
from ..client.api_models import SimulationDto, SourceResultDto


def get_simulation_urls(simulation: Simulation) -> dict[str, dict[str, str]]:
    """
    Returns urls for inputs for all tasks in simulation grouped by source.
    e.g.
    {
        "source_1": {
            "GA": {"Settings": "bla"},
            "DG": {"Settings": "bla", "Mesh": "bla"}
        }
    }
    """
    url_dict = {}
    simProgress = simulation.get_progress()
    for source in simProgress.sources:
        url_dict[source.label] = {}
        for task in source.tasks:
            url_dict[source.label][task.task_type] = get_task_urls(task.id, simulation._client)
    return url_dict


def get_task_urls(task_id: str, client: TSDKClient) -> dict[str, str]:
    """
    Return urls for inputs for a particular task.
    """
    res = client._session.get(f"{client._base_url}/admin/task-urls?taskId={task_id}")
    return res.json()


def trigger_queue_processing(organizationIds: list[str], client: TSDKClient) -> httpx.Response:
    """
    Trigger queue processing for a list of organizations.
    """
    return client._session.post(
        f"{client._base_url}/admin/trigger-queue-processing",
        data=json.dumps(organizationIds, default=vars),
        headers={"Content-type": "application/json"},
    )


def retry_task(
    taskId: str,
    client: TSDKClient,
    force: bool = False,
    regenerate_urls: bool = True,
    create_tasks_if_missing: bool = False,
) -> httpx.Response:
    return client._session.post(
        f"{client._base_url}/admin/retry-task/{taskId}?force={force}&regenerateUrls={regenerate_urls}&createTasksIfMissing={create_tasks_if_missing}"
    )


def get_simulation_dto(simulation_id: str, client: TSDKClient) -> SimulationDto:
    res = client._session.get(f"{client._base_url}/admin/simulation/{simulation_id}")
    return SimulationDto.from_response(**res.json())


def get_simulation_results(
    simulation_id: str, client: TSDKClient, result_type: str = None, include_subtasks: bool = False
) -> list[SourceResultDto]:
    uri = f"{client._base_url}/admin/simulation/{simulation_id}/results"
    add_uri = ""
    if result_type:
        add_uri = f"?resultType={result_type}"
    if include_subtasks is not None:
        if len(add_uri) > 0:
            add_uri += f"&includeSubtasks={include_subtasks}"
        else:
            add_uri += f"?includeSubtasks={include_subtasks}"
    uri += add_uri
    res = client._session.get(uri)
    if res.status_code == 404:
        return []
    if TSDKClient._report_or_raise_on_status_code(res):
        return [SourceResultDto(**item) for item in res.json()]
    return None
