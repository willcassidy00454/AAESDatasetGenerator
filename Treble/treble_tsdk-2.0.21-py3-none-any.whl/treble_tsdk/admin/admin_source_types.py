"""
Usage:
settings = treble.SimulationSettings()
settings["AdvancedSettings"] = {"SpecialGaDirectivityPatternId": admin_source_types.directive_speech["GA"], "SpecialDirectivityPatternName": admin_source_types.directive_speech["DG"]}

sim = treble.SimulationDefinition(
    name="My L-shaped room",
    simulation_type=treble.SimulationType.hybrid,
    model=m,
    crossover_frequency=300,
    ir_length=0.1,
    receiver_list=[treble.Receiver(1,1,1, treble.ReceiverType.mono, f"Receiver_1")],
    source_list=[treble.Source(1.5, 1.5, 1.5, admin_source_types.AdminSources.steinar_special, "My_source", source_properties=treble.SourceProperties(azimuth_angle=10, elevation_angle=10, source_directivity=None))],
    material_assignment=[treble.MaterialAssignment(layer_name, my_material) for layer_name in m.layer_names],
    simulation_settings=settings
)
"""

from enum import Enum


directive_speech = {"GA": "8edf5d39-8cd3-4f45-afb3-f54ebb4889fd", "DG": ""}
directive_speech_approximation = {"GA": "00000000-0000-0000-0000-000000000040", "DG": "Speech"}
directive_loudspeaker = {"GA": "03a86569-d432-4797-b2cc-233b48e69ce2", "DG": "Genelec8020"}
directive_loudspeaker_approximation = {"GA": "00000000-0000-0000-0000-000000000020", "DG": "Genelec8020"}
combined_cardioid = {"GA": "00000000-0000-0000-0000-000000000010", "DG": "Cardioid"}
glennzon_ed_speaker = {"GA": "00000000-0000-0000-0000-000000000030", "DG": "GlennzonEDSpeaker"}
glennzon_ed_speaker_true_ga = {"GA": "00000000-0000-0000-0000-000000000031", "DG": "GlennzonEDSpeaker"}
glennzon_ed_speaker_ele_45_1m = {"GA": "00000000-0000-0000-0000-000000000032", "DG": "GlennzonEDSpeaker"}
glennzon_ed_speaker_ele_45_5cm = {"GA": "00000000-0000-0000-0000-000000000033", "DG": "GlennzonEDSpeaker"}
genelec_8040 = {"GA": "00000000-0000-0000-0000-000000000021", "DG": "Genelec8020"}


class AdminSources(str, Enum):
    boundary = "Boundary"
