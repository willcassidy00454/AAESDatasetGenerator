from __future__ import annotations

import copy
from enum import Enum

import numpy as np

from ..treble_logging import logger
from ..client.api_models import MaterialCategory
from ..client.exceptions import BadRequestException

FREQUENCY_RANGE = [
    50,
    63,
    80,
    100,
    125,
    160,
    200,
    250,
    320,
    400,
    500,
    640,
    800,
    1000,
    1250,
    1600,
    2000,
    2500,
    3200,
    4000,
    5000,
    6400,
    8000,
    10000,
]


class MaterialInputException(Exception):
    def __init__(self, message):
        super().__init__(message)


class MaterialRequestType(str, Enum):
    """
    The types of request to send to the material fitter based on each of the input types
    """

    full_octave_absorption = "FullOctaveAbsorption"
    third_octave_absorption = "ThirdOctaveAbsorption"
    surface_impedance = "SurfaceImpedance"
    reflection_coefficient = "ReflectionCoefficient"
    material_builder = "MaterialBuilder"


class WoolType(str, Enum):
    """
    Types of porous absorber wools available
    """

    glass_wool = "glass_wool"
    rock_wool = "rock_wool"


class AbsorptionCoefficients:
    def __init__(self, coefficients: np.ndarray | list):
        """
        Random incidence absorption coefficients for full octave bands. The list of coefficients
        needs to match the central band frequencies and each coefficient should be between
        0.01 and 0.95. The coefficients will be rounded to two decimal points.

        Frequencies: [63, 125, 250, 500, 1000, 2000, 4000, 8000]

        :param np.ndarray | list coefficients: List of random incidence absorption
            coefficients.
        """
        self.frequency = [63, 125, 250, 500, 1000, 2000, 4000, 8000]
        if np.any(np.array(coefficients) > 0.95):
            raise MaterialInputException("Each coefficient needs to be lower or equal to 0.95")
        if np.any(np.array(coefficients) < 0.01):
            raise MaterialInputException("Each coefficient needs to be larger or equal to 0.01")

        if len(coefficients) != len(self.frequency):
            raise MaterialInputException(
                f"The coefficients need to correspond to the octave band frequencies: {self.frequency}"
            )

        self.coefficients = [round(x, 2) for x in coefficients]

        self.request_type = MaterialRequestType.full_octave_absorption

    @property
    def request_info(self):
        return dict(AbsorptionCoefficients=self.coefficients, InputType=self.request_type.value)


class OneThirdOctaveAbsorptionCoefficients:
    def __init__(self, coefficients: np.ndarray | list):
        """
        Random incidence absorption coefficients for 1/3rd octave bands. The list of coefficients
        needs to match the central band frequencies of the 1/3rd octave bands
        and each coefficient should be between 0.01 and 0.95.
        The coefficients will be rounded to two decimal points.

        Frequencies: [50, 63, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640,
          800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000]


        :param  np.ndarray | list coefficients: List of random incidence absorption
            coefficients.
        """
        self.frequency = FREQUENCY_RANGE
        if np.any(np.array(coefficients) > 0.95):
            raise MaterialInputException("Each coefficient needs to be lower or equal to 0.95")
        if np.any(np.array(coefficients) < 0.01):
            raise MaterialInputException("Each coefficient needs to be larger or equal to 0.01")

        if len(coefficients) != len(self.frequency):
            raise MaterialInputException(
                f"The coefficients need to correspond to the 1/3rd octave band frequencies: {self.frequency}"
            )

        self.coefficients = [round(x, 2) for x in coefficients]
        self.request_type = MaterialRequestType.third_octave_absorption

    @property
    def request_info(self):
        return dict(AbsorptionCoefficients=self.coefficients, InputType=self.request_type.value)


class ReflectionCoefficient:
    def __init__(self, reflection_coefficient: np.ndarray):
        """
        Complex reflection coefficient. The array needs to coincide with the third octave band frequencies
        from 50 hz to 10_000 hz.

        The modulus of the coefficient needs to be smaller than 1 for every frequency.

        Frequencies: [50, 63, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640,
          800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000]

        :param np.ndarray reflection_coefficient: The complex reflection coefficient
        """
        self.frequency = FREQUENCY_RANGE
        if not isinstance(reflection_coefficient, np.ndarray):
            reflection_coefficient = np.array(reflection_coefficient)

        if np.any(np.abs(reflection_coefficient) >= 1.0):
            raise MaterialInputException(
                "Modulus of reflection coefficient needs to be lower than 1 for all frequencies"
            )
        if len(self.frequency) != len(reflection_coefficient):
            exception_message = f"Reflection coefficient needs to have a length of {len(self.frequency)} "
            exception_message += f"but has length of {len(reflection_coefficient)}"
            raise MaterialInputException(exception_message)

        self.real_reflection = np.real(reflection_coefficient)
        self.imag_reflection = np.imag(reflection_coefficient)

        if np.all(self.imag_reflection == 0.0) and np.any(self.real_reflection != self.real_reflection[0]):
            logger.warning("Imaginary component of reflection coefficient is zero. Was that intended?")
        self.request_type = MaterialRequestType.reflection_coefficient

    @property
    def request_info(self):
        return dict(
            ReflectionCoefficientReal=self.real_reflection.tolist(),
            ReflectionCoefficientImaginary=self.imag_reflection.tolist(),
            InputType=self.request_type.value,
        )


class SurfaceImpedance:
    def __init__(self, surface_impedance: np.ndarray, specific_impedance: bool | None = False):
        """
        Complex surface impedance. The array needs to coincide with the third octave band frequencies
        from 50 hz to 10_000 hz. Can be specific impedance or absolute impedance.

        Frequencies: [50, 63, 80, 100, 125, 160, 200, 250, 320, 400, 500, 640,
          800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000, 10000]

        :param np.ndarray surface_impedance: Third octave complex surface impedance
        :param bool | None specific_impedance: Put to true if the input surface impedance is the
            specific acoustic impedance, defaults to False
        """
        self.frequency = FREQUENCY_RANGE
        if len(self.frequency) != len(surface_impedance):
            exception_message = f"Surface impedance needs to have a length of {len(self.frequency)} "
            exception_message += f"but has length of {len(surface_impedance)}"
            raise MaterialInputException(exception_message)

        if not isinstance(surface_impedance, np.ndarray):
            surface_impedance = np.array(surface_impedance)
        if specific_impedance:
            surface_impedance *= 343.0 * 1.2
        self.real_impedance = np.real(surface_impedance)
        self.imag_impedance = np.imag(surface_impedance)

        if np.any(self.real_impedance < 0.0):
            raise MaterialInputException("Real part of surface impedance needs to be larger than zero")

        if np.all(self.imag_impedance == 0.0) and np.any(self.real_impedance != self.real_impedance[0]):
            logger.warning("Imaginary component of reflection coefficient is zero. Was that intended?")
        self.request_type = MaterialRequestType.surface_impedance

    @property
    def request_info(self):
        return dict(
            SurfaceImpedanceReal=self.real_impedance.tolist(),
            SurfaceImpedanceImaginary=self.imag_impedance.tolist(),
            InputType=self.request_type.value,
        )


class MaterialBuilder:
    def __init__(self, density: float = None, bulk_modulus: float = None):
        """
        Use this class to build up materials from a starting point of a rigid backing.
        The material has to have some starting point (this is the reason for the rigid backing).
        Optional input parameters include density and bulk modulus of the rigid backing
        but both need to be input for them to be used

        Use this class by building materials form back to front by adding new material components on
        top of the one beneath.

        Currently we offer air gaps and porous materials (rockwool or glasswool)

        :param float | None density: Density of rigid backing in kg/m3
        :param float | None bulk_modulus: Bulk modulus of rigid backing in Pa
        """
        self.material_request = [self._rigid_backing(density=density, bulk_modulus=bulk_modulus)]
        self.request_type = MaterialRequestType.material_builder

    @property
    def request_info(self):
        return dict(MaterialLayers=self.material_request, InputType=self.request_type.value)

    def _rigid_backing(self, density: float = None, bulk_modulus: float = None) -> dict:
        """
        A rigid backing layer with optional density and bulk modulus properties

        :param float | None density: Density of rigid backing in kg/m3, defaults to None
        :param float | None bulk_modulus: Bulk modulus of rigid backing in Pa, defaults to None
        """
        return dict(layer_type="rigid backing", density=density, bulk_modulus=bulk_modulus)

    def _air_cavity(self, thickness: float) -> dict:
        """
        Construct the air cavity information understood by the material builder

        :param float thickness: Thickness of the air cavity in mm
        :return dict: A dictionary which is understood by the material builder
        """
        return dict(layer_type="air cavity", thickness_in_mm=thickness)

    def _porous_absorber(
        self,
        thickness: float,
        flow_resistivity: float | None,
        density: float | None,
        wool_type: WoolType | None,
    ) -> dict:
        """
        Construct the porous absorber information understood by the material builder

        :param float thickness: Thickness in mm
        :param float | None flow_resistivity: Flow resistivity in [Pa s / m2]
        :param float | None density: Density in kg / m3
        :param WoolType | None wool_type: Type of wool, either glass wool or rock wool
        :return dict: A dictionary which is understood by the material builder
        """
        return dict(
            layer_type="porous absorber",
            thickness_in_mm=thickness,
            flow_resistivity=flow_resistivity,
            density=density,
            wool_type=wool_type,
        )

    def append_air_cavity(self, thickness_in_mm: float):
        """
        Append an air cavity to a material

        :param float thickness_in_mm: Thickness in mm
        """
        self.material_request.append(self._air_cavity(thickness=thickness_in_mm))

    def append_porous_absorber(
        self,
        thickness_in_mm: float,
        flow_resistivity: float = None,
        density: float = None,
        wool_type: WoolType | None = WoolType.rock_wool,
    ):
        """
        Add a porous absorbing layer to a material. One of flow resistivity and density need to be given.

        :param float thickness_in_mm: Thickness of layer in mm
        :param float | None flow_resistivity: The flow resistivity in [Pa s / m2], if not given then
            density needs to be given, defaults to None
        :param float | None density: Density in kg/m3, if not given then flow resistivity
            needs to be given, defaults to None
        :param WoolType | None wool_type: Wool type (used for mapping between density and flow resistivity)
            available are rock wool and glass wool, defaults to WoolType.rock_wool
        """
        if flow_resistivity is None and density is None:
            raise MaterialInputException("Either flow resistivity or density need to be provided.")
        self.material_request.append(
            self._porous_absorber(
                thickness=thickness_in_mm,
                flow_resistivity=flow_resistivity,
                density=density,
                wool_type=wool_type if wool_type is None else wool_type.value,
            )
        )


class MaterialDefinition:
    def __init__(
        self,
        name: str,
        category: MaterialCategory,
        material_type: MaterialRequestType,
        coefficients: np.ndarray,
        default_scattering: float | None = 0.1,
        description: str | None = "",
        specific_impedance: bool | None = False,
    ):
        """
        The material properties are defined based on given material_type. This material definition
        can be used for performing material fit which outputs materials usable by the Treble
        solvers.

        :param str name: Name of the material
        :param MaterialCategory category: Category of material
        :param MaterialRequestType material_type: Type of the material. Possible values are
            full_octave_absorption, third_octave_absorption, reflection_coefficient and surface_impedance
        :param np.ndarray coefficients: For material types full_octave_absorption and third_octave_absorption this
            is an array of random incidence absorption coefficients (np.array[float]).
            For material type reflection_coefficient this is a complex reflection coefficient array (np.array[complex]).
            For material type surface_impedance this is a complex surface impedance array (np.array[complex]).
        :param float | None default_scattering: Default scattering value of material
            the scattering can be modified when assigning to a surface, defaults to 0.1
        :param str | None description: Description of material, defaults to ""
        :param bool | None specific_impedance: Only used for material type SurfaceImpedance.
            Put to true if the input surface impedance is the specific acoustic impedance, defaults to False
        """
        material_properties = None
        self.coefficients = None
        self.coefficients_imaginary = None

        if material_type == MaterialRequestType.full_octave_absorption:
            material_properties = AbsorptionCoefficients(coefficients=coefficients)
            self.coefficients = material_properties.request_info["AbsorptionCoefficients"]
        elif material_type == MaterialRequestType.third_octave_absorption:
            material_properties = OneThirdOctaveAbsorptionCoefficients(coefficients=coefficients)
            self.coefficients = material_properties.request_info["AbsorptionCoefficients"]
        elif material_type == MaterialRequestType.reflection_coefficient:
            material_properties = ReflectionCoefficient(reflection_coefficient=coefficients)
            self.coefficients = material_properties.request_info["ReflectionCoefficientReal"]
            self.coefficients_imaginary = material_properties.request_info["ReflectionCoefficientImaginary"]
        elif material_type == MaterialRequestType.surface_impedance:
            material_properties = SurfaceImpedance(
                surface_impedance=copy.deepcopy(coefficients), specific_impedance=specific_impedance
            )
            self.coefficients = material_properties.request_info["SurfaceImpedanceReal"]
            self.coefficients_imaginary = material_properties.request_info["SurfaceImpedanceImaginary"]
        else:
            raise MaterialInputException(
                "Material type invalid, for MaterialBuilder use PorousMaterialBuilderDefinition"
            )

        if not isinstance(category, MaterialCategory):
            raise MaterialInputException(
                "Category needs to be one of the listed categories in `MaterialCategory`"
            )

        if not 0.0 <= default_scattering <= 1.0:
            raise MaterialInputException("Default scattering needs to be between 0.0 and 1.0")

        self.category = category
        self.material_properties = material_properties
        self.name = name
        self.default_scattering = default_scattering
        self.description = description
        self.input_type = material_type

    @property
    def request(self):
        request = self.material_properties.request_info
        request["Name"] = self.name
        request["Description"] = self.description
        request["Category"] = self.category.value
        request["DefaultScattering"] = self.default_scattering
        request["InputType"] = self.input_type
        return request


class PorousMaterialBuilderDefinition:
    def __init__(
        self,
        name: str,
        category: MaterialCategory,
        porous_layer_thickness: float,
        air_cavity_layer_thickness: float | None = 0,
        flow_resistivity: float = None,
        density: float = None,
        wool_type: "WoolType" = None,
        description: str | None = "",
        default_scattering: float | None = 0.1,
    ):
        """
        This material definition can be used for creating a porous material which outputs materials usable
        by the Treble solvers.

        :param str name: Name of the material
        :param MaterialCategory category: Category of material
        :param float porous_layer_thickness: Thickness of the porous layer in mm
        :param float | None air_cavity_layer_thickness: Thickness of the air cavity in mm, if provided then an air cavity layer is added
        :param float | None flow_resistivity: Flow resistivity in [Pa s / m2]
        :param float | None density: Density in kg / m3
        :param WoolType | None wool_type: Type of wool, either glass wool or rock wool
        :param str | None description: Description of material, defaults to ""
        :param float | None default_scattering: Default scattering value of material
            the scattering can be modified when assigning to a surface, defaults to 0.1
        """
        if isinstance(wool_type, str):
            wool_type = WoolType[wool_type]

        if flow_resistivity is None and (density is None or wool_type is None):
            raise BadRequestException("Either flow_resistivity or density and wool_type need to be provided")

        if not 0.0 <= default_scattering <= 1.0:
            raise MaterialInputException("Default scattering needs to be between 0.0 and 1.0")

        # Create base with only rigid backing layer
        material_properties = MaterialBuilder()
        # Add air cavity layer if thicker than 0
        if air_cavity_layer_thickness > 0:
            material_properties.append_air_cavity(thickness_in_mm=air_cavity_layer_thickness)
        # Add porous absorber layer
        material_properties.append_porous_absorber(
            thickness_in_mm=porous_layer_thickness,
            flow_resistivity=flow_resistivity,
            density=density,
            wool_type=wool_type,
        )

        self.material_layers = material_properties.request_info["MaterialLayers"]
        self.category = category
        self.material_properties = material_properties
        self.name = name
        self.default_scattering = default_scattering
        self.description = description
        self.input_type = MaterialRequestType.material_builder

    @property
    def request(self):
        request = self.material_properties.request_info
        request["Name"] = self.name
        request["Description"] = self.description
        request["Category"] = self.category.value
        request["DefaultScattering"] = self.default_scattering
        request["InputType"] = self.input_type
        return request
