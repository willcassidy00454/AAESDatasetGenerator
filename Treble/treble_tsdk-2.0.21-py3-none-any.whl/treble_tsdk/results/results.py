from __future__ import annotations

import importlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import h5py
import numpy as np
from scipy.io import wavfile

from ..core.simulation import ResultRenameRule, ResultType, SimulationType
from ..utility_classes import Point3d
from ..utils import MirroredMapping
from .device_ir import DeviceIR
from .mono_ir import MonoIR
from .results_naming_enums import IrSuffix, IrType
from .spatial_ir import SpatialIR

if TYPE_CHECKING:
    from ..client.api_models import ReceiverDto, SourceDto
    from ..core.simulation import Simulation
    from ..free_field.results import FreeFieldResults


class SDKResultsException(Exception):
    def __init__(self, message):
        super().__init__(message)


@dataclass
class ReceiverResults:
    id: str
    label: str
    position: Point3d
    mono: str
    spatial: str | None = field(default=None)
    device: str | None = field(default=None)


@dataclass
class SourceResults:
    id: str
    label: str
    position: Point3d
    result_file: Path
    result_metadata_file: Path
    result_metadata: dict
    time: np.ndarray


@dataclass
class AcousticParameters:
    edt: list[float]
    t20: list[float]
    t30: list[float]
    c50: list[float]
    c80: list[float]
    d50: list[float]
    ts: list[float]
    g: list[float]
    spl: list[float]
    spl_a: list[float] = field(default_factory=list)
    spl_c: list[float] = field(default_factory=list)
    spl_z: list[float] = field(default_factory=list)
    sti: list[float] = field(default_factory=list)
    sti_using_spl: list[float] = field(default_factory=list)
    mtf: list[float] = field(default_factory=list)
    center_bands: list[float] = None

    def __getitem__(self, item):
        return getattr(self, item)

    def get(self, item, default=None):
        return getattr(self, item, default)

    def plot(self):
        try:
            importlib.import_module("treble_tsdk.results.plot").results_parameters_plot_widget(self)
        except ImportError:
            print("Result plotting module could not be imported, has it been installed?")


def _convert_old_results_to_new(old_files: dict, new_file: str | Path, new_json: str | Path, bv_source=False):
    """
    Take an old SDK results package and convert it to the new format

    :param dict old_files: Map of old files
    :param str | Path new_file: Path to the new file
    :param str | Path new_json: Path to the new json metadata
    """
    new_json_dict = {}
    new_json_dict["receivers"] = {}
    with h5py.File(new_file, "w") as fh:
        fh.attrs.create("zero-pad-beginning", 0)
        fh.attrs.create("sampling-rate", 32_000)

        base_dir = Path(old_files["base_dir"])
        for source in old_files["sources"].keys():
            s_dict = old_files["sources"][source]
            s_dir = base_dir / s_dict["source_dir"]
            json_file = base_dir / s_dict["json"]
            with open(json_file, "r") as jfh:
                json_dict = json.load(jfh)
            new_json_dict["frequencies"] = json_dict["frequencies"]
            new_json_dict["sources"] = json_dict["sources"]
            mono_norm = json_dict["receivers"][0]["IR_normalization"]
            spatial_norm = None
            device_norm = None
            for receiver in json_dict["receivers"]:
                if receiver.get("Spatial_IR_normalization", None) is not None:
                    spatial_norm = receiver["Spatial_IR_normalization"]
                    spatial_norm = spatial_norm * 2 if not bv_source else spatial_norm  # FFT scaling update
                    break
            for receiver in json_dict["receivers"]:
                if receiver.get("Device_normalization", None) is not None:
                    device_norm = receiver["Device_normalization"]
                    device_norm = device_norm * 2 if not bv_source else device_norm
                    break

            # Write mono IRs to file
            mono_group = fh.create_group("mono_ir")
            mono_group.attrs.create("absmax", mono_norm / 2)
            for receiver_id, wavname in s_dict["mono"].items():
                old_r_dict = [x for x in json_dict["receivers"] if x["point"]["id"] == receiver_id][0]
                mono_norm = old_r_dict["IR_normalization"]
                mono_norm = mono_norm * 2 if not bv_source else mono_norm
                sr, rec_data = wavfile.read(s_dir / wavname)
                mono_group.create_dataset(receiver_id, data=rec_data.astype(np.float32) * mono_norm)
                new_json_dict["receivers"][receiver_id] = {}
                new_json_dict["receivers"][receiver_id]["id"] = receiver_id
                new_json_dict["receivers"][receiver_id]["label"] = old_r_dict["point"].get(
                    "label", receiver_id
                )
                new_json_dict["receivers"][receiver_id]["mono_ir"] = f"mono_ir/{receiver_id}"
                new_json_dict["receivers"][receiver_id]["parameters"] = old_r_dict["result_parameters"]

            # Write spatial IRs to file
            if spatial_norm is not None:
                spatial_group = fh.create_group("spatial_ir")
                spatial_group.attrs.create("absmax", spatial_norm / 2)
                for receiver_id, wavname in s_dict["spatial"].items():
                    sr, rec_data = wavfile.read(s_dir / wavname)
                    spatial_group.create_dataset(
                        receiver_id, data=rec_data.astype(np.float32).T * spatial_norm
                    )
                    new_json_dict["receivers"][receiver_id]["spatial_ir"] = f"spatial_ir/{receiver_id}"

            # Write device IRs to file
            if device_norm is not None:
                device_group = fh.create_group("device_ir")
                device_group.attrs.create("absmax", device_norm / 2)
                for receiver_id, wavname in s_dict["spatial"].items():
                    sr, rec_data = wavfile.read(s_dir / wavname)
                    device_group.create_dataset(receiver_id, data=rec_data.astype(np.float32).T * device_norm)
                    new_json_dict["receivers"][receiver_id]["device_ir"] = f"device_ir/{receiver_id}"

    with open(new_json, "w") as jfh:
        json.dump(new_json_dict, jfh)


class Results:
    def __init__(
        self,
        simulation: "Simulation",
        results_directory: Path | str,
        result_type: ResultType = None,
    ):
        """
        A class which is designed to contain the results of a simulation.

        :param Simulation simulation: The relevant simulation object
        :param Path | str results_directory: The directory where the results were downloaded
        :param ResultType | None result_type: The type of results to be used, defaults to the simulation type
        """
        self._simulation = simulation
        self._results_directory = Path(results_directory)
        self._id_label_rec = self._make_label_id_map(self._simulation.receivers)
        self._id_label_source = self._make_label_id_map(self._simulation.sources)
        if result_type is None:
            self._result_type = self._simulation.type
        else:
            self._result_type = result_type
        self._rename_rule = self._determine_rename_rule()
        self._source_results = self._populate_source_results()
        self._receiver_results = self._populate_receiver_results()

    def _populate_source_results(self) -> dict[str, SourceResults]:
        """
        Populate SourceResults objects for all the sources in the simulation

        :return dict[str, SourceResults]: dictionary with SourceResults objects
        """
        source_results = {}
        for source in self._simulation.sources:
            res_file = self._results_directory / f"{self._renamed(source)}_{self._result_type.value}.h5"
            metadata_file = (
                self._results_directory / f"{self._renamed(source)}_{self._result_type.value}.json"
            )
            with open(metadata_file, "r") as fh:
                metadata = json.load(fh)
            source_results[source.id] = SourceResults(
                id=source.id,
                label=source.label,
                position=source.pos_as_point(),
                result_file=res_file,
                result_metadata_file=metadata_file,
                result_metadata=metadata,
                time=self._get_time_info(results_file=res_file, metadata_file=metadata_file),
            )
        return source_results

    def _get_time_info(self, results_file: Path, metadata_file: Path) -> np.ndarray:
        """
        Get time information from the results file

        :param Path results_file: The results file
        :param Path metadata_file: The metadata file
        :return np.ndarray: The time array
        """
        with h5py.File(results_file, "r") as f:
            if "time" in f:
                return f["time"][:]
            else:
                sampling_rate = f.attrs.get("sampling-rate", 32_000)
                zero_pad_beginning = f.attrs.get("zero-pad-beginning", 0)
                with open(metadata_file, "r") as fh:
                    metadata = json.load(fh)
                rec_id = self._simulation.receivers[0].id
                total_length = f[metadata["receivers"][rec_id]["mono_ir"]].shape[-1]

        return (np.arange(total_length) - zero_pad_beginning) / sampling_rate

    def _populate_receiver_results(self):
        source = self._simulation.sources[0]
        rec_results = {}
        with open(self._source_results[source.id].result_metadata_file, "r") as fh:
            resdict = json.load(fh)
        for receiver in self._simulation.receivers:
            rec_info = resdict["receivers"][receiver.id]
            rec_results[receiver.id] = ReceiverResults(
                id=receiver.id,
                label=receiver.label,
                position=receiver.pos_as_point(),
                mono=rec_info["mono_ir"],
                spatial=rec_info["spatial_ir"] if "spatial_ir" in rec_info else None,
                device=rec_info["device_ir"] if "device_ir" in rec_info else None,
            )
        return rec_results

    def _make_label_id_map(
        self, source_or_receiver: "list[SourceDto] | list[ReceiverDto]"
    ) -> MirroredMapping:
        """
        Create a two way mapping between id and label
        """
        mm = MirroredMapping()
        self._source_ids = []
        self._source_labels = []
        for sr in source_or_receiver:
            mm[sr.label] = sr.id
            self._source_ids.append(sr.id)
            self._source_labels.append(sr.label)
        return mm

    def _renamed(self, source_or_receiver: "SourceDto" | "ReceiverDto") -> str:
        if self._rename_rule == ResultRenameRule.none:
            return source_or_receiver.id
        elif self._rename_rule == ResultRenameRule.by_label:
            return source_or_receiver.label
        else:
            raise SDKResultsException("No rename rule determined")

    def _determine_rename_rule(self) -> ResultRenameRule:
        """
        Determining the results rename rule based on the content of the results directory

        :return ResultRenameRule: How results were renamed
        """
        self._source_id_files = [f"{x.id}_{self._result_type.value}.h5" for x in self._simulation.sources]
        self._source_label_files = [
            f"{x.label}_{self._result_type.value}.h5" for x in self._simulation.sources
        ]

        for directory in os.listdir(self._results_directory):
            if directory in self._source_id_files:
                return ResultRenameRule.none
            if directory in self._source_label_files:
                return ResultRenameRule.by_label
        error_message = (
            "The names of the files in the results directory are not parsable by the Results class"
        )
        error_message += " please check whether this is the correct folder and it contains the results files."
        raise SDKResultsException(error_message)

    def _get_source_results(self, source: "SourceDto | str") -> SourceResults:
        """
        Get the SourceResults object for a source

        :param SourceDto | str source: The source to get results for
        :return SourceResults: The SourceResults object
        """
        if isinstance(source, str):
            if source in self._source_labels:
                source_id = self._id_label_source[source]
            elif source in self._source_ids:
                source_id = source
            else:
                raise ValueError(f"Source {source} not found")
            source_results = self._source_results[source_id]
        else:
            source_results = self._source_results[source.id]
        return source_results

    def _get_receiver_results(self, receiver: "ReceiverDto | str") -> ReceiverResults:
        """
        Get the ReceiverResults object for a receiver

        :param SourceDto | str receiver: The receiver to get results for
        :return ReceiverResults: The ReceiverResults object
        """
        if isinstance(receiver, str):
            if receiver in self._receiver_results.keys():
                return self._receiver_results[receiver]
            if receiver in self._id_label_rec.keys():
                receiver_id = self._id_label_rec[receiver]
                return self._receiver_results[receiver_id]
            else:
                raise ValueError(f"Receiver {receiver} not found")
        else:
            return self._receiver_results[receiver.id]

    def get_mono_ir(self, source: "SourceDto | str", receiver: "ReceiverDto | str") -> MonoIR:
        """
        Receive a mono impulse response object from the simulation for a specific
        source and receiver

        :param SourceDto source: A source associated with the simulation
        :param ReceiverDto receiver: A receiver associated with the simulation and source
        :return MonoIR: A MonoIR object corresponding to the input specifications
        """
        source_results = self._get_source_results(source=source)
        receiver_results = self._get_receiver_results(receiver=receiver)

        with h5py.File(name=source_results.result_file, mode="r") as f:
            data: np.ndarray = f[receiver_results.mono][:]  # type: ignore
            norm_coff: float = f["mono_ir"].attrs.get("absmax", None)
            sampling_rate: float = f.attrs.get("sampling-rate", 32_000)
            zero_pad_samples: float = f.attrs.get("zero-pad-beginning", 0)

        return MonoIR(
            data=data,
            sampling_rate=sampling_rate,
            time=source_results.time,
            source=[source_results],
            receiver=[receiver_results],
            zero_pad_samples=zero_pad_samples,
            normalization_coefficient=norm_coff * 2 if norm_coff is not None else None,
        )

    def get_spatial_ir(self, source: "SourceDto | str", receiver: "ReceiverDto | str") -> SpatialIR:
        """
        Receive a spatial impulse response object from the simulation for a specific
        source and receiver. If receiver type was mono, will raise an exception

        :param SourceDto | str source: A source associated to the simulation.
        :param ReceiverDto | str receiver: A receiver associated to the simulation and source
        :return SpatialIR: A spatial IR object corresponding to the input specifications
        """
        source_results = self._get_source_results(source=source)
        receiver_results = self._get_receiver_results(receiver=receiver)
        if receiver_results.spatial is None:
            raise SDKResultsException("Receiver type is not spatial")

        with h5py.File(name=source_results.result_file, mode="r") as f:
            data: np.ndarray = f[receiver_results.spatial][:]  # type: ignore
            norm_coff: float | None = f["spatial_ir"].attrs.get("absmax", None)
            sampling_rate: float = f.attrs.get("sampling-rate", 32_000)
            zero_pad_samples: float = f.attrs.get("zero-pad-beginning", 0)

        return SpatialIR(
            data=data,
            sampling_rate=sampling_rate,
            source=[source_results],
            time=source_results.time,
            receiver=[receiver_results],
            normalization_coefficient=norm_coff * 2 if norm_coff is not None else None,
            zero_pad_samples=zero_pad_samples,
        )

    def get_device_ir(self, source: "SourceDto | str", receiver: "ReceiverDto | str") -> DeviceIR:
        """
        Receive a device rendered impulse response object from the simulation for a specific
        source and receiver. If receiver is not a device type, an exception will be raised.

        :param SourceDto source: A source associated with the simulation
        :param ReceiverDto receiver: A receiver associated with the simulation and source
        :return DeviceIR: A device IR object corresponding to the input specifications
        """
        source_results = self._get_source_results(source=source)
        receiver_results = self._get_receiver_results(receiver=receiver)
        if receiver_results.device is None:
            message = "Receiver does not have a device impulse response"
            if receiver_results.spatial is not None:
                message += ", you can render device using the SpatialIR."
            raise SDKResultsException(message)

        spatial_ir = self.get_spatial_ir(source=source, receiver=receiver)
        with h5py.File(name=source_results.result_file, mode="r") as f:
            data: np.ndarray = f[receiver_results.device][:]  # type: ignore
            norm_coff: float | None = f["spatial_ir"].attrs.get("absmax", None)
            sampling_rate: float = f.attrs.get("sampling-rate", 32_000)
            zero_pad_samples: float = f.attrs.get("zero-pad-beginning", 0)

        return DeviceIR(
            data=data,
            sampling_rate=sampling_rate,
            spatial_ir=spatial_ir,
            time=source_results.time,
            source=[source_results],
            receiver=[receiver_results],
            normalization_coefficient=norm_coff * 2 if norm_coff is not None else None,
            zero_pad_samples=zero_pad_samples,
        )

    def get_acoustic_parameters(
        self, source: "SourceDto | str", receiver: "ReceiverDto | str"
    ) -> AcousticParameters:
        """
        Get acoustic result parameters for a particular source and receiver, if receiver is not given

        :param SourceDto source: A source associated with the simulation
        :param ReceiverDto | None receiver: A receiver associated with the simulation and source,
            defaults to None
        :return: Acoustic parameters for the source and receiver and if device is true, the parameters for each
            microphone on the device are returned as a list of AcousticParameters
        :rtype: AcousticParameters
        """
        source_results = self._get_source_results(source=source)
        receiver_results = self._get_receiver_results(receiver=receiver)

        parameters = source_results.result_metadata["receivers"][receiver_results.id]["parameters"]
        ap = AcousticParameters(**parameters)
        ap.center_bands = source_results.result_metadata["frequencies"]
        return ap

    def plot(self):
        try:
            importlib.import_module("treble_tsdk.results.plot").result_plot_widget(self)
        except ImportError:
            print("Result plotting module could not be imported, has it been installed?")

    def plot_acoustic_parameters(self):
        try:
            importlib.import_module("treble_tsdk.results.plot").multiresults_parameter_plot_widget(self)
        except ImportError:
            print("Result plotting module could not be imported, has it been installed?")

    # def plot_acoustic_parameters(self):
    #     raise NotImplementedError("Acoustic parameters plotting is not yet implemented. Bear with us.")


def get_results_object(
    simulation: "Simulation",
    results_directory: Path | str,
    result_type: "ResultType" = None,
) -> Results | "FreeFieldResults" | None:
    if simulation._dto.category == "FreeField":
        try:
            return importlib.import_module("treble_tsdk.free_field.results").FreeFieldResults(
                simulation=simulation,
                results_directory=results_directory,
                result_type=result_type,
            )
        except ImportError as e:
            print(f"FreeFieldResults could not be imported: {e}")
            print(e.with_traceback(None))
            raise e
    return Results(
        simulation=simulation,
        results_directory=results_directory,
        result_type=result_type,
    )
