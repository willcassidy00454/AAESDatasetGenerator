from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

import numpy as np

from ..postprocessing.DRTF import render_device
from ..treble_logging import logger
from ..utility_classes import Rotation
from .base_ir import BaseIR
from .mono_ir import MonoIR


if TYPE_CHECKING:
    from ..core.device_obj import DeviceObj
    from ..postprocessing.DRTF import DeviceDefinition
    from .device_ir import DeviceIR
    from .results import ReceiverResults, SourceResults


class SpatialIR(BaseIR):
    def __init__(
        self,
        data: np.ndarray,
        sampling_rate: float,
        time: np.ndarray = None,
        source: list["SourceResults"] = None,
        receiver: list["ReceiverResults"] = None,
        zero_pad_samples: int = 0,
        normalization_coefficient: float = None,
    ):
        """
        An object containing the data for a spatial IR and methods associated with
        such an impulse response.

        :param np.ndarray data: Time series data with the shape (time, channel)
        :param float sampling_rate: sampling rate of the time series
        :param float normalization_coefficient: Normalization coefficient for correct amplitude of wavfile
        :param np.ndarray | None time: Time vector for the time series
        :param SourceDto | None source: The source associated with the IR
        :param ReceiverDto | None receiver: The receiver associated with the IR
        :param float | None normalization_coefficient: The coefficient used to normalize the data
        """
        super().__init__(
            data=data,
            sampling_rate=sampling_rate,
            time=time,
            source=source,
            receiver=receiver,
            zero_pad_samples=zero_pad_samples,
            normalization_coefficient=normalization_coefficient,
        )
        order_float = np.sqrt(self.data.shape[0]) - 1
        if np.round(order_float, 3) % 1 != 0:
            raise ValueError("SpatialIR does not have a supported number of channels, should be 1,4,9...")
        self.order = int(np.round(order_float))

    def render_device_ir(
        self,
        device: "DeviceObj" | "DeviceDefinition",
        orientation: Rotation = Rotation(0.0, 0.0, 0.0),
    ) -> "DeviceIR":
        """
        Take a spatial impulse response and render a new device with it.

        :param DeviceObj | DeviceDefinition device: An object representing a device/head related transfer function
        :param float azimuth | None: Azimuthal rotation in degrees, defaults to 0.0
        :param float elevation | None: Elevation rotation in degrees, defaults to 0.0
        :param float roll | None: Roll rotation in degrees, defaults to 0.0
        :return DeviceIR: The resulting impulse response object for the device
        """
        return render_device(
            spatial_ir=self,
            device=device,
            orientation=orientation,
        )

    def __getitem__(self, item: int) -> MonoIR:
        return MonoIR(
            data=self.data[item],
            sampling_rate=self.sampling_rate,
            source=self._source,
            receiver=self._receiver,
            zero_pad_samples=self.zero_pad_samples,
            normalization_coefficient=self.normalization_coefficient,
        )

    def plot(self, channel_range: tuple[int, int] = (0, 8)):
        """Plot the spatial impulse response"""
        try:
            importlib.import_module("treble_tsdk.results.plot").plot_spatial_ir(
                self, channel_range=channel_range
            )
        except ImportError:
            logger.warning("Result plotting module could not be imported, has it been installed?")
