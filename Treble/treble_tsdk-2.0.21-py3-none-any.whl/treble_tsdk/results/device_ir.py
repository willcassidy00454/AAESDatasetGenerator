from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

import numpy as np

from ..utility_classes import Rotation
from .base_ir import BaseIR
from .mono_ir import MonoIR


if TYPE_CHECKING:
    from ..postprocessing.DRTF import DeviceDefinition
    from .results import ReceiverResults, SourceResults
    from .spatial_ir import SpatialIR


class DeviceIR(BaseIR):
    """Device impulse response class for handling device impulse response data"""

    def __init__(
        self,
        data: np.ndarray,
        sampling_rate: float,
        spatial_ir: "SpatialIR" = None,
        time: np.ndarray = None,
        data_fd: tuple[np.ndarray, np.ndarray] = None,
        source: list["SourceResults"] = None,
        receiver: list["ReceiverResults"] = None,
        zero_pad_samples: int = 0,
        normalization_coefficient: float = None,
    ):
        """
        Class containing everything related to device impulse responses.

        :param np.ndarray data: The time domain device rendered impulse response
        :param float sampling_rate: Sampling rate of impulse response
        :param SpatialIR | None spatial_ir: The SpatialIR object associated with the Device impulse response
        :param np.ndarray | None time: Time vector for the time series
        :param np.ndarray | None data_fd: The device rendered transfer function and the frequency vector
            , defaults to None
        :param SourceDto | None source: The source associated with the IR, defaults to None
        :param ReceiverDto | None receiver: The receiver associated with the IR
        :param float | None normalization_coefficient: Coefficient used to normalize data when written to .wav
        """
        super().__init__(
            data=data,
            sampling_rate=sampling_rate,
            time=time,
            source=source,
            receiver=receiver,
            zero_pad_samples=zero_pad_samples,
            normalization_coefficient=normalization_coefficient,
        )
        if data_fd is None:
            self._frequency_response, self._frequency = super()._to_frequency_domain()
        else:
            self._frequency_response, self._frequency = data_fd

        self.spatial_ir = spatial_ir

    def change_device(
        self,
        device: "DeviceDefinition",
        oritentation: Rotation = Rotation(0.0, 0.0, 0.0),
    ) -> "DeviceIR":
        """
        Render a new device impulse response

        :param DeviceDefinition device: An object representing a device/head related transfer function
        :param Rotation: orientation rotation of the device in orientation, defaults to 0.0
        :return DeviceIR: The resulting impulse response object for the device
        """
        if self.spatial_ir is None:
            raise ValueError("No spatial IR associated with the device IR")
        return self.spatial_ir.render_device_ir(device=device, orientation=oritentation)

    def __getitem__(self, item: int) -> MonoIR:

        return MonoIR(
            data=self.data[item],
            sampling_rate=self.sampling_rate,
            source=self._source,
            receiver=self._receiver,
            zero_pad_samples=self.zero_pad_samples,
            normalization_coefficient=self.normalization_coefficient,
        )

    def plot(self, comparison: dict[str, "DeviceIR"] = None, label: str = None):
        """
        Create a plot widget for the device impulse response

        :param dict[str, DeviceIR] comparison: An optional dict with device identifier and device impulse response
        """
        if comparison is not None:
            if not isinstance(comparison, dict):
                if not isinstance(comparison, list):
                    comparison = [comparison]
                if isinstance(comparison, list):
                    comparison = {f"Comparison {i + 1}": comparison[i] for i in range(len(comparison))}
        try:
            importlib.import_module("treble_tsdk.results.plot").plot_multichannel_data(
                self, comparison=comparison, label=label
            )
        except ImportError:
            print("Result plotting module could not be imported, has it been installed?")
