from abc import ABC, abstractmethod
import numpy as np
from scipy import signal
import logging
from .result_utils import (
    fractional_octave_bands,
    upper_bounds_fractional_bands,
    lower_bounds_fractional_bands,
)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .mono_ir import MonoIR


class FilterDefinition(ABC):
    @abstractmethod
    def filter(self, data: np.ndarray, sampling_rate: int) -> np.ndarray:
        """Apply the filtering operation

        :param np.ndarray data: data to be filtered
        :param int sampling_rate: the sampling rate of the data
        :return np.ndarray: the filtered data
        """
        pass

    def __call__(self, data: np.ndarray, sampling_rate: int, zero_pad_samples: int) -> np.ndarray:
        return self.filter(data, sampling_rate, zero_pad_samples)


class GainFilter(FilterDefinition):
    """Gain stage filter"""

    def __init__(self, gain: float):
        """initialize the gain filter with the gain factor

        :param float gain: Gain factor to apply
        """
        self.gain = gain

    def filter(self, ir: np.ndarray, sampling_rate: int, zero_pad_samples: int) -> np.ndarray:
        return ir * self.gain


class ButterworthFilter(FilterDefinition):
    """Butterworth filtering for lowpass, highpass and bandpass filtering"""

    def __init__(
        self,
        lp_order: int = None,
        hp_order: int = None,
        lp_frequency: float = None,
        hp_frequency: float = None,
        forward_backward: bool = True,
    ):
        """Initialize the butterworth filter

        :param int lp_order: low pass order, None will turn off the lp filtering, defaults to None
        :param int hp_order: high pass order, None will turn off the lp filtering, defaults to None
        :param float lp_frequency: low pass frequency, None will turn off the lp filtering, defaults to None
        :param float hp_frequency: high pass frequency, None will turn off the lp filtering, defaults to None
        :param bool forward_backward: Enable zero phase filtering, using forward-backwards filtering. This applies the filter twice, i.e. doubles the order of the filter, defaults to True
        """
        self.lp_order = lp_order
        self.hp_order = hp_order
        self.lp_frequency = lp_frequency
        self.hp_frequency = hp_frequency
        self.forward_backward = forward_backward

    def filter(self, data: np.ndarray, sampling_rate: int, zero_pad_samples: int) -> np.ndarray:
        if self.forward_backward:
            applied_filter = signal.sosfiltfilt
        else:
            applied_filter = signal.sosfilt
        filtered_data = data.copy()
        if self.lp_order is not None and self.lp_frequency is not None:
            lp_sos = signal.butter(self.lp_order, self.lp_frequency, "lp", fs=sampling_rate, output="sos")
            filtered_data = applied_filter(lp_sos, filtered_data, axis=-1)

        if self.hp_order is not None and self.hp_frequency is not None:
            hp_sos = signal.butter(self.hp_order, self.hp_frequency, "hp", fs=sampling_rate, output="sos")
            filtered_data = applied_filter(hp_sos, filtered_data, axis=-1)

        return filtered_data


class FIRFilter(FilterDefinition):
    """Filtering using an finite impulse response filter"""

    def __init__(self, fir_filter: np.ndarray, sampling_rate: int, zero_pad_samples: int = 0):
        """Initialize the filter with the FIR. The FIR should be a 1D array with the filter centered at the middle element and have an odd number of elements

        :param np.ndarray fir_filter: _description_
        :param int sampling_rate: _description_
        """
        if fir_filter.ndim != 1:
            raise ValueError("FIR filter must be a 1D array")

        if fir_filter.shape[-1] % 2 == 0:
            raise ValueError("FIR filter must have an odd number of elements")
        self.fir_filter = fir_filter
        self.sampling_rate = sampling_rate

    def filter(self, data: np.ndarray, sampling_rate: int, zero_pad_samples: int) -> np.ndarray:
        if self.sampling_rate != sampling_rate:
            raise ValueError("Sampling rate of the filter does not match the sampling rate of the data")
        start_index = (self.fir_filter.shape[-1] - 1) // 2
        end_index = start_index + data.shape[-1]
        return signal.convolve(data, self.fir_filter)[start_index:end_index] / sampling_rate

    @staticmethod
    def from_mono_ir(mono_ir: "MonoIR") -> "FIRFilter":
        """Creates an FIR filter using a mono IR, a rollback and wavespeed can be specified if the ir needs to be compensated for a certain propagation distance

        :param MonoIR mono_ir: mono ir to create the filter from
        :return FIRFilter: An FIRFilter that can be used to filter other IR's
        """
        n_samples = mono_ir.data.shape[-1] - mono_ir.zero_pad_samples
        fir_filter_data = np.zeros(n_samples * 2 - 1)
        fir_filter_data[n_samples - mono_ir.zero_pad_samples - 1 :] = mono_ir.data
        return FIRFilter(fir_filter_data, mono_ir.sampling_rate)


class IIRFilter(FilterDefinition):
    """Filtering using an infinite impulse response filter"""

    def __init__(self, iir_filter: tuple[np.ndarray, np.ndarray], sampling_rate: int):
        """Initialize the filter with the IIR. The IIR should be a tuple of the numerator and denominator coefficients of the digital filter's transfer function.

        :param tuple[np.ndarray, np.ndarray] fir_filter: Numerator and denominator coefficients of the digital filter's transfer function
        :param int sampling_rate: sampling rate of the filter
        """
        if len(iir_filter) != 2:
            raise ValueError("IIR filter must be a 2D array")

        self.iir_filter = iir_filter
        self.sampling_rate = sampling_rate

    def filter(self, data: np.ndarray, sampling_rate: int, zero_pad_samples: int) -> np.ndarray:
        if self.sampling_rate != sampling_rate:
            raise ValueError("Sampling rate of the filter does not match the sampling rate of the data")
        return signal.lfilter(self.iir_filter[0], self.iir_filter[1], data)


class OctaveBandFilter(ButterworthFilter):
    def __init__(
        self,
        center_frequency: float,
        octave_fraction: int = 1,
        lp_order: int = 4,
        hp_order: int = 4,
        forward_backward: bool = True,
    ):
        """
        Defines a filter which bandpass filters across an octave band

        :param float center_frequency: The center frequency of the octave band
        :param int octave_fraction: The fraction of the octave bands, defaults to 1
        :param int lp_order: The order of the low pass filter, defaults to 4
        :param int hp_order: The order of the high pass filter, defaults to 4
        :param bool forward_backward: Enable zero phase filtering, using forward-backwards filtering.
            This applies the filter twice, i.e. doubles the order of the filter, defaults to True
        """
        self.center = center_frequency
        self.octave_fraction = octave_fraction
        self.lp_frequency = upper_bounds_fractional_bands(
            centers=self.center, octave_fraction=self.octave_fraction
        )
        self.hp_frequency = lower_bounds_fractional_bands(
            centers=self.center, octave_fraction=self.octave_fraction
        )
        super().__init__(
            lp_order=lp_order,
            hp_order=hp_order,
            lp_frequency=self.lp_frequency,
            hp_frequency=self.hp_frequency,
            forward_backward=forward_backward,
        )


class TimeshiftFilter(FilterDefinition):
    """A filter that applies a time shift to the data"""

    def __init__(self, shift_seconds: float):
        self.shift_seconds = shift_seconds

    def filter(self, data: np.ndarray, sampling_rate: float, zero_pad_start: int) -> np.ndarray:
        delay_samples = int(self.shift_seconds * sampling_rate)
        if delay_samples < 0:
            data[:-delay_samples] = 0
        else:
            data[-delay_samples:] = 0
        return np.roll(data, delay_samples)

    @staticmethod
    def from_distance(delay_distance: float, wavespeed: float = 343):
        return TimeshiftFilter(delay_distance / wavespeed)


class TimeWindowFilter(FilterDefinition):
    """A filter that applies a time window to the data"""

    def __init__(
        self,
        start_time_s: float = None,
        end_time_s: float = None,
        fadein_length_s: float = 0.005,
        fadeout_length_s: float = 0.005,
    ):
        self.start_time_s = start_time_s
        self.end_time_s = end_time_s
        if start_time_s is not None and end_time_s is not None:
            if end_time_s - start_time_s < fadein_length_s + fadeout_length_s:
                raise ValueError("The time window is too short for the fade in/out")
        self.fadein_length_s = fadein_length_s
        self.fadeout_length_s = fadeout_length_s

    def filter(self, data: np.ndarray, sampling_rate: float, zero_pad_samples: int) -> np.ndarray:
        if self.start_time_s is not None:
            start_sample = max(int(self.start_time_s * sampling_rate) + zero_pad_samples, 0)
            if start_sample > data.shape[-1] - zero_pad_samples:
                logging.warning("Start time is larger than the length of the data")
                return data
        else:
            start_sample = 0

        if self.end_time_s is not None:
            end_sample = int(self.end_time_s * sampling_rate) + zero_pad_samples
            if end_sample < start_sample:
                raise ValueError(f"end_sample {end_sample} is less than start_sample {start_sample}")
        else:
            end_sample = data.shape[-1]

        fadein_length = int(self.fadein_length_s * sampling_rate)
        fadeout_length = int(self.fadeout_length_s * sampling_rate)
        def fade(n_samples: int, direction: str = "in") -> np.ndarray:
            # Create a fade in or a fadeout taper
            if direction == "in":
                return np.hanning(n_samples * 2)[:n_samples]
            elif direction == "out":
                return np.hanning(n_samples * 2)[n_samples:]

        time_window = np.zeros(data.shape[-1])
        time_window[start_sample:end_sample] = 1
        if start_sample > 0:
            time_window[start_sample : start_sample + fadein_length] = fade(fadein_length, "in")
        if end_sample < data.shape[-1]:
            time_window[end_sample - fadeout_length : end_sample] = fade(fadeout_length, "out")
        return data * time_window


class ApproximateIntegrationFilter(FilterDefinition):
    """
    A filter that performs an integration of the data using a Butterworth filter with a very low cutoff frequency, 
    some phase distortion at the very low frequencies may occur, if this is critical, 
    use a lower cutoff frequency for the filter
    """

    def __init__(self, order=1, cutoff=10):
        self.order = order
        self.cutoff = cutoff
        reference_frequency = 100
        # The integration coefficient ensures the the resulting frequency response is scaled correctly to apply a 1/(j omega) operation
        self.integration_coefficient = 1 / (
            np.abs(1 / np.sqrt(1 + (reference_frequency / cutoff) ** 2)) * (2 * np.pi * reference_frequency)
        )
        self.butterworth_filter = ButterworthFilter(
            lp_order=order, lp_frequency=cutoff, forward_backward=False
        )

    def filter(self, data: np.ndarray, sampling_rate: int, zero_pad_samples: int = 0):
        return (
            self.butterworth_filter.filter(data, sampling_rate, zero_pad_samples)
            * self.integration_coefficient
        )
