from typing import TYPE_CHECKING, Callable
from pathlib import Path
import numpy as np
from scipy.io import wavfile
from scipy import signal
import IPython.display as ipd


from ..treble_logging import logger
from .filter_definition import FilterDefinition
from .result_utils import compute_energy_decay_curve


if TYPE_CHECKING:
    from .results import ReceiverResults, SourceResults
    from .mono_ir import MonoIR
    from .spatial_ir import SpatialIR
    from .device_ir import DeviceIR
    from .audio_signal import AudioSignal, ConvolvedAudioSignal


class BaseIR(object):
    """Base class for impulse response handling"""

    def __init__(
        self,
        data: np.ndarray,
        sampling_rate: float,
        time: np.ndarray = None,
        source: list["SourceResults"] = None,
        receiver: list["ReceiverResults"] = None,
        zero_pad_samples: int = 0,
        normalization_coefficient: float = None,
    ):
        """
        A Class handling all mono impulse response related actions

        :param np.ndarray data: The time domain impulse response
        :param float sampling_rate: The sampling rate of the impulse response
        :param SourceResults | None source: Information on source, defaults to None
        :param ReceiverResults | None receiver: Information on receiver, defaults to None
        :param int zero_pad_samples: The number of samples that have been zero padded in the beginning, defaults to 0
        :param float | None normalization_coefficient: The coefficient used to normalize the data
        """
        self.data = data
        self.sampling_rate = sampling_rate
        if time is None:
            self.time = (np.arange(data.shape[-1]) - zero_pad_samples) / sampling_rate
        else:
            self.time = time
        self._frequency_response = None
        self._frequency = None
        self.zero_pad_samples = zero_pad_samples
        self.duration = np.max(self.time)
        self._source = [] if source is None else source
        self._receiver = [] if receiver is None else receiver
        self.normalization_coefficient = normalization_coefficient

    @property
    def frequency(self) -> np.ndarray:
        """Getter for the frequency response"""
        if self._frequency_response is None:
            self._frequency_response, self._frequency = self._to_frequency_domain()
        return self._frequency

    @property
    def frequency_response(self) -> np.ndarray:
        """Getter for the frequency response"""
        if self._frequency_response is None:
            self._frequency_response, self._frequency = self._to_frequency_domain()
        return self._frequency_response

    def _to_frequency_domain(self) -> tuple[np.ndarray, np.ndarray]:
        """
        Transform impulse response to the frequency domain

        :return tuple[np.ndarray, np.ndarray]: The frequency response and frequency vector
        """
        dt = 1 / self.sampling_rate
        Nfft = self.data.shape[-1]
        freq = np.fft.rfftfreq(Nfft, dt)
        fr = np.fft.rfft(a=self.data, n=Nfft, axis=-1) * dt

        return fr, freq

    def unpadded_data(self) -> np.ndarray:
        """
        Returns the impulse response without zero padding

        :return np.ndarray: The impulse response without zero padding
        """

        if self.zero_pad_samples == 0:
            return self.data
        else:
            if len(self.data.shape) > 1:
                return self.data[:, self.zero_pad_samples : -self.zero_pad_samples]
            else:
                return self.data[self.zero_pad_samples : -self.zero_pad_samples]

    def unpadded_time(self) -> np.ndarray:
        """
        Returns the time vector without zero padding

        :return np.ndarray: The time vector without zero padding
        """
        if self.zero_pad_samples == 0:
            return self.time
        else:
            return self.time[self.zero_pad_samples : -self.zero_pad_samples]

    def write_to_wav(
        self, path_to_file: str | Path, normalize: bool = True, unpad_data: bool = True
    ) -> float:
        """
        Write the data out to a .wav file

        :param str | Path path_to_file: Where to store the file (the directory needs to exist)
        :param bool normalize: Whether to normalize the data before writing to .wav
            if the impulse response object contains a normalization coefficient this one will be used
            otherwise it will be the absolute maximum of the data times two, defaults to True
        :param bool unpad_data: Whether to unpad the data before writing to .wav, defaults to True
        :return float: The normalization coefficient used
        """
        if self.normalization_coefficient is not None and normalize is True:
            norm_coff = self.normalization_coefficient
        else:
            norm_coff = np.max(np.abs(self.data)) * 2
        if unpad_data:
            write_data = self.unpadded_data()
        else:
            write_data = self.data

        wavfile.write(
            filename=path_to_file,
            rate=self.sampling_rate,
            data=(write_data / norm_coff).T if normalize else write_data.T,
        )
        return norm_coff

    def __add__(
        self, other_ir: "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal"
    ) -> "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal":
        """
        Sum two impulse responses together

        :param "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal" other_ir: other impulse response to sum
        :return "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal": summed impulse
        """
        data = self.data.copy()
        other_data = other_ir.data.copy()

        if not isinstance(other_ir, self.__class__):
            raise TypeError(f"Cannot add {type(self)} and {type(other_ir)}")

        if self.sampling_rate != other_ir.sampling_rate:
            other_ir = other_ir.resample(self.sampling_rate)
            logger.warning("Resampling the second impulse response to match the first")

        if data.ndim != other_data.ndim:
            raise ValueError("The impulse responses must have the same dimensions")

        if data.ndim == 1:
            data = data.reshape(1, -1)
            other_data = other_data.reshape(1, -1)
        else:
            if data.shape[0] != other_data.shape[0]:
                raise ValueError("The impulse responses must have the same dimension and channels")

        max_zero_pad = max(self.zero_pad_samples, other_ir.zero_pad_samples)

        ir_data_out = np.zeros(
            (
                data.shape[0],
                max(
                    data.shape[-1] - self.zero_pad_samples,
                    other_data.shape[-1] - other_ir.zero_pad_samples,
                )
                + max_zero_pad,
            )
        )
        ir1_start = max_zero_pad - self.zero_pad_samples
        ir_data_out[:, ir1_start : ir1_start + data.shape[-1]] += data
        ir2_start = max_zero_pad - other_ir.zero_pad_samples
        ir_data_out[:, ir2_start : ir2_start + other_data.shape[-1]] += other_data

        time = (np.arange(ir_data_out.shape[-1]) - max_zero_pad) / self.sampling_rate
        if self.data.ndim == 1:
            ir_data_out = ir_data_out[0, :]

        return self.__class__(
            data=ir_data_out,
            sampling_rate=self.sampling_rate,
            time=time,
            zero_pad_samples=max_zero_pad,
            source=self._source + other_ir._source,
            receiver=self._receiver + other_ir._receiver,
        )

    def __mul__(
        self, other: "float | AudioSignal"
    ) -> "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal":
        """Apply a gain or convolve an IR to the signal to the signal"""
        from .audio_signal import AudioSignal

        if isinstance(other, float | int):
            return self.__class__(
                data=self.data * other,
                sampling_rate=self.sampling_rate,
                time=self.time,
                zero_pad_samples=self.zero_pad_samples,
                source=self._source,
                receiver=self._receiver,
                normalization_coefficient=self.normalization_coefficient,
            )

        elif isinstance(other, AudioSignal):
            return self.convolve_with_audio_signal(other)

    def filter(
        self,
        filter_definition: (
            FilterDefinition
            | list[FilterDefinition]
            | Callable[[np.ndarray, int], np.ndarray]
            | list[Callable[[np.ndarray, int], np.ndarray]]
        ),
    ) -> "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal":
        """
        :param FilterDefinition
                | list[FilterDefinition]
                | Callable[[np.ndarray, int], np.ndarray]
                | list[Callable[[np.ndarray, int], np.ndarray]]
                : The filter definition to use, either a class inheriting from FilterDefinition or
                  a function that accepts two arguments [numpy.ndarry, int] and returns [numpy.array]
        :return "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal": The filtered impulse response
        """
        filtered_data = self.data.copy()
        if isinstance(filter_definition, list):
            for filter_def in filter_definition:
                if self.data.ndim == 2:
                    filtered_data = np.array(
                        [
                            filter_def.filter(data, self.sampling_rate, self.zero_pad_samples)
                            for data in filtered_data
                        ]
                    )
                else:
                    filtered_data = filter_def.filter(
                        filtered_data, self.sampling_rate, self.zero_pad_samples
                    )
        else:
            filtered_data = filter_definition.filter(filtered_data, self.sampling_rate, self.zero_pad_samples)

        return self.__class__(
            data=filtered_data,
            sampling_rate=self.sampling_rate,
            time=self.time,
            zero_pad_samples=self.zero_pad_samples,
            source=self._source,
            receiver=self._receiver,
        )

    def resample(
        self, requested_sampling_rate: int = 32000
    ) -> "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal":
        """resample the data to a new sampling rate

        :param int requested_sampling_rate: The new sampling rate
        :return "MonoIR | SpatialIR | DeviceIR | AudioSignal | ConvolvedAudioSignal": The returned audio signal
        """
        num_samples = int(self.data.shape[-1] * requested_sampling_rate / self.sampling_rate)
        resampled_data = signal.resample(self.data, num_samples, axis=-1)
        new_zero_pad_samples = int(self.zero_pad_samples * requested_sampling_rate / self.sampling_rate)
        time = (np.arange(resampled_data.shape[-1]) - new_zero_pad_samples) / requested_sampling_rate

        return self.__class__(
            data=resampled_data,
            sampling_rate=requested_sampling_rate,
            time=time,
            zero_pad_samples=new_zero_pad_samples,
            source=self._source,
            receiver=self._receiver,
            normalization_coefficient=self.normalization_coefficient,
        )

    def playback(self, channel: int = None) -> ipd.Audio:
        """Play back the audio using the ipython display module

        :param int | None channel: select that channel you want to play back, if None is selected stereo will be played back if there are two channels, defaults to None
        :return ipd.Audio: IPython audio object
        """
        data = self.data.copy()
        if channel is None:
            if self.data.ndim > 1 and self.data.shape[0] > 2:
                logger.warning("Audio input is multichannel, summing into mono")
                data = np.mean(data, axis=0)
        else:
            data = data.data[channel]

        return ipd.Audio(data, rate=self.sampling_rate)

    def convolve_with_audio_signal(self, audio: "AudioSignal") -> "ConvolvedAudioSignal":
        """Convolve the impulse response with an audio signal to get a convolved audio signal

        :param AudioSignal audio: signal to be convolved with the IR
        :return AudioSignal: The convolved audio signal
        """
        if self.sampling_rate != audio.sampling_rate:
            audio = audio.resample(self.sampling_rate)

        if self.data.ndim == 1:
            ir_data = self.data.reshape(1, -1)
        else:
            ir_data = self.data

        if audio.data.ndim == 1:
            audio.data = audio.data.reshape(1, -1)
        if audio.data.shape[0] > 1:
            logger.warning("Audio input is multichannel, using only first channel")

        convolved_audio = np.array(
            [signal.convolve(data, audio.data[0], mode="full") / self.sampling_rate for data in ir_data]
        )
        time = (np.arange(convolved_audio.shape[-1]) - self.zero_pad_samples) / self.sampling_rate
        from .audio_signal import ConvolvedAudioSignal

        return ConvolvedAudioSignal(
            data=convolved_audio,
            time=time,
            sampling_rate=self.sampling_rate,
            source=self._source,
            receiver=self._receiver,
            zero_pad_samples=self.zero_pad_samples + audio.zero_pad_samples,
            normalization_coefficient=self.normalization_coefficient,
        )

    def _compute_edc(self, center_frequency: float = None, unpadded: bool = True) -> np.ndarray:
        """
        Compute the energy decay curve for the impulse response

        :param float | None center_frequency: If signal is bandpass filtered, the
            center frequency of the filter should be passed, defaults to None
        :param bool unpadded: Whether to use the unpadded data, defaults to True
        """
        if unpadded:
            data = self.unpadded_data()
        else:
            data = self.data
        return compute_energy_decay_curve(data, self.sampling_rate, center_frequency)

    @classmethod
    def from_file(cls, filepath: str | Path, channel: int = None, zero_pad_samples: int = 0) -> "AudioSignal":
        """Create from a wav file

        :param str | Path filepath: path to the wav file
        :param int channel: if the input is multichannel, choose the channel to load, defaults to None
        :return AudioSignal: the audio signal loaded from file
        """
        if Path(filepath).suffix.lower() == ".wav":
            audio_sampling_rate, audio = wavfile.read(filepath)
        else:
            raise ValueError("format not supported")

        if audio.dtype == np.int16:
            audio = audio.astype(np.float32) / 2**15
        if audio.dtype == np.int32:
            audio = audio.astype(np.float32) / 2**31

        if audio.ndim == 1:
            audio = audio.reshape(1, -1)
        else:
            audio = audio.T
            if channel is not None:
                audio = audio[channel].reshape(1, -1)
        return cls(data=audio, sampling_rate=audio_sampling_rate, zero_pad_samples=zero_pad_samples)
