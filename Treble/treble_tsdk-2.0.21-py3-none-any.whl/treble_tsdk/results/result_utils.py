import numpy as np
from scipy.signal import spectrogram
from scipy.interpolate import interp1d


def _smoothed_stft(
    x: np.ndarray,
    fs: int = 32000,
    window: tuple[str, float] = ("tukey", 0.25),
    nperseg: int = 2**11,
    noverlap: int = 2**10,
    nfft: int = 2**16,
    return_onesided: bool = True,
    scaling: str = "spectrum",
    mode: str = "magnitude",
    octave_fraction: int = 3,
    freq_range: tuple[float, float] = (50, 16000),
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Computes the Short time Fourier tranfrom (STFT) and smooths it in fractional octave bands.

    :param np.ndarray x: Time signal
    :param int fs: Sampling frequency of the `x` time series., defaults to 32000
    :param tuple window: Desired window to use, defaults to ("tukey", 0.25)
    :param int nperseg: Length of each segment, defaults to 2**11
    :param int noverlap: Number of points to overlap between segments, defaults to 2**10
    :param int nfft: Length of the FFT, defaults to 2**16
    :param bool return_onesided: If `True`, return a one-sided spectrum for real data, defaults to True
    :param str scaling: Selects between computing the power spectral density ('density') and spectrum ('spectrum'), defaults to "spectrum"
    :param str mode: Defines what kind of return values are expected. Options are ['psd', 'complex', 'magnitude', 'angle', 'phase'], defaults to "magnitude"
    :param int octave_fraction: Fraction of octave band (e.g., 1 for octave bands, 3 for 1/3 octave bands, etc.), defaults to 3
    :param tuple[float, float] freq_range: The min and max frequency for the octave bands, defaults to (50, 16000)
    :return float f_octave_centre: Frequency vector of the smoothed STFT.
    :return float time_vector: Time vector of the smoothed STFT.
    :return float stft_smoothed: The magnitude of the STFT averaged in fractional octave bands [frequency x time].
    """
    f, t, stft = spectrogram(
        x=x,
        fs=fs,
        window=window,
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        return_onesided=return_onesided,
        scaling=scaling,
        mode=mode,
    )

    stft = np.array(stft)

    if octave_fraction is None:
        return f, t, stft

    stft_smoothed = []
    for itf in range(stft.shape[1]):
        stft_smoothed.append(_average_octave_bands(f, stft[:, itf], octave_fraction, freq_range)[1])
    stft_smoothed = np.array(stft_smoothed)
    stft_smoothed = stft_smoothed.transpose()

    f_octave_centre = _average_octave_bands(f, stft[:, 0], octave_fraction, freq_range)[0]

    return f_octave_centre, t, stft_smoothed


def average_octave_bands(
    freqs: np.ndarray,
    freq_response: np.ndarray,
    octave_fraction: int | None = 3,
    freq_range: tuple[float, float] = (50, 16000),
) -> tuple[np.ndarray, np.ndarray]:
    """
    Average the magnitude of the frequency response within fractional octave bands.

    :param np.ndarray freqs: Frequency vector of the frequency response.
    :param np.ndarray freq_response: Frequency response, complex values
    :param Optional[int] octave_fraction: Fraction of octave (e.g., 1 for octave bands, 3 for 1/3 octave bands, etc.), defaults to 3
    :param tuple[float, float] freq_range: The max frequency for the octave bands, defaults to 16000
    :return float f_octave_centre: Center frequencies of the fractional octave bands
    :return float freq_response_smoothed: The magnitude of the frequency response averaged in fractional octave bands.
    """
    # Caclulate fractional octave bands center and bound frequencies.
    f_octave_centre, f_octave_lower, f_octave_upper = fractional_octave_bands(octave_fraction, freq_range)

    # Smoothing
    freq_response_abs = np.abs(freq_response)
    freq_response_smoothed = []
    for f_low, f_high in zip(f_octave_lower, f_octave_upper):
        idx_band = np.where((freqs >= f_low) & (freqs <= f_high))
        if np.sum(idx_band) == 0:
            freq_response_smoothed.append(None)
            continue
        band_average = np.mean(freq_response_abs[idx_band])
        freq_response_smoothed.append(band_average)

    # Replace None values with interpolated ones.
    freq_response_smoothed = np.array(freq_response_smoothed, dtype=float)
    valid_indices = np.where(~np.isnan(freq_response_smoothed))[0]
    invalid_indices = np.where(np.isnan(freq_response_smoothed))[0]
    interp_func = interp1d(
        valid_indices, freq_response_smoothed[valid_indices], kind="linear", fill_value="extrapolate"
    )
    freq_response_smoothed[invalid_indices] = interp_func(invalid_indices)

    return f_octave_centre, freq_response_smoothed


def fractional_octave_bands(
    octave_fraction: int, freq_range: tuple[float, float] = (50, 16000)
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Generates the center frequencies, lower bounds, and upper bounds for fractional octave bands. The lowest band is defined such as the bandwidth does not exceed Df.

    :param int octave_fraction: Fraction of octave (e.g., 1 for octave bands, 3 for 1/3 octave bands, etc.)
    :param tuple[float, float] freq_range: The minimum and maximum frequency, defaults to (50, 16000)
    :return float centers: Center frequencies of the fractional octave bands.
    :return float lower: Lower bounds of the fractional octave bands.
    :return float upper: Upper bounds of the fractional octave bands.
    """
    # Start from a reference frequency (usually 1 kHz), and calculate bands across the range
    freq_min, freq_max = freq_range
    f_ref = 1000

    # Compute the ratio for the fractional octave
    k = 2 ** (1 / octave_fraction)

    # Find the number of bands to cover the frequency range
    n_bands_below = int(np.floor(np.log(freq_min / f_ref) / np.log(k)))
    n_band_upper = int(np.ceil(np.log(freq_max / f_ref) / np.log(k)))
    n_bands = np.arange(n_bands_below, n_band_upper + 1)

    # Calculate the center frequencies
    centers = f_ref * k**n_bands

    # Calculate the lower and upper bounds for each band
    lower = lower_bounds_fractional_bands(centers, octave_fraction)
    upper = upper_bounds_fractional_bands(centers, octave_fraction)

    return centers, lower, upper


def lower_bounds_fractional_bands(centers: np.ndarray | float, octave_fraction: int) -> np.ndarray | float:
    """
    Generates the lower bounds for fractional octave bands.

    :param np.ndarray centers: Center frequencies of the fractional octave bands.
    :param int octave_fraction: Fraction of octave (e.g., 1 for octave bands, 3 for 1/3 octave bands, etc.)
    :return np.ndarray | float lower: Lower bounds of the fractional octave bands.
    """
    lower = centers / (2 ** (1 / (2 * octave_fraction)))
    return lower


def upper_bounds_fractional_bands(centers: np.ndarray | float, octave_fraction: int) -> np.ndarray | float:
    """
    Generates the upper bounds for fractional octave bands.

    :param np.ndarray centers: Center frequencies of the fractional octave bands.
    :param int octave_fraction: Fraction of octave (e.g., 1 for octave bands, 3 for 1/3 octave bands, etc.)
    :return np.ndarray | float lower: Lower bounds of the fractional octave bands.
    """
    upper = centers * (2 ** (1 / (2 * octave_fraction)))
    return upper


def _compute_energy_of_band_passed_signal(
    signal: np.ndarray, sampling_rate: int, central_freq: float
) -> np.ndarray:
    return (signal**2 / sampling_rate) / central_freq * np.pi * 1.06


def _compute_energy_of_unfiltered_signal(signal: np.ndarray, sampling_rate: int) -> np.ndarray:
    return signal**2 / sampling_rate


def compute_energy_decay_curve(
    signal: np.ndarray, sampling_rate: int, central_freq: float | None
) -> np.ndarray:
    """
    Use the Schroeder method to compute the energy decay curve from the energy of a signal

    :param np.ndarray signal: The signal to compute the energy decay curve from
    :param int sampling_rate: The sampling rate of the signal
    :param float central_freq: The central frequency of the bandpass filter
    :return np.ndarray: The energy decay
    """
    if central_freq is None:
        energy = _compute_energy_of_unfiltered_signal(signal=signal, sampling_rate=sampling_rate)
    else:
        energy = _compute_energy_of_band_passed_signal(
            signal=signal, sampling_rate=sampling_rate, central_freq=central_freq
        )
    if len(energy.shape) > 1:
        return 10 * np.log10(
            np.flip(
                np.cumsum((np.flip(energy, axis=-1).T / np.sum(energy, axis=-1)).T, axis=-1),
                axis=-1,
            )
        )
    else:
        return 10 * np.log10(np.flip(np.cumsum(np.flip(energy) / np.sum(energy))))
