from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.simulation import ResultType


class IrType(str, Enum):
    """
    Available types for IR
    """

    mono = "mono"
    spatial = "spatial"
    device = "device"

    def get_normalization_string(self):
        if self.name == "mono":
            return "IR_normalization"
        elif self.name == "spatial":
            return "Spatial_IR_normalization"
        elif self.name == "device":
            return "Devive_normalization"


class IrSuffix(str, Enum):
    """
    IR suffixes for simulation types.
    """

    hybrid_mono = "hybrid_IR.wav"
    hybrid_spatial = "hybrid_Spatial_IR.wav"
    hybrid_device = "Hybrid_device.wav"
    dg_mono = "DG_IR_SC.wav"
    dg_spatial = "DG_IR_Spatial.wav"
    dg_device = "DG_device.wav"
    ga_mono = "GA_IR.wav"
    ga_spatial = "GA_spatial_IR.wav"
    ga_device = "GA_device.wav"

    @staticmethod
    def get_suffix(sim_type: "ResultType", ir_type: IrType) -> str:
        return getattr(IrSuffix, f"{sim_type.name}_{ir_type.value}")


class PointType(str, Enum):
    """
    Point types
    """

    source = "sources"
    receiver = "receivers"

    def get_singular(self):
        return self.value[0:-1]


class FrequencyPlotType(str, Enum):
    """
    Frequency plot types
    """

    mag = ("spl_mag",)
    dB = "spl_db"
    complex = ("complex",)


class AxisDefinition(str, Enum):
    """
    Axis definitions
    """

    frequency = ("Frequency band [Hz]",)
    sti = ("Noise criterion (NC) curve [dB]",)
    mtf = "mtf"


class ResultParameter(str, Enum):
    """
    Result parameters
    """

    EDT = "edt"
    T20 = ("t20",)
    T30 = ("t30",)
    C50 = ("c50",)
    C80 = ("c80",)
    D50 = ("d50",)
    TS = ("ts",)
    G = ("g",)
    SPL = ("spl",)
    STI = ("sti",)
    MTF = "mtf"

    @classmethod
    def print(cls):
        print("Available result parameters")
        for c in cls:
            print(f" - {c.value}")

    def _get_frequency_type(self) -> AxisDefinition:
        if self in [ResultParameter.STI]:
            return AxisDefinition.sti
        elif self in [ResultParameter.MTF]:
            return AxisDefinition.mtf
        else:
            return AxisDefinition.frequency

    def get_yaxis(self) -> str:
        if self in [ResultParameter.STI, ResultParameter.MTF, ResultParameter.D50]:
            return f"{self} []"
        if self in [ResultParameter.EDT, ResultParameter.T20, ResultParameter.T30, ResultParameter.TS]:
            return f"{self} [s]"
        if self in [ResultParameter.C50, ResultParameter.C80, ResultParameter.G]:
            return f"{self} [dB]"
        if self in [ResultParameter.SPL]:
            return f"{self} [dB] rel. 20 uPa"
