import importlib
from typing import TYPE_CHECKING
from .base_ir import BaseIR
import numpy as np

from ..treble_logging import logger

if TYPE_CHECKING:
    from .results import ReceiverResults, SourceResults


class MonoIR(BaseIR):
    """Mono impulse response class for handling impulse response data"""

    def __init__(
        self,
        data: np.ndarray,
        sampling_rate: float,
        time: np.ndarray = None,
        source: list["SourceResults"] = [],
        receiver: list["ReceiverResults"] = [],
        zero_pad_samples: int = 0,
        normalization_coefficient: float = None,
    ):
        if data.ndim == 2:
            if data.shape[0] > 1:
                logger.warning(
                    "Input is multichannel, selecting channel 0, use channel argument to select channel"
                )
            data = data[0]

        super().__init__(
            data=data,
            sampling_rate=sampling_rate,
            time=time,
            source=source,
            receiver=receiver,
            zero_pad_samples=zero_pad_samples,
            normalization_coefficient=normalization_coefficient,
        )

    def plot(self, comparison: dict[str, "MonoIR"] = None, label: str = None):
        """Plot the impulse response"""
        if comparison is not None:
            if not isinstance(comparison, dict):
                if not isinstance(comparison, list):
                    comparison = [comparison]
                if isinstance(comparison, list):
                    comparison = {f"IR {i + 1}": comparison[i] for i in range(len(comparison))}
        try:
            importlib.import_module("treble_tsdk.results.plot").plot_mono_ir(self, comparison, label)
        except ImportError:
            logger.warning("Result plotting module could not be imported, has it been installed?")
