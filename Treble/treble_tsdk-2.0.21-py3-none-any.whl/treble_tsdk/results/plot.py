from __future__ import annotations

import importlib
import os
from typing import TYPE_CHECKING

import dash
import numpy as np
import plotly.graph_objects as go
from dash import Dash, Input, Output, callback, ctx, dcc, html
import copy

from .filter_definition import OctaveBandFilter
from .result_utils import average_octave_bands

if TYPE_CHECKING:
    from ..core.simulation import SimulationType
    from .audio_signal import AudioSignal
    from .device_ir import DeviceIR
    from .mono_ir import MonoIR
    from .spatial_ir import SpatialIR
    from .results import Results

from ..treble_logging import logger

from ..ui_components.plot_utils import BackgroundColor, initialize_widget, try_run_app

# Define colors
TrebleGreen = "#39bd9d"
TrebleLightGreen = "#5bf6d1"
PlotBlue = "#4870ff"
PlotGreen = "#5bf6d1"
PlotPurple = "#d04aff"

PlotYellow = "#f2d367"
PlotPink = "#f66565"
PlotGray = "#dadada"

TextColor = "#f4f3f7"
GridColor = "rgba(89, 89, 89, 0.24)"
ZeroLineColor = "rgba(89, 89, 89, 0.94)"

LineColors = [PlotBlue, PlotGreen, PlotPurple, PlotYellow, PlotPink, PlotGray]
FrRangeMin = 20


def _get_assets_path():
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "assets"))


def _calculate_subplot_grid(num_plots, max_cols=4):
    # Calculate the number of columns and rows
    num_cols = min(num_plots, max_cols)
    if num_cols == 0:
        num_cols = 1
    num_rows = int(np.ceil(num_plots / num_cols))
    if num_rows == 0:
        num_rows = 1
    return num_rows, num_cols


def _delay_frf_samples(frf, n_samples: int) -> np.ndarray:
    return frf * np.exp(-1j * np.pi * np.arange(len(frf)) / (len(frf) - 1) * n_samples)


def __dash_button(label: str, id: str, style: dict[str, str] = None) -> html.Button:
    if style is None:
        style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "font-family": "Poppins-regular",
        }
    return html.Button(label, id=id, n_clicks=0, style=style)


def __dash_graph(id: str, style: dict[str, str] = None) -> dcc.Graph:
    if style is None:
        style = {"color": BackgroundColor}
    return dcc.Graph(id=id, style=style)


def multiresults_parameter_plot_widget(results: "Results"):
    """
    A widget which can plot acoustic parameters for multiple sources
    and receivers at a time

    :param Results results: Results object with the relevant information
    """
    parameter_names = [
        "edt",
        "t20",
        "t30",
        "c50",
        "c80",
        "d50",
        "ts",
        "g",
        "spl",
        "sti",
    ]
    frequencies = ["63", "125", "250", "500", "1000", "2000", "4000", "8000"]
    nc_curves = [
        "NC15",
        "NC20",
        "NC25",
        "NC30",
        "NC35",
        "NC40",
        "NC45",
        "NC50",
        "NC55",
        "NC60",
        "NC65",
        "NC70",
    ]
    param_to_label = {
        "edt": "Early Decay Time [s]",
        "t20": "T20 [s]",
        "t30": "T30 [s]",
        "c50": "C50 [dB]",
        "c80": "C80 [dB]",
        "d50": "D50 [dB]",
        "ts": "Center Time [s]",
        "g": "Strength [dB]",
        "spl": "SPL [dB]",
        "sti": "STI",
    }

    all_params = {}
    sourcedtos = results._simulation.sources
    receiverdtos = results._simulation.receivers
    for source in sourcedtos:
        all_params[source.id] = {}
        for receiver in receiverdtos:
            all_params[source.id][receiver.id] = results.get_acoustic_parameters(
                source=source, receiver=receiver
            )

    # Align frequency indices with the data
    lowest_freq_index = np.argmin(
        np.abs(
            int(all_params[sourcedtos[0].id][receiverdtos[0].id].center_bands[0])
            - np.array(list(map(int, frequencies)))
        )
    )

    app_content = [
        dcc.Store(id="memory-output"),
        html.H1(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-semibold",
            },
            children="Acoustic Parameters",
        ),
        html.Div(
            [
                html.P(
                    "Select source",
                    style={
                        "textAlign": "center",
                        "color": TextColor,
                        "font-family": "Poppins-regular",
                    },
                ),
                dcc.Dropdown(
                    [dict(label=x.label, value=x.id) for x in results._source_results.values()],
                    value=[next(iter(results._source_results.values())).id],
                    id="source-dropdown-ap",
                    multi=True,
                    searchable=True,
                    style={
                        "backgroundColor": BackgroundColor,
                        "font-family": "Poppins-regular",
                    },
                ),
            ],
            style={
                "width": "50%",
                "display": "inline-block",
            },
        ),
        html.Div(
            [
                html.P(
                    "Select receiver",
                    style={
                        "textAlign": "center",
                        "color": TextColor,
                        "font-family": "Poppins-regular",
                    },
                ),
                dcc.Dropdown(
                    [dict(label=x.label, value=x.id) for x in results._receiver_results.values()],
                    value=[next(iter(results._receiver_results.values())).id],
                    id="receiver-dropdown-ap",
                    multi=True,
                    searchable=True,
                    style={
                        "backgroundColor": BackgroundColor,
                        "font-family": "Poppins-regular",
                    },
                ),
            ],
            style={
                "width": "50%",
                "float": "right",
                "display": "inline-block",
            },
        ),
        html.Div(
            [
                __dash_button(
                    label=param.upper(),
                    id=f"multibutton-{param}",
                    style={
                        "background-color": BackgroundColor,
                        "color": TextColor,
                        "font-family": "Poppins-regular",
                        "margin-left": "5px",
                        "margin-right": "5px",
                    },
                )
                for param in parameter_names
            ],
            style={
                "padding-top": "15px",
                "color": BackgroundColor,
                "width": "100%",
                "text-align": "center",
            },
        ),
        html.Div(
            [
                dcc.Graph(
                    id="multiparameter-plot",
                    style={"color": BackgroundColor, "height": "500px"},
                ),
            ]
        ),
    ]
    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @callback(
        Output("multiparameter-plot", "figure"),
        [Output(f"multibutton-{name}", "style") for name in parameter_names],
        Output("memory-output", "data"),
        Input("source-dropdown-ap", "value"),
        Input("receiver-dropdown-ap", "value"),
        Input("memory-output", "data"),
        [Input(f"multibutton-{name}", "n_clicks") for name in parameter_names],
    )
    def update_graph(sources, receivers, memory, *args):
        ctx = dash.callback_context
        if not ctx.triggered:
            button_id = "multibutton-t20"
        elif "multibutton" in ctx.triggered[0]["prop_id"].split(".")[0]:
            button_id = ctx.triggered[0]["prop_id"].split(".")[0]
        else:
            button_id = memory
        param_name = button_id.replace("multibutton-", "")

        on_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": TrebleLightGreen,
            "font-family": "Poppins-regular",
        }
        off_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": BackgroundColor,
            "font-family": "Poppins-regular",
        }

        style = {
            f"multibutton-{name}": on_style if name == param_name else off_style for name in parameter_names
        }

        fig = go.Figure()
        plot_data = []

        for source_id in sources:
            for receiver_id in receivers:
                data = copy.deepcopy(all_params[source_id][receiver_id].get(param_name, []))
                if param_name != "sti":
                    for i in range(lowest_freq_index):
                        data.insert(0, None)
                    if len(data) < len(frequencies):
                        data.extend([None] * (len(frequencies) - len(data)))

                numeric_data = [val if val is not None else None for val in data]
                plot_data.append(
                    go.Bar(
                        x=frequencies if param_name != "sti" else nc_curves,
                        y=numeric_data,
                        text=["" if val is not None else "N/A" for val in numeric_data],
                        textposition="outside",
                        name=f"{results._id_label_source[source_id]} - {results._id_label_rec[receiver_id]}",
                        marker=dict(
                            line=dict(width=0),
                        ),
                        textfont=dict(color=TrebleGreen),  # Set the color for the text here
                    )
                )

        fig = go.Figure(
            data=plot_data,
            layout=go.Layout(
                font=dict(color=TextColor, family="Poppins-regular"),
                yaxis=dict(gridcolor=GridColor),
                xaxis=dict(
                    tickmode="array",
                    tickvals=frequencies if param_name != "sti" else nc_curves,
                    ticktext=frequencies if param_name != "sti" else nc_curves,
                    gridcolor=GridColor,
                ),
                xaxis_title="Frequency (Hz)" if param_name != "sti" else "Noise Criterion",
                yaxis_title=param_to_label[param_name],
                barmode="group",
                colorway=LineColors,
                paper_bgcolor=BackgroundColor,
                plot_bgcolor=BackgroundColor,
            ),
        )

        return [fig] + [style[f"multibutton-{name}"] for name in parameter_names] + [button_id]

    try_run_app(app, height=700)


def results_parameters_plot_widget(parameter_data: "AcousticParameters"):
    parameter_names = [
        "edt",
        "t20",
        "t30",
        "c50",
        "c80",
        "d50",
        "ts",
        "g",
        "spl",
        "sti",
    ]
    frequencies = ["63", "125", "250", "500", "1000", "2000", "4000", "8000"]
    nc_curves = [
        "NC15",
        "NC20",
        "NC25",
        "NC30",
        "NC35",
        "NC40",
        "NC45",
        "NC50",
        "NC55",
        "NC60",
        "NC65",
        "NC70",
    ]
    param_to_label = {
        "edt": "Early Decay Time [s]",
        "t20": "T20 [s]",
        "t30": "T30 [s]",
        "c50": "C50 [dB]",
        "c80": "C80 [dB]",
        "d50": "D50 [dB]",
        "ts": "Center Time [s]",
        "g": "Strength [dB]",
        "spl": "SPL [dB]",
        "sti": "STI",
    }

    # Align frequency indices with the data
    if parameter_data.center_bands is not None:
        lowest_freq_index = np.argmin(
            np.abs(int(parameter_data.center_bands[0]) - np.array(list(map(int, frequencies))))
        )
    else:
        lowest_freq_index = 0

    select_param_div = [
        html.P(
            "Select parameter",
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-regular",
            },
        ),
    ]
    select_param_div.extend(
        [
            html.Button(
                name,
                id=f"button-{name}",
                style={
                    "background-color": BackgroundColor,
                    "color": TextColor,
                    "font-family": "Poppins-regular",
                    "margin-left": "15px",
                    "margin-bottom": "20px",
                },
            )
            for name in parameter_names
        ]
    )

    app_content = [
        dcc.Store(id="memory-output"),
        html.H1(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-semibold",
            },
            children="Acoustic Parameters",
        ),
        html.Div(
            select_param_div,
            style={
                "width": "100%",
                "display": "inline-block",
            },
        ),
        html.Div(
            [
                dcc.Graph(
                    id="parameter-plot",
                    style={
                        "backgroundColor": BackgroundColor,
                        "font-family": "Poppins-regular",
                    },
                ),
            ]
        ),
    ]

    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @app.callback(
        Output("parameter-plot", "figure"),
        [Output(f"button-{name}", "style") for name in parameter_names],
        [Input(f"button-{name}", "n_clicks") for name in parameter_names],
    )
    def update_graph(*args):
        ctx = dash.callback_context
        if not ctx.triggered:
            button_id = "button-t20"
        else:
            button_id = ctx.triggered[0]["prop_id"].split(".")[0]
        param_name = button_id.replace("button-", "")

        on_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": TrebleLightGreen,
            "font-family": "Poppins-regular",
        }
        off_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": BackgroundColor,
            "font-family": "Poppins-regular",
        }

        style = {f"button-{name}": on_style if name == param_name else off_style for name in parameter_names}

        data = parameter_data.get(param_name, [])

        if param_name != "sti":
            # Ensure the data is aligned with frequencies, filling in None for missing values
            if lowest_freq_index != 0:
                for i in range(lowest_freq_index):
                    data.insert(0, None)
            if len(data) < len(frequencies):
                data.extend([None] * (len(frequencies) - len(data)))

        numeric_data = [val if val is not None else None for val in data]

        fig = go.Figure()
        fig.add_trace(
            go.Bar(
                x=frequencies if param_name != "sti" else nc_curves,
                y=[val if val is not None else 0 for val in numeric_data],
                text=["" if val is not None else "N/A" for val in numeric_data],
                textposition="outside",
                name=param_name,
                marker=dict(
                    color=["#4870ff" if val is not None else "rgba(0,0,0,0)" for val in numeric_data],
                    line=dict(width=0),
                ),
            )
        )

        fig.update_layout(
            title=f"Values for {param_name}",
            xaxis_title="Frequency (Hz)" if param_name != "sti" else "Noise Criterion",
            yaxis_title=param_to_label[param_name],
            xaxis=dict(
                tickmode="array",
                tickvals=frequencies if param_name != "sti" else nc_curves,
                ticktext=frequencies if param_name != "sti" else nc_curves,
                gridcolor=GridColor,
            ),
            yaxis=dict(gridcolor=GridColor),
            barmode="group",
            colorway=LineColors,
            paper_bgcolor=BackgroundColor,
            plot_bgcolor=BackgroundColor,
            font=dict(color="#f4f3f7"),
        )
        return [fig] + [style[f"button-{name}"] for name in parameter_names]

    try_run_app(app)


def result_plot_widget(results: "Results"):
    """
    A widget where results of a simulation can be plotted in an interactive widget

    :param Results results: The results object from a certain simulation
    """
    sr = next(iter(results._source_results.values()))
    frequencies = list(map(int, sr.result_metadata["frequencies"]))
    filters = []
    for freq in frequencies:
        filters.append(OctaveBandFilter(center_frequency=freq, octave_fraction=1))
    all_mono_irs = {}
    all_edc = {}
    for source in results._simulation.sources:
        all_mono_irs[source.id] = {}
        all_edc[source.id] = {}
        for receiver in results._simulation.receivers:
            all_mono_irs[source.id][receiver.id] = results.get_mono_ir(source=source, receiver=receiver)
            all_edc[source.id][receiver.id] = {}
            for _i, freq in enumerate(frequencies):
                filtered_mono = all_mono_irs[source.id][receiver.id].filter(filters[_i])
                all_edc[source.id][receiver.id][freq] = filtered_mono._compute_edc(
                    center_frequency=freq, unpadded=True
                )

    app_content = [
        dcc.Store(id="smoothing-dropdown-memory"),
        dcc.Store(id="edc-dropdown-memory"),
        dcc.Store(id="memory-output"),
        html.H1(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-semibold",
            },
            children="Results",
        ),
        html.Div(
            [
                html.P(
                    "Select source",
                    style={
                        "textAlign": "center",
                        "color": TextColor,
                        "font-family": "Poppins-regular",
                    },
                ),
                dcc.Dropdown(
                    [dict(label=x.label, value=x.id) for x in results._source_results.values()],
                    value=[next(iter(results._source_results.values())).id],
                    id="source-dropdown",
                    multi=True,
                    searchable=True,
                    style={
                        "backgroundColor": BackgroundColor,
                        "font-family": "Poppins-regular",
                    },
                ),
            ],
            style={
                "width": "50%",
                "display": "inline-block",
            },
        ),
        html.Div(
            [
                html.P(
                    "Select receiver",
                    style={
                        "textAlign": "center",
                        "color": TextColor,
                        "font-family": "Poppins-regular",
                    },
                ),
                dcc.Dropdown(
                    [dict(label=x.label, value=x.id) for x in results._receiver_results.values()],
                    value=[next(iter(results._receiver_results.values())).id],
                    id="receiver-dropdown",
                    multi=True,
                    searchable=True,
                    style={
                        "backgroundColor": BackgroundColor,
                        "font-family": "Poppins-regular",
                    },
                ),
            ],
            style={
                "width": "50%",
                "float": "right",
                "display": "inline-block",
            },
        ),
        html.Div(
            [
                __dash_button(label="Impulse Response", id="impulse-results"),
                __dash_button(label="Frequency Response", id="frequency-results"),
                __dash_button(label="Phase Response", id="phase-results"),
                __dash_button(label="Energy Decay", id="edc-results"),
            ],
            style={"padding-top": "15px", "color": BackgroundColor},
        ),
        html.Div(
            [
                dcc.Dropdown(
                    options=[
                        {"label": "No smoothing", "value": "no smoothing"},
                        {"label": "1/3 Octave bands", "value": 3},
                        {"label": "1/6 Octave bands", "value": 6},
                        {"label": "1/12 Octave bands", "value": 12},
                        {"label": "1/24 Octave bands", "value": 24},
                    ],
                    value="no smoothing",
                    id="octavebands-dropdown",
                    searchable=False,
                    placeholder="Select fractional octave-band smoothing",
                )
            ],
            style={
                "width": "50%",
            },
        ),
        html.Div(
            [
                dcc.Dropdown(
                    options=[{"label": f"{f} Hz", "value": f} for f in frequencies],
                    value=frequencies[0],
                    id="edc-dropdown",
                    searchable=False,
                    multi=True,
                    placeholder="Select octave bands",
                )
            ],
            style={
                "width": "50%",
            },
        ),
        html.Div(
            [
                dcc.Graph(
                    id="results-plot",
                    style={"color": BackgroundColor, "height": "600px"},
                ),
            ]
        ),
    ]
    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    # (__dash_button(label="Impulse Response", id="impulse-results"),)
    # (__dash_button(label="Frequency Response", id="frequency-results"),)
    # (__dash_button(label="Spectrogram", id="spectrogram-results"),)
    # (__dash_button(label="Waterfall", id="waterfall-plots"),)

    @app.callback(
        Output("octavebands-dropdown", "style"),
        Output("edc-dropdown", "style"),
        Input("impulse-results", "n_clicks_timestamp"),
        Input("frequency-results", "n_clicks_timestamp"),
        Input("phase-results", "n_clicks_timestamp"),
        Input("edc-results", "n_clicks_timestamp"),
    )
    def update_dropdown(stamp_1, stamp_2, stamp_3, stamp_4):
        stamp_1 = stamp_1 or 0
        stamp_2 = stamp_2 or 0
        stamp_3 = stamp_3 or 0
        stamp_4 = stamp_4 or 0
        timestamps = {
            "impulse-results": stamp_1,
            "frequency-results": stamp_2,
            "phase-results": stamp_3,
            "edc-results": stamp_4,
        }
        latest_button = max(timestamps, key=timestamps.get)
        freq_drop_style = {"display": "none"}
        edc_drop_style = {"display": "none"}
        if latest_button == "frequency-results":
            freq_drop_style = {
                "display": "block",
                "font-family": "Poppins-regular",
                "fontSize": "13px",
            }
            edc_drop_style = {"display": "none"}

        elif latest_button == "edc-results":
            freq_drop_style = {"display": "none"}

            edc_drop_style = {
                "display": "block",
                "font-family": "Poppins-regular",
                "fontSize": "13px",
            }

        else:
            freq_drop_style = {"display": "none"}
            edc_drop_style = {"display": "none"}

        return freq_drop_style, edc_drop_style

    @callback(
        Output("results-plot", "figure"),
        Output("impulse-results", "style"),
        Output("frequency-results", "style"),
        Output("phase-results", "style"),
        Output("edc-results", "style"),
        Output("memory-output", "data"),
        Input("source-dropdown", "value"),
        Input("receiver-dropdown", "value"),
        Input("impulse-results", "n_clicks"),
        Input("frequency-results", "n_clicks"),
        Input("phase-results", "n_clicks"),
        Input("edc-results", "n_clicks"),
        Input("octavebands-dropdown", "value"),
        Input("edc-dropdown", "value"),
        Input("memory-output", "data"),
    )
    def update_result_plot_widget(
        sources, receivers, impulse, frequency, phase, edc, smoothing, edc_bands, memory
    ):
        data = []

        on_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": TrebleLightGreen,
            "font-family": "Poppins-regular",
        }
        off_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": BackgroundColor,
            "font-family": "Poppins-regular",
        }
        if smoothing == "no smoothing":
            smoothing = None

        # Initialize styles
        time_style = off_style
        freq_style = off_style
        phase_style = off_style
        edc_style = off_style
        # Preserving the state
        if impulse + frequency + phase + edc == 0:
            plot = "time"
            time_style = on_style

        elif ctx.triggered_id not in [
            "impulse-results",
            "frequency-results",
            "phase-results",
            "edc-results",
        ]:
            plot = memory
            time_style = on_style if plot == "time" else off_style
            freq_style = on_style if plot == "frequency" else off_style
            phase_style = on_style if plot == "phase" else off_style
            edc_style = on_style if plot == "edc" else off_style

        if "impulse-results" == ctx.triggered_id:
            plot = "time"
            time_style = on_style
        elif "frequency-results" == ctx.triggered_id:
            plot = "frequency"
            freq_style = on_style
        elif "phase-results" == ctx.triggered_id:
            plot = "phase"
            phase_style = on_style
        elif "edc-results" == ctx.triggered_id:
            plot = "edc"
            edc_style = on_style

        for source in sources:
            for receiver in receivers:
                # Smooth frequency response
                frac_band_range = (20, 14000)
                if plot == "frequency" and smoothing is not None:
                    octave_bands, smoothed_frequency_response = average_octave_bands(
                        all_mono_irs[source][receiver].frequency,
                        all_mono_irs[source][receiver].frequency_response,
                        smoothing,
                        frac_band_range,
                    )

                if plot in ["time", "frequency", "phase"]:
                    if plot == "time":
                        y = all_mono_irs[source][receiver].data
                    elif plot == "frequency":
                        y = (
                            20 * np.log10(np.abs(all_mono_irs[source][receiver].frequency_response)) + 94
                            if smoothing is None
                            else 20 * np.log10(np.abs(smoothed_frequency_response)) + 94
                        )
                    else:
                        y = np.round(
                            np.rad2deg(
                                np.angle(
                                    _delay_frf_samples(
                                        all_mono_irs[source][receiver].frequency_response,
                                        -all_mono_irs[source][receiver].zero_pad_samples,
                                    )
                                )
                            ),
                            6,
                        )

                    data.append(
                        go.Scatter(
                            x=(
                                all_mono_irs[source][receiver].time
                                if plot == "time"
                                else (
                                    all_mono_irs[source][receiver].frequency
                                    if smoothing is None
                                    else octave_bands
                                )
                            ),
                            y=y,
                            mode=("lines" if plot == "time" or smoothing is None else "lines+markers"),
                            name=f"{results._id_label_source[source]}_{results._id_label_rec[receiver]}",
                        )
                    )
                elif plot == "edc":
                    if not isinstance(edc_bands, list):
                        edc_bands = [edc_bands]
                    for freq in edc_bands:
                        data.append(
                            go.Scatter(
                                x=all_mono_irs[source][receiver].unpadded_time(),
                                y=all_edc[source][receiver][freq],
                                mode="lines",
                                name=f"{results._id_label_source[source]}_{results._id_label_rec[receiver]}_{freq}Hz",
                            )
                        )
        if plot == "time":
            fig_title = "Amplitude"
        elif plot == "phase":
            fig_title = "Phase [degrees]"
        else:
            fig_title = "Magnitude [dB]"

        fig = go.Figure(
            data=data,
            layout=go.Layout(
                font=dict(color=TextColor, family="Poppins-regular"),
                yaxis=dict(
                    title=fig_title,
                    gridcolor=GridColor,
                    zerolinewidth=2,
                    zerolinecolor=ZeroLineColor,
                ),
                xaxis=dict(
                    title="Time [s]" if plot in ["time", "edc"] else "Frequency [Hz]",
                    gridcolor=GridColor,
                    zeroline=False,
                    # rangeslider=dict(visible=True if plot == "time" else False),
                    type="linear" if plot in ["time", "edc"] else "log",
                    autorange="min" if not plot == "time" else True,
                    autorangeoptions=(
                        dict(minallowed=np.log10(FrRangeMin)) if plot in ["frequency", "phase"] else None
                    ),
                ),
                colorway=LineColors,
                paper_bgcolor=BackgroundColor,
                plot_bgcolor=BackgroundColor,
            ),
        )

        return fig, time_style, freq_style, phase_style, edc_style, plot

    try_run_app(app, height=800)


def plot_multichannel_data(
    device: "DeviceIR" | "AudioSignal",
    comparison: dict[str, "DeviceIR" | "AudioSignal"] = None,
    title: str = "Device Impulse Response",
    channel_label: str = "Device mic ",
    label: str = None,
):
    def fetch_label(ir_obj, input_label=None):
        if input_label is not None:
            return input_label
        if ir_obj._source is None or len(ir_obj._source) == 0:
            return ""
        else:
            return " + ".join(
                [
                    f"{ir_obj._source[i].label} - {ir_obj._receiver[i].label}"
                    for i in range(len(ir_obj._source))
                ]
            )

    irs = [device]
    labels = [fetch_label(device, label) + f": {channel_label}"]
    if comparison is not None:
        for label, comp in comparison.items():
            irs.append(comp)
            labels.append(fetch_label(comp, label) + f": {channel_label}")

    edc_filters = {}
    frequencies = ["63", "125", "250", "500", "1000", "2000", "4000", "8000"]

    for ir in irs:
        if ir._source is not None:
            for src in ir._source:
                freqs = frequencies.copy()
                for f in freqs:
                    if f not in src.result_metadata["frequencies"]:
                        del frequencies[frequencies.index(f)]

    for freq in frequencies:
        edc_filters[freq] = OctaveBandFilter(center_frequency=float(freq), octave_fraction=1)

    app_content = [
        dcc.Store(id="memory-output"),
        html.H1(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-semibold",
            },
            children=title,
        ),
        __dash_button(label="Impulse Response", id="impulse-multi"),
        __dash_button(label="Frequency Response", id="frequency-multi"),
        __dash_button(label="Phase Response", id="phase-multi"),
        __dash_button(label="EDC Response", id="edc-multi"),
        html.Div(
            [
                html.Div(
                    [
                        dcc.Dropdown(
                            options=[
                                {"label": "No smoothing", "value": "no smoothing"},
                                {"label": "1/3 Octave bands", "value": 3},
                                {"label": "1/6 Octave bands", "value": 6},
                                {"label": "1/12 Octave bands", "value": 12},
                                {"label": "1/24 Octave bands", "value": 24},
                            ],
                            value="no smoothing",
                            id="octavebands-dropdown-multi",
                            searchable=False,
                            placeholder="Select fractional octave-band smoothing",
                        )
                    ],
                    style={
                        "width": "50%",
                    },
                ),
                html.Div(
                    [
                        dcc.Dropdown(
                            options=[{"label": "Broadband", "value": "None"}]
                            + [{"label": f"{f} Hz", "value": f} for f in frequencies],
                            value="None",
                            id="edc-dropdown-multi",
                            searchable=False,
                            placeholder="Select edc frequency",
                        )
                    ],
                    style={
                        "width": "50%",
                    },
                ),
                __dash_graph(id="device-results-plot"),
            ]
        ),
    ]
    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @app.callback(
        Output("octavebands-dropdown-multi", "style"),
        Output("edc-dropdown-multi", "style"),
        Input("impulse-multi", "n_clicks_timestamp"),
        Input("frequency-multi", "n_clicks_timestamp"),
        Input("phase-multi", "n_clicks_timestamp"),
        Input("edc-multi", "n_clicks_timestamp"),
    )
    def update_dropdown(time_timestamp, frequency_timestamp, phase_timestamp, edc_timestamp):
        latest_button = get_latest_button(
            {
                "impulse-multi": time_timestamp,
                "frequency-multi": frequency_timestamp,
                "phase-multi": phase_timestamp,
                "edc-multi": edc_timestamp,
            }
        )
        freq_drop_style = {"display": "none"}
        edc_dropstyle = {"display": "none"}
        if latest_button in ["frequency-multi"]:
            freq_drop_style = {
                "display": "block",
                "font-family": "Poppins-regular",
                "fontSize": "13px",
            }
        if latest_button in ["edc-multi"]:
            edc_dropstyle = {
                "display": "block",
                "font-family": "Poppins-regular",
                "fontSize": "13px",
            }

        return freq_drop_style, edc_dropstyle

    @callback(
        Output("device-results-plot", "figure"),
        Output("impulse-multi", "style"),
        Output("frequency-multi", "style"),
        Output("phase-multi", "style"),
        Output("edc-multi", "style"),
        Input("impulse-multi", "n_clicks_timestamp"),
        Input("frequency-multi", "n_clicks_timestamp"),
        Input("phase-multi", "n_clicks_timestamp"),
        Input("edc-multi", "n_clicks_timestamp"),
        Input("octavebands-dropdown-multi", "value"),
        Input("edc-dropdown-multi", "value"),
    )
    def update_device_plot_widget(
        time_timestamp, frequency_timestamp, phase_timestamp, edc_timestamp, smoothing, edc_value
    ):
        latest_button = get_latest_button(
            {
                "impulse-multi": time_timestamp,
                "frequency-multi": frequency_timestamp,
                "phase-multi": phase_timestamp,
                "edc-multi": edc_timestamp,
            }
        )
        on_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": TrebleLightGreen,
            "font-family": "Poppins-regular",
        }
        off_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": BackgroundColor,
            "font-family": "Poppins-regular",
        }

        data = []
        time_style = off_style
        freq_style = off_style
        phase_style = off_style
        edc_style = off_style

        if latest_button == "impulse-multi":
            time = True
            time_style = on_style
            fig_title = "Amplitude"
            for ir, label in zip(irs, labels):
                for i_channel, channel in enumerate(ir.data):
                    data.append(
                        go.Scatter(
                            x=ir.time,
                            y=channel,
                            mode="lines",
                            name=label + f" {i_channel + 1}",
                        )
                    )
        elif latest_button == "frequency-multi":
            time = False
            freq_style = on_style
            fig_title = "Amplitude [dB SPL rel. 20μPa]"
            for ir, label in zip(irs, labels):
                for i_channel, channel_fr in enumerate(ir.frequency_response):
                    if smoothing == "no smoothing":
                        data.append(
                            go.Scatter(
                                x=ir.frequency,
                                y=20 * np.log10(np.abs(channel_fr)) + 94,
                                mode="lines",
                                name=label + f" {i_channel + 1}",
                            )
                        )

                    else:
                        frac_band_range = (20, 14000)
                        octave_bands, smoothed_frequency_response = average_octave_bands(
                            ir.frequency,
                            channel_fr,
                            smoothing,
                            frac_band_range,
                        )

                        data.append(
                            go.Scatter(
                                x=octave_bands,
                                y=20 * np.log10(np.abs(smoothed_frequency_response)) + 94,
                                mode="lines+markers",
                                name=label + f" {i_channel + 1}",
                            )
                        )
        elif latest_button == "phase-multi":
            time = False
            phase_style = on_style
            fig_title = "Phase [degrees]"
            for ir, label in zip(irs, labels):
                for i_channel, channel_fr in enumerate(ir.frequency_response):
                    phase_angle = np.angle(_delay_frf_samples(channel_fr, -ir.zero_pad_samples))
                    data.append(
                        go.Scatter(
                            x=ir.frequency,
                            y=np.round(
                                np.rad2deg(phase_angle),
                                6,
                            ),
                            mode="lines",
                            name=label + f" {i_channel + 1}",
                        )
                    )

        elif latest_button == "edc-multi":
            time = True
            edc_style = on_style
            fig_title = "EDC [dB]"
            for ir, label in zip(irs, labels):
                for i_channel in range(ir.frequency_response.shape[0]):
                    if edc_value != "None":
                        ir = ir.filter(edc_filters[edc_value])
                        edc_float_value = float(edc_value)
                    else:
                        edc_float_value = None

                    edc = ir._compute_edc(center_frequency=edc_float_value, unpadded=True)
                    data.append(
                        go.Scatter(
                            x=ir.unpadded_time(),
                            y=edc[i_channel],
                            mode="lines",
                            name=label + f" {i_channel + 1}",
                        )
                    )

        fig = go.Figure(
            data=data,
            layout=go.Layout(
                font=dict(color=TextColor, family="Poppins-regular"),
                yaxis=dict(
                    title=fig_title,
                    gridcolor=GridColor,
                    zerolinewidth=2,
                    zerolinecolor=ZeroLineColor,
                ),
                xaxis=dict(
                    title="Time [s]" if time else "Frequency [hz]",
                    gridcolor=GridColor,
                    zeroline=False,
                    # rangeslider=dict(visible=True if time else False),
                    type="linear" if time else "log",
                    autorangeoptions=dict(minallowed=np.log10(FrRangeMin)) if not time else None,
                ),
                colorway=LineColors,
                paper_bgcolor=BackgroundColor,
                plot_bgcolor=BackgroundColor,
            ),
        )

        return fig, time_style, freq_style, phase_style, edc_style

    try_run_app(app)


def plot_spatial_ir(impulse_response: "SpatialIR", channel_range: tuple[int, int] = (0, 8)):
    if channel_range[0] < 0:
        raise ValueError("Channel range must start from 0 or higher")
    if channel_range[1] < channel_range[0]:
        raise ValueError("Channel range should be in increasing order")
    if channel_range[1] > impulse_response.data.shape[0]:
        channel_range = (channel_range[0], impulse_response.data.shape[0])
    if channel_range[1] - channel_range[0] > 64:
        raise ValueError("Too many channels to plot at once. Maximum is 64")
    cr = channel_range  # Shorthand
    time_data = [
        go.Scatter(
            x=impulse_response.time,
            y=impulse_response.data[_i, :],
            mode="lines",
            name=f"Channel_{_i + 1}",
        )
        for _i in range(cr[0], cr[1] + 1)
    ]
    frequency_data = [
        go.Scatter(
            x=impulse_response.frequency,
            y=20 * np.log10(np.abs(impulse_response.frequency_response[_i, :])) + 94,
            mode="lines",
            name=f"Channel_{_i + 1}",
        )
        for _i in range(cr[0], cr[1] + 1)
    ]
    phase_data = [
        go.Scatter(
            x=impulse_response.frequency,
            y=np.round(
                np.rad2deg(
                    np.angle(
                        _delay_frf_samples(
                            impulse_response.frequency_response[_i, :],
                            -impulse_response.zero_pad_samples,
                        )
                    )
                ),
                6,
            ),
            mode="lines",
            name=f"Channel_{_i + 1}",
        )
        for _i in range(cr[0], cr[1] + 1)
    ]

    app_content = [
        html.H1(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-semibold",
            },
            children="Spatial Impulse Response",
        ),
        __dash_button(label="Impulse Response", id="impulse-spatial"),
        __dash_button(label="Frequency Response", id="frequency-spatial"),
        __dash_button(label="Phase Response", id="phase-spatial"),
        html.Div(
            [
                __dash_graph(id="spatial-results-plot"),
            ]
        ),
    ]

    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @callback(
        Output("spatial-results-plot", "figure"),
        Output("impulse-spatial", "style"),
        Output("frequency-spatial", "style"),
        Output("phase-spatial", "style"),
        Input("impulse-spatial", "n_clicks"),
        Input("frequency-spatial", "n_clicks"),
        Input("phase-spatial", "n_clicks"),
    )
    def update_spatial_plot_widget(impulse, frequency, phase):
        data = time_data
        time = True
        on_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": TrebleLightGreen,
            "font-family": "Poppins-regular",
        }
        off_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": BackgroundColor,
            "font-family": "Poppins-regular",
        }
        time_style = on_style
        freq_style = off_style
        phase_style = off_style
        if impulse + frequency + phase == 0:
            plot = "time"
            time_style = on_style
            time = True
            data = time_data
        if "impulse-spatial" == ctx.triggered_id:
            plot = "time"
            data = time_data
            time = True
            time_style = on_style
            freq_style = off_style
            phase_style = off_style
        if "frequency-spatial" == ctx.triggered_id:
            plot = "frequency"
            data = frequency_data
            time = False
            freq_style = on_style
            time_style = off_style
            phase_style = off_style
        if "phase-spatial" == ctx.triggered_id:
            plot = "phase"
            data = phase_data
            time = False
            phase_style = on_style
            freq_style = off_style
            time_style = off_style

        if plot == "time":
            fig_title = "Amplitude"
        elif plot == "frequency":
            fig_title = "Amplitude [dB SPL rel. 20μPa]"
        else:
            fig_title = "Phase [degrees]"

        fig = go.Figure(
            data=data,
            layout=go.Layout(
                font=dict(color=TextColor, family="Poppins-regular"),
                yaxis=dict(
                    title=fig_title,
                    gridcolor=GridColor,
                    zerolinewidth=2,
                    zerolinecolor=ZeroLineColor,
                ),
                xaxis=dict(
                    title="Time [s]" if time else "Frequency [hz]",
                    gridcolor=GridColor,
                    zeroline=False,
                    # rangeslider=dict(visible=True if time else False),
                    type="linear" if time else "log",
                    autorangeoptions=dict(minallowed=np.log10(FrRangeMin)) if not time else None,
                ),
                colorway=LineColors,
                paper_bgcolor=BackgroundColor,
                plot_bgcolor=BackgroundColor,
            ),
        )
        return fig, time_style, freq_style, phase_style

    try_run_app(app)


def plot_mono_ir(impulse_response: "MonoIR", comparison: dict[str, "MonoIR"] = None, label=None):
    def fetch_mono_label(ir_obj, input_label=None):
        if input_label is not None:
            return input_label
        if ir_obj._source is None or len(ir_obj._source) == 0:
            return ""
        else:
            return " + ".join(
                [
                    f"{ir_obj._source[i].label} - {ir_obj._receiver[i].label}"
                    for i in range(len(ir_obj._source))
                ]
            )

    irs = [impulse_response]
    labels = [fetch_mono_label(impulse_response, label)]
    if comparison is not None:
        for label, comp in comparison.items():
            irs.append(comp)
            labels.append(fetch_mono_label(comp, label))

    edc_filters = {}
    frequencies = ["63", "125", "250", "500", "1000", "2000", "4000", "8000"]
    for ir in irs:
        if ir._source is not None:
            for src in ir._source:
                freqs = frequencies.copy()
                for f in freqs:
                    if f not in src.result_metadata["frequencies"]:
                        del frequencies[frequencies.index(f)]

    for freq in frequencies:
        edc_filters[freq] = OctaveBandFilter(center_frequency=float(freq), octave_fraction=1)

    app_content = [
        dcc.Store(id="memory-output"),
        html.H1(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-regular",
            },
            children="Mono Impulse Response",
        ),
        __dash_button(label="Impulse Response", id="impulse-mono"),
        __dash_button(label="Frequency Response", id="frequency-mono"),
        __dash_button(label="Phase Response", id="phase-mono"),
        __dash_button(label="EDC", id="edc-mono"),
        html.Div(
            [
                dcc.Dropdown(
                    options=[
                        {"label": "No smoothing", "value": "no smoothing"},
                        {"label": "1/3 Octave bands", "value": 3},
                        {"label": "1/6 Octave bands", "value": 6},
                        {"label": "1/12 Octave bands", "value": 12},
                        {"label": "1/24 Octave bands", "value": 24},
                    ],
                    value="no smoothing",
                    id="octavebands-dropdown-mono",
                    searchable=False,
                    placeholder="Select fractional octave-band smoothing",
                )
            ],
            style={
                "width": "50%",
            },
        ),
        html.Div(
            [
                dcc.Dropdown(
                    options=[{"label": "Broadband", "value": "None"}]
                    + [{"label": f"{f} Hz", "value": f} for f in frequencies],
                    value="None",
                    id="edc-dropdown-mono",
                    searchable=False,
                    placeholder="Select edc frequency",
                )
            ],
            style={
                "width": "50%",
            },
        ),
        html.Div(
            [
                __dash_graph(id="mono-results-plot"),
            ]
        ),
    ]
    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @app.callback(
        Output("octavebands-dropdown-mono", "style"),
        Output("edc-dropdown-mono", "style"),
        Input("impulse-mono", "n_clicks_timestamp"),
        Input("frequency-mono", "n_clicks_timestamp"),
        Input("phase-mono", "n_clicks_timestamp"),
        Input("edc-mono", "n_clicks_timestamp"),
    )
    def update_dropdown(time_timestamp, frequency_timestamp, phase_timestamp, edc_timestamp):
        latest_button = get_latest_button(
            {
                "impulse-mono": time_timestamp,
                "frequency-mono": frequency_timestamp,
                "phase-mono": phase_timestamp,
                "edc-mono": edc_timestamp,
            }
        )
        freq_drop_style = {"display": "none"}
        edc_dropstyle = {"display": "none"}
        if latest_button in ["frequency-mono"]:
            freq_drop_style = {
                "display": "block",
                "font-family": "Poppins-regular",
                "fontSize": "13px",
            }
        if latest_button in ["edc-mono"]:
            edc_dropstyle = {
                "display": "block",
                "font-family": "Poppins-regular",
                "fontSize": "13px",
            }

        return freq_drop_style, edc_dropstyle

    @callback(
        Output("mono-results-plot", "figure"),
        Output("impulse-mono", "style"),
        Output("frequency-mono", "style"),
        Output("phase-mono", "style"),
        Output("edc-mono", "style"),
        Input("impulse-mono", "n_clicks_timestamp"),
        Input("frequency-mono", "n_clicks_timestamp"),
        Input("phase-mono", "n_clicks_timestamp"),
        Input("edc-mono", "n_clicks_timestamp"),
        Input("octavebands-dropdown-mono", "value"),
        Input("edc-dropdown-mono", "value"),
    )
    def update_mono_plot_widget(
        time_timestamp, frequency_timestamp, phase_timestamp, edc_timestamp, smoothing, edc_value
    ):
        latest_button = get_latest_button(
            {
                "impulse-mono": time_timestamp,
                "frequency-mono": frequency_timestamp,
                "phase-mono": phase_timestamp,
                "edc-mono": edc_timestamp,
            }
        )
        on_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": TrebleLightGreen,
            "font-family": "Poppins-regular",
        }
        off_style = {
            "background-color": BackgroundColor,
            "color": TextColor,
            "border-color": BackgroundColor,
            "font-family": "Poppins-regular",
        }
        data = []
        time_style = off_style
        freq_style = off_style
        phase_style = off_style
        edc_style = off_style

        if latest_button == "impulse-mono":
            time = True
            time_style = on_style
            fig_title = "Amplitude"
            for ir, label in zip(irs, labels):
                data.append(
                    go.Scatter(
                        x=ir.time,
                        y=ir.data,
                        mode="lines",
                        name=label,
                    )
                )
        elif latest_button == "frequency-mono":
            time = False
            freq_style = on_style
            fig_title = "Amplitude [dB SPL rel. 20μPa]"
            for ir, label in zip(irs, labels):
                if smoothing == "no smoothing":
                    data.append(
                        go.Scatter(
                            x=ir.frequency,
                            y=20 * np.log10(np.abs(ir.frequency_response)) + 94,
                            mode="lines",
                            name=label,
                        )
                    )

                else:
                    frac_band_range = (20, 14000)
                    octave_bands, smoothed_frequency_response = average_octave_bands(
                        ir.frequency,
                        ir.frequency_response,
                        smoothing,
                        frac_band_range,
                    )

                    data.append(
                        go.Scatter(
                            x=octave_bands,
                            y=20 * np.log10(np.abs(smoothed_frequency_response)) + 94,
                            mode="lines+markers",
                            name=label,
                        )
                    )
        elif latest_button == "phase-mono":
            time = False
            phase_style = on_style
            fig_title = "Phase [degrees]"
            for ir, label in zip(irs, labels):
                phase_angle = np.angle(_delay_frf_samples(ir.frequency_response, -ir.zero_pad_samples))
                data.append(
                    go.Scatter(
                        x=ir.frequency,
                        y=np.round(
                            np.rad2deg(phase_angle),
                            6,
                        ),
                        mode="lines",
                        name=label,
                    )
                )

        elif latest_button == "edc-mono":
            time = True
            edc_style = on_style
            fig_title = "EDC [dB]"
            for ir, label in zip(irs, labels):
                if edc_value != "None":
                    ir = ir.filter(edc_filters[edc_value])
                    edc_float_value = float(edc_value)
                else:
                    edc_float_value = None

                edc = ir._compute_edc(center_frequency=edc_float_value, unpadded=True)
                data.append(
                    go.Scatter(
                        x=ir.unpadded_time(),
                        y=edc,
                        mode="lines",
                        name=label,
                    )
                )

        fig = go.Figure(
            data=data,
            layout=go.Layout(
                font=dict(color=TextColor, family="Poppins-regular"),
                yaxis=dict(
                    title=fig_title,
                    gridcolor=GridColor,
                    zerolinewidth=2,
                    zerolinecolor=ZeroLineColor,
                ),
                xaxis=dict(
                    title="Time [s]" if time else "Frequency [hz]",
                    gridcolor=GridColor,
                    zeroline=False,
                    # rangeslider=dict(visible=True if time else False),
                    type="linear" if time else "log",
                    autorangeoptions=dict(minallowed=np.log10(FrRangeMin)) if not time else None,
                ),
                colorway=LineColors,
                paper_bgcolor=BackgroundColor,
                plot_bgcolor=BackgroundColor,
            ),
        )

        return fig, time_style, freq_style, phase_style, edc_style

    try_run_app(app)


def create_directivity_figure(
    index, directivity, x_coordinates: np.ndarray, y_coordinates: np.ndarray, z_coordinates: np.ndarray
) -> go.Figure:
    min_direc = np.clip(np.min(directivity), 40, 94)
    max_direc = np.clip(np.max(directivity), 40, 94)

    x = x_coordinates * np.clip(directivity[int(index)], 1, 94)
    y = y_coordinates * np.clip(directivity[int(index)], 1, 94)
    z = z_coordinates * np.clip(directivity[int(index)], 1, 94)
    max_value = max([np.max(np.abs(x)), np.max(np.abs(y)), np.max(np.abs(z))])
    caddi = go.Surface(
        x=x / max_value,
        y=y / max_value,
        z=z / max_value,
        surfacecolor=np.clip(directivity[int(index)], 40, 94),
        connectgaps=True,
        cmin=min_direc,
        cmax=max_direc,
        colorbar=dict(
            title=dict(
                font=dict(color=TrebleLightGreen, family="Poppins-regular"),
                side="right",
                text="Sound Pressure Level",
            ),
            tickfont=dict(color=TrebleLightGreen),
            # orientation="h",
        ),
    )

    fig = go.Figure(
        data=caddi,
        layout=go.Layout(
            # title=f"{frequency[int(index)]} Hz",
            paper_bgcolor=BackgroundColor,
            plot_bgcolor=BackgroundColor,
            uirevision="camera.eye",
            height=500,
        ),
    )

    fig.update_layout(
        scene=dict(
            xaxis=dict(
                backgroundcolor=BackgroundColor,
                gridcolor=GridColor,
                showbackground=True,
                zerolinecolor=ZeroLineColor,
                color=TrebleGreen,
                showticklabels=True,
                showgrid=True,
            ),
            yaxis=dict(
                backgroundcolor=BackgroundColor,
                gridcolor=GridColor,
                showbackground=True,
                zerolinecolor=ZeroLineColor,
                color=TrebleGreen,
                showticklabels=True,
                showgrid=True,
            ),
            zaxis=dict(
                backgroundcolor=BackgroundColor,
                gridcolor=GridColor,
                showbackground=True,
                zerolinecolor=ZeroLineColor,
                color=TrebleGreen,
                showgrid=True,
                showticklabels=True,
            ),
        ),
    )
    return fig


def get_directivity_layout(frequency, name):
    app_content = [
        html.H2(
            style={
                "textAlign": "center",
                "color": TextColor,
                "font-family": "Poppins-semibold",
            },
            children=f"{name} Source Pattern",
        ),
        html.Div(
            children=[
                html.P(
                    "Frequency [Hz]",
                    style={
                        "textAlign": "center",
                        "color": TextColor,
                        "font-family": "Poppins-regular",
                    },
                ),
                dcc.Slider(
                    0,
                    len(frequency),
                    marks={x: f"{frequency[x]}" for x in range(len(frequency))},
                    value=10,
                    id="directivity-slide",
                ),
            ],
            style={
                "BackgroundColor": BackgroundColor,
                "TextColor": TrebleGreen,
                "padding-top": "15px",
                "font-family": "Poppins-regular",
            },
        ),
        html.Div(
            [
                __dash_graph(id="directivity-plot"),
            ]
        ),
    ]

    return app_content


def plot_directive_source_and_geometry(
    directivity: np.ndarray,
    frequency: np.ndarray,
    x_coordinates: np.ndarray,
    y_coordinates: np.ndarray,
    z_coordinates: np.ndarray,
    model_data,
    layers,
    name: str,
):
    submodel_component = None
    viewportHeight = 625
    plotHeight = 600
    try:
        submodel_component = importlib.import_module("treble_tsdk.geometry.plot").submodel_component(
            model_data, layers, plotHeight
        )
    except ImportError:
        logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")

    directivity_layout = get_directivity_layout(frequency, name)

    app_content = [
        html.Div(
            children=[
                dcc.RadioItems(
                    id="plot-mode",
                    options=[
                        {"label": "Directivity", "value": "directivity"},
                        {"label": "Geometry", "value": "geometry"},
                    ],
                    value="directivity",
                    inline=True,
                    style={
                        "color": "white",
                        "padding": "5px",
                        "borderRadius": "5px",
                        "height": 25,
                        "background-color": "#262626fa",
                        "height": "2rem",
                        "display": "flex",
                        "gap": "1rem",
                    },
                    inputStyle={"margin-right": "4px"},
                ),
                html.Div(
                    children=[
                        html.Div(
                            id="geometry-container",
                            children=submodel_component,
                        ),
                        html.Div(
                            id="directivity-container",
                            children=directivity_layout,
                        ),
                    ],
                    style={"width": "100%", "height": plotHeight},
                ),
            ],
            style={"height": viewportHeight, "overflow": "hidden"},
        )
    ]
    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @callback(
        Output("directivity-plot", "figure"),
        Input("directivity-slide", "value"),
    )
    def update_directivity_plot_widget(index):
        return create_directivity_figure(index, directivity, x_coordinates, y_coordinates, z_coordinates)

    @app.callback(
        Output("directivity-container", "style"),
        Output("geometry-container", "style"),
        Input("plot-mode", "value"),
    )
    def toggle_visibility(mode):
        if mode == "directivity":
            return {"display": "inline-block", "width": "100%", "height": "100%"}, {"display": "none"}
        else:
            return {"display": "none"}, {"display": "inline-block", "width": "100%", "height": "100%"}

    try_run_app(app, viewportHeight)


def plot_directive_source(
    directivity: np.ndarray,
    frequency: np.ndarray,
    x_coordinates: np.ndarray,
    y_coordinates: np.ndarray,
    z_coordinates: np.ndarray,
    name: str,
):

    app_content = get_directivity_layout(frequency, name)
    app = initialize_widget(children=app_content, assets_path=_get_assets_path())

    @callback(
        Output("directivity-plot", "figure"),
        Input("directivity-slide", "value"),
    )
    def update_directivity_plot_widget(index):
        return create_directivity_figure(index, directivity, x_coordinates, y_coordinates, z_coordinates)

    try_run_app(app)


def get_latest_button(timestamps: dict[str, int]):
    timestamps = {id: timestamp or 0 for id, timestamp in timestamps.items()}
    return max(timestamps, key=timestamps.get)
