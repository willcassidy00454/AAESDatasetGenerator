from __future__ import annotations

import numpy as np
from pathlib import Path
from typing import TYPE_CHECKING
import importlib
from scipy.io import wavfile

from ..treble_logging import logger
from .base_ir import BaseIR

if TYPE_CHECKING:
    from .results import ReceiverResults, SourceResults


class AudioSignal(BaseIR):
    """Audio signal class for handling audio data"""

    def __init__(
        self,
        data: np.ndarray,
        sampling_rate: float,
        time: np.ndarray = None,
        source: list["SourceResults"] = None,
        receiver: list["ReceiverResults"] = None,
        zero_pad_samples: int = 0,
        normalization_coefficient: float = None,
    ):
        if data.ndim == 1:
            data = data.reshape(1, -1)
        else:
            if self.__class__ is AudioSignal and data.shape[0] > 1:
                logger.warning(
                    "Audio input is multichannel, selecting channel 0, use channel argument to select channel"
                )
                data = data[0].reshape(1, -1)

        super().__init__(
            data=data,
            sampling_rate=sampling_rate,
            time=time,
            source=source,
            receiver=receiver,
            zero_pad_samples=zero_pad_samples,
            normalization_coefficient=normalization_coefficient,
        )

    def plot(self, title: str = "Audio data"):
        """Plot the audio signal"""
        try:
            importlib.import_module("treble_tsdk.results.plot").plot_multichannel_data(
                device=self,
                comparison=None,
                title=title,
                channel_label="Channel ",
            )
        except ImportError:
            logger.warning("Result plotting module could not be imported, has it been installed?")

    def repeat_to_duration(
        self, duration_seconds: float, full_repeat: bool = False, fadeout_samples: int = 1024
    ) -> "AudioSignal" | "ConvolvedAudioSignal":
        """repeat the audio audio signal to a specified duration

        :param float duration_seconds: requested duration in seconds
        :param bool full_repeat: set to true if the signal only should be repeated in full length, i.e. not cut the last repeat of the signal, defaults to False
        :param int fadeout_samples: number of samples to fade the signal out with, defaults to 1024
        :return AudioSignal: the new audio signal
        """
        n_requested_samples = int(duration_seconds * self.sampling_rate)

        if n_requested_samples <= self.data.shape[-1]:
            return self.trim_to_duration(duration_seconds, fadeout_samples=fadeout_samples)

        n_repeats = int(n_requested_samples / self.data.shape[-1])

        if full_repeat:
            repeated_data = np.zeros((self.data.shape[0], self.data.shape[1] * n_repeats))
        else:
            repeated_data = np.zeros((self.data.shape[0], n_requested_samples))
            repeated_data[:, n_repeats * self.data.shape[1] : n_requested_samples] = self.data[
                :, : n_requested_samples - n_repeats * self.data.shape[1]
            ]
            if fadeout_samples > 0:
                fade_out = np.hanning(2 * fadeout_samples)[fadeout_samples:]
                repeated_data[:, -fadeout_samples:] *= fade_out
            elif fadeout_samples < 0:
                logger.warning("invalid fadeout_samples, must be >= 0")

        for i in range(n_repeats):
            repeated_data[:, i * self.data.shape[1] : (i + 1) * self.data.shape[1]] = self.data

        return self.__class__(
            data=repeated_data,
            sampling_rate=self.sampling_rate,
            time=None,
            source=self._source,
            receiver=self._receiver,
            zero_pad_samples=self.zero_pad_samples,
            normalization_coefficient=self.normalization_coefficient,
        )

    def trim_to_duration(
        self, duration_seconds: float, fadeout_samples: int = 1024
    ) -> "AudioSignal" | "ConvolvedAudioSignal":
        """Trim the audio signal to a specified duration

        :param float duration_seconds: the requested duration in seconds
        :param int fadeout_samples: number of samples of fadeout, defaults to 1024
        :return AudioSignal: A new audio signal with the trimmed duration
        """
        audio_data = self.data.copy()
        n_requested_samples = int(duration_seconds * self.sampling_rate)
        if n_requested_samples >= audio_data.shape[1]:
            return self
        audio_data = audio_data[:, :n_requested_samples]
        fade_out = np.hanning(2 * fadeout_samples)[fadeout_samples:]
        audio_data[:, -fadeout_samples:] *= fade_out
        return self.__class__(
            data=audio_data,
            sampling_rate=self.sampling_rate,
            time=None,
            source=self._source,
            receiver=self._receiver,
            zero_pad_samples=self.zero_pad_samples,
            normalization_coefficient=self.normalization_coefficient,
        )

    def convolve_with_audio_signal(self, audio: "AudioSignal") -> "AudioSignal":
        raise ValueError("convolution with audio is not supported")


class ConvolvedAudioSignal(AudioSignal):
    def __init__(
        self,
        data: np.ndarray,
        sampling_rate: float,
        time: np.ndarray = None,
        source: list["SourceResults"] = None,
        receiver: list["ReceiverResults"] = None,
        zero_pad_samples: int = 0,
        normalization_coefficient: float = None,
    ):
        super().__init__(
            data=data if data.ndim == 2 else data.reshape(1, -1),
            sampling_rate=sampling_rate,
            time=time,
            source=source,
            receiver=receiver,
            zero_pad_samples=zero_pad_samples,
            normalization_coefficient=normalization_coefficient,
        )

    def __getitem__(self, item: int) -> AudioSignal:
        return AudioSignal(
            data=self.data[item],
            sampling_rate=self.sampling_rate,
            source=self._source,
            receiver=self._receiver,
            zero_pad_samples=self.zero_pad_samples,
            normalization_coefficient=self.normalization_coefficient,
        )

    def plot(self, title: str = "Convolved audio data"):
        """Plot the convolved audio signal"""
        try:
            importlib.import_module("treble_tsdk.results.plot").plot_multichannel_data(
                device=self,
                comparison=None,
                title=title,
                channel_label="Channel ",
            )
        except ImportError:
            logger.warning("Result plotting module could not be imported, has it been installed?")
