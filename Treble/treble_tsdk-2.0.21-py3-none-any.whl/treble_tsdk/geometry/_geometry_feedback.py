from pathlib import Path
import json
import pyvista as pv
from dataclasses import dataclass, field


from ..treble_logging import logger
from treble_tsdk.geometry.mesh_collection import MeshCollection


def extract_obj_from_list(obj_list: list[list[float]], n_verts: int):
    """helper function to extract points and faces from a list of objects

    : param obj_list: List of list of points
    : param n_verts: number of vertices per face
    : return: tuple: points, faces for instantiating a pyvista object
    """
    points = []
    faces = []
    for i_small_edges in range(len(obj_list)):
        points = points + [p for p in obj_list[i_small_edges]]
        faces = faces + [n_verts] + [i_small_edges * n_verts + i for i in range(n_verts)]
    return (points, faces)


@dataclass
class FeedbackObject:
    """Dataclass to store feedback information"""

    open_edges: pv.PolyData = field(default_factory=pv.PolyData)
    non_manifold_edges: pv.PolyData = field(default_factory=pv.PolyData)
    isolated_edges: pv.PolyData = field(default_factory=pv.PolyData)
    small_edges: pv.PolyData = field(default_factory=pv.PolyData)
    excluded_faces: pv.PolyData = field(default_factory=pv.PolyData)
    small_tetrahedrons: pv.PolyData = field(default_factory=pv.PolyData)
    problem_areas: pv.PolyData = field(default_factory=pv.PolyData)
    mesh_color: str = "gray"
    open_edges_color: str = "red"
    small_edges_color: list[float] = field(default_factory=lambda: [0.99, 0.90, 0.0])
    isolated_edges_color: list[float] = field(default_factory=lambda: [0.35, 0.96, 0.81])
    excluded_surfaces_color: list[float] = field(default_factory=lambda: [0.59, 0.46, 1.0])
    problem_areas_color: list[float] = field(
        default_factory=lambda: [0.9215686274509803, 0.5882352941176471, 0.7411764705882353]
    )
    legend_background_color: list[float] = field(default_factory=lambda: [0.35, 0.35, 0.35])
    feedback_opacity: float = 0.8
    problem_area_opacity: float = 0.4
    model_opacity: float = 0.3
    n_problem_areas: int = 0

    @staticmethod
    def load_from_json(json_path: Path) -> "FeedbackObject":
        """Reads a feedback object from a json file
        :param json_path: path to the json file
        :return: FeedbackObject: The feedback object
        """

        try:
            with open(json_path, "r") as f:
                feedback_json_obj = json.load(f)
        except ImportError:
            logger.warning("Unable to load feedback")
            return None
        feedback_obj = FeedbackObject()
        if "open_edges" in feedback_json_obj:
            feedback_obj.open_edges = pv.PolyData(
                *extract_obj_from_list(feedback_json_obj["open_edges"], 2)
            ).extract_all_edges()
        if "non_manifold_edges" in feedback_json_obj:
            feedback_obj.non_manifold_edges = pv.PolyData(
                *extract_obj_from_list(feedback_json_obj["non_manifold_edges"], 2)
            ).extract_all_edges()
        if "isolated_edges" in feedback_json_obj:
            feedback_obj.isolated_edges = pv.PolyData(
                *extract_obj_from_list(feedback_json_obj["isolated_edges"], 2)
            ).extract_all_edges()
        if "small_edges" in feedback_json_obj:
            feedback_obj.small_edges = pv.PolyData(
                *extract_obj_from_list(feedback_json_obj["small_edges"], 2)
            ).extract_all_edges()
        if "excluded_faces" in feedback_json_obj:
            feedback_obj.excluded_faces = pv.PolyData(
                *extract_obj_from_list(feedback_json_obj["small_edges"], 3)
            )
        if "small_tetrahedrons" in feedback_json_obj:

            def extract_tets(tri_obj):
                n_tris = len(tri_obj)
                points, cells = extract_obj_from_list(tri_obj, 4)
                return pv.UnstructuredGrid(cells, [pv.CellType.TETRA] * n_tris, points)

            feedback_obj.small_tetrahedrons = extract_tets(feedback_json_obj["small_tetrahedrons"])
        if "problem_areas" in feedback_json_obj:

            def extract_problem_area_spheres(problem_area_objs):
                spheres = []
                for x, y, z, r in problem_area_objs:
                    spheres.append(pv.Sphere(r, [x, y, z]))
                return pv.merge(spheres)

            feedback_obj.n_problem_areas = len(feedback_json_obj["problem_areas"])
            feedback_obj.problem_areas = extract_problem_area_spheres(feedback_json_obj["problem_areas"])
        return feedback_obj


def create_feedback_plotter(feedback_object: FeedbackObject) -> "pv.Plotter":
    """creates a pyvista plotter with all the feedback information added to it
    :param feedback_object: an object of the FeedbackObject class
    :return: the pyvista plotter object
    """
    pl = pv.Plotter()
    legend_entries = []

    if feedback_object.open_edges.n_cells > 0:
        pl.add_mesh(
            feedback_object.open_edges,
            opacity=feedback_object.feedback_opacity,
            color=feedback_object.open_edges_color,
            line_width=7,
        )  # plot open edges
        legend_entries.append(
            [f"{feedback_object.open_edges.n_cells} open edges", feedback_object.open_edges_color]
        )

    if feedback_object.small_edges.n_cells > 0:
        pl.add_mesh(
            feedback_object.small_edges,
            opacity=feedback_object.feedback_opacity,
            color=feedback_object.small_edges_color,
            line_width=7,
        )
        legend_entries.append(
            [f"{feedback_object.small_edges.n_cells} small edges", feedback_object.small_edges_color]
        )
    if feedback_object.isolated_edges.n_cells > 0:
        pl.add_mesh(
            feedback_object.isolated_edges,
            opacity=feedback_object.feedback_opacity,
            color=feedback_object.isolated_edges_color,
            line_width=7,
        )
        legend_entries.append(
            [f"{feedback_object.isolated_edges.n_cells} isolated edges", feedback_object.isolated_edges_color]
        )
    if feedback_object.excluded_faces.n_cells > 0:
        pl.add_mesh(
            feedback_object.excluded_faces,
            opacity=feedback_object.feedback_opacity,
            color=feedback_object.excluded_surfaces_color,
            line_width=7,
        )
        legend_entries.append(
            [
                f"{feedback_object.excluded_faces.n_cells} excluded surfaces",
                feedback_object.excluded_surfaces_color,
            ]
        )

    if feedback_object.n_problem_areas > 0:
        pl.add_mesh(
            feedback_object.problem_areas,
            opacity=feedback_object.problem_area_opacity,
            color=feedback_object.problem_areas_color,
        )
        legend_entries.append(
            [f"{feedback_object.n_problem_areas} problem areas", feedback_object.problem_areas_color]
        )

    _ = pl.add_legend(
        legend_entries, name="Feedback", face=None, bcolor=feedback_object.legend_background_color
    )

    return pl


# Geometry feedback for dash plot

# Basic types
Coordinate = list[float]
LineSegment = list[Coordinate]
Tetrahedron = list[Coordinate]
Triangle = list[Coordinate]


@dataclass
class Sphere:
    center: Coordinate
    radius: float


@dataclass
class CappedElementLists:
    small_edges: int = None
    problem_areas: int = None
    isolated_edges: int = None
    naked_edges: int = None
    excluded_faces: int = None
    invalid_faces: int = None


def parse_sphere(items: list[float]) -> Sphere:
    return Sphere(center=list([items[0], items[1], items[2]]), radius=items[3])


def parse_capped_element_lists(data: dict) -> "CappedElementLists":
    return CappedElementLists(
        small_edges=data.get("small_edges"),
        problem_areas=data.get("problem_areas"),
        isolated_edges=data.get("isolated_edges"),
        naked_edges=data.get("naked_edges"),
        excluded_faces=data.get("excluded_faces"),
        invalid_faces=data.get("invalid_faces"),
    )


@dataclass
class GeometryFeedback:
    objectCount: int = field(default_factory=int)
    layerCount: int = field(default_factory=int)
    watertight: bool = field(default_factory=bool)
    errors: list[str] | None = field(default_factory=list)
    warnings: list[str] | None = field(default_factory=list)
    isolated_edges: list[LineSegment] = field(default_factory=list)
    naked_edges: list[LineSegment] = field(default_factory=list)
    invalid_faces: list[Triangle] = field(default_factory=list)
    small_edges: list[LineSegment] = field(default_factory=list)
    excluded_faces: list[Triangle] = field(default_factory=list)
    problem_areas: list[Sphere] = field(default_factory=list)
    boundaryMismatch: bool = field(default_factory=bool)
    modelVolume: float | None = field(default_factory=float)
    cappedElementLists: CappedElementLists = field(default_factory=CappedElementLists)

    @staticmethod
    def load_from_json(json_path: Path) -> "GeometryFeedback":
        """Reads a feedback object from a json file
        :param json_path: path to the json file
        :return: GeometryFeedback: The feedback object
        """

        try:
            with open(json_path, "r") as f:
                data = json.load(f)
        except ImportError:
            logger.warning("Unable to load feedback")
            return None

        watertight = False if "not_watertight" in data["errors"] else True

        bounding_box = data["volumes"]["bounding_box"]
        outer_shell = data["volumes"]["outer_shell"]
        boundary_mismatch = False

        # If the volume of the model's bounding box is 4 times bigger than the volume of the outer shell, trigger a boundaryMismatch Mismatch warning
        if watertight and outer_shell / bounding_box < 0.25:
            boundary_mismatch = True

        geometry_feedback = GeometryFeedback(
            objectCount=data["geometry_object_count"],
            layerCount=len(data["layer_name_by_layer_index"]),
            watertight=watertight,
            errors=data["errors"] if len(data["errors"]) > 0 else None,
            warnings=data["warnings"] if len(data["warnings"]) > 0 else None,
            isolated_edges=data["isolated_edges"] if "isolated_edges" in data else [],
            naked_edges=data["naked_edges"] if "naked_edges" in data else [],
            invalid_faces=data["invalid_faces"] if "invalid_faces" in data else [],
            small_edges=data["small_edges"] if "small_edges" in data else [],
            excluded_faces=data["excluded_faces"] if "excluded_faces" in data else [],
            problem_areas=(
                [parse_sphere(item) for item in data["problem_areas"]] if "problem_areas" in data else []
            ),
            boundaryMismatch=boundary_mismatch,
            modelVolume=outer_shell,
            cappedElementLists=parse_capped_element_lists(data["capped_element_lists"]),
        )
        return geometry_feedback
