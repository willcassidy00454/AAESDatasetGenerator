from rhino3dm import File3dm, Mesh, Layer, ObjectType, UnitSystem
from ..client.api_models import GeometryObjectLayerInfoDto, GeometryObjectInfoDto
from ..utility_classes import Point2d
import pyvista as pv
import numpy as np
import uuid
import json
import os
import math


def create_new_rhino_model(base_model_path, object_definition, new_model_path):
    """
    loads a rhino model of a room, (the meshed, exported one, not the original)
    Creates or loads an object, based on the object definition
    translates and rotates the objects
    inserts it into the original model
    returns object with uuids for the inserted objects
    """
    result_objects = []
    object_volume = {}
    object_group_enum = {}
    group_type_set = set()
    # load the original model
    if base_model_path == None:
        rhino_base_model = _create_new_model()
        # Set model unit system as meters.
        rhino_base_model.Settings.ModelUnitSystem = UnitSystem.Meters
    else:
        (
            rhino_base_model,
            pv_orig_model,
            model_object_id_by_object_index,
            model_layer_name_by_object_index,
        ) = _load_from_rhino(base_model_path)
    rhino_base_model_geometry_layer = [
        layer for layer in rhino_base_model.Layers if layer.Name == "Geometry"
    ][0]

    for object_name, object_params in object_definition.items():
        if object_params["type"] == "speaker":
            pv_part_model, surface_name_by_object_index = _create_speaker(
                width=object_params["width"],
                depth=object_params["depth"],
                height=object_params["height"],
                membrane_size=object_params["membrane_size"],
                membrane_height=object_params["membrane_height"],
                membrane_resulution=object_params["membrane_resulution"],
            )
            object_group_enum[object_name] = 2
            group_type_set.add(2)

        elif object_params["type"] == "file":
            raise NotImplementedError()
            # dirmodel,pv_part_model,dirmodel_object_id_by_object_index, surface_name_by_object_index = _load_from_rhino(object_params["path"])
            # object_group_enum[object_name] = 2
        elif object_params["type"] == "polygon_room":
            pv_part_model, surface_name_by_object_index = _create_polygon_room(object_params)
            # See group types here: https://treble-tech.atlassian.net/wiki/spaces/PM/pages/324665349/Rhino+3dm+file+format
            # 1 is outer shell, 2 is internal volume, 3 is open surface.
            object_group_enum[object_name] = 1
            group_type_set.add(1)
        elif object_params["type"] == "cylinder":
            pv_part_model, surface_name_by_object_index = _create_cylinder(object_params)
            object_group_enum[object_name] = 2
            group_type_set.add(2)
        elif object_params["type"] == "external_box":
            pv_part_model, surface_name_by_object_index = _create_external_box(object_params)
            object_group_enum[object_name] = 1
            group_type_set.add(1)
        elif object_params["type"] == "external_sphere":
            pv_part_model, surface_name_by_object_index = _create_external_sphere(object_params)
            object_group_enum[object_name] = 1
            group_type_set.add(1)
        elif object_params["type"] == "sphere":
            pv_part_model, surface_name_by_object_index = _create_external_sphere(object_params)
            object_group_enum[object_name] = 2
            group_type_set.add(2)
        elif object_params["type"] == "receiver_cylinder":
            pv_part_model, surface_name_by_object_index = _create_receiver_cylinder(object_params)
            object_group_enum[object_name] = 2
            group_type_set.add(2)
        elif object_params["type"] == "plane":
            pv_part_model, surface_name_by_object_index = _create_external_plane(object_params)
            object_group_enum[object_name] = 2
            group_type_set.add(2)

        object_volume[object_name] = pv_part_model.volume
        # Check for no_transform flag.
        if object_params.get("no_transform", False) is False:
            _transform_model(
                pv_part_model,
                object_params["location"],
                object_params["azimuth"],
                object_params["elevation"],
                object_params["rotation"],
            )

        for object_index, surface_name in enumerate(surface_name_by_object_index):
            surface_model = pv_part_model.extract_cells(
                pv_part_model.cell_data["object_index"] == surface_name_by_object_index.index(surface_name)
            ).extract_surface()
            result_objects.append(
                {"object_name": object_name, "surface_name": surface_name, "pv_model": surface_model}
            )

    # Generate group ids
    group_id_to_group_type = {}
    group_type_to_group_id = {}
    for group_type in group_type_set:
        group_id = str(uuid.uuid4())
        group_id_to_group_type[group_id] = group_type
        group_type_to_group_id[group_type] = group_id

    # Create the rhino mesh objects
    for result_object in result_objects:
        result_object["rhino_model"] = _create_rhino_mesh(
            result_object["pv_model"],
            group_id=group_type_to_group_id[object_group_enum[result_object["object_name"]]],
        )
        result_object["rhino_id"] = str(rhino_base_model.Objects.Add(result_object["rhino_model"]))
        result_object["rhino_layer_name"] = f"{result_object['object_name']}_{result_object['surface_name']}"
        new_layer = Layer()
        new_layer.Name = result_object["rhino_layer_name"]
        new_layer.ParentLayerId = rhino_base_model_geometry_layer.Id
        layer_index = rhino_base_model.Layers.Add(new_layer)
        rhino_base_model.Objects.FindId(result_object["rhino_id"]).Attributes.LayerIndex = layer_index

    _set_geometry_layer_strings(
        rhino_base_model_geometry_layer, object_volume, object_group_enum, group_id_to_group_type
    )

    geometry_group_type_by_group_id = _get_geometry_group_type_by_group_id(rhino_base_model)
    geometry_object_info = _get_geometry_object_info(rhino_base_model, group_id_to_group_type)

    geo_map = []
    for obj in rhino_base_model.Objects:
        if obj.Geometry and obj.Geometry.ObjectType == ObjectType.Mesh:
            geo_map.append(
                GeometryObjectLayerInfoDto(
                    str(obj.Attributes.Id), rhino_base_model.Layers.FindIndex(obj.Attributes.LayerIndex).Name
                )
            )

    File3dm.Write(rhino_base_model, str(new_model_path))
    return result_objects, geo_map, geometry_object_info, geometry_group_type_by_group_id


def _get_geometry_group_type_by_group_id(rhino_model) -> dict[str, float]:
    group_id_to_geometry_group = {}
    # Find geometrylayer and harvest tech.treble.geometry_group_type_by_group_id data.
    for layer in rhino_model.Layers:
        if layer.Name == "Geometry":
            group_id_to_geometry_group = json.loads(
                layer.GetUserString("tech.treble.geometry_group_type_by_group_id")
            )
            volume_by_group_id = json.loads(layer.GetUserString("tech.treble.volume_by_group_id"))
            break
    return {
        group_type: volume_by_group_id[group_id]
        for group_id, group_type in group_id_to_geometry_group.items()
    }


def _get_geometry_object_info(rhino_model, group_id_to_group_type) -> dict[str, GeometryObjectInfoDto]:
    info = {}
    for rhino_object in rhino_model.Objects:
        if not isinstance(rhino_object.Geometry, Mesh):
            continue
        object_id = str(rhino_object.Attributes.Id)
        info[object_id] = {}
        if rhino_object.Geometry.UserStringCount > 0:
            info[object_id] = GeometryObjectInfoDto(
                id=object_id,
                groupType=int(
                    group_id_to_group_type[
                        rhino_object.Geometry.GetUserString("tech.treble.geometry_group_id")
                    ]
                ),
                surfaceArea=float(rhino_object.Geometry.GetUserString("tech.treble.surface_area")),
                layerName=rhino_model.Layers.FindIndex(rhino_object.Attributes.LayerIndex).Name,
            )

    return info


def _create_external_plane(object_params):
    model = pv.Plane(
        center=object_params["center"],
        direction=object_params["normal"],
        i_size=object_params["i_size"],
        j_size=object_params["j_size"],
    )
    model.cell_data["object_index"] = np.array([0] * model.n_cells)
    return model.triangulate(), ["plane"]


def _create_external_box(object_params):
    model = pv.Box([0, object_params["x"], 0, object_params["y"], 0, object_params["z"]])
    model.cell_data["object_index"] = np.array([1, 1, 1, 1, 0, 2])
    return model.triangulate(), ["floor", "walls", "ceiling"]


def _create_external_sphere(object_params):
    model = pv.Sphere(
        radius=object_params["radius"],
        phi_resolution=object_params["resolution"],
        theta_resolution=object_params["resolution"],
    )
    model.cell_data["object_index"] = 0
    return model.triangulate(), ["boundary"]


def _create_cylinder(object_params):
    model = pv.Cylinder(
        center=[0, 0, object_params["radius"]],
        direction=[1, 0, 0],
        radius=object_params["radius"],
        height=object_params["length"],
        resolution=object_params["resolution"],
    ).triangulate()
    model.cell_data["object_index"] = 0
    return model, ["cylinder"]


def _create_receiver_cylinder(object_params):
    model = pv.Cylinder(
        center=object_params["center_pos"],
        direction=object_params["direction"],
        radius=object_params["radius"],
        height=object_params["height"],
        resolution=object_params["resolution"],
    ).triangulate()
    model.cell_data["object_index"] = 0
    return model, ["cylinder"]


def _create_debug_sphere(object_params):
    model = pv.Sphere(
        radius=object_params["radius"],
        phi_resolution=object_params["resolution"],
        theta_resolution=object_params["resolution"],
    )
    model.cell_data["object_index"] = 0
    return model.triangulate(), ["boundary"]


def _create_polygon_room(object_params):
    """
    Required object params:
    {
        "points_xy": [[x1,y1], [x2,y2],...] # Note: Must polygon vertex order must be counterclockwise.
        "height_z": float,
        "join_wall_layers": true|false (if true all walls will share a layer in the model, otherwise each wall will have a separate layer.)
    }

    Returns:
    pyvista model of room and a list of layer names in the same order as assigned surfaces.
    F.ex. ["walls", "floor", "ceiling"] if join_wall_layers is True and ["wall_0", "wall_1",.., "floor", "ceiling"] if join_wall_layers is False.
    """
    # surfs contains a list of triangulated line surfaces that have been extruded to "height" on z-axis.
    surfs = []
    join_wall_layers = object_params["join_wall_layers"]
    if isinstance(object_params["points_xy"][0], Point2d):
        points = [
            p.to_list()
            + [
                0.0,
            ]
            for p in object_params["points_xy"]
        ]  # Add z dimension to points.
    else:
        points = [
            p
            + [
                0.0,
            ]
            for p in object_params["points_xy"]
        ]

    for i_point in range(len(points)):
        # Connect all points as line segments.
        p1 = i_point
        p2 = (i_point + 1) % len(points)
        line = (
            pv.Line(points[p1], points[p2])
            .extrude([0, 0, object_params["height_z"]], capping=False)
            .extract_surface()
            .triangulate()
        )
        line.point_data.clear()
        line.cell_data.clear()
        line.cell_data["surface_id"] = i_point
        line.cell_data["object_index"] = 0 if join_wall_layers is True else i_point
        surfs.append(line)
    # Find face connection on lines.
    faces = np.array([len(points)] + [i for i in range(len(points))], dtype=np.int32)
    # Create floor
    floor = pv.PolyData(points, faces).triangulate()
    floor.cell_data["surface_id"] = i_point + 1
    floor.cell_data["object_index"] = 1 if join_wall_layers is True else i_point + 1
    # Create ceiling
    ceiling = pv.PolyData(points + np.array([0, 0, object_params["height_z"]]), faces).triangulate()
    ceiling.cell_data["surface_id"] = i_point + 2
    ceiling.cell_data["object_index"] = 2 if join_wall_layers is True else i_point + 2
    surfs.extend([floor, ceiling])
    model = pv.merge(surfs)
    if join_wall_layers is True:
        return model, ["walls", "floor", "ceiling"]
    else:
        return model, [f"wall_{i}" for i in range(len(points))] + ["floor", "ceiling"]


def _set_geometry_layer_strings(geometry_layer, object_volumes, object_group_enum, group_id_to_group_type):
    """
    Updating the user strings in the rhino model geometry layer
    """
    geom_user_strings = geometry_layer.GetUserStrings()
    volume_by_group_id = {}

    for object_name, volume in object_volumes.items():
        group_id = [
            key for key, value in group_id_to_group_type.items() if value == object_group_enum[object_name]
        ][0]
        volume_by_group_id[group_id] = volume
    geometry_layer.SetUserString("tech.treble.volume_by_group_id", json.dumps(volume_by_group_id))
    geometry_layer.SetUserString(
        "tech.treble.geometry_group_type_by_group_id", json.dumps(group_id_to_group_type)
    )


def _create_new_model():
    """
    Creates a new empty model
    """
    model = File3dm()
    treble_layer = Layer()
    treble_layer.Name = "Treble"
    model.Layers.Add(treble_layer)
    treble_layer = [layer for layer in model.Layers if layer.Name == "Treble"][0]
    geometry_layer = Layer()
    geometry_layer.Name = "Geometry"
    geometry_layer.ParentLayerId = treble_layer.Id
    model.Layers.Add(geometry_layer)

    return model


def _create_speaker(width, depth, height, membrane_size, membrane_height, membrane_resulution):
    """
    Using pyvista to create a speaker geometry
    :param width:
    :param depth:
    :param height:
    :param membrane_size:
    :param membrane_height: height of the center of speaker cone
    :param membrane_resulution: sets the number of points that discretizes the circle
    :return:
    """
    membrane = (
        pv.Circle(membrane_size, membrane_resulution)
        .rotate_y(90, inplace=True)
        .translate([0, 0, membrane_height], inplace=True)
    )
    membrane_edge = membrane.extract_feature_edges(boundary_edges=True)
    box = pv.Box([-width, 0, -depth / 2, depth / 2, 0, height])
    pointa = [0.0, -depth / 2, 0.0]
    pointb = [0.0, depth / 2, 0.0]
    pointc = [0.0, depth / 2, height]
    pointd = [0.0, -depth / 2, height]
    rectangle_edge = pv.Rectangle([pointa, pointb, pointc, pointd]).extract_feature_edges(boundary_edges=True)
    rectangle_edge.cell_data["rectange"] = 0

    front = rectangle_edge.merge(membrane_edge).delaunay_2d(
        alpha=0, edge_source=rectangle_edge.merge(membrane_edge)
    )

    box_points = []
    for i_cell, cell in enumerate(front.faces.reshape(int(front.faces.shape[0] / 4), 4)[:, 1::]):
        for p in cell:
            if _distance(front.points[p], np.array(pointa)) < 1e-3:
                box_points.append(i_cell)
            if _distance(front.points[p], np.array(pointb)) < 1e-3:
                box_points.append(i_cell)
            if _distance(front.points[p], np.array(pointc)) < 1e-3:
                box_points.append(i_cell)
            if _distance(front.points[p], np.array(pointd)) < 1e-3:
                box_points.append(i_cell)
    box.remove_cells(box.find_closest_cell([0, 0, membrane_height]), inplace=True)
    box2 = box.merge(front.extract_cells(np.unique(box_points)))

    box2.cell_data["object_index"] = 0
    membrane.cell_data["object_index"] = 1
    dirmodel_layer_name_by_object_index = ["box", "membrane"]
    return box2.merge(membrane).extract_surface().triangulate(), dirmodel_layer_name_by_object_index


def _distance(p1, p2):
    return np.sqrt(np.sum(np.abs(p1**2 - p2**2)))


def _create_rhino_mesh(pv_mesh, group_id):
    """
    Creating rhino mesh object and adding the vertices and faces
    :param pv_mesh: pyvista mesh object
    :param group_id: group id written in the user string (usually a guid, but can be any string)
    :return:
    """
    rhino_mesh = Mesh()
    [rhino_mesh.Vertices.Add(p[0], p[1], p[2]) for p in pv_mesh.points]
    [
        rhino_mesh.Faces.AddFace(v[0], v[1], v[2], v[2])
        for v in pv_mesh.faces.reshape(int(pv_mesh.faces.shape[0] / 4), 4)[:, 1::]
    ]
    rhino_mesh.SetUserString("tech.treble.geometry_group_id", str(group_id))
    rhino_mesh.SetUserString("tech.treble.surface_area", str(pv_mesh.area))
    rhino_mesh.SetUserString("tech.treble.mesh_source_object_id", str(uuid.UUID(int=0)))

    return rhino_mesh


def _transform_model(pyvista_model, location, azimuth, elevation, rotation):
    """
    Using pyvista built in functions to rotate and translate the model
    :param pyvista_model:
    :param location:
    :param azimuth:
    :param elevation:
    :param rotation:
    :return:
    """
    pyvista_model.rotate_z(azimuth, inplace=True)
    pyvista_model.rotate_vector(
        [np.cos((azimuth + 90) / 180 * np.pi), np.sin((azimuth + 90) / 180 * np.pi), 0],
        -elevation,
        inplace=True,
    )
    pyvista_model.rotate_vector(
        [
            np.cos((azimuth) / 180 * np.pi) * np.cos((elevation) / 180 * np.pi),
            np.sin((azimuth) / 180 * np.pi) * np.cos((elevation) / 180 * np.pi),
            np.sin((elevation) / 180 * np.pi),
        ],
        rotation,
        inplace=True,
    )
    pyvista_model.translate(location, inplace=True)
    # pv_dirmodel.plot(show_bounds=True)


def _load_from_rhino(model_path):
    """
    loads a rhino file and drops the meshes into a pyvista object
    object id and layer name is passed as metadata
    :param model_path:
    :return: the rhino model object, the pyvista mesh, object_id_by_object_index, layer_name_by_object_index
    """
    meshes = []
    layer_name_by_object_index = []
    object_id_by_object_index = []

    model = File3dm.Read(str(model_path))
    i_object = 0
    for rhino_object in model.Objects:
        # skip if object is a mesh or a mesh on the treble layer
        if not isinstance(rhino_object.Geometry, Mesh):
            continue
        layer_name_by_object_index.append(model.Layers[rhino_object.Attributes.LayerIndex].Name)
        pv_vertices = [
            [
                rhino_object.Geometry.Vertices[v].X,
                rhino_object.Geometry.Vertices[v].Y,
                rhino_object.Geometry.Vertices[v].Z,
            ]
            for v in range(len(rhino_object.Geometry.Vertices))
        ]
        pv_faces = [
            [
                3,
                rhino_object.Geometry.Faces[f][0],
                rhino_object.Geometry.Faces[f][1],
                rhino_object.Geometry.Faces[f][2],
            ]
            for f in range(len(rhino_object.Geometry.Faces))
        ]
        mesh_to_add = pv.PolyData(pv_vertices, pv_faces)
        mesh_to_add.cell_data["object_index"] = i_object
        object_id_by_object_index.append(str(rhino_object.Attributes.Id))
        meshes.append(mesh_to_add)
        i_object += 1
    merged_mesh = pv.merge(meshes, merge_points=True)
    return model, merged_mesh, object_id_by_object_index, layer_name_by_object_index


def load_from_rhino_no_pyvista(model_path):
    """
    loads a rhino file passes object id and layer name as metadata
    :param model_path:
    :return: object_id_by_object_index, layer_name_by_object_index
    """
    meshes = []
    layer_name_by_object_index = []
    object_id_by_object_index = []

    model = File3dm.Read(str(model_path))
    i_object = 0
    for rhino_object in model.Objects:
        # skip if object is a mesh or a mesh on the treble layer
        if not isinstance(rhino_object.Geometry, Mesh):
            continue
        layer_name_by_object_index.append(model.Layers[rhino_object.Attributes.LayerIndex].Name)
        object_id_by_object_index.append(str(rhino_object.Attributes.Id))
        i_object += 1

    return object_id_by_object_index, layer_name_by_object_index


def _get_speaker(pos, rot):
    object_definition = {}
    object_definition["speaker"] = {
        "type": "speaker",
        "width": 0.151,
        "depth": 0.142,
        "height": 0.230,
        "membrane_size": 0.105 / 2,
        "membrane_height": 0.146 - 0.105 / 2,
        "membrane_resulution": 8,
        "location": pos
        - [0, 0, 0.0935],  # Shift z-pos by 0.0985 to correctly position speaker membrane center
        "azimuth": rot[0],
        "elevation": rot[1],
        "rotation": rot[2],
    }

    return object_definition


def _get_source_soundbar(jabra_receiver_definition, resolution=4):
    """
    :param center_cyl_pos: Center of disc provided by Jabra: np.array([x,y,z]).
    :param radius_cyl_pos_1: Point on disc perimiter provided by Jabra. np.array([x,y,z]).
    :param radius_cyl_pos_2: Point on disc perimiter provided by Jabra. np.array([x,y,z]).
    :param length_cyl: Cylinder length provided by Jabra.
    """
    pCenter = np.array([p[0] for p in jabra_receiver_definition["center_cyl_pos"]])
    pRadius1 = np.array([p[0] for p in jabra_receiver_definition["radius_cyl_pos"]])
    pRadius2 = np.array([p[1] for p in jabra_receiver_definition["radius_cyl_pos"]])
    length = jabra_receiver_definition["length_cyl"]

    # Get radius value
    radius_vec = pCenter - pRadius1
    radius = np.sqrt(radius_vec.dot(radius_vec))

    # Get normal
    normal = np.cross(pRadius1 - pCenter, pRadius2 - pCenter)
    unit_normal = normal / (normal**2).sum() ** 0.5

    # Adjusted center for pyvista cylinder construct.
    adjusted_center = pCenter - unit_normal * length / 2.0

    object_definition = {}
    object_definition[f"soundbar_cylinder_{jabra_receiver_definition['receiver_id']}"] = {
        "type": "receiver_cylinder",
        "center_pos": adjusted_center,
        "direction": normal,
        "radius": radius,
        "height": length,
        "resolution": resolution,
        "no_transform": True,
    }

    return object_definition


def _get_debug_sphere(pos, radius, resolution=8):
    object_definition = {}
    object_definition["sphere"] = {
        "type": "sphere",
        "location": pos,
        "radius": radius,
        "resolution": resolution,
        "azimuth": 0,
        "elevation": 0,
        "rotation": 0,
    }
    return object_definition


def _shoe_box(x_size, y_size, z_size):
    object_definition = {}

    object_definition["external_box"] = {
        "type": "external_box",
        "x": x_size,
        "y": y_size,
        "z": z_size,
        "location": [0, 0, 0],
        "azimuth": 0,
        "elevation": 0,
        "rotation": 0,
    }

    return object_definition


def _plane(
    object_name: str,
    center: list[float],
    normal: list[float] = [0, 0, 1],
    i_size: float = 1,
    j_size: float = 1,
):
    object_definition = {}
    object_definition[object_name] = {
        "type": "plane",
        "center": center,
        "normal": normal,
        "i_size": i_size,
        "j_size": j_size,
        "location": [0, 0, 0],
        "azimuth": 0,
        "elevation": 0,
        "rotation": 0,
    }
    return object_definition


def _polygon_room(object_name: str, points_xy: list[list[float]], height: float, join_wall_layers: bool):
    object_definition = {}
    object_definition[object_name] = {
        "type": "polygon_room",
        "points_xy": points_xy,
        "height_z": height,
        "join_wall_layers": join_wall_layers,
        "location": [0, 0, 0],
        "azimuth": 0,
        "elevation": 0,
        "rotation": 0,
    }
    return object_definition


def modify_mesh(meshFile, newMeshFile, source_id):
    with open(meshFile, "r") as oldMesh:
        with open(newMeshFile, "w") as newMesh:
            oldMeshLine = oldMesh.readline()
            source_index_found = False
            while oldMeshLine:
                if source_id in oldMeshLine:
                    source_index_found = True
                    source_index = int(oldMeshLine.split()[1])
                    newMesh.write(f'2 2 "{source_id}"\n')

                elif source_index_found:
                    if f" 2 2 {str(source_index)} " in oldMeshLine:
                        x = oldMeshLine.split()
                        x[3] = "2"
                        newMesh.write(" ".join(x) + "\n")
                    else:
                        newMesh.write(oldMeshLine)
                else:
                    # Dump line as is to new mesh file.
                    newMesh.write(oldMeshLine)
                oldMeshLine = oldMesh.readline()


def _rotate_vector(vector: list[float], angle: float) -> list[float]:
    """
    Rotates a 2D vector counter-clockwise by a specified angle in degrees.

    :param vector: A list [x, y] representing the 2D vector.
    :param angle: The angle to rotate the vector, in degrees.
    """
    # Convert angle from degrees to radians
    angle_radians = math.radians(angle)

    # Extract the components of the vector
    x, y = vector

    # Perform the rotation using the rotation matrix
    x_rotated = x * math.cos(angle_radians) - y * math.sin(angle_radians)
    y_rotated = x * math.sin(angle_radians) + y * math.cos(angle_radians)

    return [x_rotated, y_rotated]
