import numpy as np
import math

from ..treble_logging import logger
from ..core.geometry_library_obj import GeometryLibraryObj
from ..core.model_obj import ModelObj
from ..core.project import Project
from ..core.temp_folder import TempFolder
from ..core.geometry_component_library import GeometryComponent
from . import _generator_internal, validation
from .mesh_collection import MeshCollection
from .geometry_definition import GeometryDefinition
from ..utility_classes import Point3d
from ..utils import deprecated
from . import _validation_helpers as helpers
from . import _generator_utils

from ..utility_classes import Point2d, BoundingBox, Point3d, Rotation, Transform3d, View2d, Vector3d


class GeometryGenerator:
    """
    Used for programmatically generating geometries. Can create shoebox, l-shaped and polygon rooms.
    """

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_shoebox_room(
        project: Project,
        model_name: str,
        width_x: float,
        depth_y: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> ModelObj:
        """
        Generate a shoebox room.
        :param project: Project to add model to.
        :param model_name: Name of model in project.
        :param width_x: width of room (x axis)
        :param depth_y: depth of room (y axis)
        :param height_z: height of room (z axis)
        :param join_wall_layers: if True walls will be put on a single layer, if False the model will have a layer for each wall in the room.
                                 Example with join_wall_layers set to True: ["shoebox_walls", "shoebox_floor", "shoebox_ceiling"]
                                 Example with join_wall_layers set to False: ["shoebox_wall_0", "shoebox_wall_1", "shoebox_wall_2", "shoebox_wall_3", "shoebox_floor", "shoebox_ceiling"]
        """
        return GeometryGenerator.create_polygon_room(
            project,
            model_name,
            [[0.0, 0.0], [width_x, 0.0], [width_x, depth_y], [0.0, depth_y]],
            height_z,
            join_wall_layers,
            "shoebox",
        )

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_angled_shoebox_room(
        project: Project,
        model_name: str,
        base_side: float,
        depth_y: float,
        left_angle: float,
        right_angle: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> ModelObj:
        """
        Create shoebox room with angled side walls (= trapezoid room) as shown in the drawing below.
               ________________________
              /                        \\                   ^
             /                          \\                  |
            /<....                       \\<.....           | depth_y
           /  LA :                        \\ RA :           |
          /______:_________________________\\...:...........v..
        0,0           base_side

        LA: left angle (in degrees, counter-clockwise from base_side)
        RA: right angle (in degrees, counter-clockwise from extension of base_side)

        """
        left_dir = _generator_internal._rotate_vector([1, 0], left_angle)
        right_dir = _generator_internal._rotate_vector([1, 0], right_angle)
        left_side = depth_y / math.sin(math.radians(left_angle))
        right_side = depth_y / math.sin(math.radians(right_angle))
        left_vertex = [left_dir[0] * left_side, left_dir[1] * left_side]
        right_vertex = [base_side + right_dir[0] * right_side, right_dir[1] * right_side]

        if left_vertex[0] >= right_vertex[0]:
            raise ValueError(
                "The specified angles result in an invalid room shape, where the left vertex is right of the right vertex. Please change the left angle and right angle or depth."
            )

        vertices = [[0, 0], [base_side, 0], right_vertex, left_vertex]

        return GeometryGenerator.create_polygon_room(
            project,
            model_name,
            vertices,
            height_z,
            join_wall_layers,
            "angledShoebox",
        )

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_l_shaped_room(
        project: Project,
        model_name: str,
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> ModelObj:
        """
        Deprecated: use create_L_shaped_room() instead.
        """
        return GeometryGenerator.create_L_shaped_room(
            project, model_name, a_side, b_side, c_side, d_side, height_z, join_wall_layers
        )

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_L_shaped_room(
        project: Project,
        model_name: str,
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> ModelObj:
        """
         Create L-shaped room with sides as shown in the drawing below.
          __________
         |          | d
         |      ____|
         |     |  c
         |     |
         |     | b
         |_____|
        0,0  a

        :param project: Project to add model to.
        :param model_name: Name of model in project.
        :param join_wall_layers: if True walls will be put on a single layer, if False the model will have a layer for each wall in the room.
        """
        return GeometryGenerator.create_polygon_room(
            project,
            model_name,
            [
                [0.0, 0.0],
                [a_side, 0.0],
                [a_side, b_side],
                [a_side + c_side, b_side],
                [a_side + c_side, b_side + d_side],
                [0.0, b_side + d_side],
            ],
            height_z,
            join_wall_layers,
            "lshape",
        )

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_T_shaped_room(
        project: Project,
        model_name: str,
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> ModelObj:
        """
        Create T-shaped room with sides as shown in the drawing below.
                _______
               |   d   |
             c |       | c
               |       |
               |       |
           ____|       |____
        b |  *           *  | b
          |_________________|
         0,0       a

        * : these sides are equally long and are automatically determined as (a-d)/2

        :param project: Project to add model to.
        :param model_name: Name of model in project.
        :param join_wall_layers: if True walls will be put on a single layer, if False the model will have a layer for each wall in the room.
        """
        if a_side <= d_side:
            raise ValueError("Side a must be larger than side b.")
        e_side = (a_side - d_side) / 2

        return GeometryGenerator.create_polygon_room(
            project,
            model_name,
            [
                [0.0, 0.0],
                [a_side, 0.0],
                [a_side, b_side],
                [a_side - e_side, b_side],
                [a_side - e_side, b_side + c_side],
                [e_side, b_side + c_side],
                [e_side, b_side],
                [0, b_side],
            ],
            height_z,
            join_wall_layers,
            "tshape",
        )

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_U_shaped_room(
        project: Project,
        model_name: str,
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> ModelObj:
        """
        Create U-shaped room with sides as shown in the drawing below.

            c            c
           ___          ___
          |   |        |   |
          |   |        |   |
          |   | d    d |   |
        b |   |        |   | b
          |   |________|   |
          |                |
          |________________|
         0,0      a

        :param project: Project to add model to.
        :param model_name: Name of model in project.
        :param join_wall_layers: if True walls will be put on a single layer, if False the model will have a layer for each wall in the room.
        """
        if d_side >= b_side:
            raise ValueError("Side b must be larger than side d.")
        if 2 * c_side >= a_side:
            raise ValueError("Side a must be larger than 2x side c.")

        return GeometryGenerator.create_polygon_room(
            project,
            model_name,
            [
                [0.0, 0.0],
                [a_side, 0.0],
                [a_side, b_side],
                [a_side - c_side, b_side],
                [a_side - c_side, b_side - d_side],
                [c_side, b_side - d_side],
                [c_side, b_side],
                [0.0, b_side],
            ],
            height_z,
            join_wall_layers,
            "ushape",
        )

    @staticmethod
    @deprecated("GeometryGenerator is deprecated, please use GeometryDefinitionGenerator instead.")
    def create_polygon_room(
        project: Project,
        model_name: str,
        points_xy,
        height_z: float,
        join_wall_layers=True,
        object_name: str = "polygon_room",
    ) -> ModelObj:
        tmp_folder = TempFolder()
        tmp_file = f"{tmp_folder._temp_dir}/model.3dm"
        (
            _,
            geo_map,
            geometry_object_info,
            geometry_group_type_by_group_id,
        ) = _generator_internal.create_new_rhino_model(
            None,
            _generator_internal._polygon_room(object_name, points_xy, height_z, join_wall_layers),
            tmp_file,
        )

        model = project._add_model_skip_gcs(
            model_name, tmp_file, geo_map, geometry_object_info, geometry_group_type_by_group_id
        )
        model._temp_dir = tmp_folder
        return model


class PointsGenerator:
    @staticmethod
    def _get_model_path():
        pass

    @staticmethod
    def _get_geometry_lib_model_path():
        pass

    @staticmethod
    def generate_valid_points(
        model: ModelObj | GeometryLibraryObj,
        max_count: int,
        ruleset: validation.PointRuleset,
        existing_receiver_points: list[Point3d] | list[list[float]] = None,
        existing_source_points: list[Point3d] | list[list[float]] = None,
        x_range: tuple[float, float] = None,
        y_range: tuple[float, float] = None,
        z_range: tuple[float, float] = None,
    ) -> list[Point3d]:
        """
        Tries to generate max_count valid points within bounds of the model and within the rules of the provided ruleset.

        :param model: Either a ModelObj, GeometryObj or a path to a valid 3dm model file.
        :param max_count: Maximum number of points you can receive.
        :param ruleset: What ruleset to use when validating points.
        :param existing_receiver_points: Validate as if these receivers were in the model.
        :param existing_source_points: Validate as if these sources were in the model.
        :param x_range: min-max x values to search within, if nothing given the bounding box will be taken
        :param y_range: min-max y values to search within, if nothing given the bounding box will be taken
        :param z_range: min-max z values to search within, if nothing given the bounding box will be taken
        """
        if isinstance(model, ModelObj) and model.status != "Valid":
            print("Unable to generate points until model has finished processing and has status = 'Valid'")
            return []
        model._has_valid_local_file(True)
        model = model._model_file_path

        mesh_collection = MeshCollection.load_3dm(model)
        bounding_box = mesh_collection.bounding_box()

        if existing_receiver_points is None:
            existing_receiver_points = []
        if existing_source_points is None:
            existing_source_points = []
        if existing_receiver_points and isinstance(existing_receiver_points[0], list):
            existing_receiver_points = [Point3d(*point) for point in existing_receiver_points]
        if existing_source_points and isinstance(existing_source_points[0], list):
            existing_source_points = [Point3d(*point) for point in existing_source_points]
        if x_range is None:
            x_range = (bounding_box.min.x, bounding_box.max.x)
        if y_range is None:
            y_range = (bounding_box.min.y, bounding_box.max.y)
        if z_range is None:
            z_range = (bounding_box.min.z, bounding_box.max.z)

        # Generate at least 250 random points within bounding box.
        generated_point_count = max(250, max_count * 10)
        generated_points = np.random.uniform(
            [x_range[0], y_range[0], z_range[0]],
            [x_range[1], y_range[1], z_range[1]],
            (generated_point_count, 3),
        )
        valid_point_count = 0
        valid_points = []
        for i in range(generated_point_count):
            if valid_point_count >= max_count:
                break

            point = Point3d(
                round(generated_points[i][0], 4),
                round(generated_points[i][1], 4),
                round(generated_points[i][2], 4),
            )

            # Check if point is too close to an already accepted point.
            if (
                ruleset.min_dist_from_other_points > 0
                and len(valid_points) > 0
                and not all(
                    [
                        helpers.point_dist_check(valid_point, point, ruleset.min_dist_from_other_points)
                        for valid_point in valid_points
                    ]
                )
            ):
                continue
            # Check if point is too close to an already existing receiver
            if (
                ruleset.min_dist_from_receivers > 0
                and len(existing_receiver_points) > 0
                and not all(
                    [
                        helpers.point_dist_check(receiver, point, ruleset.min_dist_from_receivers)
                        for receiver in existing_receiver_points
                    ]
                )
            ):
                continue
            # Check if point is too close to an already existing source.
            if (
                ruleset.min_dist_from_sources > 0
                and len(existing_source_points) > 0
                and not all(
                    [
                        helpers.point_dist_check(source, point, ruleset.min_dist_from_sources)
                        for source in existing_source_points
                    ]
                )
            ):
                continue

            # Check if point is within boundaries of the model.
            if helpers.point_in_model_check(point, mesh_collection) is False:
                continue

            # Check if point is too close to a surface.
            if helpers.point_close_to_surface_check(
                point=point,
                mesh_collection=mesh_collection,
                min_distance_from_surface=ruleset.min_dist_from_surface,
            ):
                continue

            valid_points.append(point)
            valid_point_count += 1

        if valid_point_count < max_count:
            logger.warning(
                f"Requested {max_count} valid points, but only {valid_point_count} could be generated. Please consider relaxing the rules."
            )

        return valid_points

    @staticmethod
    def generate_valid_grid(
        model: ModelObj | GeometryLibraryObj,
        x_res: float = None,
        y_res: float = None,
        z_res: float = None,
        x_range: tuple[float, float] = None,
        y_range: tuple[float, float] = None,
        z_range: tuple[float, float] = None,
        existing_points: list[Point3d] | list[list[float]] = None,
        min_dist_surf: float = 0.1,
        min_dist_existing_points: float = 0.1,
    ) -> list[Point3d]:
        """
        Generates a grid of points within bounds of the model or within the specified range. Grid points follow rules
        regarding minimum distance from surfaces of the model or minimum distance to other points (e.g. when generating
        a receiver grid and all receivers should have a minimum distance from the sources).

        :param model: Either a ModelObj, GeometryObj or a path to a valid 3dm model file.
        :param x_res: Grid resolution in x, in meters. If nothing is given, the grid includes only a single point at half of the x_range.
        :param y_res: Grid resolution in y, in meters. If nothing is given, the grid includes only a single point at half of the y_range.
        :param z_res: Grid resolution in z, in meters. If nothing is given, the grid includes only a single point at half of the z_range.
        :param x_range: min-max x values of the grid. Grid excludes max if max-min fits integer number of points.
            If nothing given the bounding box will be taken.
        :param y_range: min-max y values of the grid. Grid excludes max if max-min fits integer number of points.
            If nothing given the bounding box will be taken.
        :param z_range: min-max z values of the grid. Grid excludes max if max-min fits integer number of points.
            If nothing given the bounding box will be taken.
        :param existing_points: Grid points can be generated to have a minimum distance from these points.
        :param min_dist_surf: Minimum distance between generated grid points and surfaces of the model.
        :param min_dist_existing_points: Minimum distance between generated grid points and existing_points.
        """
        if isinstance(model, ModelObj) and model.status != "Valid":
            print("Unable to generate points until model has finished processing and has status = 'Valid'")
            return []
        model._has_valid_local_file(True)
        model = model._model_file_path

        mesh_collection = MeshCollection.load_3dm(model)
        bounding_box = mesh_collection.bounding_box()

        if existing_points is None:
            existing_points = []
        if existing_points and isinstance(existing_points[0], list):
            existing_points = [Point3d(*point) for point in existing_points]
        if x_range is None:
            x_range = (bounding_box.min.x, bounding_box.max.x)
        if y_range is None:
            y_range = (bounding_box.min.y, bounding_box.max.y)
        if z_range is None:
            z_range = (bounding_box.min.z, bounding_box.max.z)

        # If no resolution is given, just place a single point at half of the respective coordinate range
        if x_res is None:
            x_grid = 0.5 * (x_range[1] - x_range[0])
        else:
            x_grid = np.arange(x_range[0], x_range[1], x_res)
        if y_res is None:
            y_grid = 0.5 * (y_range[1] - y_range[0])
        else:
            y_grid = np.arange(y_range[0], y_range[1], y_res)
        if z_res is None:
            z_grid = 0.5 * (z_range[1] - z_range[0])
        else:
            z_grid = np.arange(z_range[0], z_range[1], z_res)

        # Generate grid and stack it into a single [n x 3] vector
        generated_grid = np.meshgrid(x_grid, y_grid, z_grid)
        generated_points = np.vstack([*map(np.ravel, generated_grid)]).T

        valid_points = []
        for raw_point in generated_points:
            point = Point3d(*np.round(raw_point, 4))

            # Check if point is too close to existing points
            if min_dist_existing_points > 0 and not all(
                [
                    helpers.point_dist_check(existing_point, point, min_dist_existing_points)
                    for existing_point in existing_points
                ]
            ):
                continue

            # Check if point is within boundaries of the model.
            if helpers.point_in_model_check(point, mesh_collection) is False:
                continue

            # Check if point is too close to a surface.
            if helpers.point_close_to_surface_check(
                point=point,
                mesh_collection=mesh_collection,
                min_distance_from_surface=min_dist_surf,
            ):
                continue

            valid_points.append(point)

        return valid_points


class GeometryDefinitionGenerator:
    @staticmethod
    def create_polygon_room(
        points_xy: list[Point2d], height_z: float, join_wall_layers=True, object_name=None
    ) -> GeometryDefinition:
        """
        Generate a polygon shaped room.
        :param points_xy: List of points defining the polygon in the xy-plane.
        :param height_z: height of room (z axis)
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        if object_name is None:
            object_name = "polygon_room"

        tmp_folder = TempFolder()
        tmp_file = tmp_folder.get_available_path("model.3dm")
        _ = _generator_internal.create_new_rhino_model(
            None,
            _generator_internal._polygon_room(object_name, points_xy, height_z, join_wall_layers),
            str(tmp_file),
        )
        return GeometryDefinition(str(tmp_file))

    @staticmethod
    def create_shoebox_room(
        width_x: float,
        depth_y: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> GeometryDefinition:
        """
        Generate a shoebox room.
        :param width_x: width of room in meters (x axis)
        :param depth_y: depth of room in meters (y axis)
        :param height_z: height of room in meters (z axis)
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
                                 Example with join_wall_layers set to True: ["shoebox_walls", "shoebox_floor", "shoebox_ceiling"]
                                 Example with join_wall_layers set to False: ["shoebox_wall_0", "shoebox_wall_1", "shoebox_wall_2", "shoebox_wall_3", "shoebox_floor", "shoebox_ceiling"]
                                 The walls are ordered counter-clockwise beginning with the wall coinciding with the x-axis.
        """
        return GeometryDefinitionGenerator.create_polygon_room(
            points_xy=[
                Point2d(0.0, 0.0),
                Point2d(width_x, 0.0),
                Point2d(width_x, depth_y),
                Point2d(0.0, depth_y),
            ],
            height_z=height_z,
            join_wall_layers=join_wall_layers,
            object_name="shoebox",
        )

    @staticmethod
    def create_random_shoebox_rooms(
        n_rooms: int,
        x_range: tuple[float, float],
        y_range: tuple[float, float],
        z_range: tuple[float, float],
        join_wall_layers: bool = True,
    ) -> list[GeometryDefinition]:
        """
        Generate multiple random shoebox rooms. The dimensions are randomly drawn from a specified range according to a uniform probability.
        :param n_rooms: Number of rooms to create
        :param x_range: The x length of all generated rooms are randomly drawn from this range.
        :param y_range: The y length of all generated rooms are randomly drawn from this range.
        :param z_range: The z length of all generated rooms are randomly drawn from this range.
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        rooms = []
        while len(rooms) < n_rooms:
            x = np.random.uniform(*x_range)
            y = np.random.uniform(*y_range)
            z = np.random.uniform(*z_range)

            # Generate Shoebox room
            rooms.append(
                GeometryDefinitionGenerator.create_shoebox_room(
                    width_x=x,
                    depth_y=y,
                    height_z=z,
                    join_wall_layers=join_wall_layers,
                )
            )

        return rooms

    @staticmethod
    def create_angled_shoebox_room(
        base_side: float,
        depth_y: float,
        left_angle: float,
        right_angle: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> GeometryDefinition:
        """
        Create shoebox room with angled side walls (= trapezoid room) as shown in the drawing below.
               ________________________
              /                        \                   ^
             /                          \                  |
            /<....                       \<.....           | depth_y
           /  LA :                        \ RA :           |
          /______:_________________________\...:...........v..
        0,0           base_side

        LA: left angle (in degrees, counter-clockwise from base_side)
        RA: right angle (in degrees, counter-clockwise from extension of base_side)
        """
        left_dir = _generator_internal._rotate_vector([1, 0], left_angle)
        right_dir = _generator_internal._rotate_vector([1, 0], right_angle)
        left_side = depth_y / math.sin(math.radians(left_angle))
        right_side = depth_y / math.sin(math.radians(right_angle))
        left_vertex = Point2d(left_dir[0] * left_side, left_dir[1] * left_side)
        right_vertex = Point2d(base_side + right_dir[0] * right_side, right_dir[1] * right_side)

        if left_vertex[0] >= right_vertex[0]:
            raise ValueError(
                "The specified angles result in an invalid room shape, where the left vertex is right of the right vertex. Please change the left angle and right angle or depth."
            )

        vertices = [Point2d(0, 0), Point2d(base_side, 0), right_vertex, left_vertex]
        return GeometryDefinitionGenerator.create_polygon_room(
            vertices,
            height_z,
            join_wall_layers,
            "angledShoebox",
        )

    @staticmethod
    def create_random_angled_shoebox_rooms(
        n_rooms: int,
        base_side_range: tuple[float, float],
        depth_range: tuple[float, float],
        left_angle_range: tuple[float, float],
        right_angle_range: tuple[float, float],
        height_range: tuple[float, float],
        join_wall_layers: bool = True,
    ) -> list[GeometryDefinition]:
        """
        Generate multiple random angled shoebox rooms. The dimensions are randomly drawn from a specified range according to a uniform probability. For details on how to specify each side of the room, please refer to create_angled_shoebox_room().
        :param n_rooms: Number of rooms to create
        :param base_side_range: The lengths of the base_side for all generated rooms are randomly drawn from this range.
        :param depth_range: The depths for all generated rooms are randomly drawn from this range.
        :param left_angle_range: The left angles (in degrees) for all generated rooms are randomly drawn from this range.
        :param right_angle_range: The right angles (in degrees) for all generated rooms are randomly drawn from this range.
        :param height_range: The heights for all generated rooms are randomly drawn from this range.
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        rooms = []
        while len(rooms) < n_rooms:
            base_side = np.random.uniform(*base_side_range)
            depth = np.random.uniform(*depth_range)
            left_angle = np.random.uniform(*left_angle_range)
            right_angle = np.random.uniform(*right_angle_range)
            height = np.random.uniform(*height_range)

            # Try to create room, but randomly drawn values could be invalid
            try:
                room = GeometryDefinitionGenerator.create_angled_shoebox_room(
                    base_side=base_side,
                    depth_y=depth,
                    left_angle=left_angle,
                    right_angle=right_angle,
                    height_z=height,
                    join_wall_layers=join_wall_layers,
                )
            except ValueError:
                continue

            rooms.append(room)

        return rooms

    @staticmethod
    def create_L_shaped_room(
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> GeometryDefinition:
        """
         Create L-shaped room with sides as shown in the drawing below.
          __________
         |          | d
         |      ____|
         |     |  c
         |     |
         |     | b
         |_____|
        0,0  a

        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        return GeometryDefinitionGenerator.create_polygon_room(
            [
                Point2d(0.0, 0.0),
                Point2d(a_side, 0.0),
                Point2d(a_side, b_side),
                Point2d(a_side + c_side, b_side),
                Point2d(a_side + c_side, b_side + d_side),
                Point2d(0.0, b_side + d_side),
            ],
            height_z,
            join_wall_layers,
            "lshape",
        )

    @staticmethod
    def create_random_L_shaped_rooms(
        n_rooms: int,
        a_side_range: tuple[float, float],
        b_side_range: tuple[float, float],
        c_side_range: tuple[float, float],
        d_side_range: tuple[float, float],
        height_range: tuple[float, float],
        join_wall_layers: bool = True,
    ) -> list[GeometryDefinition]:
        """
        Generate multiple random L-shaped rooms. The dimensions are randomly drawn from a specified range according to a uniform probability. For details on how to specify each side of the room, please refer to create_L_shaped_room().
        :param n_rooms: Number of rooms to create
        :param a_side_range: The lengths of the a_side for all generated rooms are randomly drawn from this range.
        :param b_side_range: The lengths of the b_side for all generated rooms are randomly drawn from this range.
        :param c_side_range: The lengths of the c_side for all generated rooms are randomly drawn from this range.
        :param d_side_range: The lengths of the d_side for all generated rooms are randomly drawn from this range.
        :param height_range: The heights for all generated rooms are randomly drawn from this range.
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        rooms = []
        while len(rooms) < n_rooms:
            a_side = np.random.uniform(*a_side_range)
            b_side = np.random.uniform(*b_side_range)
            c_side = np.random.uniform(*c_side_range)
            d_side = np.random.uniform(*d_side_range)
            height = np.random.uniform(*height_range)

            rooms.append(
                GeometryDefinitionGenerator.create_L_shaped_room(
                    a_side=a_side,
                    b_side=b_side,
                    c_side=c_side,
                    d_side=d_side,
                    height_z=height,
                    join_wall_layers=join_wall_layers,
                )
            )

        return rooms

    @staticmethod
    def create_T_shaped_room(
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> GeometryDefinition:
        """
        Create T-shaped room with sides as shown in the drawing below.
                   d
                _______
               |       |                  ^
             b |       |                  |
               |       |                  |
               |       | c              length
           ____|       |____              |
        a |                 |             |
          |_________________|             v
         0,0

         <------ width ------>

        a+b   = length
        2*c+d = width

        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        width = 2 * c_side + d_side
        length = a_side + b_side
        return GeometryDefinitionGenerator.create_polygon_room(
            [
                Point2d(0.0, 0.0),
                Point2d(width, 0.0),
                Point2d(width, a_side),
                Point2d(width - c_side, a_side),
                Point2d(width - c_side, length),
                Point2d(c_side, length),
                Point2d(c_side, a_side),
                Point2d(0, a_side),
            ],
            height_z,
            join_wall_layers,
            "tshape",
        )

    @staticmethod
    def create_random_T_shaped_rooms(
        n_rooms: int,
        a_side_range: tuple[float, float],
        b_side_range: tuple[float, float],
        c_side_range: tuple[float, float],
        d_side_range: tuple[float, float],
        height_range: tuple[float, float],
        join_wall_layers: bool = True,
    ) -> list[GeometryDefinition]:
        """
        Generate multiple random T-shaped rooms. The dimensions are randomly drawn from a specified range according to a uniform probability. For details on how to specify each side of the room, please refer to create_T_shaped_room().
        :param n_rooms: Number of rooms to create
        :param a_side_range: The lengths of the a_side for all generated rooms are randomly drawn from this range.
        :param b_side_range: The lengths of the b_side for all generated rooms are randomly drawn from this range.
        :param c_side_range: The lengths of the c_side for all generated rooms are randomly drawn from this range.
        :param d_side_range: The lengths of the d_side for all generated rooms are randomly drawn from this range.
        :param height_range: The heights for all generated rooms are randomly drawn from this range.
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        rooms = []
        while len(rooms) < n_rooms:
            a_side = np.random.uniform(*a_side_range)
            b_side = np.random.uniform(*b_side_range)
            c_side = np.random.uniform(*c_side_range)
            d_side = np.random.uniform(*d_side_range)
            height = np.random.uniform(*height_range)

            rooms.append(
                GeometryDefinitionGenerator.create_T_shaped_room(
                    a_side=a_side,
                    b_side=b_side,
                    c_side=c_side,
                    d_side=d_side,
                    height_z=height,
                    join_wall_layers=join_wall_layers,
                )
            )

        return rooms

    @staticmethod
    def create_U_shaped_room(
        a_side: float,
        b_side: float,
        c_side: float,
        d_side: float,
        height_z: float,
        join_wall_layers: bool = True,
    ) -> GeometryDefinition:
        """
        Create U-shaped room with sides as shown in the drawing below.

            c
           ___          ___
          |   |        |   |         ^
          |   |        |   |         |
          |   |        |   |         | b
          |   |   d    |   |         |
          |   |________|   |    ^    v
          |                |    | a
          |________________|    v
         0,0

        :param a_side: length of the lower part of the U in meters
        :param b_side: length of the upper part of the U in meters
        :param c_side: width of the upper part of the U in meters
        :param d_side: width of the inside part of the U in meters
        :param height_z: height of room in meters
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        length = a_side + b_side
        width = 2 * c_side + d_side
        return GeometryDefinitionGenerator.create_polygon_room(
            [
                Point2d(0.0, 0.0),
                Point2d(width, 0.0),
                Point2d(width, length),
                Point2d(width - c_side, length),
                Point2d(width - c_side, a_side),
                Point2d(c_side, a_side),
                Point2d(c_side, length),
                Point2d(0.0, length),
            ],
            height_z,
            join_wall_layers,
            "ushape",
        )

    @staticmethod
    def create_random_U_shaped_rooms(
        n_rooms: int,
        a_side_range: tuple[float, float],
        b_side_range: tuple[float, float],
        c_side_range: tuple[float, float],
        d_side_range: tuple[float, float],
        height_range: tuple[float, float],
        join_wall_layers: bool = True,
    ) -> list[GeometryDefinition]:
        """
        Generate multiple random U-shaped rooms. The dimensions are randomly drawn from a specified range according to a uniform probability. For details on how to specify each side of the room, please refer to create_U_shaped_room().
        :param n_rooms: Number of rooms to create
        :param a_side_range: The lengths of the a_side for all generated rooms are randomly drawn from this range.
        :param b_side_range: The lengths of the b_side for all generated rooms are randomly drawn from this range.
        :param c_side_range: The lengths of the c_side for all generated rooms are randomly drawn from this range.
        :param d_side_range: The lengths of the d_side for all generated rooms are randomly drawn from this range.
        :param height_range: The heights for all generated rooms are randomly drawn from this range.
        :param join_wall_layers: if True, walls will be put on a single layer, if False, the model will have a layer for each wall in the room.
        """
        rooms = []
        while len(rooms) < n_rooms:
            a_side = np.random.uniform(*a_side_range)
            b_side = np.random.uniform(*b_side_range)
            c_side = np.random.uniform(*c_side_range)
            d_side = np.random.uniform(*d_side_range)
            height = np.random.uniform(*height_range)

            rooms.append(
                GeometryDefinitionGenerator.create_U_shaped_room(
                    a_side=a_side,
                    b_side=b_side,
                    c_side=c_side,
                    d_side=d_side,
                    height_z=height,
                    join_wall_layers=join_wall_layers,
                )
            )

        return rooms


class GeometryComponentGenerator:
    @staticmethod
    def load_3dm(component_name: str, path: str):
        return _generator_utils._mc_to_gc(component_name, MeshCollection.load_3dm(path))

    @staticmethod
    def create_box(
        bounding_box: BoundingBox = BoundingBox.from_points(-1, 1, -1, 1, -1, 1),
        layer_name: str = "box",
    ) -> GeometryComponent:
        """
        Create a box mesh with the given dimensions
        :param bounding_box: BoundingBox object with the min and max coordinates of the box
        :param layer_name: name of the layer of the box
        """
        mc = MeshCollection.create_box(
            bounding_box.min.x,
            bounding_box.max.x,
            bounding_box.min.y,
            bounding_box.max.y,
            bounding_box.min.z,
            bounding_box.max.z,
            layer_name,
        )
        return _generator_utils._mc_to_gc(layer_name, mc)

    @staticmethod
    def create_plane(length: float = 1.0, width: float = 1.0, layer_name: str = "plane"):
        """
        Create a plane mesh with the given dimensions

        :param length: length of the plane in meters
        :param width: width of the plane in meters
        :param layer_name: name of the layer of the plane
        """
        mc = MeshCollection.create_plane(length, width, layer_name)
        return _generator_utils._mc_to_gc(layer_name, mc)

    @staticmethod
    def create_triangle(
        point0: Point3d = Point3d(0, 0, 0),
        point1: Point3d = Point3d(0, 1, 0),
        point2: Point3d = Point3d(0, 0, 1),
        layer_name: str = "triangle",
    ) -> GeometryComponent:
        """
        Create a plane mesh with the given dimensions

        :param point0: first point of the triangle
        :param point1: second point of the triangle
        :param point2: third point of the triangle
        :param layer_name: name of the layer of the triangle
        """

        mc = MeshCollection.create_triangle(point0.to_list(), point1.to_list(), point2.to_list(), layer_name)
        return _generator_utils._mc_to_gc(layer_name, mc)

    @staticmethod
    def create_loudspeaker(
        width: float,
        depth: float,
        height: float,
        membrane_diameter: float,
        membrane_center_height: float,
        membrane_resulution: int = 12,
        enclosure_layer_name: str = "enclosure",
        membrane_layer_name: str = "membrane",
    ) -> "MeshCollection":
        """
        Create a speaker mesh with the given dimensions
        :param width: width of the speaker in meters
        :param depth: depth of the speaker in meters
        :param height: height of the speaker in meters
        :param membrane_diameter: diameter of the membrane
        :param membrane_center_height: height of the membrane center from the bottom of the enclosure
        :param membrane_resulution: Number of points to use for the membrane
        """
        mc = MeshCollection.create_loudspeaker(
            width=width,
            depth=depth,
            height=height,
            membrane_diameter=membrane_diameter,
            membrane_center_height=membrane_center_height,
            membrane_resulution=membrane_resulution,
            enclosure_layer_name=enclosure_layer_name,
            membrane_layer_name=membrane_layer_name,
        )
        return _generator_utils._mc_to_gc("loudspeaker", mc)
