import math

import pyvista as pv
import numpy as np
from .mesh_collection import MeshCollection
from ..utility_classes import Point3d
from ..client.api_models import ReceiverDto, SourceDto
from ..treble_logging import logger


def equidistributed_points_on_sphere(radius, num, center_point: Point3d = Point3d(0, 0, 0)) -> list[Point3d]:
    a = 4.0 * math.pi * (radius**2.0 / num)
    d = math.sqrt(a)
    m_theta = int(round(math.pi / d))
    d_theta = math.pi / m_theta
    d_phi = a / d_theta

    points = []
    for m in range(0, m_theta):
        theta = math.pi * (m + 0.5) / m_theta
        m_phi = int(round(2.0 * math.pi * math.sin(theta) / d_phi))
        for n in range(0, m_phi):
            phi = 2.0 * math.pi * n / m_phi
            x = radius * math.sin(theta) * math.cos(phi)
            y = radius * math.sin(theta) * math.sin(phi)
            z = radius * math.cos(theta)
            points.append(Point3d(center_point[0] + x, center_point[1] + y, center_point[2] + z))
    return points


def point_close_to_surface_check(
    point: Point3d,
    mesh_collection: MeshCollection,
    min_distance_from_surface: float,
    number_of_rays: int = 100,
) -> bool:
    """
    Use ray tracing to check whether point is too close to surface

    :param Point3d: Point of origin
    :param MeshCollection mesh_collection: Mesh collection including mesh, outer_shell,
        inner_volume and bounding_box
    :param float min_distance_from_surface: Minimum distance from a surface
    :param int number_of_rays: Number of rays to shoot to do the check, defaults to 100
    :return bool: True if point is too close to a surface
    """
    # Check buffer zone.
    if number_of_rays and min_distance_from_surface > 0:
        # Shoot out 500 rays in a sphere around point and check for intersections with model.
        points_on_sphere = equidistributed_points_on_sphere(
            radius=1, num=number_of_rays, center_point=Point3d(0, 0, 0)
        )
        buffer_points = [
            [
                p.x * min_distance_from_surface + point.x,
                p.y * min_distance_from_surface + point.y,
                p.z * min_distance_from_surface + point.z,
            ]
            for p in points_on_sphere
        ]

        for buffer_point in buffer_points:
            intersection_points, _ = mesh_collection.mesh.ray_trace(point.to_list(), buffer_point)
            if len(intersection_points) > 0:
                return True
    return False


def points_in_model_check(
    points: list[Point3d],
    mesh_collection: MeshCollection,
) -> list[bool]:
    """
    Check if point is valid within the bounds in model.
    :param point: Receiver/Source location.
    :param mesh_collection: Mesh collection including mesh, outer_shell, inner_volume and bounding_box.
    :returns: True if point is valid, False otherwise
    """
    # This functions performs batch operations which return a boolean mask which is then used to filter the points if they are valid or not.
    # Convert points to numpy array for faster processing.
    np_points = np.array([p.to_list() for p in points])
    # Bounding box filtering
    bb = mesh_collection.bounding_box()
    valid_points_mask = np.array([bb.point_in_box(p) for p in points])

    # Get original indices where valid_points_mask is True
    # Filter by mask
    valid_points_indices = np.where(valid_points_mask)[0]
    valid_points_list = np_points[valid_points_mask]

    if not valid_points_list.any():
        return list(valid_points_mask.astype(bool))  # No points left after bounding box check

    # Use PyVista's select_enclosed_points for batch external volume check, only works for watertight meshes.
    # But it's significantly faster than the old ray tracing method.
    ray_trace_fallback = False
    try:
        polydata = pv.PolyData(valid_points_list)
        selected = polydata.select_enclosed_points(mesh_collection.outer_shell())
        enclosed_flags = selected["SelectedPoints"].astype(bool)
    except RuntimeError as e:
        if "Surface is not closed" in str(e):
            # Model not watertight, fall back to ray tracing.
            logger.debug("Points in model check. Model not watertight, falling back to ray tracing.")
            ray_trace_fallback = True
        else:
            raise

    if ray_trace_fallback:
        ray_z_max = abs(mesh_collection.bounding_box().min.z) + abs(mesh_collection.bounding_box().max.z) + 1
        ray_endpoints = np.array([[p[0], p[1], ray_z_max + p[2]] for p in valid_points_list])
        ray_trace_mask = []
        for i, point in enumerate(valid_points_list):
            ray_z_max = (
                abs(mesh_collection.bounding_box().min.z) + abs(mesh_collection.bounding_box().max.z) + 1
            )
            ray_end_point = [point[0], point[1], ray_z_max + point[2]]
            intersection_points, _ = mesh_collection.outer_shell().ray_trace(point, ray_end_point)
            ray_trace_mask.append(len(intersection_points) % 2 != 0)
        enclosed_flags = np.array(ray_trace_mask).astype(bool)

    # Update original mask.
    valid_points_mask[valid_points_indices] = enclosed_flags
    # Filter by mask.
    valid_points_indices = valid_points_indices[enclosed_flags]
    valid_points_list = valid_points_list[enclosed_flags]

    if not valid_points_list.any():
        return list(valid_points_mask.astype(bool))

    # Ray tracing checks for collision with internal volume.
    # Assuming we always shoot straight up the Y axis.
    # Find needed max ray length.
    # Compute ray endpoints for inner volume check
    ray_z_max = abs(mesh_collection.bounding_box().min.z) + abs(mesh_collection.bounding_box().max.z) + 1
    ray_endpoints = np.array([[p[0], p[1], ray_z_max + p[2]] for p in valid_points_list])

    # Check if point is inside internal volume.
    inner_volume = mesh_collection.inner_volume()
    if inner_volume.n_cells > 0:
        ray_trace_mask = [
            len(inner_volume.ray_trace(p, ray_endpoints[i])[0]) % 2 == 0
            for i, p in enumerate(valid_points_list)
        ]
        # Update original mask.
        valid_points_mask[valid_points_indices] = ray_trace_mask
        valid_points_list = valid_points_list[ray_trace_mask]

    return valid_points_mask


def point_in_model_check(
    point: Point3d,
    mesh_collection: MeshCollection,
) -> bool:
    """
    Check if point is valid within the bounds in model.
    :param point: Receiver/Source location.
    :param mesh_collection: Mesh collection including mesh, outer_shell, inner_volume and bounding_box.
    :returns: True if point is valid, False otherwise
    """

    # Bounding box check first.
    bb = mesh_collection.bounding_box()
    if not bb.point_in_box(point):
        return False

    # Check if point is inside model external shell.
    ray_trace_fallback = False
    try:
        select = pv.PolyData(point.to_list()).select_enclosed_points(mesh_collection.outer_shell())
        if select["SelectedPoints"][0] == 0:
            return False
    except RuntimeError as e:
        if "Surface is not closed" in str(e):
            # Model not watertight, fall back to ray tracing.
            logger.debug("Point in model check. Model not watertight, falling back to ray tracing.")
            ray_trace_fallback = True
        else:
            raise

    if ray_trace_fallback:
        ray_z_max = abs(mesh_collection.bounding_box().min.z) + abs(mesh_collection.bounding_box().max.z) + 1
        ray_end_point = Point3d(point[0], point[1], ray_z_max + point[2])
        intersection_points, _ = mesh_collection.outer_shell().ray_trace(
            point.to_list(), ray_end_point.to_list()
        )
        if len(intersection_points) % 2 == 0:
            # Even number of intersections means point is outside the model.
            return False

    # Ray tracing checks
    # Assuming we always shoot straight up the Y axis.
    # Find needed max ray length.
    ray_z_max = (
        abs(mesh_collection.bounding_box().min.z) + abs(mesh_collection.bounding_box().max.z) + 1
    ) + point.z
    ray_end_point = [point.x, point.y, ray_z_max]

    # Check if point is inside internal volume.
    if mesh_collection.inner_volume().n_cells > 0:
        intersection_points, _ = mesh_collection.inner_volume().ray_trace(point.to_list(), ray_end_point)
        if len(intersection_points) % 2 != 0:
            return False

    return True


def points_dist_check(a: Point3d, b: list[Point3d], min_dist: float) -> bool:
    """
    Returns true if point a is >= min_dist apart from all points in list b.
    """
    return all([point_dist_check(a, point_b, min_dist) for point_b in b])


def point_dist_check(a: Point3d, b: Point3d, min_dist: float) -> bool:
    """
    Returns true if point a and b are >= min_dist apart.
    """
    if isinstance(a, SourceDto) or isinstance(a, ReceiverDto):
        a = a.pos_as_point()
    if isinstance(b, SourceDto) or isinstance(b, ReceiverDto):
        b = b.pos_as_point()

    return math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2) >= min_dist
