import importlib
import base64
import json
import os
import tempfile
from packaging.version import Version
from pathlib import Path

import pyvista as pv
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from rhino3dm import File3dm
from treble_tsdk.core.source import Source

from ..tsdk import TSDK
from ..treble_logging import logger
from ..client.tsdk_client import TSDKClient
from ..core.model_obj import MaterialAssignment, ModelObj
from ..core.source_directivity_obj import SourceDirectivityObj
from ..core.geometry_library_obj import GeometryLibraryObj
from ..core.simulation import Simulation
from ..core.receiver import Receiver, ReceiverType
from ..core.temp_folder import TempFolder
from ..core.source_boundary_velocity import BoundaryVelocitySubmodel
from ..core.material_obj import Material
from ..client.api_models import (
    MaterialAssignmentDto,
    SourceDto,
    ReceiverDto,
    SourcePropertiesDto,
    ReceiverPropertiesDto,
    PositionSuggestionDto,
)
from ..utility_classes import Transform3d, Point3d, Rotation, View2d
from ._geometry_feedback import create_feedback_plotter, FeedbackObject, GeometryFeedback
from .mesh_collection import MeshCollection, _get_valid_layer_name, _load_layer_names_with_ids_from_3dm
from . import validation


def _spherical_to_cartesian(radius, azimuth, elevation):
    # Convert spherical coordinates to Cartesian coordinates
    rcos_theta = radius * np.cos(np.deg2rad(elevation))
    x = rcos_theta * np.cos(np.deg2rad(azimuth))
    y = rcos_theta * np.sin(np.deg2rad(azimuth))
    z = radius * np.sin(np.deg2rad(elevation))
    return x, y, z


def _add_source_data_to_plot(plot: "pv.Plotter", item: Source):
    """
    Adds direction as arrow to source plot if applicable.
    """
    ele = 0.0
    azi = 0.0
    if item.source_properties:
        azi = item.source_properties.azimuth_angle
        ele = item.source_properties.elevation_angle

    # Calculate the end point for the direction line
    dx, dy, dz = _spherical_to_cartesian(1.0, azi, ele)
    plot.add_mesh(
        pv.Arrow(start=item.pos_as_point().to_list(), direction=(dx, dy, dz), scale=0.08), color="black"
    )


def _add_position_suggestion_data_to_plot(plot: "pv.Plotter", item: PositionSuggestionDto):
    """
    Adds direction as arrow to source plot if applicable.
    """
    if item.azimuth_angle is not None and item.elevation_angle is not None:
        ele = item.elevation_angle
        azi = item.azimuth_angle
        dx, dy, dz = _spherical_to_cartesian(1.0, azi, ele)
        plot.add_mesh(pv.Arrow(start=item.position, direction=(dx, dy, dz), scale=0.08), color="black")


def _add_receiver_data_to_plot(plot: "pv.Plotter", item: Receiver):
    """
    Adds direction as arrow and spatial radius as sphere to receiver plot if applicable.
    """
    # Add spatial sphere.
    if item.receiver_type.value == "Spatial":
        spatial_radius = 0.1
        if item.receiver_properties:
            spatial_radius = item.receiver_properties.spatial_radius

        plot.add_mesh(
            pv.Sphere(spatial_radius, item.pos_as_point().to_list()),
            color="white",
            opacity=0.2,
        )


def _add_points_to_plot(
    plot: "pv.Plotter",
    items: list[Source] | list[Receiver],
    point_size: int,
    point_color: str,
    label_suffix: str = "",
    buffer_sphere_radius: float = None,
    disable_labels: bool = False,
):
    if items and len(items) > 0:
        if not disable_labels:
            show_label_items = [i for i in items if i.label and not i.label.startswith("_")]
            plot.add_point_labels(
                [i.pos_as_point().to_list() for i in show_label_items],
                [f"{i.label}{label_suffix}" for i in show_label_items],
                show_points=False,
                shape_opacity=0.3,
            )
        plot.add_points(
            pv.PolyData([i.pos_as_point().to_list() for i in items]),
            point_size=point_size,
            style="points",
            color=point_color,
        )

        for item in items:
            if isinstance(item, Source) and item.source_type.value != "Omni":
                _add_source_data_to_plot(plot, item)
            elif isinstance(item, Receiver):
                _add_receiver_data_to_plot(plot, item)

            # Add error sphere
            if buffer_sphere_radius:
                plot.add_mesh(
                    pv.Sphere(buffer_sphere_radius, item.pos_as_point().to_list()), color="red", opacity=0.3
                )


def _add_mesh_to_plot(plot: "pv.Plotter", mesh: pv.PolyData):
    sargs = dict(interactive=True, label_font_size=12)
    p_mesh = plot.add_mesh(
        mesh,
        scalars="layer_name",
        scalar_bar_args=sargs,
        opacity=1,
        cmap=mpl.pyplot.colormaps.get_cmap("rainbow"),
    )
    f = lambda val: p_mesh.GetProperty().SetOpacity(val)
    plot.add_slider_widget(f, [0.0, 1.0], title="Model opacity", pointa=(0.35, 0.1), pointb=(0.64, 0.1))


def _add_submodel_sources_to_mesh_collection(
    simulation: Simulation,
    mesh_collection: MeshCollection,
    sources: list[Source],
    invalid_source_identifiers: list[str],
) -> MeshCollection:
    join_meshes = [mesh_collection]
    for source in sources:
        submodel_id = source.source_properties.boundary_velocity_submodel_id
        if submodel_id not in simulation._boundary_velocity_submodel_cache:
            simulation._boundary_velocity_submodel_cache[submodel_id] = BoundaryVelocitySubmodel(
                simulation._client.boundary_velocity_submodel.get_by_id(submodel_id),
                client=simulation._client,
            )
        source_submodel = simulation._boundary_velocity_submodel_cache[submodel_id]
        submodel_mesh_collection = source_submodel._get_mesh_collection()
        submodel_mesh_collection = submodel_mesh_collection.transform(
            Transform3d(
                Point3d(x=source.x, y=source.y, z=source.z),
                Rotation(
                    azimuth=source.source_properties.azimuth_angle,
                    elevation=source.source_properties.elevation_angle,
                    roll=0,
                ),
            ),
        )
        join_meshes.append(submodel_mesh_collection)
    return MeshCollection.join_mesh_collections(join_meshes, False)


def plot_simulation(
    simulation: Simulation,
    with_validation: bool = True,
    view_2d: View2d = None,
    disable_labels: bool = False,
):
    """
    Plot a simulation.

    :param Simulation simulation: The Simulation object to plot.
    :param bool with_validation: Plot validation results. Optional, defaults to true.
    :param view_2d: Show a 2d view, choose between None, "xy", "xz", "yz". Optional, defaults to None.
    :param disable_labels: Disables source and receiver labels. Optional, defaults to false.
    """
    # Jupyter: notebook, pythreejs, trame
    model_obj = simulation.get_model()
    if hasattr(model_obj, "status") and model_obj.status != "Valid":
        print(
            f"Unable to plot model until model processing has completed and model status is 'Valid'. Model status is {model_obj.status}"
        )
        return
    model_obj._has_valid_local_file(True)

    mesh_collection = MeshCollection.load_3dm(model_obj._model_file_path)

    valid_point_source_list = []
    invalid_point_source_list = []
    submodel_source_list = []
    valid_receiver_list = []
    invalid_receiver_list = []

    validation_results = None
    invalid_source_identifiers = []
    invalid_receiver_identifiers = []

    if with_validation:
        # Perform validation and store invalid sources and receivers information.
        validation_results = validation.validate_simulation(simulation)
        for result in validation_results.invalid_sources:
            if s_id := result.source_id:
                invalid_source_identifiers.append(s_id)
            invalid_source_identifiers.append(result.source_label)
        for result in validation_results.invalid_receivers:
            if r_id := result.receiver_id:
                invalid_receiver_identifiers.append(r_id)
            invalid_receiver_identifiers.append(result.receiver_label)

    for source in simulation.sources:
        if (
            source.source_type.value == "BoundaryVelocity"
            and source.source_properties.boundary_velocity_submodel_id
        ):
            submodel_source_list.append(source)
            valid_point_source_list.append(source)

        # Point source
        if (source.id in invalid_source_identifiers) or (source.label in invalid_source_identifiers):
            invalid_point_source_list.append(source)
        else:
            valid_point_source_list.append(source)

    for receiver in simulation.receivers:
        if (receiver.id in invalid_receiver_identifiers) or (receiver.label in invalid_receiver_identifiers):
            invalid_receiver_list.append(receiver)
        else:
            valid_receiver_list.append(receiver)

    pl = pv.Plotter()
    pl.set_background("#1E1E2E")
    # Settings
    pl.add_axes()
    pl.show_grid()

    if submodel_source_list:
        mesh_collection = _add_submodel_sources_to_mesh_collection(
            simulation=simulation,
            mesh_collection=mesh_collection,
            sources=submodel_source_list,
            invalid_source_identifiers=invalid_source_identifiers,
        )

    _add_mesh_to_plot(pl, mesh_collection.mesh)
    _add_points_to_plot(pl, valid_receiver_list, 8, "blue", disable_labels=disable_labels)
    _add_points_to_plot(pl, invalid_receiver_list, 8, "red", "*", 0.15, disable_labels=disable_labels)
    _add_points_to_plot(pl, valid_point_source_list, 10, "yellow", disable_labels=disable_labels)
    _add_points_to_plot(pl, invalid_point_source_list, 10, "red", "*", 0.25, disable_labels=disable_labels)

    if view_2d:
        if Version(pv.__version__) >= Version("0.44.0"):
            if view_2d == View2d.xz:
                pl.view_xz()
            elif view_2d == View2d.yz:
                pl.view_yz()
            elif view_2d == View2d.xy:
                pl.view_xy()
            else:
                logger.warning(
                    "Invalid view_2d parameter, choose between None, 'xy', 'xz', 'yz'! Defaulting to 'xy'."
                )
                pl.view_xz()

            pl.enable_parallel_projection()
            pl.enable_2d_style()
            # Center the camera on model.
            pl.reset_camera()
        else:
            logger.warning("2D view requires pyvista version 0.44.0 or higher. Defaulting to 3D view.")
    # return pl
    pl.show()


def plot_simulation_dash(simulation: Simulation, with_validation: bool = True, view2d: View2d = None):
    """
    Plot a simulation.

    :param Simulation simulation: The Simulation object to plot.
    :param bool with_validation: Plot validation results. Optional, defaults to true.
    """
    model_obj = simulation.get_model()
    if hasattr(model_obj, "status") and model_obj.status != "Valid":
        print(
            f"Unable to plot model until model processing has completed and model status is 'Valid'. Model status is {model_obj.status}"
        )
        return
    model_obj._has_valid_local_file(True)

    layers_by_id = []
    submodel_source_list = []
    submodel_material_assignment_dtos: list[MaterialAssignmentDto] = []
    valid_source_list = []
    invalid_source_list = []
    valid_receiver_list = []
    invalid_receiver_list = []

    invalid_source_identifiers = []
    invalid_receiver_identifiers = []

    if with_validation:
        validation_results = validation.validate_simulation(simulation)
        invalid_source_list = [result for result in validation_results.invalid_sources]
        invalid_source_identifiers = [
            result.source_id or result.source_label for result in invalid_source_list
        ]
        invalid_receiver_list = [result for result in validation_results.invalid_receivers]
        invalid_receiver_identifiers = [
            result.receiver_id or result.receiver_label for result in invalid_receiver_list
        ]

    for source in simulation.sources:
        if (
            source.source_type.value == "BoundaryVelocity"
            and source.source_properties.boundary_velocity_submodel_id
        ):
            submodel_source_list.append(source)
            # Load submodel object
            submodel_id = source.source_properties.boundary_velocity_submodel_id
            if submodel_id not in simulation._boundary_velocity_submodel_cache:
                simulation._boundary_velocity_submodel_cache[submodel_id] = BoundaryVelocitySubmodel(
                    simulation._client.boundary_velocity_submodel.get_by_id(submodel_id),
                    client=simulation._client,
                )
            source_submodel = simulation._boundary_velocity_submodel_cache[submodel_id]
            assignments = source_submodel._get_material_assignments()
            if assignments != None:
                submodel_material_assignment_dtos.extend(assignments)

        if (getattr(source, "id", None) or source.label) not in invalid_source_identifiers:
            valid_source_list.append(source)

    valid_receiver_list = [
        receiver
        for receiver in simulation.receivers
        if (getattr(receiver, "id", None) or receiver.label) not in invalid_receiver_identifiers
    ]

    # combine the materials assignments of the simulation definitions and the submodels into one list
    material_assignments = simulation.get_simulation_definition().material_assignment
    materials = {
        x.materialId: simulation._client.material.get_material_by_id(x.materialId)
        for x in submodel_material_assignment_dtos
    }
    material_assignments.extend(
        [
            MaterialAssignment(
                layer_name=m.layerName,
                material=materials[m.materialId],
                scattering_coefficient=m.scatteringCoefficient,
            )
            for m in submodel_material_assignment_dtos
        ]
    )

    # add the subnmodels to the model
    if submodel_source_list:
        mesh_collection = MeshCollection.load_3dm(model_obj._model_file_path)
        mesh_collection = _add_submodel_sources_to_mesh_collection(
            simulation=simulation,
            mesh_collection=mesh_collection,
            sources=submodel_source_list,
            invalid_source_identifiers=invalid_source_identifiers,
        )

        model = mesh_collection._as_simple_3dm()
        model_data = model.Encode()
        layers_by_id = _load_layer_names_with_ids_from_3dm(model)

    else:
        with open(model_obj._model_file_path, "rb") as f:
            model_data = base64.b64encode(f.read()).decode("utf-8")
        layers_by_id = _load_layer_names_with_ids_from_3dm(model_obj._model_file_path)

    # update layer names in material_assignments to match model names in the combined model
    # _add_submodel_sources_to_mesh_collection uses _get_valid_layer_name to get a unique name for layers
    # when there are multiple layers with the same name, we assume the same order of items
    global_layer_index = 0
    global_layer_indices_pr_name = {}
    for m in material_assignments:
        new_layer_name = _get_valid_layer_name(m.layer_name, list(global_layer_indices_pr_name.keys()))
        m.layer_name = new_layer_name
        if m.layer_name not in global_layer_indices_pr_name:
            global_layer_indices_pr_name[m.layer_name] = global_layer_index
            global_layer_index += 1

    try:
        importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_simulation(
            model_data,
            layers_by_id,
            model_obj._compute_model_volume(),
            material_assignments,
            valid_source_list,
            valid_receiver_list,
            invalid_source_list,
            invalid_receiver_list,
            view2d,
        )
    except ImportError:
        logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_geometry(geometry: GeometryLibraryObj, client: TSDK = None):
    """
    Plot geometry

    :param GeometryLibraryObj geometry: Geometry object to plot.
    :param TSDK client: Instance of TSDK client, used to download the geometry
    """
    file_path = None
    if geometry._has_valid_local_file(True):
        file_path = geometry._model_file_path
    elif client is not None:
        file_path = os.path.join(tempfile.mkdtemp(), "model.3dm")
        client.geometry_library.download(geometry.id, file_path)
    else:
        print("Unable to plot geometry. Unable to find/download geometry file.")
        return

    mesh_collection = MeshCollection.load_3dm(file_path)

    pl = pv.Plotter()
    pl.set_background("#1E1E2E")
    pl.add_axes()
    pl.show_grid()

    _add_mesh_to_plot(pl, mesh_collection.mesh)

    if geometry.position_suggestions:
        points_to_plot = [
            ReceiverDto(ReceiverType.mono, pos.name, pos.position[0], pos.position[1], pos.position[2])
            for pos in geometry.position_suggestions
        ]
        _add_points_to_plot(pl, points_to_plot, 10, "black")
        for pos in geometry.position_suggestions:
            _add_position_suggestion_data_to_plot(pl, pos)

    pl.show()


def plot_geometry_dash(geometry: GeometryLibraryObj, view2d: View2d = None, client: TSDK = None):
    """
    Plot geometry

    :param GeometryLibraryObj geometry: Geometry object to plot.
    :param TSDK client: Instance of TSDK client, used to download the geometry
    """
    file_path = None
    if geometry._has_valid_local_file(True):
        file_path = geometry._model_file_path
    elif client is not None:
        file_path = os.path.join(tempfile.mkdtemp(), "model.3dm")
        client.geometry_library.download(geometry.id, file_path)
    else:
        print("Unable to plot geometry. Unable to find/download geometry file.")
        return

    # Read the file as bytes and encode to base64
    with open(file_path, "rb") as f:
        geometry_data = base64.b64encode(f.read()).decode("utf-8")

    layers = _load_layer_names_with_ids_from_3dm(file_path)

    try:
        suggested_points = (
            [
                ReceiverDto(
                    receiverType="",
                    label=pos.name,
                    x=pos.position.x,
                    y=pos.position.y,
                    z=pos.position.z,
                    receiverProperties=(
                        ReceiverPropertiesDto(
                            azimuthAngle=getattr(getattr(pos, "orientation", None), "azimuth", None),
                            elevationAngle=getattr(getattr(pos, "orientation", None), "elevation", None),
                        )
                    ),
                )
                for pos in geometry.position_suggestions
            ]
            if geometry.position_suggestions != None
            else []
        )

        importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_geometry(
            geometry_data, layers, suggested_points, geometry.volumeM3, view2d
        )
    except ImportError:
        logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_model_obj(model: ModelObj):
    """
    Plot a model object

    :param ModelObj model: Model object to plot
    """
    if model._has_valid_local_file(True):
        plot_3dm_model(model._model_file_path)
    else:
        print("Unable to plot model. Unable to find/download model file.")


def _plot_model_file(file_path: str):
    with open(file_path, "rb") as f:
        model_data = base64.b64encode(f.read()).decode("utf-8")

    model_3dm = File3dm.Read(str(file_path))
    layers = _load_layer_names_with_ids_from_3dm(model_3dm)

    try:
        importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_model(
            model_data, layers, None
        )
    except ImportError:
        logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_model_dash(model: ModelObj, view2d: View2d = None):
    """
    Plot a model object

    :param ModelObj model: Model object to plot
    """
    if model.status != "Valid":
        print(f"Unable to plot model in status {model.status}")
        return

    if model._has_valid_local_file(download_if_missing=True):
        # Read the file as bytes and encode to base64
        with open(model._model_file_path, "rb") as f:
            model_data = base64.b64encode(f.read()).decode("utf-8")

        layers = _load_layer_names_with_ids_from_3dm(model._model_file_path)

        try:
            importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_model(
                model_data, layers, model._compute_model_volume(), view2d
            )
        except ImportError:
            logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_submodel_dash(submodel: BoundaryVelocitySubmodel):
    """
    Plot a submodel object
    :param BoundaryVelocitySubmodel submodel: Submodel object to plot
    """
    if submodel._has_valid_local_file(download_if_missing=True):
        # Read the file as bytes and encode to base64
        with open(submodel._model_file_path, "rb") as f:
            model_data = base64.b64encode(f.read()).decode("utf-8")

        layers = _load_layer_names_with_ids_from_3dm(submodel._model_file_path)

        try:
            importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_model(
                model_data, layers, 0  # pass in 0 for volume, not necessary to plot here
            )
        except ImportError:
            logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def submodel_component(model_data, layers, height):
    """
    Return a submodel component
    """
    try:
        return importlib.import_module("treble_tsdk.ui_components.geometry_plot").model_component(
            model_data, layers, 0, height  # pass in 0 for volume, not necessary for submodel
        )
    except ImportError:
        logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_model_feedback(model: ModelObj) -> None:
    """
    Plot the model with the feedback from the geometry checking service.

    :param ModelObj model: Model object to plot
    """
    if model.status != "Valid":
        print(f"Unable to plot model in status {model.status}")
        return

    if not model._has_valid_local_file(True):
        logger.warning("Unable to plot model. Unable to find/download model file.")
        return
    if model._temp_dir is None:
        model._temp_dir = TempFolder()
    feedback_json_path = Path(model._temp_dir.temp_dir, "feedback.json")
    if not model.get_geometry_processing_feedback_json(feedback_json_path):
        logger.warning("Unable to plot feedback, no data available")
        return
    feedback_object = FeedbackObject.load_from_json(feedback_json_path)
    if feedback_object == None:
        logger.warning("Unable to plot feedback, no data available")
        return

    pl = create_feedback_plotter(feedback_object)

    mesh_collection = MeshCollection.load_3dm(model._model_file_path)
    pl.set_background("#1E1E2E")
    # Settings
    pl.add_axes()
    pl.show_grid()
    p_mesh = pl.add_mesh(
        mesh_collection.mesh,
        color=feedback_object.mesh_color,
        opacity=0.5,
        cmap=mpl.pyplot.colormaps.get_cmap("rainbow"),
    )
    pl.add_mesh(mesh_collection.mesh.extract_feature_edges(), color="black")
    f = lambda val: p_mesh.GetProperty().SetOpacity(val)
    pl.add_slider_widget(f, [0.0, 1.0], title="Model opacity", pointa=(0.35, 0.1), pointb=(0.64, 0.1))

    pl.show()


def plot_model_feedback_dash(model: ModelObj) -> None:
    """
    Plot the model with the feedback from the geometry checking service.

    :param ModelObj model: Model object to plot
    """
    if model.status != "Valid":
        print(f"Unable to plot model in status {model.status}")
        return

    if not model._has_valid_local_file(True):
        logger.warning("Unable to plot model. Unable to find/download model file.")
        return
    if model._temp_dir is None:
        model._temp_dir = TempFolder()
    feedback_json_path = Path(model._temp_dir.temp_dir, "feedback.json")
    if not model.get_geometry_processing_feedback_json(feedback_json_path):
        logger.warning("Unable to plot feedback, no data available")
        return
    geometry_feedback = GeometryFeedback.load_from_json(feedback_json_path)
    if geometry_feedback == None:
        logger.warning("Unable to plot feedback, no data available")
        return

    if model._has_valid_local_file(download_if_missing=True):
        # Read the file as bytes and encode to base64
        with open(model._model_file_path, "rb") as f:
            model_data = base64.b64encode(f.read()).decode("utf-8")

        layers = _load_layer_names_with_ids_from_3dm(model._model_file_path)

        try:
            importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_geometry_feedback(
                model_data, layers, geometry_feedback, model._compute_model_volume()
            )
        except ImportError:
            logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_3dm_model(file_path: str):
    """
    Plot .3dm model from file

    :param str file_path: Path to the model file to plot
    """
    mesh_collection = MeshCollection.load_3dm(file_path)
    mesh_collection.plot()


def plot_surface_mesh(
    mesh_path: Path | str,
    model_mesh_collection: MeshCollection,
    layer_names: list[str] = None,
    smallest_element_length_threshold: float = None,
    n_small_elements: int = 100,
):
    """Read and plot the surface mesh part of the volumetric mesh.

    :param str mesh_path: Path to the mesh file to plot
    :param str model: ModelObj that was used to generate the mesh
    :param list[str] layer_names: List of layer names to plot, only the specified layers will be plotted
    :param float smallest_element_length_threshold: The smallest element length threshold to use when extracting short elements
    :param int n_small_elements: The number of small elements to extract
    """

    try:
        volumetric_mesh = importlib.import_module("treble_tsdk.geometry.volumetric_mesh")
    except ImportError as e:
        logger.warning('Unable to load "volumetric mesh", has its dependencies been installed?', exc_info=e)
        return

    surface_mesh, volume_mesh = volumetric_mesh.extract_mesh(
        mesh_path, model_mesh_collection, smallest_element_length_threshold, n_small_elements
    )

    if layer_names:
        surface_mesh = volumetric_mesh.filter_surface_mesh_by_layer_names(surface_mesh, layer_names)

    pl = pv.Plotter()
    pl.set_background("#1E1E2E")
    # Settings
    pl.add_axes()
    sargs = dict(interactive=True, label_font_size=12)
    pl.show_grid()

    if (volume_mesh is not None) and (volume_mesh.n_cells > 0):
        p_mesh = pl.add_mesh(
            surface_mesh,
            color="gray",
            opacity=0.5,
            show_edges=True,
        )
        pl.add_mesh(
            volume_mesh,
            scalars="characteristic_length",
            scalar_bar_args=sargs,
            opacity=0.95,
            cmap=mpl.pyplot.colormaps.get_cmap("rainbow"),
            show_edges=True,
        )

    else:
        p_mesh = pl.add_mesh(
            surface_mesh,
            scalars="layer_name",
            scalar_bar_args=sargs,
            opacity=0.5,
            cmap=mpl.pyplot.colormaps.get_cmap("rainbow"),
            show_edges=True,
        )

    f = lambda val: p_mesh.GetProperty().SetOpacity(val)
    pl.add_slider_widget(f, [0.0, 1.0], title="Model opacity", pointa=(0.35, 0.1), pointb=(0.64, 0.1))

    pl.show()


def plot_surface_mesh_dash(
    mesh_path: Path | str,
    model_mesh_collection: MeshCollection,
    layer_names: list[str] = None,
    smallest_element_length_threshold: float = None,
    n_small_elements: int = 100,
):
    """Read and plot the surface mesh part of the volumetric mesh.

    :param str mesh_path: Path to the mesh file to plot
    :param str model: ModelObj that was used to generate the mesh
    :param list[str] layer_names: List of layer names to plot, only the specified layers will be plotted
    :param float smallest_element_length_threshold: The smallest element length threshold to use when extracting short elements
    :param int n_small_elements: The number of small elements to extract
    """

    try:
        volumetric_mesh = importlib.import_module("treble_tsdk.geometry.volumetric_mesh")
    except ImportError as e:
        logger.warning('Unable to load "volumetric mesh", has its dependencies been installed?', exc_info=e)
        return

    surface_mesh, _ = volumetric_mesh.extract_mesh(
        mesh_path, model_mesh_collection, smallest_element_length_threshold, n_small_elements
    )

    if layer_names:
        surface_mesh = volumetric_mesh.filter_surface_mesh_by_layer_names(surface_mesh, layer_names)

    mesh_collection = MeshCollection(surface_mesh, model_mesh_collection.layer_names)
    mesh = mesh_collection._as_simple_3dm()
    mesh_model_data = mesh.Encode()

    vertices, faces = volumetric_mesh.get_mesh_data(mesh_path)

    model = model_mesh_collection._as_simple_3dm()
    layers_by_id = _load_layer_names_with_ids_from_3dm(model)

    try:
        importlib.import_module("treble_tsdk.ui_components.geometry_plot").plot_mesh(
            vertices, faces, mesh_model_data, layers_by_id
        )
    except ImportError:
        logger.warning("Unable to find required treble_tsdk.ui_components module, has it been installed?")


def plot_mesh_statistics(plot_title: str, mesh_path: Path | str, parameter_type: str = "charlength"):
    """Read and plot the surface mesh part of the volumetric mesh.

    :param str mesh_path: Path to the mesh file to plot
    :param str parameter_type: select which mesh parameter to plot, either \"charlength\" or \"edgelength\"
    """

    try:
        volumetric_mesh = importlib.import_module("treble_tsdk.geometry.volumetric_mesh")
    except ImportError:
        logger.warning('Unable to load "volumetric mesh", has its dependencies been installed?')
        return

    if parameter_type == "charlength":
        charlength = volumetric_mesh.compute_mesh_metric(mesh_path, parameter_type)

        plt.hist(
            charlength,
            bins=100,
            label=f"Characteristic lengths:\n  min={min(charlength):.3f},\n  max={max(charlength):.3f}",
        )
        plt.xlabel("Tetrahedra characteristic length [m]")

    elif parameter_type == "edgelength":
        edgelength = volumetric_mesh.compute_mesh_metric(mesh_path, parameter_type)
        plt.hist(
            edgelength,
            bins=100,
            label=f"Edge lengths:\n  min={min(edgelength):.3f},\n  max={max(edgelength):.3f}",
        )
        plt.xlabel("Tetrahedra edge length [m]")

    else:
        logger.warning('Invalid type, select either "charlength" or "edgelength"')
        return
    plt.title(f'"{plot_title}" mesh statistics')
    plt.legend()
    plt.show()


def plot_material_info(material: Material):
    """
    Plot material information

    :param Material material: Material object to plot
    """
    try:
        importlib.import_module("treble_plotter")
        plt.style.use("treble_dark")
    except ImportError:
        pass

    fig, axs = plt.subplots(1, 2, figsize=(13, 6))  # Adjusted the figsize

    # Absorption plot
    x = np.array([63, 125, 250, 500, 1000, 2000, 4000, 8000])
    y = np.array(material.absorption_coefficients)

    axs[0].plot(x, y, marker="o")
    axs[0].set_title("Absorption Coefficient (Random Incidence)")
    axs[0].set_xscale("log")
    axs[0].set_xticks(x)
    axs[0].set_xticklabels(["63", "125", "250", "500", "1k", "2k", "4k", "8k"])
    axs[0].grid(True, which="both", axis="x", linestyle="--", linewidth=0.5)
    axs[0].set_xlabel("Frequency [Hz]")
    axs[0].set_ylabel("Absorption Coefficient")
    axs[0].set_ylim((-0.01, 1.01))

    # Absorption coefficients table above the plot
    columns = ["63", "125", "250", "500", "1k", "2k", "4k", "8k"]
    cell_text = [y]
    table = axs[0].table(
        cellText=list(map(lambda i: [f"{j:.2f}" for j in i], cell_text)),
        colLabels=columns,
        cellLoc="center",
        bbox=[0.0, 1.15, 1.0, 0.15],
        edges="closed",
    )

    # Set background color for the cells and columns
    for _, cell in table.get_celld().items():
        cell.set_facecolor("#606060")

    table.auto_set_font_size(False)
    table.set_fontsize(9)

    # Reflection coefficients plot
    data = json.loads(material["materialMetadataJson"])
    x_new = np.logspace(np.log10(50), np.log10(10000), 24)

    axs[1].plot(x_new, data["RealReflectionCoefficient"], label="Real Reflection Coefficient", marker="o")
    axs[1].plot(
        x_new, data["ImagReflectionCoefficient"], label="Imaginary Reflection Coefficient", marker="o"
    )
    axs[1].set_title("Reflection Coefficient")
    axs[1].set_xscale("log")
    axs[1].set_xticks([63, 125, 250, 500, 1000, 2000, 4000, 8000])
    axs[1].set_xticklabels(["63", "125", "250", "500", "1k", "2k", "4k", "8k"])
    axs[1].grid(True, which="both", axis="x", linestyle="--", linewidth=0.5)
    axs[1].set_xlabel("Frequency [Hz]")
    axs[1].set_ylabel("Coefficient")
    axs[1].set_ylim((-1.01, 1.01))
    axs[1].legend()

    plt.subplots_adjust(top=0.75, hspace=0.4)

    # Set Title
    fig.suptitle(material.name, fontsize=16, y=0.98)
    fig.tight_layout()

    plt.show()


def plot_spl_on_axis(source_dir: SourceDirectivityObj):
    if source_dir._dto.splOnAxis1mByFrequencyJson is None:
        logger.info("SPL data not available for this directivity.")
        return
    data = json.loads(source_dir._dto.splOnAxis1mByFrequencyJson)

    x_values = list(range(1, len(data) + 1))  # Generate x values from 1 to the number of data points
    labels = list(data.keys())  # Use the keys as labels
    values = list(data.values())

    # Define the specific frequencies where you want to show labels
    specific_frequencies = ["32", "63", "125", "250", "500", "1000", "2000", "4000", "8000", "16000"]

    # Extract the corresponding x-axis indices for the specific frequencies
    specific_x_label_locations = [labels.index(freq) + 1 for freq in specific_frequencies]

    # Create a custom function to format x-axis labels
    def format_ticks(x, pos):
        if x >= 1000:
            return f"{int(x/1000)}k"
        else:
            return int(x)

    plt.figure(figsize=(10, 6))
    plt.plot(x_values, values, marker="o", linestyle="-")
    plt.title("Plot of spl_on_axis_1m_by_frequency")
    plt.xlabel("Frequency (Hz)")
    plt.ylabel("SPL (dB)")

    plt.xticks(
        specific_x_label_locations, [format_ticks(float(freq), 0) for freq in specific_frequencies]
    )  # Set x-axis labels with formatting
    plt.grid(True)
    plt.show()
