import math
import json
from dataclasses import asdict
import random
from typing import TYPE_CHECKING

import numpy as np
from shapely import Polygon
from treble_tsdk.geometry.mesh_collection import MeshCollection

from ..core.temp_folder import TempFolder
from ..core.geometry_component_library import (
    GeometryComponent,
    GeometryComponentPlacement,
    ComponentAnglePool,
    ComponentSelectionAlgorithm,
)
from ..utility_classes import BoundingBox, Point3d, Point2d, Rotation, Transform3d
from ..client.api_models import GeometryComponentDto

if TYPE_CHECKING:
    from .geometry_definition import (
        GeometryDefinition,
    )


def get_rotation_angle(settings: ComponentAnglePool = None) -> int:
    """
    Get a random rotation angle based on the settings.
    """
    if settings is None:
        return np.random.uniform(0, 360)
    else:
        return random.choice(settings.allowed_angle_pool)


def rotate_point_2d(point: Point2d, angle: float, origin: Point2d) -> Point2d:
    """
    Rotates a 2D point around an origin by a given angle in degrees.
    """
    angle_rad = math.radians(angle)
    cos_theta = math.cos(angle_rad)
    sin_theta = math.sin(angle_rad)

    # Translate point to origin
    translated_x = point.x - origin.x
    translated_y = point.y - origin.y

    # Rotate
    rotated_x = translated_x * cos_theta - translated_y * sin_theta
    rotated_y = translated_x * sin_theta + translated_y * cos_theta

    # Translate back
    return Point2d(rotated_x + origin.x, rotated_y + origin.y)


def rotate_2d(
    bb: BoundingBox,
    angle: float,
    rot_origin: Point2d | list[float] = None,
    translate: Point2d | list[float] = None,
) -> Polygon:
    """
    Rotates a bounding box around an origin and returns a Shapely polygon translated by translate parameter if provided.

    :param bb: BoundingBox to rotate
    :param angle: Rotation angle in degrees
    :param rot_origin: Rotation origin as Point2d or [x, y]. Defaults to bbox center.
    :param translate: Translation vector as Point2d or [x, y]. Defaults to [0, 0].
    :returns: Shapely Polygon of the rotated bounding box which was then translated by translate.
    """
    # Compute the four corner points
    corners = [
        Point2d(bb.min.x, bb.min.y),
        Point2d(bb.max.x, bb.min.y),
        Point2d(bb.max.x, bb.max.y),
        Point2d(bb.min.x, bb.max.y),
    ]

    # Determine the rotation origin
    if rot_origin is None:
        rot_origin = Point2d((bb.min.x + bb.max.x) / 2, (bb.min.y + bb.max.y) / 2)
    elif isinstance(rot_origin, list):
        rot_origin = Point2d(rot_origin[0], rot_origin[1])

    # Rotate each corner
    rotated_corners = [rotate_point_2d(corner, angle, rot_origin) for corner in corners]

    if translate is None:
        translate = Point2d(0, 0)

    return Polygon([(p.x + translate[0], p.y + translate[1]) for p in rotated_corners])


def get_valid_component_name(base_name: str, geo_def: "GeometryDefinition") -> str:
    existing_names = geo_def._geometry_components.keys()
    comp_name = base_name
    counter = 1
    while comp_name in existing_names:
        counter += 1
        comp_name = f"{base_name}_{counter}"
        if counter > 100000:
            raise ValueError("Too many components with the same name.")
    return comp_name


def is_valid_placement(
    floor_polygon: Polygon,
    placed_polys: list[Polygon],
    pos_xy: Point2d | list[float, float],
    comp_bb: BoundingBox,
    comp_rot_angle: float,
    dist_from_walls: float = 0.05,
    dist_between_objects: float = 0.2,
) -> bool:
    """
    Check if a component can be placed at a given position.
    """
    wall_expanded_bb = comp_bb.expand(dist_from_walls, dist_from_walls, 0)
    wall_expanded_poly = rotate_2d(wall_expanded_bb, comp_rot_angle, rot_origin=[0.0, 0.0], translate=pos_xy)

    obj_expanded_bb = comp_bb.expand(dist_between_objects, dist_between_objects, 0)
    obj_expanded_poly = rotate_2d(obj_expanded_bb, comp_rot_angle, rot_origin=[0.0, 0.0], translate=pos_xy)
    if floor_polygon.contains_properly(wall_expanded_poly.centroid) and floor_polygon.contains_properly(
        wall_expanded_poly
    ):
        for placed_poly in placed_polys:
            if placed_poly.intersects(obj_expanded_poly):
                return False
        return True
    return False


def get_floor_polygon(floor_mc: MeshCollection) -> Polygon:
    """
    Fix ordering of floor edge points and create a shapely Polygon object.
    """
    floor_edges = floor_mc.mesh.extract_feature_edges()
    lines = floor_edges.lines.reshape(-1, 3)[:, 1:]  # Extract edges as pairs of point indices
    # Reconstruct an ordered boundary loop
    ordered_boundary = [tuple(floor_edges.points[lines[0][0]][:2])]  # Start with the first point
    point_map = {}
    # Create a map between start and end of lines.
    for i, p_i in enumerate(lines):
        point_map[tuple(floor_edges.points[p_i[0]][:2])] = tuple(floor_edges.points[p_i[1]][:2])

    # Create the ordered boundary by connecting line end points with line start points.
    for i in range(len(lines)):
        ordered_boundary.append(point_map[ordered_boundary[i]])

    return Polygon(ordered_boundary)


def try_place_components(
    geo_def: "GeometryDefinition", comp_pool: list[GeometryComponentPlacement], back_off_value: int = 100
):
    placed_polys = []
    # Extract floor geometry
    room_mc = geo_def._room
    floor_layers = [fl for fl in room_mc.layer_names if "floor" in fl]
    if not floor_layers:
        raise ValueError("No floor layers found in the room geometry.")
    floor_mc = room_mc.extract_layers(floor_layers)
    # Get the 2D floor polygon
    floor_polygon = get_floor_polygon(floor_mc)
    for comp in comp_pool:
        # Assume each component in pool has "preferred_count == 1".
        for _ in range(back_off_value):
            rand_x, rand_y = np.random.uniform(
                floor_polygon.bounds[0], floor_polygon.bounds[2]
            ), np.random.uniform(floor_polygon.bounds[1], floor_polygon.bounds[3])
            rand_angle = get_rotation_angle(comp.rotation_settings)
            selected_comp = random.choice(comp.components)
            comp_bb = selected_comp.get_bounding_box()
            # Component snap to floor
            delta_z = 0
            if is_valid_placement(
                floor_polygon=floor_polygon,
                placed_polys=placed_polys,
                pos_xy=[rand_x, rand_y],
                comp_bb=comp_bb,
                comp_rot_angle=rand_angle,
                dist_from_walls=comp.min_dist_from_walls,
                dist_between_objects=comp.min_dist_from_objects,
            ):
                rot_comp_poly = rotate_2d(
                    comp_bb, rand_angle, rot_origin=[0.0, 0.0], translate=[rand_x, rand_y]
                )
                placed_polys.append(rot_comp_poly)
                geo_def.add_geometry_component(
                    name=get_valid_component_name(selected_comp.name, geo_def),
                    geometry_component=selected_comp,
                    transform=Transform3d(
                        Point3d(rand_x, rand_y, delta_z), rotation=Rotation(azimuth=rand_angle)
                    ),
                )
                break


def create_component_pool(
    components: list[GeometryComponentPlacement], selection_algorithm: ComponentSelectionAlgorithm
) -> list[GeometryComponentPlacement]:
    """
    Create a pool of components based on the selection algorithm.
    """
    pool = []
    if selection_algorithm == ComponentSelectionAlgorithm.random:
        for comp in components:
            pool.extend([comp] * comp.preferred_count)
        random.shuffle(pool)
    elif selection_algorithm == ComponentSelectionAlgorithm.ordered_single:
        pool = []
        index_to_count = {i: c.preferred_count for i, c in enumerate(components)}
        while any(index_to_count.values()):
            for i, count in index_to_count.items():
                if count:
                    pool.append(components[i])
                    index_to_count[i] -= 1
    elif selection_algorithm == ComponentSelectionAlgorithm.ordered_all:
        for comp in components:
            pool.extend([comp] * comp.preferred_count)
    else:
        raise ValueError(f"Invalid selection algorithm: {selection_algorithm}")
    return pool


def _mc_to_gc(name: str, mc: MeshCollection) -> GeometryComponent:
    dto = GeometryComponentDto(
        id=None,
        name=name,
        description="",
        group_name="",
        bounding_box_json=json.dumps(asdict(mc.bounding_box())),
        layer_names=mc.layer_names,
        model_file_upload_id=None,
        suggested_materials_json="",
    )
    gc = GeometryComponent(dto, None)
    gc._temp_folder = TempFolder()
    gc._file_path = gc._temp_folder.get_available_path("generated.3dm")
    mc._save_simple_3dm(str(gc._file_path))
    return gc
