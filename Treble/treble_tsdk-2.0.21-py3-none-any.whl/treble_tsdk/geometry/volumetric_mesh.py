from pathlib import Path
import numpy as np
import meshio
import pyvista as pv
from ..core.model_obj import ModelObj
from .mesh_collection import MeshCollection
from ..treble_logging import logger


def compute_triangle_area(points, v0, v1, v2):
    """
    Calculates the area of a triangle

    :param points: The points of the triangle
    :return: The area of the triangle
    """
    ab = points[v1] - points[v0]
    ac = points[v2] - points[v0]
    cross = np.cross(ab, ac)
    cross = np.cross(ab, ac, axis=-1)
    return 0.5 * np.linalg.norm(cross, axis=-1)


def get_n_sorted_cells(pv_data: pv.PolyData, cell_data: str, n: int) -> pv.PolyData:
    """
    Extracts the n smallest cells from a polydata object

    :param pv_data: The polydata object to extract the cells from
    :param cell_data: The cell data to use for sorting
    :param n: The number of cells to extract
    :return: A new polydata object containing the n smallest cells
    """

    if pv_data.n_cells == 0:
        return pv.PolyData()

    # Finding the indices of the smallest to largest quantity
    sorted_indices = np.argsort(pv_data.cell_data[cell_data])

    #  Extract a new capped object
    return pv_data.extract_cells(sorted_indices[:n])


def extract_tets(points, tets) -> pv.PolyData:
    """
    Extracts the tetrahedrons of a mesh

    :param points: The points of the mesh
    :param tets: The tetrahedrons of the mesh
    :return: A polydata object containing the tetrahedrons of the mesh
    """
    cells = np.insert(tets, 0, 4, axis=1)
    pv_tetras = pv.UnstructuredGrid(cells, [pv.CellType.TETRA] * len(cells), points)
    volumes = pv_tetras.compute_cell_sizes(length=False, area=False, volume=True).cell_data["Volume"]
    surf0_area = compute_triangle_area(points, tets[:, 0], tets[:, 1], tets[:, 2])
    surf1_area = compute_triangle_area(points, tets[:, 0], tets[:, 1], tets[:, 3])
    surf2_area = compute_triangle_area(points, tets[:, 0], tets[:, 2], tets[:, 3])
    surf3_area = compute_triangle_area(points, tets[:, 1], tets[:, 2], tets[:, 3])
    max_surf_area = np.max(np.stack([surf0_area, surf1_area, surf2_area, surf3_area], axis=-1), axis=-1)

    pv_tetras.cell_data["characteristic_length"] = 3 * volumes / max_surf_area
    return pv_tetras


def extract_short_tets(points, tets, smallest_element_length_threshold, n_small_elements) -> pv.PolyData:
    """
    Extracts the smallest tetrahedrons from a volumetric mesh

    :param points: The points of the mesh
    :param tets: The tetrahedrons of the mesh
    :param smallest_element_length_threshold: The smallest element length threshold to use when extracting short elements
    :param n_small_elements: The number of small elements to extract
    :return: A polydata object containing the n smallest tetrahedrons
    """
    pv_tetras = extract_tets(points, tets)
    small_tets = pv_tetras.extract_cells(
        pv_tetras.cell_data["characteristic_length"] < smallest_element_length_threshold
    )

    return get_n_sorted_cells(small_tets, "characteristic_length", n_small_elements)


def get_mesh_data(file_path):
    mesh = meshio.read(file_path)
    vertices = mesh.points
    faces = mesh.cells[0].data

    return vertices, faces


def extract_mesh(
    input_mesh_path: Path,
    model_mesh: MeshCollection,
    smallest_element_length_threshold: float = None,
    n_small_elements: int = 100,
):
    """extract_mesh Extracts the surface mesh and the smallest tetrahedrons of the mesh from a mesh file

    :param str input_mesh_path: Path to the mesh file to plot
    :param str model: ModelObj that was used to generate the mesh
    :param list[str] layer_names: List of layer names to plot, only the specified layers will be plotted
    :param float smallest_element_length_threshold: The smallest element length threshold to use when extracting short elements
    :param int n_small_elements: The number of small elements to extract
    :return: A tuple containing: The surface mesh, the volumetric mesh, and the field data
    """
    mesh = meshio.read(input_mesh_path)
    vertices = mesh.points
    faces = mesh.cells[0].data
    pv_mesh = pv.PolyData(vertices, np.insert(faces, 0, 3, axis=1))

    tags = mesh.cell_data["gmsh:physical"][0]
    tags_pr_object_id = {k: v[0] for k, v in mesh.field_data.items()}

    object_index_pr_object_id = model_mesh.object_index_pr_object_id()
    layer_index_pr_object_id = model_mesh.layer_index_pr_object_id()
    layer_name_pr_object_id = model_mesh.layer_name_pr_object_id()

    object_index_pr_tag = {
        mesh_tag: object_index_pr_object_id[obj_id] for obj_id, mesh_tag in tags_pr_object_id.items()
    }
    layer_index_pr_tag = {
        mesh_tag: layer_index_pr_object_id[obj_id] for obj_id, mesh_tag in tags_pr_object_id.items()
    }
    layer_name_pr_tag = {
        mesh_tag: layer_name_pr_object_id[obj_id] for obj_id, mesh_tag in tags_pr_object_id.items()
    }

    pv_mesh.cell_data["object_index"] = [object_index_pr_tag[tag] for tag in tags]
    pv_mesh.cell_data["layer_index"] = [layer_index_pr_tag[tag] for tag in tags]
    pv_mesh.cell_data["layer_name"] = [layer_name_pr_tag[tag] for tag in tags]

    if smallest_element_length_threshold is not None:
        volumetric_mesh = extract_short_tets(
            vertices, mesh.cells[1].data, smallest_element_length_threshold, n_small_elements
        )
    else:
        volumetric_mesh = None

    return pv_mesh, volumetric_mesh


def compute_mesh_metric(input_mesh_path: Path, parameter_type: str = "charlength") -> np.ndarray:
    mesh = meshio.read(input_mesh_path)
    if parameter_type == "charlength":
        pv_tetras = extract_tets(mesh.points, mesh.cells[1].data)
        return pv_tetras.cell_data["characteristic_length"]
    elif parameter_type == "edgelength":
        tet_verts = mesh.points[mesh.cells[1].data]
        edge_lengths = []
        edge_lengths.append(np.linalg.norm(tet_verts[:, 1, :] - tet_verts[:, 0, :], axis=1))
        edge_lengths.append(np.linalg.norm(tet_verts[:, 2, :] - tet_verts[:, 0, :], axis=1))
        edge_lengths.append(np.linalg.norm(tet_verts[:, 3, :] - tet_verts[:, 0, :], axis=1))
        edge_lengths.append(np.linalg.norm(tet_verts[:, 2, :] - tet_verts[:, 1, :], axis=1))
        edge_lengths.append(np.linalg.norm(tet_verts[:, 2, :] - tet_verts[:, 1, :], axis=1))
        edge_lengths.append(np.linalg.norm(tet_verts[:, 3, :] - tet_verts[:, 2, :], axis=1))
    return np.array(edge_lengths).flatten()


def filter_surface_mesh_by_layer_names(surface_mesh: pv.PolyData, layer_names: list[str]):
    """Filters a surface mesh by the layer names. This function needs access to the model to be able to find the relationship between the layer names, object ids and the indices applied in the different processing

    :param surface_mesh: The surface mesh to filter
    :param tag_index_pr_object_id: A dictionary containing the relationship between the object ids and the indices applied in the different processing
    :param model: The model object
    :param layer_names: The layer names to filter by
    :return: the filter PolyData object containing only the geometry of the specific layers
    """
    unique_layer_names = np.unique(surface_mesh.cell_data["layer_name"])
    extracted_mesh = pv.PolyData()
    for layer_name in layer_names:
        if layer_name in unique_layer_names:
            extracted_mesh = extracted_mesh.merge(
                surface_mesh.extract_cells(surface_mesh.cell_data["layer_name"] == layer_name)
            )

        else:
            logger.warning(f"Layer {layer_name} not contained in model")
            return None
    return extracted_mesh
