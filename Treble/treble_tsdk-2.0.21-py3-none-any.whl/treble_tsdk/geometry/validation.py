import json
from collections import Counter
from numbers import Number

from ..treble_logging import logger
from ..client.api_models import ReceiverDto, SourceDto
from ..utility_classes import Point3d, Rotation, Transform3d
from .. import utils
from ..core.project import Project
from ..core.source_boundary_velocity import BoundaryVelocitySubmodel
from ..core.source_directivity_obj import SourceDirectivityObj
from ..core.simulation import Simulation
from ..core.source import SourceType
from ..core.receiver import Receiver, ReceiverType
from .mesh_collection import MeshCollection
from . import _validation_helpers as helpers


class PointRuleset:
    MIN_DIST_SOURCE = 0.25
    MIN_DIST_RECEIVER = 0.15

    def __init__(
        self,
        min_dist_from_surface: float = 0.0,
        min_dist_from_other_points: float = 0.0,
        min_dist_from_sources: float = 0.0,
        min_dist_from_receivers: float = 0.0,
    ):
        """
        Create a ruleset for source/receiver positions.
        All distances in meters.
        :param min_dist_from_surface: Minimum distance from an any surface in model.
        :param min_dist_from_other_points: Minimum distances from other points.
        :param min_dist_from_sources: Minimum distance from other sources.
        :param min_dist_from_receivers: Minimum distance from other receivers.
        """
        self.min_dist_from_surface = min_dist_from_surface
        self.min_dist_from_other_points = min_dist_from_other_points
        self.min_dist_from_sources = min_dist_from_sources
        self.min_dist_from_receivers = min_dist_from_receivers

    @staticmethod
    def get_default_source_ruleset():
        return PointRuleset(
            PointRuleset.MIN_DIST_SOURCE,
            PointRuleset.MIN_DIST_SOURCE,
            PointRuleset.MIN_DIST_SOURCE,
            PointRuleset.MIN_DIST_SOURCE,
        )

    @staticmethod
    def get_default_receiver_ruleset():
        return PointRuleset(
            PointRuleset.MIN_DIST_RECEIVER,
            PointRuleset.MIN_DIST_RECEIVER,
            PointRuleset.MIN_DIST_SOURCE,
            PointRuleset.MIN_DIST_RECEIVER,
        )


class ReceiverValidationResult:
    def __init__(self, receiver: ReceiverDto, check: str):
        self._dto = receiver
        self._check = check

    @property
    def receiver_label(self) -> str | None:
        if hasattr(self._dto, "label"):
            return self._dto.label
        return None

    @property
    def receiver_type(self) -> ReceiverType:
        return ReceiverType(self._dto.receiverType)

    @property
    def receiver_id(self) -> str:
        return self._dto.id

    @property
    def receiver_position(self) -> Point3d:
        return Point3d(x=self._dto.x, y=self._dto.y, z=self._dto.z)

    @property
    def check(self) -> str:
        return self._check

    def __repr__(self) -> str:
        return f"ReceiverValidationResult(receiver='{self.receiver_label}', check='{self.check}')"


class SourceValidationResult:
    def __init__(self, source: SourceDto, check: str):
        self._dto = source
        self._check = check

    @property
    def source_label(self) -> str | None:
        return getattr(self._dto, "label", None)

    @property
    def source_type(self) -> SourceType:
        return SourceType(self._dto.sourceType)

    @property
    def source_id(self) -> str | None:
        return getattr(self._dto, "id", None)

    @property
    def source_position(self) -> Point3d:
        return Point3d(x=self._dto.x, y=self._dto.y, z=self._dto.z)

    @property
    def check(self) -> str:
        return self._check

    def __repr__(self) -> str:
        return f"SourceValidationResult(source='{self.source_label}', check='{self.check}')"


class SimulationValidationResults:
    def __init__(
        self,
        simulation_id: str,
        simulation_name: str,
        invalid_receivers: list[ReceiverValidationResult],
        invalid_sources: list[SourceValidationResult],
        layers_without_materials: list[str],
        invalid_settings: list[str],
        error_message: str = None,
    ):
        self.simulation_id = simulation_id
        self.simulation_name = simulation_name
        self.is_valid = (
            len(invalid_sources) == 0
            and len(invalid_receivers) == 0
            and len(layers_without_materials) == 0
            and len(invalid_settings) == 0
            and error_message is None
        )
        self.invalid_settings = invalid_settings
        self.invalid_receivers = invalid_receivers
        self.invalid_sources = invalid_sources
        self.layers_without_material_assignment = layers_without_materials
        self.error_message = error_message

    def __repr__(self) -> str:
        return f"SimulationValidationResults(simulation_id='{self.simulation_id}', simulation_name='{self.simulation_name}', is_valid={self.is_valid})"

    def __str__(self):
        return json.dumps(self, default=vars, indent=2)

    def as_tree(self):
        """
        Uses the display_data module to display validation results as tree.
        """
        if m := utils.try_load_treble_module("treble_tsdk.display_data"):
            m.as_tree(self)


def validate_project(project: Project) -> list[SimulationValidationResults]:
    return [validate_simulation(simulation) for simulation in project.get_simulations()]


def validate_boundary_velocity_submodel_source(
    simulation: Simulation,
    source_submodel: BoundaryVelocitySubmodel,
    source: SourceDto,
    model_mesh_collection: MeshCollection,
) -> SourceValidationResult | None:
    if (
        source_submodel._dto.maxCrossoverFrequency
        and source_submodel._dto.maxCrossoverFrequency < simulation.crossover_frequency
    ):
        return SourceValidationResult(
            source=source,
            check=f"Supplied Boundary velocity submodel max crossover frequency is lower than simulation crossover frequency ({simulation.crossover_frequency}). Result may be inaccurate.",
        )

    if (
        source_submodel._dto.simulationTypeFilter
        and simulation.type.value not in source_submodel._dto.simulationTypeFilter
    ):
        return SourceValidationResult(
            source=source,
            check=f"Supplied Boundary velocity submodel is not compatible with simulation type {simulation.type.value}. Results may be inaccurate.",
        )
    submodel_mesh_collection = source_submodel._get_mesh_collection()
    submodel_mesh_collection = submodel_mesh_collection.transform(
        Transform3d(
            Point3d(x=source.x, y=source.y, z=source.z),
            Rotation(
                azimuth=source.sourceProperties.azimuthAngle,
                elevation=source.sourceProperties.elevationAngle,
                roll=0,
            ),
        ),
    )
    boundary_layer_mesh_collection = submodel_mesh_collection.extract_layers(
        [source_submodel._dto.boundaryLayerName]
    )

    # Check if submodel boundary collides with model.
    _, ncol = model_mesh_collection.mesh.collision(
        other_mesh=boundary_layer_mesh_collection.mesh, contact_mode=1
    )
    if ncol > 0:
        return SourceValidationResult(source=source, check="Submodel source collides with model.")

    # Check if submodel boundary is inside model.
    model_bb = model_mesh_collection.bounding_box()
    submodel_bb = submodel_mesh_collection.bounding_box()
    submodel_boundary_bb = boundary_layer_mesh_collection.bounding_box()
    if not model_bb.contains(submodel_boundary_bb):
        return SourceValidationResult(source=source, check="Submodel source boundary is not inside model.")
    if not helpers.point_in_model_check(
        submodel_boundary_bb.center(), model_mesh_collection
    ):
        return SourceValidationResult(source=source, check="Submodel source is not inside model.")

    # Check if receivers collide with submodel or are too close.
    expanded_bb = submodel_boundary_bb.expand(0.004)  # 4mm check
    if not model_bb.contains(expanded_bb):
        return SourceValidationResult(
            source=source, check="Warning: Submodel source boundary is very close to surface."
        )
    for corner in submodel_boundary_bb.get_corners():
        if helpers.point_close_to_surface_check(corner, model_mesh_collection, 0.004):
            return SourceValidationResult(
                source=source, check="Warning: Submodel source boundary is very close to surface."
            )

    # Check if receivers collide with submodel.
    for receiver in simulation._dto.receivers:
        if submodel_bb.point_in_box(receiver.pos_as_point()):
            return SourceValidationResult(source=source, check="Receiver is too close to submodel source.")
    return None


def validate_simulation(simulation: Simulation) -> SimulationValidationResults:
    """
    Validate simulation.
    Validates source/receiver positions.
    Receivers should be inside model and be placed 0.15m from any surface.
    Sources should be inside model and placed 0.25m from any surface.
    All layers should have materials assigned to them.
    """
    model_obj = simulation.get_model()
    if hasattr(model_obj, "status") and model_obj.status != "Valid":
        return SimulationValidationResults(
            simulation.id,
            simulation.name,
            [],
            [],
            [],
            [],
            f"Unable to validate simulation until model processing has completed and model status is 'Valid'. Model status is {model_obj.status}",
        )
    model_obj._has_valid_local_file(True)
    mesh_collection = MeshCollection.load_3dm(model_obj._model_file_path)

    invalid_settings = []
    if (
        simulation._dto.simulationSettings
        and hasattr(simulation._dto.simulationSettings, "ambisonicsOrder")
        and simulation._dto.simulationSettings.ambisonicsOrder not in (0, 1, 2, 4, 8, 16, 32)
    ):
        invalid_settings.append(
            "Invalid ambisonics order: {simulation._dto.simulationSettings.ambisonicsOrder}. Supported ambisonics orders are 0, 1, 2, 4, 8, 16, 32."
        )

    invalid_receivers = []
    if not simulation._dto.receivers:
        invalid_settings.append("No receivers in simulation!")
    else:
        labels = set()
        receiver_rules = PointRuleset.get_default_receiver_ruleset()
        not_boundary_sources = [
            source for source in simulation._dto.sources if source.sourceType != SourceType.boundary_velocity
        ]

        # Batch points in model check. Returns a boolean mask for valid points.
        valid_points_mask = helpers.points_in_model_check(
            [receiver.pos_as_point() for receiver in simulation._dto.receivers], mesh_collection
        )
        valid_receivers = []
        for i, r in enumerate(simulation._dto.receivers):
            if valid_points_mask[i]:
                valid_receivers.append(r)
            else:
                invalid_receivers.append(ReceiverValidationResult(receiver=r, check="not inside model"))

        # Continue validating receivers that are inside the model.
        for receiver in valid_receivers:
            if not utils.is_valid_label(receiver.label):
                invalid_receivers.append(
                    f"Invalid receiver label '{receiver.label}'. Receiver labels must be alphanumeric and may contain underscores."
                )
                continue
            labels.add(receiver.label)
            if receiver.receiverType != ReceiverType.mono and helpers.point_close_to_surface_check(
                point=receiver.pos_as_point(),
                mesh_collection=mesh_collection,
                min_distance_from_surface=receiver_rules.min_dist_from_surface,
                number_of_rays=100,
            ):
                invalid_receivers.append(
                    ReceiverValidationResult(receiver=receiver, check="too close to surface")
                )
                continue

            # For mono receivers, skip checking distance to boundary sources
            sources_to_check = simulation._dto.sources
            if receiver.receiverType == ReceiverType.mono:
                sources_to_check = not_boundary_sources

            if not helpers.points_dist_check(
                receiver, sources_to_check, receiver_rules.min_dist_from_sources
            ):
                invalid_receivers.append(
                    ReceiverValidationResult(receiver=receiver, check="too close to source")
                )

        if len(labels) != len(simulation._dto.receivers):
            invalid_settings.append("Receiver labels must be unique.")

    invalid_sources = []
    if not simulation._dto.sources:
        invalid_settings.append("No sources in simulation!")
    else:
        labels = set()
        source_rules = PointRuleset.get_default_source_ruleset()
        # Check if source position is valid for surface.
        for i, source in enumerate(simulation._dto.sources):
            if not utils.is_valid_label(source.label):
                invalid_receivers.append(
                    f"Invalid source label '{source.label}'. Source labels must be alphanumeric and may contain underscores."
                )
                continue
            labels.add(source.label)
            is_boundary_velocity_source = source.sourceType == "BoundaryVelocity"
            is_directive_source = source.sourceType == "Directive"

            if is_boundary_velocity_source:
                if not source.sourceProperties:
                    invalid_sources.append(
                        SourceValidationResult(
                            source=source,
                            check="A boundary velocity source must specify a boundary velocity definition.",
                        )
                    )
                else:
                    submodel_id = source.sourceProperties.boundaryVelocitySubmodelId
                    if not submodel_id:
                        if not source.sourceProperties or not source.sourceProperties.sourceBoundaryLayerName:
                            invalid_sources.append(
                                SourceValidationResult(
                                    source=source,
                                    check="A boundary velocity source must specify a boundary layer name.",
                                )
                            )
                        elif source.sourceProperties.sourceBoundaryLayerName not in model_obj.layer_names:
                            invalid_sources.append(
                                SourceValidationResult(
                                    source=source,
                                    check="Source boundary layer name not specified or not found in model.",
                                )
                            )
                    else:
                        # Source is a boundary velocity submodel source.
                        if submodel_id not in simulation._boundary_velocity_submodel_cache:
                            simulation._boundary_velocity_submodel_cache[submodel_id] = (
                                BoundaryVelocitySubmodel(
                                    simulation._client.boundary_velocity_submodel.get_by_id(submodel_id),
                                    client=simulation._client,
                                )
                            )
                        source_submodel = simulation._boundary_velocity_submodel_cache[submodel_id]
                        res = validate_boundary_velocity_submodel_source(
                            simulation=simulation,
                            source_submodel=source_submodel,
                            source=source,
                            model_mesh_collection=mesh_collection,
                        )
                        if res:
                            invalid_sources.append(res)
            else:
                # Point source checks.
                if helpers.point_in_model_check(source.pos_as_point(), mesh_collection) is False:
                    invalid_sources.append(SourceValidationResult(source=source, check="not inside model"))
                elif helpers.point_close_to_surface_check(
                    point=source.pos_as_point(),
                    mesh_collection=mesh_collection,
                    min_distance_from_surface=source_rules.min_dist_from_surface,
                    number_of_rays=100,
                ):
                    invalid_sources.append(
                        SourceValidationResult(source=source, check="too close to surface")
                    )
                elif i < (len(simulation._dto.sources) - 1) and not helpers.points_dist_check(
                    source, simulation._dto.sources[i + 1 :], source_rules.min_dist_from_sources
                ):
                    invalid_sources.append(SourceValidationResult(source=source, check="too close to source"))
                elif is_directive_source:
                    if not source.sourceProperties or not source.sourceProperties.sourceDirectivityId:
                        invalid_sources.append(
                            SourceValidationResult(
                                source=source,
                                check="Directive source missing directivity pattern (source_directivity)",
                            )
                        )
                    else:
                        source_dir_id = source.sourceProperties.sourceDirectivityId
                        if source_dir_id not in simulation._source_directivity_obj_cache:
                            simulation._source_directivity_obj_cache[source_dir_id] = SourceDirectivityObj(
                                simulation._client.source_directivity.get_source_directivity(source_dir_id),
                                client=simulation._client,
                            )
                        source_directivity = simulation._source_directivity_obj_cache[source_dir_id]
                        if (
                            source_directivity._dto.maxCrossoverFrequency
                            and source_directivity._dto.maxCrossoverFrequency < simulation.crossover_frequency
                        ):
                            invalid_sources.append(
                                SourceValidationResult(
                                    source=source,
                                    check=f"Supplied source directivity max crossover frequency is lower than simulation crossover frequency ({simulation.crossover_frequency}). Result may be inaccurate.",
                                )
                            )
                        if (
                            source_directivity._dto.simulationTypeFilter
                            and simulation.type.value not in source_directivity._dto.simulationTypeFilter
                        ):
                            invalid_sources.append(
                                SourceValidationResult(
                                    source=source,
                                    check=f"Supplied source directivity is not compatible with simulation type {simulation.type.value}. Results may be inaccurate.",
                                )
                            )

        if len(labels) != len(simulation._dto.sources):
            invalid_settings.append("Source labels must be unique.")

    # Find model layers that are not included in simulation.layer_material_assignment.
    mat_ass = {x.layerName: x for x in simulation._dto.layerMaterialAssignments}
    if not hasattr(model_obj, "status") or model_obj.status == "Valid":
        missing_assignments = [
            layer_name for layer_name in model_obj.layer_names if layer_name not in mat_ass.keys()
        ]
        # Find simulation.layer_material_assignments with materials set to None.
        missing_assignments.extend(
            [
                layer_name
                for layer_name, material in mat_ass.items()
                if material is None or material.materialId is None
            ]
        )

        # Check for duplicate layer names in material assignment.
        layer_name_count = Counter([assignment for assignment in simulation._dto.layerMaterialAssignments])
        missing_assignments.extend(
            [
                f"Duplicate material assignment for layer {name}"
                for name, count in layer_name_count.items()
                if count > 1
            ]
        )
    else:
        missing_assignments = [
            f"Unable to validate material assignments, model status is: {model_obj.status}"
        ]

    # Check if set scattering coefficients are valid.
    for layer_name, assignment in mat_ass.items():
        if coeff := getattr(assignment, "scatteringCoefficient", None):
            if (
                coeff
                and not isinstance(coeff, Number)
                and isinstance(coeff, list)
                and len(coeff) not in (0, 1, 8)
            ):
                invalid_settings.append(
                    f"Invalid scattering coefficient set for layer {layer_name}: {coeff}. If scattering coefficient is set, it should either be a single number or a list of 8 numbers."
                )

    return SimulationValidationResults(
        simulation.id,
        simulation.name,
        invalid_receivers,
        invalid_sources,
        missing_assignments,
        invalid_settings,
    )
