from dataclasses import dataclass

from ..utility_classes import Point3d, Rotation, Transform3d, View2d, Vector3d, BoundingBox
from ..core.temp_folder import TempFolder
from ..core.model_obj import ModelObj
from ..core.geometry_library_obj import GeometryLibraryObj
from . import plot
from .mesh_collection import MeshCollection
from .. import utils
from ..core.geometry_component_library import (
    GeometryComponent,
    GeometryComponentPlacement,
    ComponentSelectionAlgorithm,
)

from ..treble_logging import logger

from . import _generator_utils as gen_utils


class GeometryDefinition:
    @dataclass
    class __GeometryFunky:
        # id: str ?
        name: str
        mesh_collection: MeshCollection
        transform: Transform3d
        bounding_box: BoundingBox

    def __init__(
        self,
        room_geo: str | ModelObj | GeometryLibraryObj,
        layer_as_component: dict[str, str] = None,
    ):
        """Create a geometry definition object

        :param str | ModelObj | GeometryLibraryObj room_geo: Input the room geometry
        :param dict[str, str] layer_as_component: In case parts of the geometry should be separated into components, supply the component name and geometry name, defaults to None
        """
        # Handle different geometry input types.
        match room_geo:
            case str():
                self._room = MeshCollection.load_3dm(room_geo)
            case MeshCollection():
                self._room = room_geo
            case ModelObj():
                self._room = MeshCollection.load_model(room_geo)
            case GeometryLibraryObj():

                self._room = MeshCollection.load_model(room_geo)
            case _:
                raise ValueError("Invalid input type.")

        # Extract the layers into components if requested.
        separated_components = {}
        if layer_as_component is not None:
            logger.warning(
                "Splitting model into components is a beta feature. Please use caution while using it."
            )
            remaining_layers = self._room.layer_names.copy()
            for component_name, layer_name in layer_as_component.items():
                if layer_name not in self._room.layer_names:
                    raise ValueError(f"Layer '{layer_name}' not found in the geometry.")
                separated_components[component_name] = self._room.extract_layers(layer_name)
                del remaining_layers[remaining_layers.index(layer_name)]

            self._room = self._room.extract_layers(remaining_layers)

        self._geometry_components = {}
        self._joined_mesh_collection = self._room
        self._temp_folder = TempFolder()
        self._joined_model_path = self._temp_folder.get_available_path("joined_model.3dm")
        self._is_dirty = True

        # Add the components to the geometry definition
        for name, mc_comp in separated_components.items():
            mc_comp_transformed = mc_comp.transform(
                Transform3d(
                    Point3d(-mc_comp.mesh.center[0], -mc_comp.mesh.center[1], -mc_comp.mesh.center[2]),
                    Rotation(),
                )
            )
            self.add_geometry_component(
                name,
                gen_utils._mc_to_gc(component_name, mc_comp_transformed),
                Transform3d(
                    Point3d(mc_comp.mesh.center[0], mc_comp.mesh.center[1], mc_comp.mesh.center[2]),
                    Rotation(),
                ),
            )

    @staticmethod
    def _get_geometry_component_mesh_collection(comp: GeometryComponent) -> MeshCollection:
        return MeshCollection.load_3dm(comp._load_component_data())

    def _rebuild_joined_mesh_collection(self, force: bool = False, include_bounding_boxes: bool = False):
        if self._is_dirty or force:
            if include_bounding_boxes:
                self._joined_mesh_collection = MeshCollection.join_mesh_collections(
                    [self._room]
                    + [
                        obj.mesh_collection.transform(obj.transform)
                        for obj in self._geometry_components.values()
                    ]
                    + [
                        MeshCollection.create_box(*obj.bounding_box.to_point_list()).transform(obj.transform)
                        for obj in self._geometry_components.values()
                    ]
                )
                # Bounding boxes are debug only.
                self._is_dirty = True

            else:
                self._joined_mesh_collection = MeshCollection.join_mesh_collections(
                    [self._room]
                    + [
                        obj.mesh_collection.transform(obj.transform)
                        for obj in self._geometry_components.values()
                    ]
                )
                self._is_dirty = False
            self._joined_mesh_collection._save_simple_3dm(str(self._joined_model_path))

    def add_geometry_component(
        self, name: str, geometry_component: GeometryComponent, transform: Transform3d
    ):
        if name in self._geometry_components:
            raise ValueError(f"Geometry object with name '{name}' already exists.")
        self._geometry_components[name] = GeometryDefinition.__GeometryFunky(
            name=name,
            mesh_collection=GeometryDefinition._get_geometry_component_mesh_collection(geometry_component),
            transform=transform,
            bounding_box=geometry_component.get_bounding_box(),
        )
        self._is_dirty = True

    def remove_geometry_component(self, name: str):
        if name not in self._geometry_components:
            raise ValueError(f"Geometry object with name '{name}' does not exist.")
        del self._geometry_components[name]
        self._is_dirty = True

    def get_geometry_component_transform(self, name: str):
        if name not in self._geometry_components:
            raise ValueError(f"Geometry object with name '{name}' does not exist.")
        return self._geometry_components[name].transform

    def set_geometry_component_transform(self, name: str, transform: Transform3d):
        if name not in self._geometry_components:
            raise ValueError(f"Geometry object with name '{name}' does not exist.")
        self._geometry_components[name].transform = transform
        self._is_dirty = True

    def move_geometry_component(self, name: str, translation: Point3d | Vector3d):
        if name not in self._geometry_components:
            raise ValueError(f"Geometry object with name '{name}' does not exist.")
        self._geometry_components[name].transform.translation += translation
        self._is_dirty = True

    def set_geometry_component_rotation(self, name: str, rotation: Rotation):
        if name not in self._geometry_components:
            raise ValueError(f"Geometry object with name '{name}' does not exist.")
        self._geometry_components[name].transform.rotation = rotation
        self._is_dirty = True

    def clear_geometry_components(self):
        """
        Removes all geometry components from the room.
        """
        if self._geometry_components:
            self._geometry_components.clear()
            self._is_dirty = True

    def plot(self, view_2d: View2d = None, show_bounding_boxes: bool = False):
        if self._is_dirty:
            self._rebuild_joined_mesh_collection(include_bounding_boxes=show_bounding_boxes)
        if utils.get_env_var_as_string("TSDK_PYVISTA_PLOTTING") == "1":
            self._joined_mesh_collection.plot(view_2d=view_2d)
        else:
            plot._plot_model_file(self._joined_model_path)

    def populate_with_geometry_components(
        self,
        components: list[GeometryComponentPlacement],
        selection_algorithm: ComponentSelectionAlgorithm = ComponentSelectionAlgorithm.random,
    ):
        # Spread components list out into GeometryComponentPlacements 'all considered with count = 1'.
        component_pool = gen_utils.create_component_pool(components, selection_algorithm)
        gen_utils.try_place_components(self, component_pool)

    def __repr__(self):
        return f"GeometryDefinition(geometry_component_count={len(self._geometry_components.keys())}."
