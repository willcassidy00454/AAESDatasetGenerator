from __future__ import annotations

import uuid
import traceback
from dataclasses import dataclass

import numpy as np
import pyvista as pv
from rhino3dm import File3dm, UnitSystem
from rhino3dm import Layer as RhinoLayer
from rhino3dm import Mesh as RhinoMesh
from ..core.geometry_library_obj import GeometryLibraryObj
from ..core.model_obj import ModelObj
from ..utility_classes import Transform3d, View2d

from ._treble_rhino_metadata import TrebleGroupType, treble_metadata_from_layers
import matplotlib as mpl
from pathlib import Path
from .. import utils
from ..utility_classes import BoundingBox
from ..treble_logging import logger


class MeshCollection:
    """
    Includes mesh of the model, model bounding box, and if available it includes inner volume mesh and outer shell mesh.
    """

    mesh: pv.PolyData
    layer_names: list[str]

    def __init__(self, mesh: pv.PolyData, layer_names: list[str], object_ids: list[str] = None):
        if "layer_index" not in mesh.cell_data:
            logger.warning("No layer_index cell data in mesh")
            return None
        if mesh.cell_data["layer_index"].max() > len(layer_names):
            logger.warning("More layer index entries in the mesh than in the layer_names list")
            return None

        self.mesh = mesh
        self.layer_names = layer_names
        self.object_ids = object_ids
        if not object_ids and self.mesh.cell_data.get("object_index") is not None:
            # Generate object ids if missing.
            self.object_ids = [str(uuid.uuid4()) for _ in range(len(self.mesh.cell_data["object_index"]))]

    def inner_volume(self):
        """
        getter for the inner volume if they have been identified.

        :returns pv.PolyData: Returns all the inner volumes.
        """
        if "group_type" in self.mesh.cell_data:
            inner_volume_mask = self.mesh.cell_data["group_type"] == TrebleGroupType.InnerVolume.value
            if np.count_nonzero(inner_volume_mask) > 0:
                return self.mesh.extract_cells(inner_volume_mask).extract_surface()
        return pv.PolyData()

    def outer_shell(self):
        """
        getter for the outer shell if it has been identified.

        :returns pv.PolyData: Returns the outer shell.
        """
        if "group_type" in self.mesh.cell_data:
            exterior_shell_mask = self.mesh.cell_data["group_type"] == TrebleGroupType.OuterShell.value
            if np.count_nonzero(exterior_shell_mask) > 0:
                return self.mesh.extract_cells(exterior_shell_mask).extract_surface()
        return pv.PolyData()

    def bounding_box(self) -> BoundingBox:
        """
        getter for the bounding box of the mesh

        :returns BoundingBox: Returns the bounding box of the mesh.
        """
        return BoundingBox.from_points(*self.mesh.bounds)

    def extract_layers(self, layer_names: list[str]) -> "MeshCollection":
        """Extracts the geometry of the layer given by the string

        Args:
            layer_name: string of layer name

        Returns:
            PolyData object with the layer geometry
        """
        if isinstance(layer_names, str):
            layer_names = [layer_names]

        output_geometry = pv.PolyData()
        for layer_name in layer_names:
            if layer_name in self.layer_names:
                layer_index = self.layer_names.index(layer_name)
                output_geometry = output_geometry.merge(
                    self.mesh.extract_cells(
                        self.mesh.cell_data["layer_index"] == layer_index
                    ).extract_surface()
                )
            else:
                logger.warning(f'layer "{layer_name}" not found')
                return None
        return MeshCollection(output_geometry, self.layer_names, self.object_ids)

    def transform(self, transform: Transform3d, inplace=False) -> "MeshCollection":
        """
        Transforms the mesh in place by the given transform
        """
        tmp_mc = MeshCollection(self.mesh.copy(), self.layer_names, self.object_ids)
        elevation_vector = pv.PolyData([0.0, -1.0, 0.0]).rotate_z(transform.azimuth)
        rotation_vector = (
            pv.PolyData([1.0, 0.0, 0.0])
            .rotate_z(transform.azimuth)
            .rotate_vector(elevation_vector.points[0], transform.elevation)
        )
        tmp_mc.mesh = (
            tmp_mc.mesh.rotate_z(transform.azimuth)
            .rotate_vector(elevation_vector.points[0], transform.elevation)
            .rotate_vector(rotation_vector.points[0], transform.roll)
        )
        tmp_mc.mesh = tmp_mc.mesh.translate([transform.x, transform.y, transform.z])
        if inplace:
            self.mesh = tmp_mc.mesh
        else:
            return tmp_mc

    def layer_name_pr_object_id(self):
        """
        Returns a dictionary with the layer names and the object ids
        """
        layer_names_pr_object_id = {}
        object_indices = np.unique(self.mesh.cell_data["object_index"]).astype(int)
        for object_index, object_id in zip(object_indices, self.object_ids):
            cell_index = np.where(self.mesh.cell_data["object_index"] == object_index)[0][0]
            layer_names_pr_object_id[object_id] = self.layer_names[
                int(self.mesh.cell_data["layer_index"][cell_index])
            ]
        return layer_names_pr_object_id

    def layer_index_pr_object_id(self):
        """
        Returns a dictionary with the layer index and the object ids
        """
        layer_index_pr_object_id = {}
        object_indices = np.unique(self.mesh.cell_data["object_index"]).astype(int)
        for object_index, object_id in zip(object_indices, self.object_ids):
            cell_index = np.where(self.mesh.cell_data["object_index"] == object_index)[0][0]
            layer_index_pr_object_id[object_id] = self.mesh.cell_data["layer_index"][cell_index]
        return layer_index_pr_object_id

    def object_index_pr_object_id(self):
        """
        Returns a dictionary with the object index and the object ids
        """
        object_index_pr_object_id = {}
        object_indices = np.unique(self.mesh.cell_data["object_index"]).astype(int)
        for object_index, object_id in zip(object_indices, self.object_ids):
            object_index_pr_object_id[object_id] = object_index
        return object_index_pr_object_id

    def plot(self, view_2d: View2d = None):
        pl = pv.Plotter()
        pl.set_background("#1E1E2E")
        # Settings
        pl.add_axes()
        pl.show_grid()
        sargs = dict(interactive=True, label_font_size=12)

        if "layer_name" in self.mesh.array_names:
            p_mesh = pl.add_mesh(
                self.mesh,
                scalars="layer_name",
                scalar_bar_args=sargs,
                opacity=0.5,
                cmap=mpl.pyplot.colormaps.get_cmap("rainbow"),
            )
        else:
            p_mesh = pl.add_mesh(
                self.mesh,
                opacity=0.5,
                cmap=mpl.pyplot.colormaps.get_cmap("rainbow"),
            )

        f = lambda val: p_mesh.GetProperty().SetOpacity(val)
        pl.add_slider_widget(f, [0.0, 1.0], title="Model opacity", pointa=(0.35, 0.1), pointb=(0.64, 0.1))

        if view_2d:
            match view_2d:
                case View2d.xz:
                    pl.view_xz()
                case View2d.yz:
                    pl.view_yz()
                case View2d.xy:
                    pl.view_xy()
                case _:
                    logger.warning(
                        "Invalid view_2d parameter, choose between None, 'xy', 'xz', 'yz'! Defaulting to 'xy'."
                    )
                    pl.view_xz()

            pl.enable_parallel_projection()
            pl.enable_2d_style()
            # Center the camera on model.
            pl.reset_camera()

        pl.show()

    @utils.beta_feature()
    def closest_point(self, point: list[float], layer_names: list[str] = None) -> tuple[list[float], str]:
        """Queries the closest point on the mesh to a given point. The mesh can be prefiltered with the list of layer names


        :param list[float] point: input point
        :param list[str] layer_names: List of layer names to prefilter the geometry, defaults to None
        :return tuple[list[float], str]: the point and the layer name of the closest point
        """
        if layer_names is None:
            mesh = self.mesh
        else:
            mesh = self.extract_layers(layer_names).mesh
        closest_cell, closest_point = mesh.find_closest_cell(point, return_closest_point=True)

        return closest_point, self.layer_names[mesh.cell_data["layer_index"][closest_cell]]

    @staticmethod
    def load_model(model_obj: ModelObj | GeometryLibraryObj) -> "MeshCollection":
        """
        Load the mesh of a model object.

        :returns MeshCollection: Returns the contents of the model object as a mesh collection.
        """
        if not (isinstance(model_obj, ModelObj) or isinstance(model_obj, GeometryLibraryObj)):
            raise TypeError("model_obj should be a ModelObj or GeometryLibraryObj object")
        model_obj._has_valid_local_file(True)
        file = model_obj._model_file_path
        return MeshCollection.load_3dm(file)

    @staticmethod
    def load_3dm(model_path: str, merging_tolerance: float = 1e-3) -> "MeshCollection":
        """
        load the "mesh" contents of a 3dm file.

        :returns MeshCollection: Returns the contents of the 3dm file as a mesh collection.
        """
        model = File3dm.Read(str(model_path))

        def has_treble_layers(model: File3dm) -> bool:
            for layer in model.Layers:
                if "Treble::Geometry::" in layer.FullPath:
                    return True
            return False

        is_treble_generated_file = has_treble_layers(model)

        if is_treble_generated_file:
            # Find the "Treble" layer.
            layer_names = [
                layer.FullPath.removeprefix("Treble::Geometry::").replace("::", "/") for layer in model.Layers
            ]
            treble_layer_index = layer_names.index("Treble")
            try:
                group_id_info = treble_metadata_from_layers(model)
            except Exception as e:
                logger.debug(f"Warning: Error loading treble metadata from layers: {e}")
                group_id_info = {}
        else:
            layer_names = [layer.FullPath for layer in model.Layers]
            treble_layer_index = -1

        # The complete model mesh
        model_mesh = []
        object_ids = []

        i_obj = 0
        for rhino_object in model.Objects:
            # skip if object is a mesh or a mesh on the treble layer
            if (not isinstance(rhino_object.Geometry, RhinoMesh)) or (
                rhino_object.Attributes.LayerIndex == treble_layer_index
            ):
                continue

            rhino_object.Geometry.Faces.ConvertQuadsToTriangles()
            pv_vertices = [
                [
                    rhino_object.Geometry.Vertices[v].X,
                    rhino_object.Geometry.Vertices[v].Y,
                    rhino_object.Geometry.Vertices[v].Z,
                ]
                for v in range(len(rhino_object.Geometry.Vertices))
            ]
            pv_faces = [
                [
                    3,
                    rhino_object.Geometry.Faces[f][0],
                    rhino_object.Geometry.Faces[f][1],
                    rhino_object.Geometry.Faces[f][2],
                ]
                for f in range(len(rhino_object.Geometry.Faces))
            ]
            mesh_to_add = pv.PolyData(pv_vertices, pv_faces)
            mesh_to_add.cell_data["layer_index"] = rhino_object.Attributes.LayerIndex
            mesh_to_add.cell_data["object_index"] = i_obj
            object_ids.append(str(rhino_object.Attributes.Id))
            i_obj += 1
            if is_treble_generated_file and group_id_info:
                object_group_id = str(rhino_object.Geometry.GetUserString("tech.treble.geometry_group_id"))
                mesh_to_add.cell_data["group_type"] = group_id_info[object_group_id].group_type
            mesh_to_add_triangulated = mesh_to_add.triangulate()
            model_mesh.append(mesh_to_add_triangulated)

        merged_mesh = pv.merge(model_mesh, merge_points=True).clean(
            point_merging=True, tolerance=merging_tolerance
        )
        merged_mesh.field_data["obj_id_pr_obj_index"] = object_ids

        merged_mesh["layer_name"] = [layer_names[int(i)] for i in merged_mesh.cell_data["layer_index"]]
        merged_mesh, layer_names = MeshCollection._remove_empty_layers(merged_mesh, layer_names=layer_names)

        return MeshCollection(merged_mesh, layer_names, object_ids)

    def _save_simple_3dm(self, output_path: str) -> None:
        """
        Saves the content of the mesh as a 3dm file without writing additional metadata into the file, such as identification of inner volumes and outer shells

        """
        model = File3dm()
        model.Settings.ModelUnitSystem = UnitSystem.Meters
        layer_indices = []
        for layer_name in self.layer_names:
            rhino_layer = RhinoLayer()
            rhino_layer.Name = layer_name
            layer_indices.append(model.Layers.Add(rhino_layer))
        object_string = "object_index" if "object_index" in self.mesh.cell_data else "layer_index"
        for i_obj in np.unique(self.mesh.cell_data[object_string]).astype(int):
            pv_obj = (
                self.mesh.extract_cells(self.mesh.cell_data[object_string] == i_obj)
                .extract_surface()
                .triangulate()
            )
            if pv_obj.n_cells > 0:
                rhino_mesh = RhinoMesh()
                [rhino_mesh.Vertices.Add(p[0], p[1], p[2]) for p in pv_obj.points]
                [
                    rhino_mesh.Faces.AddFace(v[0], v[1], v[2], v[2])
                    for v in pv_obj.faces.reshape(int(pv_obj.faces.shape[0] / 4), 4)[:, 1::]
                ]
                layer_index = pv_obj.cell_data["layer_index"][0]
                object_id = model.Objects.Add(rhino_mesh)
                new_object = model.Objects.FindId(object_id)
                new_object.Attributes.LayerIndex = layer_index
                if self.object_ids:
                    new_object.Attributes.Id = self.object_ids[i_obj]

        model.Write(output_path)

    def _as_simple_3dm(self) -> File3dm:
        """
        Returns the content of the mesh as a 3dm file without writing additional metadata into the file, such as identification of inner volumes and outer shells
        """
        model = File3dm()
        model.Settings.ModelUnitSystem = UnitSystem.Meters
        layer_indices = []
        for layer_name in self.layer_names:
            rhino_layer = RhinoLayer()
            rhino_layer.Name = layer_name
            layer_indices.append(model.Layers.Add(rhino_layer))
        object_string = "object_index" if "object_index" in self.mesh.cell_data else "layer_index"
        for i_obj in np.unique(self.mesh.cell_data[object_string]).astype(int):
            pv_obj = (
                self.mesh.extract_cells(self.mesh.cell_data[object_string] == i_obj)
                .extract_surface()
                .triangulate()
            )
            if pv_obj.n_cells > 0:
                rhino_mesh = RhinoMesh()
                [rhino_mesh.Vertices.Add(p[0], p[1], p[2]) for p in pv_obj.points]
                [
                    rhino_mesh.Faces.AddFace(v[0], v[1], v[2], v[2])
                    for v in pv_obj.faces.reshape(int(pv_obj.faces.shape[0] / 4), 4)[:, 1::]
                ]
                layer_index = pv_obj.cell_data["layer_index"][0]
                object_id = model.Objects.Add(rhino_mesh)
                new_object = model.Objects.FindId(object_id)
                new_object.Attributes.LayerIndex = layer_index
                if self.object_ids:
                    new_object.Attributes.Id = self.object_ids[i_obj]

        return model

    @staticmethod
    def join_mesh_collections(
        mesh_collections: list["MeshCollection"], merge_by_layer_name: bool = True
    ) -> "MeshCollection":
        """
        Joins a list of MeshCollections objects into a single object, joining the layer_name lists. Any layer names that are coinciding between the meshes will be joined into one

        :param bool merge_by_layer_name: If true, objects in layers that share the same name will be merged into one layer. If False the layers will be kept separate by appending a number to the layer name.
        :returns MeshCollection: Returns a joined MeshCollection object.
        """

        global_layer_indices_pr_name = {}
        joined_mesh = pv.PolyData()
        global_layer_index = 0
        global_max_object_index = 0
        for mesh_collection in mesh_collections:
            global_layer_index_pr_local = {}
            for local_layer_index, layer_name in enumerate(mesh_collection.layer_names):
                if not merge_by_layer_name:
                    new_layer_name = _get_valid_layer_name(
                        layer_name, list(global_layer_indices_pr_name.keys())
                    )
                    layer_name = new_layer_name
                if layer_name not in global_layer_indices_pr_name:
                    # Update layer name if required.
                    global_layer_indices_pr_name[layer_name] = global_layer_index
                    global_layer_index += 1

                global_layer_index_pr_local[local_layer_index] = global_layer_indices_pr_name[layer_name]

            if "object_index" in mesh_collection.mesh.cell_data:
                mesh_collection.mesh.cell_data["object_index"] = (
                    mesh_collection.mesh.cell_data["object_index"] + global_max_object_index
                )
                global_max_object_index = max(mesh_collection.mesh.cell_data["object_index"]) + 1
            else:
                mesh_collection.mesh.cell_data["object_index"] = (
                    mesh_collection.mesh.cell_data["layer_index"] + global_max_object_index
                )
                global_max_object_index = max(mesh_collection.mesh.cell_data["object_index"]) + 1

            new_layer_indices = np.array(
                [
                    global_layer_index_pr_local[local_layer_index]
                    for local_layer_index in mesh_collection.mesh.cell_data["layer_index"]
                ]
            )
            mesh_collection.mesh.cell_data["layer_index"] = new_layer_indices
            joined_mesh = joined_mesh.merge(mesh_collection.mesh)

        def convert_layer_name_dict_to_list(new_layer_names):
            layer_names = [None for i in range(len(new_layer_names))]
            for layer_name, layer_index in new_layer_names.items():
                layer_names[layer_index] = layer_name
            return layer_names

        layer_names = convert_layer_name_dict_to_list(global_layer_indices_pr_name)

        # Attempt to keep original object ids.
        joined_object_ids = []
        for mesh in mesh_collections:
            for object_id in mesh.object_ids:
                if joined_object_ids in joined_object_ids:
                    # Use generated id, log warning.
                    logger.warning(
                        f"Object id {object_id} already exists in the joined mesh, original object ids will not be kept in joined geometry."
                    )
                    joined_object_ids.append(str(uuid.uuid4()))
                else:
                    joined_object_ids.append(object_id)

        return MeshCollection(mesh=joined_mesh, layer_names=layer_names, object_ids=list(joined_object_ids))

    def _remove_layer_from_geo(self, layer_name) -> "MeshCollection" | None:
        if layer_name not in self.layer_names:
            logger.error("Layer name {layer_name} not found in geometry")
            return None
        layer_index = self.layer_names.index(layer_name)
        layer_mask = self.mesh.cell_data["layer_index"] != layer_index
        filtered_geo_points = self.mesh.extract_cells(layer_mask)
        # Clean up object ids.
        unique_object_index = np.unique(filtered_geo_points.cell_data["object_index"]).astype(int)
        # Reduce object index.
        object_index_map = {i: v for i, v in enumerate(unique_object_index)}

        mapped_data = np.vectorize(object_index_map.get, otypes=[int])(
            filtered_geo_points.cell_data["object_index"]
        )
        filtered_geo_points.cell_data["object_index"] = mapped_data

        filtered_object_ids = [item for i, item in enumerate(self.object_ids) if i in unique_object_index]

        filtered_layer_names = [item for item in self.layer_names if item != layer_name]
        return MeshCollection(
            mesh=filtered_geo_points, layer_names=filtered_layer_names, object_ids=filtered_object_ids
        )

    @staticmethod
    def create_box(
        x_min: float = -1,
        x_max: float = 1,
        y_min: float = -1,
        y_max: float = 1,
        z_min: float = -1,
        z_max: float = 1,
        layer_name: str = "box",
    ) -> "MeshCollection":
        """
        Create a box mesh with the given dimensions

        :param x_min: minimum x coordinate
        :param x_max: maximum x coordinate
        :param y_min: minimum y coordinate
        :param y_max: maximum y coordinate
        :param z_min: minimum z coordinate
        :param z_max: maximum z coordinate
        :param layer_name: name of the layer of the box
        """
        mesh = pv.Box([x_min, x_max, y_min, y_max, z_min, z_max]).triangulate()

        mesh.cell_data["layer_index"] = 0
        mesh.cell_data["object_index"] = 0
        mesh["layer_name"] = [layer_name for _ in mesh.cell_data["layer_index"]]
        return MeshCollection(mesh, [layer_name])

    @staticmethod
    def create_plane(length: float = 1.0, width: float = 1.0, layer_name: str = "plane"):
        """
        Create a plane mesh with the given dimensions

        :param length: length of the plane
        :param width: width of the plane
        :param layer_name: name of the layer of the plane
        """
        mesh = pv.Quadrilateral(
            [
                [0, -length / 2, -width / 2],
                [0, length / 2, -width / 2],
                [0, length / 2, width / 2],
                [0, -length / 2, width / 2],
            ]
        ).triangulate()
        mesh.cell_data["layer_index"] = 0
        mesh.cell_data["object_index"] = 0
        mesh["layer_name"] = [layer_name for _ in mesh.cell_data["layer_index"]]
        return MeshCollection(mesh, [layer_name])

    @staticmethod
    def create_triangle(
        point0: list[float] = [0, 0, 0],
        point1: list[float] = [0, 1, 0],
        point2: list[float] = [0, 0, 1],
        layer_name: str = "triangle",
    ):
        """
        Create a plane mesh with the given dimensions

        :param point0: first point of the triangle
        :param point1: second point of the triangle
        :param point2: third point of the triangle
        :param layer_name: name of the layer of the triangle
        """

        mesh = pv.Triangle([point0, point1, point2])
        mesh.cell_data["layer_index"] = 0
        mesh["layer_name"] = [layer_name for _ in mesh.cell_data["layer_index"]]
        return MeshCollection(mesh, [layer_name])

    @staticmethod
    def create_loudspeaker(
        width: float,
        depth: float,
        height: float,
        membrane_diameter: float,
        membrane_center_height: float,
        membrane_resulution: int = 12,
        enclosure_layer_name: str = "enclosure",
        membrane_layer_name: str = "membrane",
    ) -> "MeshCollection":
        """
        Create a speaker mesh with the given dimensions
        :param width: width of the speaker
        :param depth: depth of the speaker
        :param height: height of the speaker
        :param membrane_diameter: diameter of the membrane
        :param membrane_center_height: height of the membrane center from the bottom of the enclosure
        :param membrane_resulution: Number of points to use for the membrane
        """
        if (
            width <= 0
            or depth <= 0
            or height <= 0
            or membrane_diameter <= 0
            or membrane_center_height <= 0
            or membrane_resulution <= 0
        ):
            logger.error("All dimensions should be positive")
            return None

        if membrane_diameter >= width:
            logger.error("Membrane diameter should be smaller than the width of the speaker")
            return None

        if (
            membrane_center_height + membrane_diameter / 2 >= height
            or membrane_center_height - membrane_diameter / 2 <= 0
        ):
            logger.error(
                "Membrane diameter +- membrane center height should be within the height of the speaker"
            )
            return None

        membrane = (
            pv.Circle(membrane_diameter / 2, membrane_resulution)
            .rotate_y(90, inplace=True)
            .translate([0, 0, membrane_center_height], inplace=True)
        )
        membrane_edge = membrane.extract_feature_edges(boundary_edges=True)
        box = pv.Box([-depth, 0, -width / 2, width / 2, 0, height])
        pointa = [0.0, -width / 2, 0.0]
        pointb = [0.0, width / 2, 0.0]
        pointc = [0.0, width / 2, height]
        pointd = [0.0, -width / 2, height]

        rectangle_edge = pv.Quadrilateral([pointa, pointb, pointc, pointd]).extract_feature_edges(
            boundary_edges=True
        )
        rectangle_edge.cell_data["rectangle"] = 0

        front = rectangle_edge.merge(membrane_edge).delaunay_2d(
            alpha=0, edge_source=rectangle_edge.merge(membrane_edge)
        )

        def _distance(p1, p2):
            return np.sqrt(np.sum(np.abs(p1**2 - p2**2)))

        box_points = []
        for i_cell, cell in enumerate(front.faces.reshape(int(front.faces.shape[0] / 4), 4)[:, 1::]):
            for p in cell:
                if _distance(front.points[p], np.array(pointa)) < 1e-3:
                    box_points.append(i_cell)
                if _distance(front.points[p], np.array(pointb)) < 1e-3:
                    box_points.append(i_cell)
                if _distance(front.points[p], np.array(pointc)) < 1e-3:
                    box_points.append(i_cell)
                if _distance(front.points[p], np.array(pointd)) < 1e-3:
                    box_points.append(i_cell)
        box.remove_cells(box.find_closest_cell([0, 0, membrane_center_height]), inplace=True)
        box2 = box.merge(front.extract_cells(np.unique(box_points)))

        box2.cell_data["layer_index"] = 0
        box2.cell_data["object_index"] = 0
        membrane.cell_data["layer_index"] = 1
        membrane.cell_data["object_index"] = 1

        merged_mesh = (
            box2.merge(membrane).extract_surface().triangulate().translate([0, 0, -membrane_center_height])
        )
        layer_names = [enclosure_layer_name, membrane_layer_name]
        merged_mesh["layer_name"] = [layer_names[int(i)] for i in merged_mesh.cell_data["layer_index"]]

        return MeshCollection(
            merged_mesh,
            [enclosure_layer_name, membrane_layer_name],
        )

    @staticmethod
    def _remove_empty_layers(mesh: pv.PolyData, layer_names: list[str]) -> tuple[pv.PolyData, list[str]]:
        """
        Remove empty layers from the mesh
        """
        unique_indices = np.unique(mesh.cell_data["layer_index"]).astype(int)
        new_layer_names = [layer_names[i] for i in unique_indices]
        # Mapping between old indices and new ones
        index_map = {old: new for new, old in enumerate(unique_indices)}
        # Update layer indices.
        mesh.cell_data["layer_index"] = np.vectorize(index_map.get)(mesh.cell_data["layer_index"])
        return mesh, new_layer_names


def _get_valid_layer_name(layer_name: str, layer_names: list[str]) -> str:
    if layer_name in ("Treble", "Treble/Geometry"):
        return layer_name
    if layer_name in layer_names:
        i = 1
        while f"{layer_name}_{i}" in layer_names:
            i += 1
        return f"{layer_name}_{i}"
    return layer_name


def _load_layer_names_with_ids_from_3dm(model: str | File3dm) -> list[dict[str, str]]:
    """
    load layers from 3dm with full name and id
    """

    if type(model) == str:
        model = File3dm.Read(str(model))

    return _load_layer_names_with_ids_from_3dm_obj(model)


def _load_layer_names_with_ids_from_3dm_obj(model: File3dm) -> list[dict[str, str]]:
    """
    load layers from 3dm with full name and id
    """

    def has_treble_layers(model: File3dm) -> bool:
        for layer in model.Layers:
            if "Treble::Geometry::" in layer.FullPath:
                return True
        return False

    if has_treble_layers(model):
        layers = [
            {str(layer.Id): layer.FullPath.removeprefix("Treble::Geometry::").replace("::", "/")}
            for layer in model.Layers
        ]
    else:
        layers = [{str(layer.Id): layer.FullPath} for layer in model.Layers]

    return layers
