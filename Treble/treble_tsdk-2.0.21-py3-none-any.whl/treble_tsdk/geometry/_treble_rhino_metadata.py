from enum import Enum
from rhino3dm import File3dm
from dataclasses import dataclass
import json


class TrebleGroupType(Enum):
    """
    Represents what group a object belongs to in model.
    """

    OuterShell = 1
    InnerVolume = 2
    OpenSurface = 3


@dataclass
class TrebleObjectGroupInfo:
    group_type: TrebleGroupType
    volume: float


def treble_metadata_from_layers(model: File3dm) -> dict[str, TrebleObjectGroupInfo]:
    """
    Parse metadata from Geometry layer.
     * tech.treble.geometry_group_type_by_group_id
     * tech.treble.volume_by_group_id
    :returns: dictionary where the key is group_id and values is a TrebleObjectGroupInfo object.
    """
    geometry_layer_index = next(
        iter([index for index, layer in enumerate(model.Layers) if layer.Name == "Geometry"]), None
    )
    if not geometry_layer_index:
        # Unable to find geometry layer.
        return None

    group_id_to_group_type = json.loads(
        model.Layers[geometry_layer_index].GetUserString("tech.treble.geometry_group_type_by_group_id")
    )

    try:
        group_id_to_volume = json.loads(
            model.Layers[geometry_layer_index].GetUserString("tech.treble.volume_by_group_id")
        )
    except:
        group_id_to_volume = {}

    return {
        group_id: TrebleObjectGroupInfo(
            group_id_to_group_type[group_id], group_id_to_volume.get(group_id, None)
        )
        for group_id in group_id_to_group_type.keys()
    }
