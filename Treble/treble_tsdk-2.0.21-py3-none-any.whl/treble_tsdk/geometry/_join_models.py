from pathlib import Path

from ..treble_logging import logger
from .mesh_collection import MeshCollection
from ..utility_classes import Transform3d, Point3d, Rotation


def join_models(
    source_model_path: str,
    target_models: list[str | Path | MeshCollection],
    target_model_transforms: list[Transform3d],
    merge_by_layer_name: bool = True,
) -> Path | None:
    """
    joins a model (source_model) with a list of models (target_models). Each of the target models can be given a transform to locate it inside of the source model.

    This method can be used to for example insert sound sources in connection with the boundary velocity functionality or to modify existing spaces by inserting furniture and other objects into an existing space

    :param str source_model: Name of model to insert the target model into
    :param list[str | MeshCollection] target_models: Path to the target model file to be uploaded or MeshCollection containing the geometry.
    :param list[Transform3d] target_model_transform: Transform of the target model.
    :param str new_model_name: Optional description of your model.
    :param str new_model_description: Optional description of your model.
    :param bool skip_collision_validation: Optional description of your model.
    :param GeometryCheckerSettingsDto geometry_checker_settings: Optional advanced settings for geometry checking service.
    :param bool merge_by_layer_name: If true, objects in layers that share the same name will be merged into one layer. If False the layers will be kept separate by appending a number to the layer name.
    :returns ModelObj: Returns the uploaded ModelObj object.
    """
    if len(target_models) != len(target_model_transforms):
        logger.error("Target model paths and target model transforms do not match")
        return None

    source_mesh_collection = MeshCollection.load_3dm(source_model_path)
    target_mesh_collections = []
    for target_model, transform in zip(target_models, target_model_transforms):
        if isinstance(target_model, str) or isinstance(target_model, Path):
            mesh_collection = MeshCollection.load_3dm(target_model)
        elif isinstance(target_model, MeshCollection):
            mesh_collection = target_model
        else:
            logger.error("Target model is not a valid type")
            return None

        mesh_collection.transform(transform, inplace=True)
        target_mesh_collections.append(mesh_collection)
    return MeshCollection.join_mesh_collections(
        [source_mesh_collection] + target_mesh_collections, merge_by_layer_name
    )
