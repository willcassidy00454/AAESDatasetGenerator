from pathlib import Path
import json
import uuid

import numpy as np

from ..treble_logging import logger
from ..core.temp_folder import TempFolder
from ..core.project import Project
from ..core.model_obj import ModelObj
from .. import utils as utils
from ..core.geometry_component_library import GeometryComponent
from ..geometry.mesh_collection import MeshCollection
from ..client.api_models import GeometryCheckerSettingsDto
from ..utility_classes import Point3d

from ..free_field import utils as free_field_utils



def add_free_field_model(
    project: Project,
    name: str,
    geometry: ModelObj | GeometryComponent | Path | str,
    sphere_geometry_radius: float = 3,
    description: str = None,
    geometry_checker_settings: GeometryCheckerSettingsDto = None,
    output_mode: utils.ProgressOutputMode = utils.ProgressOutputMode.TQDM_OUTPUT,
) -> ModelObj:
    """
    Create a FreeFieldGeometry model from a device geometry by adding a sphere geometry around it.
    FreeFieldGeometry models can be used to create FreeFieldSimulations.

    :param Project project: Project to create the model in.
    :param str name: Name of the model.
    :param ModelObj | MeshCollection | str device_geometry: Device geometry, the device must be centered around the origin.
    :param float sphere_geometry_radius: Radius of the sphere geometry in meters, defaults to 3 meters.
    :param int number_of_receivers: Number of receivers in the sphere of receivers around the device, defaults to 500.
    :param str description: Optional description of the model, defaults to None
    :param GeometryCheckerSettingsDto geometry_checker_settings: Advanced settings for GeometryProcessing, defaults to None
    :param utils.ProgressOutputMode output_mode: Optional, can be used to set how model creation progress reporting is handled, defaults to TQDM progress bars.
    :return ModelObj: Returns a ModelObj object representing the free field geometry.
    """
    if project.get_model_by_name(name):
        logger.error(f"Model with name '{name}' already exists in project.")
        return None

    output_mode, tqdm = utils.try_load_tqdm(output_mode)

    # Close progress bar helper.
    def close_pbar(pbar):
        if pbar:
            pbar.close()

    pbar = None
    progress_bar_steps = [
        "Validate input geometry",
        "Generate sphere geometry",
        "Validate joined geometry",
        "Processing FreeField model",
        "Completed",
    ]
    # Validate input geometry.
    if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
        pbar = tqdm.tqdm(progress_bar_steps, bar_format="{desc} {bar} [{n_fmt}/{total_fmt}]")
        pbar.update()
        pbar.set_description(progress_bar_steps[0])
    elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
        logger.info(f"Processing [0/{len(progress_bar_steps)}]: {progress_bar_steps[0]}")
    # Check and upload original geometry.
    tmp_folder = TempFolder()
    if (
        isinstance(geometry, MeshCollection)
        or isinstance(geometry, str)
        or isinstance(geometry, GeometryComponent)
    ):
        if isinstance(geometry, MeshCollection):
            model_file_path = f"{tmp_folder._temp_dir}/model.3dm"
            geometry._save_simple_3dm(model_file_path)
        elif isinstance(geometry, GeometryComponent):
            model_file_path = str(geometry._load_component_data())
        elif isinstance(geometry, str):
            if not Path(geometry).exists():
                logger.error("Model file does not exist.")
                close_pbar(pbar)
                return None
            if Path(geometry).suffix != ".3dm":
                logger.error("Model file must be a 3dm file.")
                close_pbar(pbar)
                return None
            model_file_path = geometry
        # Run device_geometry through GCS to validate it.
        processed_device_geo = project.add_model(
            model_name=f"{uuid.uuid4()}-GCS", model_file_path=model_file_path
        )
        processed_device_geo.wait_for_model_processing()
        if processed_device_geo.status != "Valid":
            project.delete_model(processed_device_geo)
            logger.error("Device geometry is not valid.")
            close_pbar(pbar)
            return None
        processed_device_geo._has_valid_local_file(True)
        project.delete_model(processed_device_geo)
        input_geometry = MeshCollection.load_3dm(processed_device_geo._model_file_path)
    elif isinstance(geometry, ModelObj):
        # Use provided geometry.
        if geometry.status != "Valid":
            logger.error(
                f"Invalid device geometry, device geometry status must be 'Valid', but was {geometry.status}"
            )
            close_pbar(pbar)
            return None
        if geometry._has_valid_local_file(True):
            input_geometry = MeshCollection.load_3dm(geometry._model_file_path)
        else:
            logger.error("Unable to load model from model object!")
            close_pbar(pbar)
            return None
    else:
        logger.error("Invalid device_geometry type.")
        close_pbar(pbar)
        return None

    # Generate sphere geometry
    if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
        pbar.set_description(progress_bar_steps[1])
        pbar.update()
    elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
        logger.info(f"Processing [1/{len(progress_bar_steps)}]: {progress_bar_steps[1]}")
    # Create FreeField geometry (sphere around source geometry).
    source_bounding_box = input_geometry.bounding_box()
    if not source_bounding_box.is_inside_sphere(Point3d(0, 0, 0), sphere_geometry_radius):
        logger.error(
            f"Sphere with radius {sphere_geometry_radius} does not encapsulate the device geometry. Please provide a larger sphere radius."
        )
        close_pbar(pbar)
        return None
    furthest_dist_from_origin = np.linalg.norm(input_geometry.mesh.points).max() / 10.0
    sphere_geo = free_field_utils.create_sphere_geometry(sphere_geometry_radius)
    combined_geo = MeshCollection.join_mesh_collections([input_geometry, sphere_geo])

    # Verify joined geometry
    if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
        pbar.set_description(progress_bar_steps[2])
        pbar.update()
    elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
        logger.info(f"Processing [2/{len(progress_bar_steps)}]: {progress_bar_steps[2]}")

    # Add FreeField model to project.
    ff_model = project._add_model_from_meshcollection(
        model_name=name,
        meshcollection=combined_geo,
        model_description=description,
        geometry_checker_settings=geometry_checker_settings,
        metadata={
            "__treble_model_sphere_geometry_radius": str(sphere_geometry_radius),
            "__treble_model_furthest_dist_from_origin": str(furthest_dist_from_origin),
            "__treble_model_source_bounding_box": str(json.dumps(source_bounding_box, default=vars)),
        },
        category="FreeField",
    )
    if ff_model is None:
        logger.error("Failed to add free field model to project!")
        close_pbar(pbar)
        return None

    ff_model.wait_for_model_processing()
    if ff_model.status != "Valid":
        logger.error("FreeField model geometry is not valid!")
        close_pbar(pbar)
        return ff_model

    # Processing FreeField model
    if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
        pbar.set_description(progress_bar_steps[3])
        pbar.update()
    elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
        logger.info(f"Processing [3/{len(progress_bar_steps)}]: {progress_bar_steps[3]}")

    # We need to save a model containing only the speaker geometry.
    # which has the same object_ids as the free field model. So we remove the sphere from the free field model.
    # and save the speaker geometry as a new model. This model will be linked to any
    # Boundary Velocity submodels created from a FreeField simulation using this free field model..
    # Remove sphere, upload geometry
    gcs_ff_geo = MeshCollection.load_model(ff_model)
    gcs_speaker_geo = gcs_ff_geo._remove_layer_from_geo("exterior")
    # Save and upload geometry
    gcs_speaker_path = f"{tmp_folder._temp_dir}/base_gcs.3dm"
    gcs_speaker_geo._save_simple_3dm(gcs_speaker_path)
    # Harvest data from ff_model.
    geometry_object_info = {}
    geometry_layer_info = []
    geometry_group_volumes = (
        ff_model._dto.geometryGroupTypeToVolume
    )
    for object_id in gcs_speaker_geo.object_ids:
        if object_info := ff_model._dto.geometryObjectInfo.get(object_id, None):
            geometry_object_info[object_id] = object_info
            geometry_layer_info.append({"ObjectId": object_id, "LayerName": object_info.layerName})

    gcs_speaker_model = project._add_model_skip_gcs(
        model_name=f"{name}_ORIGINAL",
        model_file_path=gcs_speaker_path,
        model_description=f"Generated when creating FreeFieldGeometry '{name}'",
        parent_id=ff_model.id,  # Link between this geometry and it's parent FreeFieldGeometry model.
        groups_volume=geometry_group_volumes,
        layer_info=geometry_layer_info,
        object_info=geometry_object_info,
    )
    # Make sure the _ORIGINAL model does not show up in the project model list.
    project.delete_model(gcs_speaker_model)

    # Completed
    if output_mode == utils.ProgressOutputMode.TQDM_OUTPUT:
        pbar.set_description(progress_bar_steps[4])
        pbar.update()
    elif output_mode == utils.ProgressOutputMode.LOGGING_OUTPUT:
        logger.info(f"Processing [4/{len(progress_bar_steps)}]: {progress_bar_steps[4]}")
    close_pbar(pbar)
    return ModelObj(ff_model._dto, ff_model._model_file_path, ff_model._client)
