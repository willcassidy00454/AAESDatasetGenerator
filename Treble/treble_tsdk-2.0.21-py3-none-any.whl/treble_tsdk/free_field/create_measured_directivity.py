from ..client.tsdk_client import TSDKClient
from .source_model_generation import _create_source_directivity
from .sphere_interpolation import SphereInterpolator
import numpy as np


def import_directivity_pattern(
    client: TSDKClient,
    name: str,
    points: np.ndarray,
    frequencies: np.ndarray,
    data: np.ndarray,
    category: str,
    subcategory: str,
):
    """Create a measured directivity object

    :param np.ndarray points: _description_
    :param np.ndarray frequencies: _description_
    :param np.ndarray data: _description_

    """

    sphere_interpolator = SphereInterpolator(points, frequencies, data)

    (
        f_third_octaves,
        frs_third_oct_top_pole,
        _,
        _,
    ) = sphere_interpolator.interpolate_on_axis_normalized_top_pole_third_octave(frequencies, data)

    return _create_source_directivity(
        client=client,
        f_third_octave=f_third_octaves,
        top_pole_azi_colat_third_octave=frs_third_oct_top_pole,
        category=category,
        sub_category=subcategory,
        crossover_frequency=int(max(frequencies)),
        name=name,
    )
