import numpy as np
from ..client.tsdk_client import TSDKClient
from .fit_mono_dipole import fit_mono_dipole
import json

import numpy as np

from ..treble_logging import logger
from ..core.temp_folder import TempFolder
from ..core.source_directivity_obj import (
    SourceDirectivityObj,
    SourceDirectivityNatural,
    SourceDirectivityAmplified,
    SourceDirectivityCategory,
    SourceDirectivityOther,
)
from .sphere_interpolation import SphereInterpolator
from ..core.source_directivity_obj import DirectivityPatternInputData
from .utils import pad_freqs_third_octave_top_pole_response


def import_source_directivity_from_data(
    client: TSDKClient,
    name: str,
    directivity_pattern_input: str | DirectivityPatternInputData,
    category: SourceDirectivityCategory,
    sub_category: SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther = None,
    description: str = None,
    manufacturer: str = None,
):
    """Add your directivity pattern to the treble database

    :param TSDKClient client: tsdk client
    :param str name: name of the directivity pattern
    :param str | DirectivityPatternInputData directivity_pattern_input: directivity pattern data
    :param SourceDirectivityCategory category: catergory of the directivity pattern
    :param SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther sub_category: sub category, defaults to None
    :param str description: description, defaults to None
    :param str manufacturer: name of the manufacturer, defaults to None
    """
    sphere_interpolator = SphereInterpolator(
        points=directivity_pattern_input.points,
        frequencies=directivity_pattern_input.frequencies,
        data=directivity_pattern_input.frequency_responses,
    )
    (
        f_third_octave,
        interpolated_data,
        _,
        _,
    ) = sphere_interpolator.interpolate_on_axis_normalized_top_pole()

    (
        f_third_octaves_padded,
        interpolated_responses_padded,
    ) = pad_freqs_third_octave_top_pole_response(f_third_octave, interpolated_data)

    if len(f_third_octaves_padded) != len(f_third_octave):
        logger.warning(
            "The input frequency range does not cover the full range, the directivity pattern model will be padded with the highest frequency value to the full frequency range"
        )

    return _create_source_directivity(
        client=client,
        f_third_octave=f_third_octaves_padded,
        top_pole_azi_colat_third_octave=interpolated_responses_padded,
        category=category,
        sub_category=sub_category,
        name=name,
        manufacturer=manufacturer,
        description=description,
        crossover_frequency=int(directivity_pattern_input.frequencies.max()),
    )


def _create_source_directivity(
    client: TSDKClient,
    f_third_octave,
    top_pole_azi_colat_third_octave,
    category: SourceDirectivityCategory,
    sub_category: SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther,
    name: str,
    crossover_frequency: int,
    manufacturer: str = None,
    description: str = None,
    parent_simulation_id: str = None,
) -> SourceDirectivityObj:

    temp_folder = TempFolder()
    ga_directivity_model = get_ga_directivity_model(f_third_octave, top_pole_azi_colat_third_octave)
    ga_fitted_mono_dipole_model = get_ga_mono_dipole_model(f_third_octave, top_pole_azi_colat_third_octave)
    dg_mono_dipole_model = get_dg_mono_dipole_model(ga_fitted_mono_dipole_model, crossover_frequency)
    ga_directivity_path = temp_folder.temp_dir + "/ga_directivity_model.json"
    ga_fitted_mono_dipole_path = temp_folder.temp_dir + "/ga_fitted_mono_dipole_model.json"
    dg_mono_dipole_path = temp_folder.temp_dir + "/mono_dipole_model.json"
    json.dump(ga_directivity_model, open(ga_directivity_path, "w"))
    json.dump(ga_fitted_mono_dipole_model, open(ga_fitted_mono_dipole_path, "w"))
    json.dump(dg_mono_dipole_model, open(dg_mono_dipole_path, "w"))

    source_dt = client.source_directivity.create_source_directivity_from_models(
        ga_directivity_path=ga_directivity_path,
        ga_fitted_mono_dipole_path=ga_fitted_mono_dipole_path,
        dg_mono_dipole_path=dg_mono_dipole_path,
        category=category,
        sub_category=sub_category,
        name=name,
        manufacturer=manufacturer,
        description=description,
        parent_simulation_id=parent_simulation_id,
    )
    if source_dt is None:
        logger.error("Failed to create source directivity")
        return None
    return SourceDirectivityObj(source_directivity_dto=source_dt, client=client)


def _fit_mono_dipole(f_third_octave, fr_top_pole_third_octave) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Helper method to fit the mono-diple model to the top pole response

    :return _type_: The frequency vector, the mono_dipole coefficients and the top pole response
    """
    azimuths = np.arange(0, 2 * np.pi, 2 * np.pi / 72)
    colatitudes = np.linspace(0, np.pi, 37)

    mono_dipole_fit = fit_mono_dipole(
        target_fr=fr_top_pole_third_octave,
        azimuth_rad=azimuths,
        colatitude_rad=colatitudes,
        f_third_octaves=f_third_octave,
    )
    mono_dipole_coefficients = np.column_stack(
        (mono_dipole_fit[0], mono_dipole_fit[1])
    )
    mono_dipole_toppole_third_octave = mono_dipole_fit[2]
    return f_third_octave, mono_dipole_coefficients, mono_dipole_toppole_third_octave


def get_directivity_dict(
    f_third_octave: np.ndarray,
    top_pole_azi_colat_third_octave: np.ndarray,
    mono_dipole_coefficients: np.ndarray = None,
    n_azi: int = 72,
    n_colat: int = 37,
):
    """
    Return directivity data in format that GA can read.

    :param np.ndarray f_third_octave: third octave frequency bands
    :param np.ndarray top_pole_azi_colat_third_octave: the top pole response of the loudspeaker model
    :param np.ndarray mono_dipole_coefficients: mono dipole coefficients if available, defaults to None
    :param int n_azi: number of azimuth angles in the top pole response, defaults to 72
    :param int n_colat:  number of colatitude angles in the top pole response, defaults to 37
    """
    if top_pole_azi_colat_third_octave.shape[0] != len(f_third_octave):
        raise ValueError("top pole response does not contain correctly formatted data")
    if top_pole_azi_colat_third_octave.shape[1] != n_azi:
        raise ValueError("top pole response does not contain correctly formatted data")
    if top_pole_azi_colat_third_octave.shape[2] != n_colat:
        raise ValueError("top pole response does not contain correctly formatted data")

    if mono_dipole_coefficients is not None:
        if mono_dipole_coefficients.shape != (len(f_third_octave), 2):
            raise ValueError("mono dipole coefficients do not contain correctly formatted data")

    return {
        "convention": "spherical coordinates",
        "data_format": "list[frequency,phi(Azimuth:0deg=[1,0,0],counter-clockwise rotation),theta(elevation:0deg=[0,0,1],90deg=[1,0,0]),180deg=[0,0,-1]]",
        "f": [int(f) for f in f_third_octave],
        "phi": np.arange(0, 2 * np.pi, 2 * np.pi / n_azi).tolist(),
        "theta": np.linspace(
            0, np.pi, n_colat
        ).tolist(),
        "data_real": np.real(top_pole_azi_colat_third_octave).tolist(),
        "data_imag": np.imag(top_pole_azi_colat_third_octave).tolist(),
        "mono_dipole_coefficients": (
            mono_dipole_coefficients.tolist() if mono_dipole_coefficients is not None else []
        ),
    }


def get_ga_directivity_model(
    f_third_octave,
    top_pole_azi_colat_third_octave,
    n_azi: int = 72,
    n_colat: int = 37,
) -> dict:
    check_directivity_poles(
        f_third_octave=f_third_octave,
        top_pole_azi_colat_third_octave=top_pole_azi_colat_third_octave,
        n_azi=n_azi,
        n_colat=n_colat,
    )
    n_ele = n_colat  # What is n_ele suppose to be ? Switched to n_colat for now.
    return {
        "convention": "spherical coordinates",
        "data_format": "list[frequency,phi(Azimuth:0deg=[1,0,0],counter-clockwise rotation),theta(elevation:0deg=[0,0,1],90deg=[1,0,0]),180deg=[0,0,-1]]",
        "f": [int(f) for f in f_third_octave],
        "phi": np.arange(0, 2 * np.pi, 2 * np.pi / n_azi).tolist(),
        "theta": np.linspace(0, np.pi, n_ele).tolist(),
        "data_real": np.real(top_pole_azi_colat_third_octave).tolist(),
        "data_imag": np.imag(top_pole_azi_colat_third_octave).tolist(),
    }


def get_ga_mono_dipole_model(
    f_third_octave, fr_top_pole_third_octave, n_azi: int = 72, n_colat: int = 37
) -> dict:
    (
        f_third_octave,
        mono_dipole_coefficients,
        mono_dipole_toppole_azi_ele_third_octave,
    ) = _fit_mono_dipole(f_third_octave, fr_top_pole_third_octave)
    if mono_dipole_coefficients.shape != (len(f_third_octave), 2):
        raise ValueError("mono dipole coefficients do not contain correctly formatted data")
    # Create GA directivity
    directivity_data = get_directivity_dict(
        f_third_octave=f_third_octave,
        top_pole_azi_colat_third_octave=mono_dipole_toppole_azi_ele_third_octave,
        n_azi=n_azi,
        n_colat=n_colat,
    )
    # Add mono dipole coefficients.
    directivity_data["mono_dipole_coefficients"] = mono_dipole_coefficients.tolist()
    return directivity_data


def get_dg_mono_dipole_model(ga_fitted_mono_dipole_model: dict, crossover_frequency: float = 12000) -> dict:
    coeffs = ga_fitted_mono_dipole_model["mono_dipole_coefficients"]
    f_third_octave = ga_fitted_mono_dipole_model["f"]
    # Not used in join directivity lambda. Should be calculated from fitting errors, but use crossover_frequency for now.
    f_max = f_third_octave[0]
    for i, f in enumerate(f_third_octave):
        if i > 0 and f > crossover_frequency:
            f_max = f_third_octave[i - 1]
            break
    return {
        "mono_coefficient": [x[0] for x in coeffs],
        "dipole_coefficient": [x[1] for x in coeffs],
        "frequency": f_third_octave,
        "fmax": f_max,
    }


def check_directivity_poles(
    f_third_octave: np.ndarray,
    top_pole_azi_colat_third_octave: np.ndarray,
    n_azi: int = 72,
    n_colat: int = 37,
):
    if top_pole_azi_colat_third_octave.shape[0] != len(f_third_octave):
        raise ValueError("top pole response does not contain correctly formatted data")
    if top_pole_azi_colat_third_octave.shape[1] != n_azi:
        raise ValueError("top pole response does not contain correctly formatted data")
    if top_pole_azi_colat_third_octave.shape[2] != n_colat:
        raise ValueError("top pole response does not contain correctly formatted data")
