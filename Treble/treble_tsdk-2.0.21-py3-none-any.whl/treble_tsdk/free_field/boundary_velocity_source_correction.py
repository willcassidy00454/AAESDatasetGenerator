from scipy import signal
import numpy as np


def compute_boundary_velocity_fr_correction(
    crossover_frequency: int, speed_of_sound: float = 343, n_frequencies: int = 16001, fs: int = 32000
) -> tuple[np.ndarray, np.ndarray]:
    """
    Compute the boundary velocity frequency response correction filter to apply to the gaussian pulse output of the DG solver when using the boundary velocity source. The filter includes the high pass and low pass filters that should be applied to the time domain responses.

    :param int crossover_frequency: crossover frequency of the simulation
    :param float speed_of_sound: speed of sound, defaults to 343
    :param int n_frequencies: number of frequencies for the filter, defaults to 16001
    :param int fs: sampling frequency of the filter, defaults to 32000
    :return tuple[np.ndarray, np.ndarray]: the frequency vector and the correction filter
    """
    f, hplp_fr = get_hplp_filter(lp_freq=crossover_frequency, n_frequencies=n_frequencies, fs=fs)
    source_width = get_source_width(crossover_frequency)
    time_vector = np.arange(2 * (n_frequencies - 1)) / fs
    pulse_start_distance = 4.0 * source_width
    velocity_gaussian = initial_velocity_gaussian(
        crossover_frequency, pulse_start_distance, time_vector, speed_of_sound
    )
    velocity_fr = np.fft.rfft(velocity_gaussian) / (fs / 2)
    plateaued_velocity_fr = plateau_response_in_high_freq(
        f, pulse_start_distance, speed_of_sound, crossover_frequency, velocity_fr
    )
    final_filter_fr = 1 / plateaued_velocity_fr * hplp_fr
    return f, final_filter_fr


def plateau_response_in_high_freq(
    f: np.ndarray,
    distance: float,
    speed_of_sound: float,
    crossover_frequency: float,
    velocity_fr: np.ndarray,
) -> np.ndarray:
    """
    Helper function to smooth out the high frequency response of the boundary velocity source correction filter. The challenge is that the upper frequencies become gained extremely high if the inverse of the gaussian pulse is used.

    :param np.ndarry f: frequency vector
    :param float distance: distance of the pulse (so the phase response of the plateu can be aligned)
    :param float speed_of_sound: speed of sound
    :param float crossover_frequency: crossover frequency
    :param np.ndarray velocity_fr: Frequency response velocity compensated signal
    :return np.ndarray: the smoothed and compensated frequency response
    """
    k = f * 2 * np.pi / speed_of_sound
    crossover_index = np.argmin(np.abs(f - crossover_frequency))
    fade_index = np.argmin(np.abs(f - crossover_frequency * np.sqrt(2)))
    hanning_length = min(fade_index, len(f) - 1) - crossover_index

    fade = np.exp(-1j * k * distance) * np.abs(velocity_fr[fade_index])
    fade[0:crossover_index] = 0
    fade[crossover_index : crossover_index + hanning_length] *= np.hanning(hanning_length * 2)[
        0:hanning_length
    ]
    return velocity_fr + fade


def initial_velocity_gaussian(
    crossover_frequency: float, distance: float, time_vector: np.ndarray, speed_of_sound: float
) -> np.ndarray:
    """
    Creates the initial velocity gaussian pulse for the boundary velocity source correction filter (has amplitude 1)

    :param float crossover_frequency: crossover frequency
    :param float distance: distance of the pulse
    :param np.ndarray time_vector: time vector
    :param float speed_of_sound: speed of sound
    :return np.ndarray: the gaussian pulse signal in the time domain
    """
    source_width = get_source_width(crossover_frequency)
    rminct = (distance - speed_of_sound * time_vector) / (source_width + 1e-7)
    return np.exp(-(rminct**2))


def get_hplp_filter(
    hp_order: int = 2,
    lp_order: int = 10,
    hp_freq: int = 20,
    lp_freq: int = 710,
    n_frequencies: int = 16001,
    fs: int = 32000,
) -> np.ndarray:
    """
    Creates the high pass and low pass filter applied in treble

    :param int hp_order: order of the high pass filter, defaults to 2
    :param int lp_order: order of the low pass filter, defaults to 10
    :param int hp_freq: frequency of the hp filter, defaults to 20
    :param int lp_freq: frequency of the low pass filter, defaults to 710
    :param int n_frequencies: number of frequencies for the filter, defaults to 16001
    :param int fs: sampling frequency, defaults to 32000
    :return np.ndarray: the combined filter frequency response
    """
    hp_sos = signal.butter(hp_order, hp_freq, "hp", fs=fs, output="sos")
    lp_sos = signal.butter(lp_order, lp_freq, "lp", fs=fs, output="sos")
    f, h_hp = signal.sosfreqz(hp_sos, worN=n_frequencies - 1, fs=fs)
    f, h_lp = signal.sosfreqz(lp_sos, worN=n_frequencies - 1, fs=fs)
    hplp_fr = np.abs(h_hp * h_lp) ** 2
    hplp_fr = np.append(hplp_fr, 0)
    f = np.append(f, fs / 2)
    return f, hplp_fr


def get_source_width(crossover_frequency: float) -> float:
    """
    Get the source width for the gaussian pulse used in the DG solver

    :param float crossover_frequency: crossover frequency
    :return float: source width
    """

    if crossover_frequency <= 3000:
        return round(0.24 / (crossover_frequency / 500 / 1.41), 3)
    else:
        return 0.34 / (crossover_frequency / 500 / 1.41)
