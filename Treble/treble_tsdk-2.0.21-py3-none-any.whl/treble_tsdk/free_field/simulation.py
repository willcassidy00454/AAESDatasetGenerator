from typing import TYPE_CHECKING

import numpy as np
import pyvista as pv

if TYPE_CHECKING:
    from .results import FreeFieldResults

from ..treble_logging import logger
from ..core.simulation import (
    SimulationDefinition,
    SimulationSettings,
    MesherSettings,
    GaSolverSettings,
    DgSolverSettings,
    SimulationType,
)
from ..core.receiver import Receiver, ReceiverType
from ..core.source import Source, SourceProperties, SourceType
from ..core.source_boundary_velocity import BoundaryVelocityLayer
from ..client.tsdk_client import TSDKClient
from ..client.api_models import ObjectMetadataDto
from ..core.model_obj import ModelObj, MaterialAssignment, LocalMeshSizing
from ..core.object_metadata import ObjectMetadata
from ..geometry.mesh_collection import MeshCollection
from . import utils as ff_utils


class FreeFieldSimulationSettings(SimulationSettings):
    def __init__(
        self,
        number_of_receivers: int = 500,
        max_picked_source_element_area: float = 1e-3,
        speed_of_sound: float = 343.0,
        ga_settings: GaSolverSettings = None,
        dg_settings: DgSolverSettings = None,
        ir_shift_seconds: float = None,
        gpu_count: int = None,
        dev_blob: str = None,
    ):
        """
        Free field simulation settings.
        :param int number_of_receivers: Number of receivers on the sphere, defaults to 500
        :param float receiver_sphere_radius: _description_, defaults to 1
        :param float sphere_shell_radius: _description_, defaults to 2
        :param float max_picked_source_element_area: _description_, defaults to 1e-3
        :param float speed_of_sound: SpeedOfSound (m/s) in medium.
        :param GaSolverSettings ga_settings: Settings specific to the GA solver.
        :param DgSolverSettings dg_settings: Settings sepcific to the DG solver.
        :param float ir_shift_seconds: Shift the IRs and effectively pad the beginning of them to allow for the source correction and postprocessing create more accurate results.
        :param int gpu_count: Sets the number of GPUs to allocate for each wave-solver task in the simulation.
        """
        self.number_of_receivers = number_of_receivers
        self.max_picked_source_element_area = max_picked_source_element_area
        # Minimum distance from the receivers to the device
        self._minimum_rec_to_device_distance: float = 0.1
        # Layer name for the source
        self._source_layer_name: str = "_free_field_source_surface"
        # Label of the source center receiver
        self._source_center_label: str = "_source_center"
        # Label of the on axis receiver
        self._on_axis_label: str = "on_axis"
        # Prefix for the sphere receiver labels
        self._receiver_label_prefix: str = "_r"
        # Prefix for the sphere receiver labels
        self._source_label: str = "source"
        # The distance the source_center receiver is placed in front of the source surface
        self._source_center_receiver_distance: float = 1e-3
        # 1.0 means that the wave will travel the distance from the source to the exterior and back to the receivers
        self._ir_length_ratio: float = 0.9
        # number of negative time samples in the impulse response
        self._negative_time_samples = 3200

        super().__init__(
            speed_of_sound=speed_of_sound,
            ga_settings=ga_settings,
            dg_settings=dg_settings,
            ir_shift_seconds=ir_shift_seconds,
            gpu_count=gpu_count,
            dev_blob=dev_blob,
        )

    def as_metadata_payload(self) -> dict[str, str]:
        pass


class FreeFieldSimulationDefinition(SimulationDefinition):
    def __init__(
        self,
        name: str,
        free_field_model: ModelObj,
        frequency: float,
        receiver_sphere_radius: float,
        source_input: str,
        free_field_simulation_settings: FreeFieldSimulationSettings = None,
        material_assignment: list[MaterialAssignment] = None,
        description: str = None,
        local_mesh_sizing: list[LocalMeshSizing] = None,
        mesher_settings: MesherSettings = None,
        metadata: dict[str, str] | ObjectMetadataDto | ObjectMetadata = None,
    ):
        if free_field_simulation_settings is None:
            free_field_simulation_settings = FreeFieldSimulationSettings()

        # Basic initial validation.
        self._validate_input(
            free_field_model=free_field_model,
            frequency=frequency,
            receiver_sphere_radius=receiver_sphere_radius,
            free_field_simulation_settings=free_field_simulation_settings,
        )

        # Generate source
        # Find smallest edge of source layer and use that as local sizing ?
        source_layer = self._pick_source_layer(free_field_model=free_field_model, source_input=source_input)
        source_list = [
            Source(
                x=0.0,
                y=0.0,
                z=0.0,
                source_type=SourceType.boundary_velocity,
                label=free_field_simulation_settings._source_label,
                source_properties=SourceProperties(
                    boundary_velocity_definition=BoundaryVelocityLayer(
                        boundary_layer_name=source_layer, mesh_keep_exterior_edges=True
                    ),
                ),
            )
        ]

        source_center_point = self._find_source_center(
            free_field_model=free_field_model,
            source_layer_name=source_layer,
            free_field_simulation_settings=free_field_simulation_settings,
        )

        # Generate receiver list.
        receiver_list = self._generate_receivers(
            free_field_model=free_field_model,
            receiver_sphere_radius=receiver_sphere_radius,
            source_layer_name=source_layer,
            source_center_point=source_center_point,
            free_field_simulation_settings=free_field_simulation_settings,
        )

        # Material assignment.
        updated_material_assignment = self._update_material_assignment(
            free_field_model._client, material_assignment, free_field_model.layer_names
        )

        # Set the local mesh sizing for the layers except for the exterior layer
        if local_mesh_sizing is None:
            local_mesh_sizing = [
                LocalMeshSizing(
                    layer_name=layer_name,
                    mesh_sizing_m=_compute_mesh_sizing(frequency),
                    keep_exterior_edges=True,
                )
                for layer_name in free_field_model.layer_names
                if layer_name != "exterior"
            ]

        # Calculate ir length.
        model_sphere_radius = float(free_field_model.metadata["__treble_model_sphere_geometry_radius"])
        propagation_distance = (
            2 * model_sphere_radius - receiver_sphere_radius - np.linalg.norm(source_center_point)
        ) * free_field_simulation_settings._ir_length_ratio
        ir_length = propagation_distance / float(
            free_field_simulation_settings.get("speedOfSound", None) or 343.0
        )

        if metadata is None:
            metadata = {}

        metadata["__treble_ff_simulation_source_layer"] = source_layer

        super().__init__(
            name=name,
            description=description,
            simulation_type=SimulationType.dg,
            model=free_field_model,
            ir_length=ir_length,
            crossover_frequency=frequency,
            source_list=source_list,
            receiver_list=receiver_list,
            material_assignment=updated_material_assignment,
            local_mesh_sizing=local_mesh_sizing,
            mesher_settings=mesher_settings,
            metadata=metadata,
            simulation_settings=free_field_simulation_settings,
        )
        self.category = "FreeField"

    @staticmethod
    def _validate_input(
        free_field_model: ModelObj,
        frequency: float,
        receiver_sphere_radius: float,
        free_field_simulation_settings: FreeFieldSimulationSettings,
    ):
        # Make sure model is a FreeField model.
        if free_field_model._dto.category != "FreeField":
            raise ValueError(
                "Unable to initialize simulation definition, Provided geometry is not a FreeFieldGeometry!"
            )

        model_sphere_radius = float(
            free_field_model.metadata.get("__treble_model_sphere_geometry_radius", "0")
        )
        model_furthest_dist_from_origin = float(
            free_field_model.metadata.get("__treble_model_furthest_dist_from_origin", "0")
        )

        if receiver_sphere_radius > model_sphere_radius:
            raise ValueError("Receiver sphere radius must be smaller than the model sphere radius.")

        # Check distance between device and receiver sphere.
        if (
            model_furthest_dist_from_origin
            > receiver_sphere_radius - free_field_simulation_settings._minimum_rec_to_device_distance
        ):
            raise ValueError(
                f"Model too large or not centered around the origin, max radius={receiver_sphere_radius - free_field_simulation_settings._minimum_rec_to_device_distance}"
            )

    @staticmethod
    def _pick_source_layer(
        free_field_model: ModelObj, source_input: str | tuple[float, float, float] | list[float]
    ) -> str:
        if source_input not in free_field_model.layer_names:
            raise ValueError(
                f"Layer {source_input} not found, available layers: {free_field_model.layer_names}"
            )
        logger.info(f'Source set to layer "{source_input}"')
        return source_input

    @staticmethod
    def _update_material_assignment(
        client: TSDKClient,
        input_assignment: list[MaterialAssignment],
        model_layer_names: list[str],
    ) -> list[MaterialAssignment]:
        # Source -> Default fully reflecting.
        # Sphere -> Default 95% absorption.
        fully_reflecting_mat = client.material.get_material_by_name("Fully reflective surface")
        absorbing_mat = client.material.get_material_by_name("95% Absorption")
        if input_assignment:
            input_assignment_dict = {assignment["layerName"]: assignment for assignment in input_assignment}
        else:
            input_assignment_dict = {}

        material_assignment = []
        # If input material assignment is missing, assign fully reflecting material to all layers.
        if input_assignment is None:
            input_assignment = []

        for layer_name in model_layer_names:
            if layer_name in input_assignment_dict:
                # User specified material assignment.
                material_assignment.append(input_assignment_dict[layer_name])
            elif layer_name == "exterior":
                # Make exterior sphere absorbing.
                material_assignment.append(
                    MaterialAssignment(layer_name, absorbing_mat, scattering_coefficient=0.0)
                )
            else:
                # Set fully reflecting material on all other unassigned layers.
                material_assignment.append(
                    MaterialAssignment(layer_name, fully_reflecting_mat, scattering_coefficient=0.0)
                )

        return material_assignment

    @staticmethod
    def _find_source_center(
        free_field_model: ModelObj,
        source_layer_name: str,
        free_field_simulation_settings: FreeFieldSimulationSettings,
    ) -> np.ndarray:
        # Load the model mesh.
        if not free_field_model._has_valid_local_file(True):
            logger.error("Unable to load model file!")
        free_field_mesh = MeshCollection.load_3dm(free_field_model._model_file_path)
        # Find center point of source layer.
        source_layer_index = free_field_mesh.layer_names.index(source_layer_name.replace("::", "/"))
        source_surface: pv.PolyData = free_field_mesh.mesh.extract_cells(
            free_field_mesh.mesh.cell_data["layer_index"] == source_layer_index
        ).extract_surface()
        source_center_triangle, source_center = source_surface.find_closest_cell(
            source_surface.center_of_mass(), return_closest_point=True
        )

        source_center_point = np.array(
            source_center
            + source_surface.cell_normals[source_center_triangle]
            * free_field_simulation_settings._source_center_receiver_distance,
            np.float64,
        )
        return source_center_point

    @staticmethod
    def _generate_receivers(
        free_field_model: ModelObj,
        receiver_sphere_radius: float,
        source_layer_name: str,
        source_center_point: np.ndarray,
        free_field_simulation_settings: FreeFieldSimulationSettings,
    ):
        """
        Creates the receivers for the free field simulation.
        A sphere of receiver points is uniformly on a sphere using a fibonacci sphere.
        The sphere of receivers is place such that the first receiver is on the x-axis, which becomes the on-axis receiver.
        Additionally a receiver is placed right in front of the center of the defined source
        """
        # Creating a grid of receivers using a fibonacci sphere.
        # It is rotated towards the x axis, so the on axis response is covered exactly by a receiver,
        # this receiver is pulled out to assign to its own variable
        receiver_sphere_points = (
            pv.PolyData(
                ff_utils.fibonacci_sphere(free_field_simulation_settings.number_of_receivers)
                * receiver_sphere_radius
            )
            .rotate_y(90)
            .points[1:]
        )

        on_axis_receiver_point = np.array([1, 0, 0], np.float64) * receiver_sphere_radius

        # Create on-axis receiver.
        receivers = [
            Receiver(
                x=float(on_axis_receiver_point[0]),
                y=float(on_axis_receiver_point[1]),
                z=float(on_axis_receiver_point[2]),
                receiver_type=ReceiverType.mono,
                label=free_field_simulation_settings._on_axis_label,
            )
        ]

        # Add receivers of receiver sphere.
        for i_rec, rec in enumerate(receiver_sphere_points):
            receivers.append(
                Receiver(
                    float(rec[0]),
                    float(rec[1]),
                    float(rec[2]),
                    ReceiverType.mono,
                    label=f"{free_field_simulation_settings._receiver_label_prefix}{i_rec}",
                )
            )

        # Add receiver on source.
        receivers.append(
            Receiver(
                float(source_center_point[0]),
                float(source_center_point[1]),
                float(source_center_point[2]),
                ReceiverType.mono,
                label=free_field_simulation_settings._source_center_label,
            )
        )

        return receivers


def _compute_mesh_sizing(
    frequency: float, speed_of_sound: float = 343, elements_pr_wavelength: float = 1.585
) -> float:
    """Computes the mesh sizing for a 4th order element to be computed properly with the treble solver

    :param float frequency: frequency in Hz
    :param float speed_of_sound: speed of sound, defaults to 343
    :param float elements_pr_wavelength: setting for the mesh sizing, defaults to 1.585
    :return float: the mesh sizing, i.e. the average element edge length in meters
    """
    wavelength = speed_of_sound / frequency
    return wavelength / elements_pr_wavelength
