import numpy as np
import pyvista as pv

import treble_tsdk.free_field.utils as ff_utils
from .utils import fibonacci_sphere, third_octave_average_frs
from scipy.spatial import KDTree


class SphereInterpolator:
    """Class for interpolating the complex frequency response on a sphere given points, frequencies and data"""

    def __init__(self, points: np.ndarray, frequencies: np.ndarray, data: np.ndarray):
        """Class to help interpolate

        :param np.ndarray input_points: input points that lies on a sphere
        :param np.ndarray frequencies: input frequencies
        :param np.ndarray data: complex input data that corresponds to [n_points,n_frequencies]
        """
        if points.shape[0] == 0 or frequencies.shape[0] == 0:
            raise IOError("No point or frequencies found")

        if points.shape[0] < 50:
            raise IOError("at least 50 points is needed to do a proper interpolation on the sphere")

        if len(points.shape) != 2 or points.shape[1] != 3:
            raise IOError("input_points not formatted as an [n_points,3] array")

        if points.shape[0] != data.shape[0] or frequencies.shape[0] != data.shape[1]:
            raise IOError("data is not shaped as an [n_points,n_frequencies] array")

        point_distances = np.linalg.norm(points, axis=1)
        self.sphere_radius = point_distances[0]
        if (
            np.min(point_distances) < self.sphere_radius - 1e-3
            or np.max(point_distances) > self.sphere_radius + 1e-3
        ):
            raise IOError("Points not located on a sphere")

        if len(points) < 2500:
            # Recreates a surface mesh from the points to interpolate across by delaunay triangulation
            pv_points = pv.PolyData(points)
            pv_points["data_real"] = np.real(data)
            pv_points["data_imag"] = np.imag(data)

            pv_sphere = (
                pv_points.delaunay_3d(alpha=2.0, tol=1e-6)
                .clean()
                .triangulate()
                .extract_geometry()
                .triangulate()
            )
        else:
            # Map the measured points onto a finely resolved regular sphere (delaunay triangulation tends to not perfor so well with large dataset)
            if len(points) < 10000:
                # Front pole 5 deg resolution
                pv_sphere = pv.Sphere(phi_resolution=37, theta_resolution=72).triangulate().rotate_y(90)
            else:
                # Front pole 2.5 deg resolution
                pv_sphere = pv.Sphere(phi_resolution=73, theta_resolution=144).triangulate().rotate_y(90)
            kd_tree = KDTree(points)
            point_indices = kd_tree.query(pv_sphere.points)[1]
            pv_sphere.point_data["data_real"] = np.real(data)[point_indices]
            pv_sphere.point_data["data_imag"] = np.imag(data)[point_indices]

        self._sphere = pv_sphere

        self.frequencies = frequencies
        self.data = pv_sphere["data_real"] + 1j * pv_sphere["data_imag"]
        self.f_third_octave, self.data_third_octave = third_octave_average_frs(self.frequencies, self.data)

    def plot(self, frequency):
        self._sphere.point_data["pressure_abs"] = np.abs(self.data[:, frequency])
        self._sphere.plot(scalars="pressure_abs")

    def interpolate_fr(
        self, azimuth_rad: float, elevation_rad: float, third_octave_output: bool = True
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Interpolate a frequency response at the given azimuth and elevation

        :param float azimuth_rad: Azimuth angle in radians
        :param float elevation_rad: Elevation angle in radians
        :param ff_utils.FrScaling scaling: Scaling of the frequency response, defaults to ff_utils.FrScaling.on_axis_normalized
        :param bool include_hplp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray]: The frequency vector and the interpolated frequency response
        """
        sphere = self._sphere.copy()
        point = ff_utils.azi_ele_to_cart(azimuth_rad, elevation_rad) * self.sphere_radius

        if third_octave_output:
            return (
                self.f_third_octave,
                _interpolate_complex_points_on_surface(sphere, np.array([point]), self.data_third_octave)[0],
            )
        else:
            return (
                self.frequencies,
                _interpolate_complex_points_on_surface(sphere, np.array([point]), self.data)[0],
            )

    def interpolate_to_uniform_sphere(
        self,
        n_points: np.ndarray,
        rotate_towards_x: bool = True,
        third_octave_output: bool = True,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Interpolates the spherical data onto uniformly spaced points generated using a fibonacci sphere

        :param np.ndarray n_points: number of points requested
        :param np.ndarray data: data that should be interpolated onto the sphere
        :param bool rotate_towards_x: rotates the pattern towards the x axis (will ensure that there is a point at 1,0,0), defaults to True
        :return tuple[np.ndarray, np.ndarray]: points, interpolated data
        """
        fib_points = fibonacci_sphere(n_points)
        if rotate_towards_x:
            pv_points = pv.PolyData(fib_points)
            fib_points = pv_points.rotate_y(-90).points

        if third_octave_output:
            return (
                fib_points,
                self.f_third_octave,
                _interpolate_complex_points_on_surface(self._sphere, fib_points, self.data_third_octave),
            )
        else:
            return (
                fib_points,
                self.frequencies,
                _interpolate_complex_points_on_surface(self._sphere, fib_points, self.data),
            )

    def interpolate_on_axis_normalized_top_pole(
        self,
        n_azi: int = 72,
        n_colat: int = 37,
        third_octave_output: bool = True,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Interpolates the top pole response

        :param int n_azi: number of azimuth angles, defaults to 72
        :param int n_colat: number of colatitude angles, defaults to 37
        :return tuple[np.ndarray, np.ndarray]: returns the frequency vector and the interpolated frequency responses
        """
        azimuths = np.arange(0, 2 * np.pi, 2 * np.pi / n_azi)
        colatitudes = np.linspace(0, np.pi, n_colat)

        points = ff_utils.generate_azi_colat_points(azimuths, colatitudes, self.sphere_radius)
        if third_octave_output:
            f = self.f_third_octave
            data = self.data_third_octave
        else:
            f = self.frequencies
            data = self.data

        interpolated_responses = _interpolate_complex_points_on_surface(self._sphere, points, data)

        on_axis_response = _interpolate_complex_points_on_surface(self._sphere, np.array([[1, 0, 0]]), data)
        interpolated_responses = interpolated_responses / on_axis_response[0]

        interpolated_responses_transposed = interpolated_responses.reshape(n_colat, n_azi, len(f)).transpose(
            (2, 1, 0)
        )
        return f, interpolated_responses_transposed, azimuths, colatitudes

    def interpolate_azimuth_response(
        self,
        n_azi: int = 360,
        elevation: float = 0,
        third_octave_output: bool = True,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Interpolate the azimuth response at the given elevation

        :param int n_azi: number of azimuth points, defaults to 360
        :param float elevation_deg: the elevation in radians, defaults to 0
        :return tuple[np.ndarray, np.ndarray, np.ndarray]: the azimuth angles, the frequency vector and the interpolated frequency responses
        """

        def generate_azi_points(n_azi, radius, elevation: float = 0):
            azimuths = np.arange(0, 2 * np.pi, 2 * np.pi / n_azi)
            points = np.zeros((n_azi, 3))
            for i_azi, azi in enumerate(azimuths):
                points[i_azi] = ff_utils.azi_ele_to_cart(azi, elevation) * radius
            return azimuths, points

        azimuths, points = generate_azi_points(n_azi, self.sphere_radius, elevation)
        if third_octave_output:
            return (
                azimuths,
                self.f_third_octave,
                _interpolate_complex_points_on_surface(self._sphere, points, self.data_third_octave),
            )
        else:
            return (
                azimuths,
                self.frequencies,
                _interpolate_complex_points_on_surface(self._sphere, points, self.data),
            )

    def interpolate_elevation_response(
        self,
        n_ele: int = 360,
        azimuth: float = 0,
        third_octave_output: bool = True,
    ):
        """Interpolate the elevation response at the given azimuth angle

        :param int n_ele: number of elevation points, defaults to 360
        :param float azimuth: the azimuth in radians, defaults to 0
        :return tuple[np.ndarray, np.ndarray, np.ndarray]: the elevation angles, the frequency vector and the interpolated frequency responses
        """

        def generate_ele_points(n_ele, radius, azimuth: float = 0):
            elevations = np.arange(-np.pi, np.pi, 2 * np.pi / n_ele)

            points = np.zeros((n_ele, 3))
            for i_ele, ele in enumerate(elevations):
                points[i_ele] = ff_utils.azi_ele_to_cart(ele, azimuth) * radius
            return elevations, points

        elevations, points = generate_ele_points(n_ele, self.sphere_radius, azimuth)
        if third_octave_output:
            return (
                elevations,
                self.f_third_octave,
                _interpolate_complex_points_on_surface(self._sphere, points, self.data_third_octave),
            )
        else:
            return (
                elevations,
                self.frequencies,
                _interpolate_complex_points_on_surface(self._sphere, points, self.data),
            )


def _interpolate_complex_points_on_surface(
    surface: pv.PolyData, points: np.ndarray, original_values: np.ndarray
) -> np.ndarray:
    """
    Interpolate complex values on a surface

    :param pv.PolyData surface: Surface given as a pyvista PolyData object
    :param np.ndarray points: Points to interpolate on the surface
    :param np.ndarray original_values: The original values to use for the interpolation (should corresponse to the points in the surface)
    :return np.ndarray: The interpolated complex values
    """
    # finding the closest_points and their associated cells on the surface of the sphere
    closest_cells, closest_points = surface.find_closest_cell(points, return_closest_point=True)

    def barycentric_coordinates(sphere_points, points_on_sphere, sphere_faces):
        point_a = sphere_points[sphere_faces[:, 0]]
        point_b = sphere_points[sphere_faces[:, 1]]
        point_c = sphere_points[sphere_faces[:, 2]]

        a = point_a[closest_cells]
        b = point_b[closest_cells]
        c = point_c[closest_cells]
        p = points_on_sphere

        area_abc = 0.5 * np.linalg.norm(np.cross(b - a, c - a), axis=1)
        area_pbc = 0.5 * np.linalg.norm(np.cross(b - p, c - p), axis=1)
        area_pca = 0.5 * np.linalg.norm(np.cross(c - p, a - p), axis=1)
        area_pab = 0.5 * np.linalg.norm(np.cross(a - p, b - p), axis=1)
        alpha = area_pbc / area_abc
        beta = area_pca / area_abc
        gamma = area_pab / area_abc
        return alpha, beta, gamma

    faces = surface.faces.reshape(-1, 4)[:, 1:]
    alpha, beta, gamma = barycentric_coordinates(surface.points, closest_points, faces)

    relevant_points = faces[closest_cells]
    weights = np.vstack([alpha, beta, gamma]).T

    # The the values are real valued, the interpolation can be done on the real part
    if np.max(np.abs(np.imag(original_values))) < 1e-12:
        real = np.real(original_values)
        return np.sum(real[relevant_points] * weights[:, :, np.newaxis], axis=1)

    mag = np.abs(original_values)
    interpolated_mag = np.sum(mag[relevant_points] * weights[:, :, np.newaxis], axis=1)

    interpolated_phase = []
    phase_angle = np.angle(original_values)
    phase_relevant = phase_angle[relevant_points]
    phase_span = np.max(phase_relevant, axis=1) - np.min(phase_relevant, axis=1)
    for i_point in range(len(points)):
        if (phase_span[i_point] > np.pi * 0.99).any():
            interpolated_phase.append(phase_relevant[i_point][weights[i_point].argmax()])
        else:
            interpolated_phase.append(
                np.sum(phase_relevant[i_point] * weights[i_point][:, np.newaxis], axis=0)
            )

    interpolated_complex = interpolated_mag * np.exp(1j * np.array(interpolated_phase))
    return interpolated_complex
