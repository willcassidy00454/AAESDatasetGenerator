from pathlib import Path
import json

import numpy as np
import h5py

from .sphere_interpolation import SphereInterpolator
from .boundary_velocity_source_correction import get_hplp_filter
from .on_axis_source_correction import compute_on_axis_correction_filter
from . import utils as ff_utils
from . import plot as ff_plot
from ..results import Results
from ..core.temp_folder import TempFolder
from ..core.source_directivity_obj import (
    SourceDirectivityObj,
    SourceDirectivityNatural,
    SourceDirectivityAmplified,
    SourceDirectivityCategory,
    SourceDirectivityOther,
)
from ..geometry.mesh_collection import MeshCollection
from ..core.simulation import SimulationType, Simulation
from ..core.source_boundary_velocity import BoundaryVelocitySubmodel
from ..client.api_models import CreateBoundaryVelocitySubmodelDto
from .source_model_generation import get_ga_directivity_model, _create_source_directivity
from .fit_mono_dipole import fit_mono_dipole
from ..treble_logging import logger


class FreeFieldResults(Results):
    def __init__(
        self,
        simulation: Simulation,
        results_directory: Path | str,
        result_type: SimulationType = None,
    ):
        super().__init__(simulation=simulation, results_directory=results_directory, result_type=result_type)

        self._source_center_label = "_source_center"
        self._on_axis_label = "on_axis"
        self._drtf_ref_receiver_label = "_drtf_ref_receiver"

        self._mono_irs = {
            rec.id: self.get_mono_ir(self._simulation.sources[0], rec) for rec in self._simulation.receivers
        }

        self.fs = next(iter(self._mono_irs.values())).sampling_rate
        self.fft_correction = self.fs

        # Load free field model data as MeshCollection.
        model = self._simulation.get_model()
        model._has_valid_local_file(True)

        self._ff_model_mesh_collection = MeshCollection.load_3dm(model._model_file_path)
        self._source_area_scaling = self._compute_source_area_scaling()
        (
            self._sphere_interpolator,
            self._on_axis_fr,
            self._source_center_fr,
        ) = self._extract_fr_data()
        self.f = self._sphere_interpolator.frequencies
        self.sphere_radius = self._sphere_interpolator.sphere_radius
        self.f_ind_l = np.argmin(np.abs(self.f - 20))
        self.f_ind_u = np.argmin(np.abs(self.f - self._simulation.crossover_frequency)) + 1

    def _compute_source_area_scaling(self) -> float:
        """
        Compute the source area scaling based on the source boundary layer name.
        """
        bv_layer_name = self._simulation.sources[0].source_properties.source_boundary_layer_name.replace(
            "::", "/"
        )
        bv_layer_index = self._ff_model_mesh_collection.layer_names.index(bv_layer_name)
        return 1 / sum(
            self._ff_model_mesh_collection.mesh.compute_cell_sizes(area=True).cell_data["Area"][
                self._ff_model_mesh_collection.mesh.cell_data["layer_index"] == bv_layer_index
            ]
        )

    def _extract_fr_data(self) -> tuple[SphereInterpolator, np.ndarray, np.ndarray]:
        """
        Helper method to extract the frequency response data from the simulation results.

        :return tuple[pv.PolyData, np.ndarray, np.ndarray, np.ndarray, np.ndarray]: Triangulated sphere, the frequency vector, the frequency responses at the sphere points, the on axis frequency responses and the source center frequency response
        """

        sphere_rec_responses = []
        locations = []

        def delay_fr_samples(fr, n_samples):
            return fr * np.exp(-1j * np.pi * np.arange(len(fr)) / (len(fr) - 1) * n_samples)

        for rec in self._simulation.receivers:
            mono_ir = self._mono_irs[rec.id]
            f = np.fft.rfftfreq(mono_ir.sampling_rate, 1 / mono_ir.sampling_rate)
            fr = np.fft.rfft(mono_ir.data, mono_ir.sampling_rate) / mono_ir.sampling_rate
            fr = delay_fr_samples(fr, -mono_ir.zero_pad_samples)
            if rec.label == self._source_center_label:
                source_center = fr
            elif rec.label == self._on_axis_label:
                on_axis = fr
            elif rec.label == self._drtf_ref_receiver_label:
                pass
            else:
                sphere_rec_responses.append(fr)
                locations.append(np.array([rec.x, rec.y, rec.z]))

        sphere_interpolator = SphereInterpolator(
            points=np.array(locations),
            frequencies=f,
            data=np.array(sphere_rec_responses),
        )
        return sphere_interpolator, on_axis, source_center

    def _scale_fr(
        self,
        fr_full: np.ndarray,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.velocity,
        include_hplp_filters=False,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Helper method to scale the frequency response

        :param np.ndarray fr_full: Input  frequency response in as a flat velocity with the filters applied
        :param ff_utils.FrScaling scaling: Which scaling to apply, defaults to ff_utils.FrScaling.velocity
        :param bool include_hplp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        """
        fr_full = fr_full.copy()
        if scaling == ff_utils.FrScaling.on_axis_normalized:
            if include_hplp_filters:
                raise ValueError("Filters cannot be included for the on axis normalized response")

            return (
                self.f[self.f_ind_l : self.f_ind_u],
                fr_full[self.f_ind_l : self.f_ind_u] / self._on_axis_fr[self.f_ind_l : self.f_ind_u],
            )
        if scaling.is_acceleration():
            fr_full /= 1j * 2 * np.pi * self.f
        if scaling.is_volume_normalized():
            fr_full *= self._source_area_scaling
        if not include_hplp_filters:
            fr_full[self.f_ind_l : self.f_ind_u] = (
                fr_full[self.f_ind_l : self.f_ind_u]
                / get_hplp_filter(
                    n_frequencies=len(self.f), lp_freq=self._simulation.crossover_frequency, fs=self.fs
                )[1][self.f_ind_l : self.f_ind_u]
            )
            return self.f[self.f_ind_l : self.f_ind_u], fr_full[self.f_ind_l : self.f_ind_u]
        else:
            return self.f, fr_full

    def sphere_points_fr(
        self,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
        include_hp_lp_filters: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        The frequency responses at the sphere points

        :param ff_utils.FrScaling scaling: scaling of the frequency responses, defaults to ff_utils.FrScaling.on_axis_normalized
        :param bool include_hp_lp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray, np.ndarray]: unit vectors of the points, the frequency vector and the frequency responses.
        """
        unit_vectors = self._sphere_interpolator._sphere.points / self.sphere_radius
        frs = []

        for sphere_fr in self._sphere_interpolator.data:
            f, scaled_fr = self._scale_fr(
                sphere_fr,
                scaling=scaling,
                include_hplp_filters=include_hp_lp_filters,
            )
            frs.append(scaled_fr)

        return unit_vectors, f, np.array(frs)

    def on_axis_fr(
        self, scaling: ff_utils.FrScaling = ff_utils.FrScaling.velocity, include_hplp_filters=False
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Get the on axis frequency response

        :param ff_utils.FrScaling scaling: Choose the scaling of the frequency response, defaults to ff_utils.FrScaling.velocity
        :param bool include_hplp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray]: The frequency vector and the on axis frequency response
        """
        if scaling == ff_utils.FrScaling.on_axis_normalized:
            raise ValueError("on axis response cannot be normalized by the on axis response")
        return self._scale_fr(self._on_axis_fr, scaling, include_hplp_filters)

    def source_center_fr(
        self, scaling: ff_utils.FrScaling = ff_utils.FrScaling.velocity, include_hplp_filters=False
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Get the source center frequency response

        :param ff_utils.FrScaling scaling: Choose the scaling of the frequency response, defaults to ff_utils.FrScaling.velocity
        :param bool include_hplp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray]: The frequency vector and the source center frequency response.
        """
        return self._scale_fr(self._source_center_fr, scaling, include_hplp_filters)

    def interpolate_fr(
        self,
        azimuth_deg: float,
        elevation_deg: float,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
        include_hplp_filters: bool = False,
    ) -> tuple[np.ndarray, np.ndarray]:
        """
        Interpolate an frequency response at the given azimuth and elevation

        :param float azimuth_deg: Azimuth angle in degrees
        :param float elevation_deg: Elevation angle in degrees
        :param ff_utils.FrScaling scaling: Scaling of the frequency response, defaults to ff_utils.FrScaling.on_axis_normalized
        :param bool include_hplp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray]: The frequency vector and the interpolated frequency response.
        """
        _, fr = self._sphere_interpolator.interpolate_fr(
            azimuth_rad=azimuth_deg / 180 * np.pi,
            elevation_rad=elevation_deg / 180 * np.pi,
            third_octave_output=False,
        )
        return self._scale_fr(fr_full=fr, scaling=scaling, include_hplp_filters=include_hplp_filters)

    def interpolate_polar_azimuth(
        self,
        n_azi: int = 360,
        elevation_deg: float = 0,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
        include_hp_lp_filters: bool = False,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Interpolate the azimuth response at the given elevation

        :param int n_azi: number of azimuth points, defaults to 360
        :param float elevation_deg: the elevation in degrees, defaults to 0
        :param bool third_octave_average: Choose whether to output the third octave averages, defaults to False
        :param ff_utils.FrScaling scaling: scaling of the frequency responses, defaults to ff_utils.FrScaling.on_axis_normalized
        :param bool include_hp_lp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray, np.ndarray]: the azimuth angles, the frequency vector and the interpolated frequency responses
        """
        azimuths, _, interpolated_responses = self._sphere_interpolator.interpolate_azimuth_response(
            n_azi=n_azi,
            elevation=elevation_deg / 180 * np.pi,
            third_octave_output=False,
        )

        scaled_frs = []
        for interpolated_fr in interpolated_responses:
            f_scaled, scaled_fr = self._scale_fr(
                interpolated_fr,
                scaling=scaling,
                include_hplp_filters=include_hp_lp_filters,
            )
            scaled_frs.append(scaled_fr)

        return azimuths * 180 / np.pi, f_scaled, np.array(scaled_frs)

    def interpolate_polar_elevation(
        self,
        n_ele: int = 360,
        azimuth_deg: float = 0,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
        include_hp_lp_filters: bool = False,
    ):
        """Interpolate the elevation response at the given azimuth angle

        :param int n_ele: number of elevation points, defaults to 360
        :param float azimuth_deg: the azimuth in degrees, defaults to 0
        :param bool third_octave_average: Choose whether to output the third octave averages, defaults to False
        :param ff_utils.FrScaling scaling: scaling of the frequency response, defaults to ff_utils.FrScaling.on_axis_normalized
        :param bool include_hp_lp_filters: Whether to include the time domain hp lp filters, if this is false, the frequency axis will be limited to the valid range of the simulation and the filters that are normally applied in the time domain will be compensated for, defaults to False
        :return tuple[np.ndarray, np.ndarray, np.ndarray]: the elevation angles, the frequency vector and the interpolated frequency responses
        """
        elevations, _, interpolated_responses = self._sphere_interpolator.interpolate_elevation_response(
            n_ele=n_ele,
            azimuth=azimuth_deg / 180 * np.pi,
            third_octave_output=False,
        )
        scaled_frs = []
        for interpolated_fr in interpolated_responses:
            f_scaled, scaled_fr = self._scale_fr(
                interpolated_fr,
                scaling=scaling,
                include_hplp_filters=include_hp_lp_filters,
            )
            scaled_frs.append(scaled_fr)

        return elevations * 180 / np.pi, f_scaled, np.array(scaled_frs)

    def interpolate_directivity_balloon_third_octave(
        self,
        n_azi: int = 72,
        n_colat: int = 37,
        pad_to_full_frequency_range: bool = True,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Interpolates the directivity balloon onto a top pole response in third octave bands

        :param int n_azi: number of azimuth angles, defaults to 72
        :param int n_colat: number of colatitude angles, defaults to 37
        :param ff_utils.FrScaling scaling: choose the scaling of the frequency responses, defaults to ff_utils.FrScaling.on_axis_normalized
        :return tuple[np.ndarray, np.ndarray]: returns the frequency vector and the interpolated frequency responses
        """
        (
            f_third_octaves,
            interpolated_responses_transposed,
            azimuths,
            colatitudes,
        ) = self._sphere_interpolator.interpolate_on_axis_normalized_top_pole(
            n_azi=n_azi,
            n_colat=n_colat,
        )
        f_upper = np.abs(f_third_octaves - self._simulation.crossover_frequency).argmin() + 1
        f_third_octaves = f_third_octaves[:f_upper]
        interpolated_responses_transposed = interpolated_responses_transposed[:f_upper]
        if pad_to_full_frequency_range:
            (
                f_third_octaves,
                interpolated_responses_transposed,
            ) = ff_utils.pad_freqs_third_octave_top_pole_response(
                f_third_octaves, interpolated_responses_transposed
            )

        return (
            f_third_octaves,
            interpolated_responses_transposed,
            azimuths * 180 / np.pi,
            colatitudes * 180 / np.pi,
        )

    def _estimate_acoustic_center(self) -> np.ndarray:
        """Estimates the acoustic center of the simulation

        :return np.ndarray: acoustical center at the given frequencies
        """
        phase = np.unwrap(np.angle(self._sphere_interpolator.data), axis=1)
        speed_of_sound = self._simulation._dto.simulationSettings.speedOfSound or 343.0
        delay_distance = (phase - np.pi / 2) / (2 * np.pi) / self.f * speed_of_sound

        f_acoustic_center = []
        acoustic_center = []
        for f_ind in range(self.f_ind_l, self.f_ind_u):
            f_acoustic_center.append(self.f[f_ind])
            fr_abs = np.abs(self._sphere_interpolator.data[:, f_ind])
            delay_deviation = self.sphere_radius + delay_distance[:, f_ind]

            def weighed_center(coordinate: np.ndarray):
                return np.sum(delay_deviation * coordinate * fr_abs) / np.sum(np.abs(coordinate * fr_abs))

            acoustic_center.append(
                np.array(
                    [
                        weighed_center(self._sphere_interpolator._sphere.points[:, 0]),
                        weighed_center(self._sphere_interpolator._sphere.points[:, 1]),
                        weighed_center(self._sphere_interpolator._sphere.points[:, 2]),
                    ]
                )
            )
        return np.array(f_acoustic_center), np.array(acoustic_center)

    def _compute_on_axis_correction_filter(self) -> tuple[np.ndarray, int]:
        """
        Compute an IIR filter that compensates the original gaussian pulse on-axis response.
        The applying this filter to the on-axis response will result in a flat response on axis.
        The phase response on axis will be delayed, so it corresponds to the acoustic distance from the source.

        :return tuple[np.ndarray, int]: Filter and the center of the filter
        """
        frequency_vector, fr_v = self.on_axis_fr(
            scaling=ff_utils.FrScaling.velocity, include_hplp_filters=True
        )
        on_axis_correction_filter, filter_half_length = compute_on_axis_correction_filter(
            frequency_vector=frequency_vector,
            on_axis_velocity_fr=fr_v,
            sphere_radius=self.sphere_radius,
            crossover_frequency=self._simulation.crossover_frequency,
            wave_speed=self._simulation._dto.simulationSettings.speedOfSound or 343.0,
        )

        return on_axis_correction_filter, filter_half_length

    def create_boundary_velocity_submodel(
        self, source_name: str, source_description: str
    ) -> BoundaryVelocitySubmodel:
        c_filter = self._compute_on_axis_correction_filter()
        tmp_folder = TempFolder()
        h5_path = f"{tmp_folder.temp_dir}/source_correction_filter.h5"
        with h5py.File(h5_path, "w") as f:
            dset = f.create_dataset("on_axis_correction_filter", data=c_filter[0])
            dset.attrs["filter_half_length"] = c_filter[1]
            dset.attrs["crossover_frequency"] = self._simulation.crossover_frequency

        ga_directivity_path = f"{tmp_folder.temp_dir}/ga_directivity_model.json"
        (
            f_third_octave,
            top_pole_azi_colat_third_octave,
            _,
            _,
        ) = self.interpolate_directivity_balloon_third_octave(pad_to_full_frequency_range=True)

        if self._simulation.crossover_frequency < 8000:
            logger.warning(
                "The crossover frequency of the free field simulation is below 8000 Hz, the directivity model used for geometrical acoustics will be padded with the highest frequency value to the full frequency range"
            )

        ga_directivity_model = get_ga_directivity_model(f_third_octave, top_pole_azi_colat_third_octave)
        json.dump(ga_directivity_model, open(ga_directivity_path, "w"))

        res = self._simulation._client.boundary_velocity_submodel.create(
            source_filter_path=h5_path,
            ga_directivity_json_path=ga_directivity_path,
            req=CreateBoundaryVelocitySubmodelDto(
                name=source_name, description=source_description, parentSimulationId=self._simulation.id
            ),
        )

        if res is None:
            raise ValueError("Failed to create source submodel")

        return BoundaryVelocitySubmodel(dto=res, client=self._simulation._client)

    def create_source_directivity(
        self,
        category: SourceDirectivityCategory,
        sub_category: SourceDirectivityAmplified | SourceDirectivityNatural | SourceDirectivityOther,
        name: str,
        manufacturer: str = None,
        description: str = None,
    ) -> SourceDirectivityObj:
        (
            f_third_octave,
            top_pole_azi_colat_third_octave,
            _,
            _,
        ) = self.interpolate_directivity_balloon_third_octave(pad_to_full_frequency_range=True)
        if self._simulation.crossover_frequency < 8000:
            logger.warning(
                "The crossover frequency of the free field simulation is below 8000 Hz, the directivity model used for geometrical acoustics will be padded with the highest frequency value to the full frequency range"
            )
        return _create_source_directivity(
            client=self._simulation._client,
            f_third_octave=f_third_octave,
            top_pole_azi_colat_third_octave=top_pole_azi_colat_third_octave,
            category=category,
            sub_category=sub_category,
            name=name,
            manufacturer=manufacturer,
            description=description,
            parent_simulation_id=self._simulation.id,
            crossover_frequency=self._simulation.crossover_frequency,
        )

    #####
    # Plot functions
    #####
    def plot_on_axis_fr(self, scaling: ff_utils.FrScaling = ff_utils.FrScaling.velocity):
        """
        Plot the on-axis frequency response

        :param FrScaling scaling: Scaling, defaults to FrScaling.velocity
        """
        ff_plot.plot_on_axis_fr(self, scaling)

    def plot_source_center_fr(self, scaling: ff_utils.FrScaling = ff_utils.FrScaling.velocity):
        """
        Plot the source center frequency response

        :param FrScaling scaling: Scaling, defaults to FrScaling.velocity
        """
        ff_plot.plot_source_center_fr(self, scaling)

    def plot_interpolated_fr(
        self,
        azimuth_deg: float,
        elevation_deg: float,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.velocity,
    ):
        """
        Plot the interpolated frequency response at the given azimuth and elevation

        :param float azimuth_deg: Azimuth angle in degrees
        :param float elevation_deg: Elevation angle in degrees
        :param FrScaling scaling: Scaling, defaults to FrScaling.on_axis_normalized
        """
        ff_plot.plot_interpolated_fr(self, azimuth_deg, elevation_deg, scaling)

    def plot_polar_azimuth(
        self,
        frequency: float,
        n_azi: int = 360,
        elevation_deg: float = 0,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
    ):
        """
        Plot the interpolated response as a function of the azimuth angle at a given frequency

        :param _type_ frequency: Frequency to plot
        :param int n_azi: Number of azimuth points, defaults to 360
        :param float elevation_deg: The elevation angle, defaults to 0
        :param FrScaling scaling: Scaling, defaults to FrScaling.on_axis_normalized
        """
        ff_plot.plot_interpolated_azimuth_response(
            self, frequency=frequency, n_azi=n_azi, elevation_deg=elevation_deg, scaling=scaling
        )

    def plot_polar_elevation(
        self,
        frequency: float,
        n_ele: int = 360,
        azimuth_deg: float = 0,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
    ):
        """
        Plot the interpolated response as a function of the elevation angle at a given frequency

        :param _type_ frequency: Frequency to plot
        :param int n_ele: number of elevation angles, defaults to 360
        :param float azimuth_deg: choose the azimuth angle for the plot, defaults to 0
        :param FrScaling scaling: scaling, defaults to FrScaling.on_axis_normalized
        """
        ff_plot.plot_interpolated_elevation_response(
            self, frequency=frequency, n_ele=n_ele, azimuth_deg=azimuth_deg, scaling=scaling
        )

    def plot_directivity_balloon(
        self,
        selected_frequency: int,
        scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
        plot_amplitude_scaling_factor: float = 10,
    ):
        """
        Plot the directivity response on a sphere at the given frequency

        :param int selected_frequency: frequency to plot
        :param FrScaling scaling: scaling, defaults to FrScaling.on_axis_normalized
        :param int plot_amplitude_scaling_factor: scaling factor for the deformation of the plot, defaults to 10
        """
        ff_plot.plot_sphere(self, selected_frequency, scaling, plot_amplitude_scaling_factor)

    def plot_mono_dipole_sphere(self, frequency: float, plot_amplitude_scaling_factor=10):
        """
        Plot the mono dipole sphere response at the given frequency

        :param _type_ frequency: selected frequency to plot
        :param int plot_amplitude_scaling_factor: scaling factor for the deformation of the plot, defaults to 10
        """
        ff_plot.plot_mono_dipole_sphere(self, frequency, plot_amplitude_scaling_factor)

    def _fit_mono_dipole(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Helper method to fit the mono-diple model to the top pole response

        :return _type_: The frequency vector, the mono_dipole coefficients and the top pole response
        """
        f_third_octave, fr_third_octave, _, _ = self.interpolate_directivity_balloon_third_octave()

        azimuths = np.arange(0, 2 * np.pi, 2 * np.pi / 72)
        colatitudes = np.linspace(0, np.pi, 37)

        mono_dipole_fit = fit_mono_dipole(
            target_fr=fr_third_octave,
            azimuth_rad=azimuths,
            colatitude_rad=colatitudes,
            f_third_octaves=f_third_octave,
        )
        mono_dipole_coefficients = np.column_stack(
            (mono_dipole_fit[0], mono_dipole_fit[1])
        )
        mono_dipole_toppole_third_octave = mono_dipole_fit[2]
        return f_third_octave, mono_dipole_coefficients, mono_dipole_toppole_third_octave
