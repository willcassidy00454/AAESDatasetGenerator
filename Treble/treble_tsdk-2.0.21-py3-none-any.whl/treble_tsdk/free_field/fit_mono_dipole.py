import numpy as np
from mystic import scipy_optimize


def fit_mono_dipole(
    target_fr: np.ndarray, azimuth_rad: np.ndarray, colatitude_rad: np.ndarray, f_third_octaves
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    """
    We create coefficients for a mono-dipole type directivity.

    :return: Mono coefficient array, Dipole coefficient array, resulting directivity, maximum acceptable frequency
    :rtype: tuple[np.ndarray, np.ndarray, np.ndarray, int]
    """
    elevation_rad = np.pi / 2 - colatitude_rad
    elevation_mesh, phi_mesh = np.meshgrid(elevation_rad, azimuth_rad)

    # Convert spherical coordinates to Cartesian
    x_coordinate = np.cos(elevation_mesh) * np.cos(phi_mesh)
    y_coordinate = np.cos(elevation_mesh) * np.sin(phi_mesh)
    z_coordinate = np.sin(elevation_mesh)

    target_directivity = np.abs(target_fr)

    # Computer weighting sampling areas
    del_azimuth = azimuth_rad[4] - azimuth_rad[3]
    del_colatitude = colatitude_rad[4] - colatitude_rad[3]
    sample_areas = np.tile(2 * del_azimuth * np.sin(colatitude_rad) * np.sin(del_colatitude / 2), [72, 1])
    sample_areas[:, 0] = 4 * np.pi / len(azimuth_rad) * (np.sin(del_colatitude / 4)) ** 2
    sample_areas[:, -1] = 4 * np.pi / len(azimuth_rad) * (np.sin(del_colatitude / 4)) ** 2

    # Initialize coefficients to optimize and helper arrays
    coeff1 = np.zeros_like(f_third_octaves, dtype=float)
    coeff2 = np.zeros_like(f_third_octaves, dtype=float)
    result_awd = np.zeros_like(f_third_octaves, dtype=float)
    f_max = 0
    unity_array = np.ones_like(x_coordinate)
    coordinates = np.array([x_coordinate.ravel(), y_coordinate.ravel(), z_coordinate.ravel()])
    n_s = np.array(
        [
            np.ones((72, 37)).ravel(),
            np.zeros((72, 37)).ravel(),
            np.zeros((72, 37)).ravel(),
        ]
    )
    gamma = np.arccos(np.sum(n_s.conj() * coordinates, axis=0).reshape(72, 37))
    achieved_directivity = np.zeros_like(target_directivity)

    # Go through each band and compute the coefficients
    for i_freq in range(len(f_third_octaves)):
        target = target_directivity[i_freq, :, :]

        scale = np.max(np.abs(target))
        target = target / scale
        result = scipy_optimize.fmin(
            # result = opt.minimize(
            cost=_mono_dipole_error_func,
            x0=np.array([0.5, 0.5]),
            args=(target, sample_areas, gamma, unity_array),
            disp=False,
            full_output=True,
        )

        coeff1[i_freq] = result[0][0]
        coeff2[i_freq] = result[0][1]

        result_awd[i_freq] = result[1]

        if result_awd[i_freq] > 3 and f_max == 0:
            f_max = f_third_octaves[i_freq]

        di = np.cos(gamma)
        cardioid = coeff1[i_freq] * unity_array + coeff2[i_freq] * di
        achieved_directivity[i_freq, :, :] = np.abs(cardioid) / np.abs(cardioid[0, :])

    return coeff1, coeff2, achieved_directivity, f_max


def _mono_dipole_error_func(
    coefficients: np.ndarray,
    target: np.ndarray,
    sample_areas: np.ndarray,
    gamma: np.ndarray,
    unity_array: np.ndarray,
) -> float:
    """
    Error function computing the Area Weighted Error over a sphere for fitting mono-dipole coefficients
    to a directivity pattern.

    :param coefficients: coefficients omni/dipole
    :type coefficients: np.ndarray
    :param target: Directivity data from CLF file
    :type target: np.ndarray
    :param sample_areas: Area weighted coefficients
    :type sample_areas: np.ndarray
    :param gamma: Array of angles
    :type gamma: np.ndarray
    :param unity_array: Helper parameter to avoid re-initializing
    :type unity_array: np.ndarray
    :return: Area weighted error
    :rtype: float
    """
    mono_weight = coefficients[0]
    dipole_weight = coefficients[1]  # 1 - mono_weight  # input[1]

    di = np.cos(gamma)
    cardioid = mono_weight * unity_array + dipole_weight * di
    cardioid_l = 20 * np.log10(np.abs(cardioid) / np.abs(cardioid[0, :]))
    target_l = 20 * np.log10(np.abs(target) / np.abs(target[0, :]))

    # Calculate the squared difference element-wise
    squared_difference = sample_areas * (target_l - cardioid_l) ** 2

    # Calculate and return the square root of the sum
    return np.sqrt(np.sum(squared_difference) / np.sum(sample_areas))
