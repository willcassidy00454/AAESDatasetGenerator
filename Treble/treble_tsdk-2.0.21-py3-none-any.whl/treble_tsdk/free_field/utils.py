from pathlib import Path
from enum import Enum
import numpy as np
import pyvista as pv

from ..treble_logging import logger
from ..core.model_obj import ModelObj
from ..geometry.mesh_collection import MeshCollection

DEFAULT_THIRD_OCTAVE_BANDS = np.array(
    [
        25,
        32,
        40,
        50,
        63,
        80,
        100,
        125,
        160,
        200,
        250,
        315,
        400,
        500,
        630,
        800,
        1000,
        1250,
        1600,
        2000,
        2500,
        3150,
        4000,
        5000,
        6300,
        8000,
        10000,
    ]
)


class FrScaling(Enum):
    """Enumerator to define the scaling of the frequency response"""

    velocity = "velocity"
    volume_velocity = "volume_velocity"
    acceleration = "acceleration"
    volume_acceleration = "volume_acceleration"
    on_axis_normalized = "on_axis_normalized"

    def is_volume_normalized(self) -> bool:
        return "volume" in self.value

    def is_acceleration(self) -> bool:
        return "acceleration" in self.value

    def get_ylabel(self) -> str:
        if self == self.volume_acceleration:
            return "Magnitude [dB Pa/(m^3/s^2)]"
        elif self == self.acceleration:
            return "Magnitude [dB Pa/(m/s^2)]"
        if self == self.volume_velocity:
            return "Magnitude [dB Pa/(m^3/s)]"
        elif self == self.velocity:
            return "Magnitude [dB Pa/(m/s)]"


def create_freefield_model_geometry(
    device_geometry: ModelObj | MeshCollection,
    sphere_geometry_radius: float = 3,
    upper_frequency: float = 8000,
) -> MeshCollection:
    if isinstance(device_geometry, MeshCollection):
        input_geometry = device_geometry
    elif isinstance(device_geometry, ModelObj):
        if device_geometry._has_valid_local_file(True):
            input_geometry = MeshCollection.load_3dm(device_geometry._model_file_path)
        else:
            logger.error("Unable to load model from model object!")
            return None
    elif isinstance(device_geometry, str):
        if not Path(device_geometry).exists():
            logger.error("Model file does not exist")
            return None
        if Path(device_geometry).suffix != ".3dm":
            logger.error("Model file must be a 3dm file")
            return None
        input_geometry = MeshCollection.load_3dm(model_input)
    # if _check_input(input_geometry) == False: Check in simulation creation.
    #    # TODO: Add log.
    #    return None

    sphere_geo = create_sphere_geometry(sphere_geometry_radius, upper_frequency)
    return MeshCollection.join_mesh_collections([input_geometry, sphere_geo])


def create_sphere_geometry(
    exterior_radius: float = 3, upper_frequency: float = 8000, layer_name: str = "exterior"
) -> MeshCollection:
    """
    Creates a sphere geometry.

    :param float exterior_radius: The radius of the sphere, defaults to 3m
    :param float upper_frequency: Upper frequency for the simulation, defaults to 8000Hz.
    :param str layer_name: The name of the layer containing the sphere, defaults to "exterior".
    :return MeshCollection: _description_
    """
    len_pr_element = 0.3 / upper_frequency * 710
    n_points = int(4 * np.pi * exterior_radius / (len_pr_element**2))
    sphere_mesh = pv.PolyData(fibonacci_sphere(min(n_points, 10000)) * exterior_radius).delaunay_3d()
    sphere_mesh.cell_data["layer_index"] = 0
    sphere_mesh.cell_data["object_index"] = sphere_mesh.cell_data["layer_index"]
    return MeshCollection(sphere_mesh, [layer_name])


def fibonacci_sphere(num_points: int) -> np.ndarray:
    """
    Creates a fibonacci sphere of points in 3d space

    :param int num_points: Number of points to generate
    :return np.ndarray: the Locations of the points on a sphere
    """
    phi = (1 + np.sqrt(5)) / 2
    indices = np.arange(0, num_points)
    z = 1 - (2 * indices) / (num_points - 1)
    radius = np.sqrt(1 - z**2)
    theta = 2 * np.pi * indices / phi
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)
    return np.column_stack((x, y, z))


def azi_ele_to_cart(azimuth: float, elevation: float) -> np.ndarray:
    """
    Converts azimuth and elevation to cartesian coordinates

    :param float azimuth: Azimuth angle in radians
    :param float elevation: Elevation angle in radians
    :return np.ndarray: Unit vector in cartesian coordinates
    """
    return np.array(
        [np.cos(azimuth) * np.cos(elevation), np.sin(azimuth) * np.cos(elevation), np.sin(elevation)]
    )


def azi_colat_to_cart(azimuth: float, colatitude: float) -> np.ndarray:
    """
    Converts azimuth and colatitude to cartesian coordinates

    :param float azimuth: Azimuth angle in radians
    :param float colatitude: Colatitude angle in radians
    :return np.ndarray: Unit vector in cartesian coordinates
    """
    return np.array(
        [np.cos(azimuth) * np.sin(colatitude), np.sin(azimuth) * np.sin(colatitude), np.cos(colatitude)]
    )


def generate_azi_colat_points(azimuths: np.ndarray, colatitudes: np.ndarray, radius: float) -> np.ndarray:
    """
    Generates points on a sphere given azimuth and colatitude angles

    :param np.ndarray azimuths: An array of azimuth angles in radians
    :param np.ndarray colatitudes: An array of colatitude angles in radians
    :param float radius: Radius of the sphere
    :return np.ndarray: Array of points on the sphere [n_points, 3]
    """
    points = np.zeros((len(azimuths) * len(colatitudes), 3))
    for i_azi, azi in enumerate(azimuths):
        for i_colat, colat in enumerate(colatitudes):
            points[i_colat * len(azimuths) + i_azi] = azi_colat_to_cart(azi, colat) * radius
    return points


def _get_active_active_band_indices(f: np.ndarray, crossover: int = None) -> list:
    """
    Gets the indices of the active third octave bands

    :param np.ndarray f: Linear spaced frequency vector of the active frequency responses
    :param int crossover: Crossover frequency, defaults to None
    :return list: The active third octave bands
    """
    if crossover == None:
        crossover = max(f)

    third_octave_bands = DEFAULT_THIRD_OCTAVE_BANDS
    third_octave_bands_lower = np.array(np.round(third_octave_bands / 2 ** (1 / 6)), np.int64)
    third_octave_bands_upper = np.array(np.round(third_octave_bands * 2 ** (1 / 6)), np.int64)

    third_octave_indices = []
    for i_band, f_center in enumerate(third_octave_bands):
        f_lower = third_octave_bands_lower[i_band]
        f_upper = third_octave_bands_upper[i_band]
        if f_lower > crossover:
            break
        i_lower = np.abs(f - f_lower).argmin()
        i_upper = np.abs(f - f_upper).argmin() + 1
        third_octave_indices.append((f_center, i_lower, i_upper))

    return third_octave_indices


def third_octave_average_frs(
    f: np.ndarray,
    frs: np.ndarray,
    crossover_frequency: float = None,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Third octave averages the frequency responses

    :param np.ndarray f: Frequency vector of the frequency responses
    :param np.ndarray frs: Frequency responses functions of the system
    :param float crossover_frequency: Crossover frequency, defaults to None
    :return tuple[np.ndarray, np.ndarray]: The third octave centers and the third octave averaged frequency responses
    """
    third_octave_band_indices = _get_active_active_band_indices(f, crossover_frequency)

    third_oct_frs = []
    third_oct_centers = []
    for f_center, i_l, i_u in third_octave_band_indices:
        fr_range = frs[:, i_l:i_u]
        mean_mag = np.abs(fr_range).mean(axis=1)
        mean_phase = np.unwrap(np.angle(fr_range), axis=1).mean(axis=1)
        third_oct_frs.append(mean_mag * np.exp(1j * mean_phase))
        third_oct_centers.append(f_center)

    return np.array(third_oct_centers), np.array(third_oct_frs).T


def map_toppole_to_pyvista_sphere(data: np.ndarray) -> pv.PolyData:
    """
    maps the toppole data to a pyvista sphere for easy visualization

    :param np.ndarray data: The complex data to be mapped to the sphere. assumed to be [n_freqs,n_azi,n_colat]
    :return pv.PolyData: The sphere with the data mapped to it as point data "data_real" and "data_imag"
    """
    sphere = pv.Sphere(radius=1, theta_resolution=data.shape[1], phi_resolution=data.shape[2])
    azi = np.arange(data.shape[1]) / data.shape[1] * (2 * np.pi)
    colat = np.linspace(0, np.pi, data.shape[2])
    sphere.point_data["data_real"] = np.zeros((sphere.n_points, data.shape[0]))
    sphere.point_data["data_imag"] = np.zeros((sphere.n_points, data.shape[0]))

    for i_azi, azi_angle in enumerate(azi):
        for i_colat, colat_angle in enumerate(colat):
            point = azi_colat_to_cart(azi_angle, colat_angle)
            closest_point = sphere.find_closest_point(point)
            sphere.point_data["data_real"][closest_point] = np.real(data[:, i_azi, i_colat])
            sphere.point_data["data_imag"][closest_point] = np.imag(data[:, i_azi, i_colat])

    return sphere


def pad_freqs_third_octave_top_pole_response(
    f_third_octaves: np.ndarray, data: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Extrapolates the top pole data in third octave bands by extending the lowest and highest frequnency to the extends of the default

    :param np.ndarray f_third_octaves: _description_
    :param np.ndarray data: _description_
    :return tuple[np.ndarray, np.ndarray]: _description_
    """
    data_out = np.zeros((len(DEFAULT_THIRD_OCTAVE_BANDS), data.shape[1], data.shape[2]), dtype=np.complex128)
    low_frequency_missing = True
    for i, f in enumerate(DEFAULT_THIRD_OCTAVE_BANDS):
        if f in f_third_octaves:
            data_out[i] = data[np.where(f_third_octaves == f)[0][0]]
            low_frequency_missing = False
        else:
            if low_frequency_missing:
                data_out[i] = data[0]
            else:
                data_out[i] = data[-1]

    return DEFAULT_THIRD_OCTAVE_BANDS, data_out
