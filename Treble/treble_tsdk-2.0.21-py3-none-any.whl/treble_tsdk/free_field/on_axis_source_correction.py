import numpy as np

from .boundary_velocity_source_correction import get_hplp_filter


def trim_filter_ir(
    ir: np.ndarray, headroom=80, window_width=256, min_half_length=1024
) -> tuple[np.ndarray, int]:
    """
    Helper function to trim the IIR filter to a reasonable length

    :param np.ndarray ir: impulse response of the filter centered at the middle of the signal
    :param int headroom: headroom requested in dB, defaults to 80
    :param int window_width: width of the window applied when trimming, defaults to 256
    :param int min_half_length: minimum half length of the filter, defaults to 1024
    :return tuple[np.ndarray, int]: filter and center sample
    """
    half_filter_length = len(ir) // 2
    ir_log = 20 * np.log10(np.abs(ir + 1e-18))
    ir_log_max = np.max(ir_log)
    cutoff = ir_log_max - headroom
    lower_cutoff = np.nonzero(ir_log > cutoff)[0][0]
    upper_cutoff = np.nonzero(ir_log > cutoff)[0][-1]
    target_filter_half_width = max(
        [half_filter_length - lower_cutoff, upper_cutoff - half_filter_length, min_half_length]
    )

    ir_trimmed = ir[
        half_filter_length - target_filter_half_width : half_filter_length + target_filter_half_width
    ]
    ir_trimmed[0:window_width] *= np.hanning(2 * window_width)[0:window_width]
    ir_trimmed[-window_width:] *= np.hanning(2 * window_width)[window_width:]
    return ir_trimmed, target_filter_half_width


def compute_on_axis_correction_filter(
    frequency_vector: np.ndarray,
    on_axis_velocity_fr: np.ndarray,
    crossover_frequency: float,
    sphere_radius: float,
    wave_speed: float = 343,
    sampling_rate: int = 32000,
) -> tuple[np.ndarray, int]:
    """
    Compute the IIR filter to do on axis source correction given a frequency response of the axis velocity

    :param np.ndarray frequency_vector: frequency vector
    :param np.ndarray on_axis_velocity_fr: on axis frequency response that has already been corrected to velocity
    :param float crossover_frequency: crossover frequency
    :param float receiver_distance: the receivers distance from the origin in the free field simulation
    :param float wave_speed: speed of sound, defaults to 343
    :param int fs: sampling frequency, defaults to 32000
    :return tuple[np.ndarray, int]: the custom source correction filter and the center sample
    """

    def delay_fr_distance(
        fr: np.ndarray, distance: float, wave_speed: float, frequency_vector: np.ndarray
    ) -> np.ndarray:
        """Adds a delay to the frequency response corresponding to a given distance of propagation"""
        return fr * np.exp(-1j * 2 * np.pi * frequency_vector / wave_speed * distance)

    # Sets up a target response, which is the default high pass low pass filter shape, but with a delay corresponding to the propagation distance in the free field simulation (assuming that the acoustical center is at the origin of the source)
    target_response = get_hplp_filter(lp_freq=crossover_frequency)[1]
    target_response = delay_fr_distance(
        fr=target_response,
        distance=sphere_radius,
        wave_speed=wave_speed,
        frequency_vector=frequency_vector,
    )

    # The filter is then created by dividing the target response with the on axis velocity frequency response, but only in the valid frequency range
    valid_min_frequency = 20
    min_ind = np.argmin(np.abs(frequency_vector - valid_min_frequency))
    max_ind = np.argmin(np.abs(frequency_vector - crossover_frequency))
    filter_fr = np.zeros_like(target_response)
    filter_fr[min_ind:max_ind] = target_response[min_ind:max_ind] / on_axis_velocity_fr[min_ind:max_ind]

    def dampen_curve(fr: np.ndarray, max_ind: int, damping_factor: float) -> np.ndarray:
        """Extend the frequency response curve with by applying damping to the slope of the curve"""
        i = max_ind
        while i < len(fr) - 1:
            slope = fr[i] - fr[i - 1]
            fr[i + 1] = fr[i] + slope * np.exp(-damping_factor)
            i += 1
        return fr

    # The rest of the curve has to be regularized to avoid high and low frequency artifacts
    dampened_filter = dampen_curve(filter_fr, max_ind - 1, 0.005)
    dampened_filter = np.flip(dampen_curve(np.flip(dampened_filter), len(dampened_filter) - min_ind - 1, 0.5))
    sc_filter_fr = dampened_filter  # * get_hplp_filter(lp_freq=15000, lp_order=1, hp_order=1, hp_freq=5)[1]

    # The filter is then transformed to the time domain and trimmed to a reasonable length
    source_correction_ir_long = np.roll(np.fft.irfft(sc_filter_fr) * sampling_rate, sampling_rate // 2)
    source_correction_ir, filter_half_length = trim_filter_ir(source_correction_ir_long)
    return source_correction_ir, filter_half_length
