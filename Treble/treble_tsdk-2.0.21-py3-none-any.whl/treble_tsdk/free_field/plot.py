from typing import TYPE_CHECKING

from . import utils as ff_utils

import matplotlib.pyplot as plt
import pyvista as pv
import numpy as np

if TYPE_CHECKING:
    from .results import FreeFieldResults


def plot_on_axis_fr(
    results: "FreeFieldResults", scaling: ff_utils.FrScaling = ff_utils.FrScaling.volume_velocity
):
    """
    Plot the on-axis frequency response

    :param FrScaling scaling: Scaling, defaults to FrScaling.volume_velocity
    """
    f, fr = results.on_axis_fr(scaling)
    mag_db = 20 * np.log10(np.abs(fr) + 1e-12)
    phase = np.angle(fr)

    fig, axs = plt.subplots(2, 1, figsize=(10, 10))
    axs[0].plot(f, mag_db)
    axs[0].set_title("Magnitude response")
    axs[0].set_ylabel(scaling.get_ylabel())
    axs[0].set_xscale("log")
    axs[0].set_xlim([f[0], f[-1]])
    axs[0].set_ylim([min(mag_db) - 6, max(mag_db) + 6])
    axs[0].grid()

    axs[1].plot(f, phase)
    axs[1].set_title("Phase response")
    axs[1].set_ylabel("phase [rad]")
    axs[1].set_xscale("log")
    axs[1].set_xlim([f[0], f[-1]])
    axs[1].set_ylim([-np.pi, np.pi])
    axs[1].grid()
    fig.suptitle(f"On-axis response - {results._simulation.name}")
    plt.show()


def plot_source_center_fr(
    results: "FreeFieldResults", scaling: ff_utils.FrScaling = ff_utils.FrScaling.volume_velocity
):
    """
    Plot the source center frequency response

    :param FrScaling scaling: Scaling, defaults to FrScaling.volume_velocity
    """
    f, fr = results.source_center_fr(scaling)
    mag_db = 20 * np.log10(np.abs(fr) + 1e-12)
    phase = np.angle(fr)

    fig, axs = plt.subplots(2, 1, figsize=(10, 10))
    axs[0].plot(f, mag_db)
    axs[0].set_title("Magnitude response")
    axs[0].set_ylabel(scaling.get_ylabel())
    axs[0].set_xscale("log")
    axs[0].set_xlim([f[0], f[-1]])
    axs[0].set_ylim([min(mag_db) - 6, max(mag_db) + 6])
    axs[0].grid()

    axs[1].plot(f, phase)
    axs[1].set_title("Phase response")
    axs[1].set_ylabel("phase [rad]")
    axs[1].set_xscale("log")
    axs[1].set_xlim([f[0], f[-1]])
    axs[1].set_ylim([-np.pi, np.pi])
    axs[1].grid()
    fig.suptitle(f"Source center response - {results._simulation.name}")
    plt.show()


def plot_interpolated_fr(
    results: "FreeFieldResults",
    azimuth_deg: float,
    elevation_deg: float,
    scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
):
    """
    Plot the interpolated frequency response at the given azimuth and elevation

    :param float azimuth_deg: Azimuth angle in degrees
    :param float elevation_deg: Elevation angle in degrees
    :param FrScaling scaling: Scaling, defaults to FrScaling.on_axis_normalized
    """
    f, fr = results.interpolate_fr(azimuth_deg=azimuth_deg, elevation_deg=elevation_deg, scaling=scaling)

    mag_db = 20 * np.log10(np.abs(fr) + 1e-12)
    phase = np.angle(fr)
    fig, axs = plt.subplots(2, 1, figsize=(10, 10))

    axs[0].plot(f, mag_db)
    axs[0].set_title("Magnitude response")
    axs[0].set_ylabel(scaling.get_ylabel())
    axs[0].set_xscale("log")
    axs[0].set_xlim([20, results._simulation.crossover_frequency])
    axs[0].set_ylim([min(mag_db) - 6, max(mag_db) + 6])
    axs[0].grid()

    axs[1].plot(f, phase)
    axs[1].set_title("Phase response")
    axs[1].set_ylabel("phase [rad]")
    axs[1].set_xscale("log")
    axs[1].set_xlim([20, results._simulation.crossover_frequency])
    axs[1].set_ylim([-np.pi, np.pi])
    axs[1].grid()
    fig.suptitle(
        f"Response Azi={azimuth_deg:.2f} deg, Ele={elevation_deg:.2f} deg   - {results._simulation.name}"
    )
    plt.show()


def plot_interpolated_azimuth_response(
    results,
    frequency,
    n_azi: int = 360,
    elevation_deg: float = 0,
    scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
):
    """
    Plot the interpolated azimuth response

    :param _type_ frequency: Frequency to plot
    :param int n_azi: Number of azimuth points, defaults to 360
    :param float elevation_deg: The elevation angle, defaults to 0
    :param FrScaling scaling: Scaling, defaults to FrScaling.on_axis_normalized
    """
    if frequency < 20 or frequency > results._simulation.crossover_frequency:
        raise ValueError(
            f"Frequency must be between 20 and crossover frequency ({results._simulation.crossover_frequency})"
        )
    elevation = elevation_deg * np.pi / 180
    azimuths, f, responses = results.interpolate_polar_azimuth(
        n_azi=n_azi, elevation_deg=elevation, scaling=scaling
    )
    f_ind = np.argmin(np.abs(f - frequency))
    mag_db = 20 * np.log10(np.abs(responses[:, f_ind]) + 1e-12)

    max_val = np.max(mag_db)
    min_val = np.min(mag_db)
    plt.figure()
    ax = plt.subplot(projection="polar")  # Set polar projection
    ax.set_title(f"Azimuth response ({f[f_ind]:.2f} Hz) - elevation={elevation_deg} deg")
    ax.set_ylabel(scaling.get_ylabel())
    ax.set_xlabel("Azimuth [deg]")
    ax.plot(azimuths / 180 * np.pi, mag_db)
    ax.set_ylim([min_val - 6, max_val + 6])
    plt.show()


def plot_interpolated_elevation_response(
    results,
    frequency,
    n_ele: int = 360,
    azimuth_deg: float = 0,
    scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
):
    """
    Plot the interpolated elevation response

    :param _type_ frequency: Frequency to plot
    :param int n_ele: number of elevation angles, defaults to 360
    :param float azimuth_deg: choose the azimuth angle for the plot, defaults to 0
    :param FrScaling scaling: scaling, defaults to FrScaling.on_axis_normalized
    """
    if frequency < 20 or frequency > results._simulation.crossover_frequency:
        raise ValueError("Frequency must be between 20 and crossover frequency")
    azimuth = azimuth_deg * np.pi / 180
    (
        elevations,
        f,
        responses,
    ) = results.interpolate_polar_elevation(n_ele=n_ele, azimuth_deg=azimuth, scaling=scaling)
    f_ind = np.argmin(np.abs(f - frequency))
    mag_db = 20 * np.log10(np.abs(responses[:, f_ind]) + 1e-12)

    max_val = np.max(mag_db)
    min_val = np.min(mag_db)
    plt.figure()
    ax = plt.subplot(projection="polar")  # Set polar projection
    ax.set_title(f"Elevation response({f[f_ind]:.2f} Hz) - azimuth={azimuth_deg} deg")
    ax.set_ylabel(scaling.get_ylabel())
    ax.set_xlabel("Elevation [deg]")
    ax.plot(elevations / 180 * np.pi, mag_db)
    ax.set_ylim([min_val - 6, max_val + 6])
    plt.show()


def plot_sphere(
    results,
    selected_frequency: int,
    scaling: ff_utils.FrScaling = ff_utils.FrScaling.on_axis_normalized,
    plot_amplitude_scaling_factor: float = 10,
):
    """Plot the directivity response on a sphere at the given frequency

    :param int selected_frequency: frequency to plot
    :param FrScaling scaling: scaling, defaults to FrScaling.on_axis_normalized
    :param int plot_amplitude_scaling_factor: scaling factor for the deformation of the plot, defaults to 10
    """
    sphere = results._sphere_interpolator._sphere.copy()
    _, f, sphere_frs = results.sphere_points_fr(scaling=scaling)

    selected_freq_index = np.argmin(np.abs(f - selected_frequency))

    sphere.point_data["pressure [dB]"] = 20 * np.log10(np.abs(sphere_frs[:, selected_freq_index]) + 1e-12)

    point_scaling = sphere.point_data["pressure [dB]"] + plot_amplitude_scaling_factor
    point_scaling[point_scaling < plot_amplitude_scaling_factor / 10] = plot_amplitude_scaling_factor / 10

    sphere.points *= (point_scaling / plot_amplitude_scaling_factor)[:, np.newaxis]

    pl = pv.Plotter()
    exterior_layer_index = results._ff_model_mesh_collection.layer_names.index("exterior")
    pl.add_mesh(
        results._ff_model_mesh_collection.mesh.extract_cells(
            results._ff_model_mesh_collection.mesh.cell_data["layer_index"] == exterior_layer_index,
            invert=True,
        ),
        show_scalar_bar=False,
    )

    pressure_mesh = pl.add_mesh(
        sphere,
        scalars="pressure [dB]",
        opacity=0.8,
        cmap="viridis",
    )

    f = lambda val: pressure_mesh.GetProperty().SetOpacity(val)
    pl.add_slider_widget(f, [0.0, 1.0], title="Opacity", pointa=(0.1, 0.1), pointb=(0.3, 0.1))
    pl.show()


def plot_mono_dipole_sphere(results, frequency, plot_amplitude_scaling_factor=10):
    """Plot the mono dipole sphere response at the given frequency

    :param _type_ frequency: selected frequency to plot
    :param int plot_amplitude_scaling_factor: scaling factor for the deformation of the plot, defaults to 10
    """
    f_third_octave, _, mono_dipole_toppole_azi_ele_third_octave = results._fit_mono_dipole()
    azimuths = np.arange(0, 2 * np.pi, 2 * np.pi / 72)
    colatitudes = np.linspace(0, np.pi, 37)
    selected_freq_index = np.argmin(np.abs(f_third_octave - frequency))
    sphere = pv.PolyData(ff_utils.generate_azi_colat_points(azimuths, colatitudes, 1))
    sphere.point_data["pressure [dB]"] = 20 * np.log10(
        np.abs(mono_dipole_toppole_azi_ele_third_octave[selected_freq_index].T.flatten())
    )
    sphere = sphere.delaunay_3d()

    point_scaling = sphere.point_data["pressure [dB]"] + plot_amplitude_scaling_factor
    point_scaling[point_scaling < plot_amplitude_scaling_factor / 10] = plot_amplitude_scaling_factor / 10

    sphere.points *= (point_scaling / plot_amplitude_scaling_factor)[:, np.newaxis]

    pl = pv.Plotter()
    exterior_layer_index = results._ff_model_mesh_collection.layer_names.index("exterior")
    pl.add_mesh(
        results._ff_model_mesh_collection.mesh.extract_cells(
            results._ff_model_mesh_collection.mesh.cell_data["layer_index"] == exterior_layer_index,
            invert=True,
        ),
        show_scalar_bar=False,
    )

    pressure_mesh = pl.add_mesh(
        sphere,
        scalars="pressure [dB]",
        opacity=0.8,
        cmap="viridis",
    )

    f = lambda val: pressure_mesh.GetProperty().SetOpacity(val)
    pl.add_slider_widget(f, [0.0, 1.0], title="Opacity", pointa=(0.1, 0.1), pointb=(0.3, 0.1))
    pl.show()
