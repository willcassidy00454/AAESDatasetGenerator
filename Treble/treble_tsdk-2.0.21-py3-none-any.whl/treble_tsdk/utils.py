import concurrent.futures
import functools
import gzip
import hashlib
import importlib
import math
import re
import time
from enum import Enum
from functools import lru_cache, update_wrapper
from os import environ
from pathlib import Path
from queue import Queue
from typing import Any, Callable
from zipfile import ZipFile

import httpx

from .treble_logging import logger

# Once download_files is used this will be come a Queue object that contains
# a <max_number> of httpx.Client objects that can be reused by download worker threads.
_session_queue = None

_label_check_regex = re.compile("[ \\w-]{1,255}")


def is_valid_label(label_str: str) -> bool:
    """
    Check if a string is a valid label.
    """
    return _label_check_regex.fullmatch(label_str) is not None


def _repr_trim_str(data: str, max_len=50) -> str:
    """
    Trims string representation to max_len.
    """
    if data is None or len(data) <= max_len:
        return repr(data)
    else:
        return repr(data[:max_len] + ", ...")


def _repr_trim_lst(data: list, max_len=5) -> str:
    """
    Trims list representation to max_len.
    """
    if data is None or len(data) <= max_len:
        return repr(data)
    else:
        return f"[{', '.join(map(repr, data[:max_len]))}...]"


def try_load_treble_module(module_name: str):
    """
    Try to load a module by name.
    """
    if not module_name.startswith("treble_tsdk."):
        module_name = "treble_tsdk." + module_name
    try:
        return importlib.import_module(module_name)
    except ImportError as e:
        logger.debug(e)
        logger.error(f"Unable to find required module '{module_name}', has it been installed ?")
        return None


def clean_label_str(s: str, default: str = "default") -> str:
    # Remove invalid characters
    valid_chars = re.findall(r"[\w-]", s)
    valid_str = "".join(valid_chars)

    # Ensure length constraint (1 to 255 characters)
    if not valid_str:
        valid_str = default  # Fallback if the input was completely invalid
    elif len(valid_str) > 255:
        valid_str = valid_str[:255]

    return valid_str


class FreezableDict(dict):
    """
    A dictionary that can be frozen to prevent modifications.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._frozen = False

    def _freeze(self):
        """
        Make the object immutable.
        """
        self._frozen = True

    def _deep_freeze(self):
        """
        Make the object and all nested FreezableDict objects immutable.
        """
        self._freeze()
        for value in self.values():
            if isinstance(value, FreezableDict):
                value._deep_freeze()

    def _thaw(self):
        """
        Make the object mutable.
        """
        self._frozen = False

    def _deep_thaw(self):
        """
        Make the object and all nested FreezableDict objects mutable.
        """
        self._thaw()
        for value in self.values():
            if isinstance(value, FreezableDict):
                value._deep_thaw()

    def _freeze_check(self):
        """
        Perform a check to see if the object is frozen.
        :raises TypeError: If the object is Imutable.
        """
        if self._frozen:
            raise TypeError("Object is immutable and cannot be modified.")

    def __setitem__(self, key, value):
        """
        :raises TypeError: If the object is immutable.
        """
        if self._frozen:
            raise TypeError("Object is immutable and cannot be modified.")
        super().__setitem__(key, value)


# Custom decorator to label a function as 'beta'
def beta_feature(message=None):
    def decorator(func):
        func._first_call = True

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if func._first_call:
                if message:
                    logger.warning(message)
                else:
                    logger.warning(f"'{func.__name__}' is a beta feature. Please use caution while using it.")
                func._first_call = False  # Ensure this message shows only once
            return func(*args, **kwargs)

        return wrapper

    return decorator


# Custom decorator to label a function as 'deprecated'
def deprecated(message=None):
    def decorator(func):
        func._first_call = True

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if func._first_call:
                if message:
                    logger.warning(message)
                else:
                    logger.warning(
                        f"'{func.__name__}' is a deprecated and may be removed in future versions of the SDK."
                    )
                func._first_call = False  # Ensure this message shows only once
            return func(*args, **kwargs)

        return wrapper

    return decorator


def get_env_var_as_string(name: str, default: str = None) -> str:
    """
    Get environment variable, searches both string and byte representation
    of variable name.
    """
    val = environ.get(name, None)
    if val is None:
        try:
            val = environ.get(name.encode("utf-8"), None)
            if val is None:
                val = default
            else:
                val = val.decode("utf-8")
        except TypeError:
            val = default
    return val


def decompress_file(filepath: str, work_dir: str, remove_original: bool = True):
    """
    Decompress a zip archive or a gzip compressed file.

    :param filePath: File to decompress
    :param workDir: Directory to extract archive to.
    :param removeOriginal: If true the original file will be removed.
    """
    logger.debug(f"Decompress file {filepath}")
    filepath = Path(filepath)
    if not filepath.is_file():
        logger.warning(f"{filepath} not found!")
        return
    elif filepath.suffix.lower() == ".zip":
        Path(work_dir).mkdir(exist_ok=True, parents=True)
        with ZipFile(str(filepath), "r") as zipObj:
            zipObj.extractall(path=work_dir)
        if remove_original:
            filepath.unlink()
    elif filepath.suffix.lower() == ".gz":
        with gzip.open(str(filepath), "rb") as f:
            with open(str(Path.joinpath(filepath.parent, filepath.stem)), "wb") as out:
                out.write(f.read())
        if remove_original:
            filepath.unlink()
    else:
        logger.info(f"Unknown file extension, will not decompress file {filepath}")
    logger.debug("Mesh file decompression finished")


class ProgressOutputMode(str, Enum):
    NO_OUTPUT = "no_output"
    LOGGING_OUTPUT = "logging_output"
    TQDM_OUTPUT = "tqdm_output"  # Requires tqdm package


def try_load_tqdm(
    output_mode: ProgressOutputMode, fallback_mode: ProgressOutputMode = ProgressOutputMode.LOGGING_OUTPUT
) -> tuple[ProgressOutputMode, Any]:
    """
    If output_mode is set to TQDM_OUTPUT, try to load tqdm package.
    :param ProgressOutputMode output_mode: Current output_mode.
    :returns: A tuple of the output_mode and the loaded tqdm module if successful. If Tqdm was not loaded successfully it falls back to fallback mode.
    """
    tqdm = None
    if output_mode == ProgressOutputMode.TQDM_OUTPUT:
        # TQDM is an optional dependency. Try to import it and if it fails fall back to 'print_output'.
        try:
            tqdm = importlib.import_module("tqdm.auto")
        except ImportError:
            logger.warning(f"Unable to load tqdm package. Falling back to {fallback_mode.name} output.")
            return fallback_mode, None
    return output_mode, tqdm


def download_file(
    url: str,
    dest_path: str | Path,
    chunk_size: int = 8192,
    output_mode: ProgressOutputMode = ProgressOutputMode.NO_OUTPUT,
    progress_title: str = None,
    progress_leave: bool = False,
    cancel_token: Queue = None,
    use_session_queue: bool = False,
) -> bool:
    """
    Download a file from url and write to dest_path, with optional progress reporting.
    :param url: URL to download from.
    :param dest_path: Destination file to write to.
    :param chunk_size: Optional, Read data from url in chunks of chunk_size.
    :param output_mode: Control output mode.
    :param progress_title: Optional, if set this title will be used in the progress bar.
    :param progress_leave: Optional, if set to False the tqdm progress bar will be removed upon completion.
    :param cancel_token: Internal use only, if token contains data the download will be cancelled.
    :param use_session_queue: Internal use only, if True the function will attempt to fetch a session object from the session queue.
    """
    global _session_queue
    output_mode, tqdm = try_load_tqdm(output_mode)

    if not progress_title:
        progress_title = "Downloading"
    try:
        session = None
        if use_session_queue and _session_queue is not None:
            # Fetch an available session object from the session queue.
            session = _session_queue.get(timeout=60)
        else:
            session = httpx
        with httpx.stream("GET", url) as r:
            r.raise_for_status()

            # Get total file size from headers (Content-Length)
            total_size = int(r.headers.get("Content-Length", 0))
            downloaded_size = 0

            # Set up tqdm progress bar if needed
            if output_mode == ProgressOutputMode.TQDM_OUTPUT and total_size > 0:
                progress_bar = tqdm.tqdm(
                    total=total_size, unit_scale=True, desc=progress_title, leave=progress_leave
                )

            with open(dest_path, "wb") as f:
                for chunk in r.iter_bytes(chunk_size=chunk_size):
                    if chunk:  # Filter out keep-alive new chunks
                        f.write(chunk)
                        downloaded_size += len(chunk)

                        # Handle progress output
                        if total_size > 0:
                            if output_mode == ProgressOutputMode.LOGGING_OUTPUT:
                                progress = (downloaded_size / total_size) * 100
                                logger.info(f"{progress_title}: {progress:.2f}%", end="")
                            elif output_mode == ProgressOutputMode.TQDM_OUTPUT:
                                progress_bar.update(len(chunk))
                    if cancel_token and not cancel_token.empty():
                        progress_bar.close()
                        return False

            if output_mode == ProgressOutputMode.TQDM_OUTPUT and progress_bar:
                progress_bar.close()

        return True

    except httpx.RequestError as e:
        logger.error(f"Error downloading {url}: {e}")
        raise
    except IOError as e:
        logger.error(f"Error writing to {dest_path}: {e}")
        raise
    finally:
        if use_session_queue and _session_queue is not None and session is not None:
            # Return session to session queue for reuse by other worker threads.
            _session_queue.put(session)


def download_files(
    urls_and_paths: list[tuple[str, str]],
    chunk_size: int = 8192,
    progress_callback: Callable[[str, int, int], None] = None,
    output_mode: ProgressOutputMode = ProgressOutputMode.NO_OUTPUT,
    progress_leave: bool = True,
    urls_to_titles: dict[str, str] = {},
):
    """
    Download multiple files concurrently.

    :param urls_and_paths list[tuple[str, str]]: List of urls, destination path tuples.
    :param chunk_size int: Optional, Read data from url in chunks of chunk_size.
    :param progress_callback Callback[[str, int,int], None]: Optional progress callback,
        will be called when a file download completes with parameters
        (url_that_just_completed, completed_download_count, total_download_count).
    :param output_mode: Optional, set how download_files reports download progress.
    :param progress_leave: Optional, if set to False the tqdm progress bar will be removed upon completion.
    :param urls_to_titles: Optional, can be used to set progress bar titles for a given url.
    """
    global _session_queue
    # This queue object is shared between all download workers, if this queue is not empty then
    # download workers will interpret it as a signal to stop the download progress.
    cancel_token = Queue()
    max_workers = 3
    # Add to session queue for session reuse between worker threads.
    if _session_queue is None:
        _session_queue = Queue()
        for _ in range(max_workers):
            _session_queue.put(httpx.Client())

    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Submit tasks to executor.
        future_to_tup = {
            executor.submit(
                download_file,
                tup[0],  # Url
                tup[1],  # Dest path
                chunk_size,  # Download chunk_size.
                output_mode,  # Reporting mode
                urls_to_titles.get(tup[0], None),  # Progress bar title if available.
                progress_leave,
                cancel_token,
                True,  # Use session_queue.
            ): tup
            for tup in urls_and_paths
        }

        total_count = len(urls_and_paths)
        completed_count = 0
        # Retrieve results as they become available
        try:
            for future in concurrent.futures.as_completed(future_to_tup):
                url, _ = future_to_tup[future]
                future.result()
                completed_count += 1
                if progress_callback:
                    progress_callback(url, completed_count, total_count)
        except KeyboardInterrupt as e:
            # User cancelled progress.
            # Send cancel signal to workers via cancel_token queue since
            # executor does not support stopping in progress workers directly.
            cancel_token.put(1)
            # Cancel pending tasks and shutdown the ThreadPoolExecutor.
            executor.shutdown(wait=True, cancel_futures=True)
            logger.warning("Download interrupted by user")
            raise e
        except Exception as e:
            logger.error(f"Download from {url} failed", exc_info=e)
            raise e


def calculate_file_hash(file_path) -> str | None:
    """
    Calculate SHA256 hash of file.
    :returns: Hash or None if hashing fails or file is not found.
    """
    if file_path and Path(file_path).is_file():
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                # Read and update hash string value in blocks of 16 kilobytes
                for byte_block in iter(lambda: f.read(16384), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest()
        except:
            # Unable to hash file.
            return None
    # File not found.
    return None


class TTLCacheError(Exception):
    "Raised when the TTL input is 0 or less."

    pass


def ttl_cache(maxsize: int = 50, typed: bool = False, ttl: int = 10):
    """
    Wrapper around lru_cache with ttl support.
    :param maxsize: Max cache size, default 1 for ttl cache.
    :param typed: "If typed is set to true, function arguments of different types will be cached separately. If typed is false, the implementation will usually regard them as equivalent calls and only cache a single result."
    :param ttl: Cache time to live in seconds.
    """
    if ttl <= 0:
        raise TTLCacheError

    hash_gen = _ttl_hash_gen(ttl)

    def wrapper(func: Callable) -> Callable:
        @lru_cache(maxsize, typed)
        def ttl_func(ttl_hash, *args, **kwargs):
            return func(*args, **kwargs)

        def wrapped(*args, **kwargs) -> Any:
            th = next(hash_gen)
            return ttl_func(th, *args, **kwargs)

        return update_wrapper(wrapped, func)

    return wrapper


def _ttl_hash_gen(seconds: int):
    start_time = time.time()

    while True:
        yield math.floor((time.time() - start_time) / seconds)


def _atoi(text) -> bool:
    return int(text) if text.isdigit() else text


def natural_sort(data: list, attr_name: str = None):
    """
    Sort a list of string in a "human" way. Sorts list in-place.
    :param data: list to sort.
    :param attr_name: Attribute to sort by, if None then the method will assume data is a list of strings.
    """
    if attr_name:
        # Sort by attribute. Expects attribute to contain a string.
        data.sort(key=lambda x: [_atoi(c) for c in re.split(r"(\d+)", getattr(x, attr_name) or "")])
    else:
        # No attribute name provided, assume list of strings.
        data.sort(key=lambda x: [_atoi(c) for c in re.split(r"(\d+)", x)])


def get_status_url(environment: str):
    env = "sdk-dev"
    if environment == "staging":
        env = "sdk-staging"
    if environment == "prod":
        env = "sdk-prod"
    return f"https://ts.eu2.treble.tech/system?id={env}"


class MirroredMapping(dict):
    def __setitem__(self, key, value):
        # Remove any previous connections with these values
        if key in self:
            del self[key]
        if value in self:
            del self[value]
        dict.__setitem__(self, key, value)
        dict.__setitem__(self, value, key)

    def __delitem__(self, key):
        dict.__delitem__(self, self[key])
        dict.__delitem__(self, key)

    def __len__(self):
        """Returns the number of connections"""
        return dict.__len__(self) // 2
