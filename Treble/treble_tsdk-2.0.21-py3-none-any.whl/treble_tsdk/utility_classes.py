import math
import json
from dataclasses import dataclass
from enum import Enum

import numpy as np


@dataclass
class Point2d:
    x: float
    y: float

    def __post_init__(self):
        self.x = float(self.x)
        self.y = float(self.y)

    def __add__(self, other: "Point2d") -> "Point2d":
        return self.__class__(self.x + other.x, self.y + other.y)

    def __sub__(self, other: "Point2d") -> "Point2d":
        return self.__class__(self.x - other.x, self.y - other.y)

    def __str__(self) -> str:
        return f"({self.x}, {self.y})"

    def __iter__(self):
        return iter((self.x, self.y))  # Allows for * unpacking.

    def __getitem__(self, key):
        match key:
            case 0:
                return self.x
            case 1:
                return self.y
            case _:
                raise IndexError("Index out of range")

    def __eq__(self, other: "Point2d") -> bool:
        if not isinstance(other, Point2d):
            return NotImplemented
        return self.x == other.x and self.y == other.y

    def almost_equal(self, other: "Point2d", tolerance: float = 1e-9) -> bool:
        """
        Check equality with a small floating-point tolerance.
        """
        return abs(self.x - other.x) < tolerance and abs(self.y - other.y) < tolerance

    def euclidean_distance(self, other_point: "Point2d" = None) -> float:
        """
        Calculate euclidean distance to another point. If no other point is specified, calculate the distance to the origin.
        :param other_point: Another Point2d
        """
        # Use same function as Point3d, but do everything on xy plane.
        this_point = Point3d(self.x, self.y, 0)
        if other_point:
            other_point = Point3d(other_point.x, other_point.y, 0)
        return this_point.euclidean_distance(other_point)

    def to_list(self) -> list[float]:
        return [self.x, self.y]

    def to_dict(self) -> dict[str, float]:
        return {
            "x": self.x,
            "y": self.y,
        }

    @staticmethod
    def get_zero() -> "Point2d":
        return Point2d(0.0, 0.0)

    @staticmethod
    def from_list(lst: list[float]) -> "Point2d":
        if len(lst) != 2:
            raise ValueError("list must contain exactly two elements.")
        return Point2d(float(lst[0]), float(lst[1]))


@dataclass
class Vector2d(Point2d):
    pass


@dataclass
class Point3d:
    x: float
    y: float
    z: float

    def __post_init__(self):
        self.x = float(self.x)
        self.y = float(self.y)
        self.z = float(self.z)

    def __add__(self, other: "Point3d") -> "Point3d":
        return self.__class__(self.x + other.x, self.y + other.y, self.z + other.z)

    def __sub__(self, other: "Point3d") -> "Point3d":
        return self.__class__(self.x - other.x, self.y - other.y, self.z - other.z)

    def __str__(self) -> str:
        return f"({self.x}, {self.y}, {self.z})"

    def __iter__(self):
        return iter((self.x, self.y, self.z))  # Allows for * unpacking.

    def __getitem__(self, key):
        match key:
            case 0:
                return self.x
            case 1:
                return self.y
            case 2:
                return self.z
            case _:
                raise IndexError("Index out of range")

    def __eq__(self, other: "Point3d") -> bool:
        if not isinstance(other, Point3d):
            return NotImplemented
        return self.x == other.x and self.y == other.y and self.z == other.z

    def almost_equal(self, other: "Point3d", tolerance: float = 1e-9) -> bool:
        """
        Check equality with a small floating-point tolerance.
        """
        return (
            abs(self.x - other.x) < tolerance
            and abs(self.y - other.y) < tolerance
            and abs(self.z - other.z) < tolerance
        )

    def to_list(self) -> list[float]:
        return [self.x, self.y, self.z]

    def to_dict(self) -> dict[str, float]:
        return {
            "x": self.x,
            "y": self.y,
            "z": self.z,
        }

    def euclidean_distance(self, other_point: "Point3d" = None) -> float:
        """
        Calculate euclidean distance to another point. If no other point is specified, calculate the distance to the origin.
        :param other_point: Another Point3d
        """
        if other_point:
            vector = other_point - self
        else:
            vector = self
        return np.linalg.norm(vector.to_list())

    @staticmethod
    def from_list(lst: list[float]) -> "Point3d":
        if len(lst) != 3:
            raise ValueError("List must contain exactly three elements.")
        return Point3d(float(lst[0]), float(lst[1]), float(lst[2]))

    @staticmethod
    def get_zero() -> "Point3d":
        return Point3d(0.0, 0.0, 0.0)


@dataclass
class Vector3d(Point3d):
    pass


@dataclass
class Rotation:
    """
    Azimuth, elevation and roll in degrees.

    The orientation angles are defined as azimuth, elevation and roll and they represent the intrinsic
    rotation of the device around the Z axis, Y' axis and X'' axis, respectively.
    Intrinsic means that the coordinate system rotates with the applied rotation and the rotation
    is applied: 1. Azimuth, 2. Elevation, 3. Roll
    """

    azimuth: float = 0.0
    elevation: float = 0.0
    roll: float = 0.0

    def __post_init__(self):
        """
        Ensure that the angles are within the valid range.
        """
        if abs(self.azimuth) > 360:
            raise ValueError("Azimuth must be in the range [-360, 360].")
        if abs(self.elevation) > 90:
            raise ValueError("Elevation must be in the range [-90, 90].")
        if abs(self.roll) > 360:
            raise ValueError("Roll must be in the range [-360, 360].")
        self.azimuth = float(self.azimuth)
        self.elevation = float(self.elevation)
        self.roll = float(self.roll)

    def __eq__(self, other: "Rotation") -> bool:
        if not isinstance(other, Rotation):
            return NotImplemented
        return self.azimuth == other.azimuth and self.elevation == other.elevation and self.roll == other.roll

    def almost_equal(self, other: "Rotation", tolerance: float = 1e-9) -> bool:
        """
        Check equality with a small floating-point tolerance.
        """
        return (
            abs(self.azimuth - other.azimuth) < tolerance
            and abs(self.elevation - other.elevation) < tolerance
            and abs(self.roll - other.roll) < tolerance
        )

    def _to_radians(self, angle: float) -> float:
        return angle * math.pi / 180.0

    def has_roll(self):
        return abs(self.roll) > 0.0

    def to_dict(self) -> dict[str, float]:
        return {
            "azimuth": self.azimuth,
            "elevation": self.elevation,
            "roll": self.roll,
        }

    def to_array(self) -> np.ndarray:
        return np.array([self.azimuth, self.elevation, self.roll])

    def to_array_radians(self) -> np.ndarray:
        return np.array([self.azimuth_radians, self.elevation_radians, self.roll_radians])

    def array_counterclockwise_rotation(self) -> np.ndarray:
        return np.array([self.azimuth_radians, -self.elevation_radians, self.roll_radians])

    @property
    def azimuth_radians(self) -> float:
        return self._to_radians(self.azimuth)

    @property
    def elevation_radians(self) -> float:
        return self._to_radians(self.elevation)

    @property
    def roll_radians(self) -> float:
        return self._to_radians(self.roll)

    @property
    def colatitude(self) -> float:
        return 90 - self.elevation

    @property
    def colatitude_rad(self) -> float:
        return self._to_radians(self.colatitude)

    @staticmethod
    def get_zero() -> "Rotation":
        return Rotation(0.0, 0.0, 0.0)


@dataclass
class Transform3d:
    """
    A 3D transformation consisting of a translation and a rotation.
    """

    translation: Vector3d | Point3d | list[float]
    rotation: Rotation | list[float]

    def __post_init__(self):
        if isinstance(self.translation, list):
            self.translation = Point3d.from_list(self.translation)
        if isinstance(self.rotation, list):
            self.rotation = Rotation(*self.rotation)

    @property
    def x(self) -> float:
        return self.translation.x

    @property
    def y(self) -> float:
        return self.translation.y

    @property
    def z(self) -> float:
        return self.translation.z

    @property
    def azimuth(self) -> float:
        return self.rotation.azimuth

    @property
    def elevation(self) -> float:
        return self.rotation.elevation

    @property
    def roll(self) -> float:
        return self.rotation.roll

    @property
    def azimuth_radians(self) -> float:
        return self.to_radians(self.rotation.azimuth)

    @property
    def elevation_radians(self) -> float:
        return self.to_radians(self.rotation.elevation)

    @property
    def roll_radians(self) -> float:
        return self.to_radians(self.rotation.roll)

    def to_dict(self) -> dict[str, dict]:
        return {
            "translation": self.translation.to_dict(),
            "rotation": self.rotation.to_dict(),
        }

    def to_radians(self, angle: float) -> float:
        return angle * np.pi / 180

    @staticmethod
    def get_zero() -> "Transform3d":
        return Transform3d(Point3d.get_zero(), Rotation.get_zero())

    def to_array(self) -> np.ndarray:
        return np.array([self.azimuth, self.elevation, self.roll])

    def to_array_radians(self) -> np.ndarray:
        return np.array([self.azimuth_radians, self.elevation_radians, self.roll_radians])


@dataclass
class BoundingBox:
    """Contains the min and max coordinates for the bounding box of an object"""

    min: Point3d | list[float]
    max: Point3d | list[float]

    def __post_init__(self):
        if isinstance(self.min, list):
            self.min = Point3d.from_list(self.min)
        if isinstance(self.max, list):
            self.max = Point3d.from_list(self.max)

    def expand(self, dx: float = -1, dy: float = 0, dz: float = 0) -> "BoundingBox":
        """
        Expands the bounding box by the given values
        :returns: BoundingBox with min.x - dx, max.x + dx, min.y - dy, max.y + yd, min.z - dz, max.z + dz
        """
        return BoundingBox.from_points(
            self.min.x - dx,
            self.max.x + dx,
            self.min.y - dy,
            self.max.y + dy,
            self.min.z - dz,
            self.max.z + dz,
        )

    def point_in_box(self, p: Point3d) -> bool:
        """
        Checks if the point is inside the bounding box
        :returns: True if the point is inside the bounding box, False otherwise
        """
        return (
            self.min.x <= p.x <= self.max.x
            and self.min.y <= p.y <= self.max.y
            and self.min.z <= p.z <= self.max.z
        )

    def center(self) -> Point3d:
        """
        Returns the center of the bounding box
        :returns: list[float] with the center of the bounding box
        """
        return Point3d(
            (self.min.x + self.max.x) / 2, (self.min.y + self.max.y) / 2, (self.min.z + self.max.z) / 2
        )

    def get_corners(self) -> list[Point3d]:
        """
        Returns the 8 corners of the bounding box
        :returns: List of 8 tuples with the coordinates of the corners
        """
        return [
            Point3d(self.min.x, self.min.y, self.min.z),
            Point3d(self.min.x, self.min.y, self.max.z),
            Point3d(self.min.x, self.max.y, self.min.z),
            Point3d(self.min.x, self.max.y, self.max.z),
            Point3d(self.max.x, self.min.y, self.min.z),
            Point3d(self.max.x, self.min.y, self.max.z),
            Point3d(self.max.x, self.max.y, self.min.z),
            Point3d(self.max.x, self.max.y, self.max.z),
        ]

    def is_inside_sphere(self, center: Point3d, radius: float) -> bool:
        """
        Check if the bounding box is inside a sphere.
        :param center: Center of sphere
        :param radius: Radius of sphere
        :returns: True if the bounding box is inside the sphere, False otherwise
        """

        def distance(p: Point3d) -> float:
            distance_squared = (p.x - center.x) ** 2 + (p.y - center.y) ** 2 + (p.z - center.z) ** 2
            return math.sqrt(distance_squared)

        return all(distance(corner) <= radius for corner in self.get_corners())

    def contains(self, other: "BoundingBox") -> bool:
        """
        Checks if another bounding box is fully contained within this box.
        """
        return (
            self.min.x <= other.min.x
            and self.max.x >= other.max.x
            and self.min.y <= other.min.y
            and self.max.y >= other.max.y
            and self.min.z <= other.min.z
            and self.max.z >= other.max.z
        )

    @staticmethod
    def from_json_str(json_data: str) -> "BoundingBox":
        json_data = json.loads(json_data)
        return BoundingBox(Point3d(**json_data["min"]), Point3d(**json_data["max"]))

    def to_point_list(self) -> list[Point3d]:
        return [
            self.min.x,
            self.max.x,
            self.min.y,
            self.max.y,
            self.min.z,
            self.max.z,
        ]

    @staticmethod
    def from_points(xmin, xmax, ymin, ymax, zmin, zmax):
        return BoundingBox(Point3d(xmin, ymin, zmin), Point3d(xmax, ymax, zmax))


class View2d(str, Enum):
    xy = "xy"
    xz = "xz"
    yz = "yz"
