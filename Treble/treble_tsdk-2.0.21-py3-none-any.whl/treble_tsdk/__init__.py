from importlib.metadata import version
import importlib
from treble_tsdk.treble_logging import logger
import os

try:
    # Get version information from installed package.
    __version__ = version("treble-tsdk")
except:
    # If unable to get version set as 0.0.0.
    __version__ = "0.0.0"

try:
    if "TSDK_USE_TRUSTSTORE" in os.environ and os.environ.get("TSDK_USE_TRUSTSTORE") == "1":
        truststore = importlib.import_module("truststore")
        truststore.inject_into_ssl()
except Exception as e:
    logger.info("Unable to load truststore module!")
    logger.debug("Exception while loading truststore", exc_info=e)
